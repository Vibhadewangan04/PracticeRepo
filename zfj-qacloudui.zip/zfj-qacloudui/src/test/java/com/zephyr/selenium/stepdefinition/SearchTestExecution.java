package com.zephyr.selenium.stepdefinition;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.zephyr.selenium.pageobject.CreateIssuePage;
import com.zephyr.selenium.pageobject.ExecuteTestPage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.pageobject.PlanTestCyclePage;
import com.zephyr.selenium.pageobject.SearchTestExecutionPage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;

import cucumber.api.java.en.*;

public class SearchTestExecution extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	SearchTestExecutionPage ste;
	PlanTestCyclePage ptcp;
	CreateIssuePage cip;
	ExecuteTestPage etp;
	PlanTestCycle PTC;
	String Test;
	String Bug;
	String Test1;
	String CycleName;
	String NewCycleName;
	
	String fileName = "SearchTestExecution";

	@Given("^Launch and Click on Predefined All Unexecuted Tests filter in Search Test Execution$")
	/*public void launch_and_Click_on_Predefined_All_Unexecuted_Tests_filter_in_Search_Test_Execution() throws Throwable {
		
		ste = new SearchTestExecutionPage(driver);
		bp = new CommonUtils();
		ste.clickonTestAndSearchTestExecution();
		boolean predefinedFilterSearch = ste.predefinedFilterSearch();
		
		if (predefinedFilterSearch == true)
		{
			System.out.println("Retrieved predefinedFilterSearch cases sucessfully");
		}
		
	}*/
	
	//@Then("^Export in all format\\(CSV/HTML/XML\\)$")
	/*public void export_in_all_format_CSV_HTML_XML() throws Throwable {
		bp = new CommonUtils();
		ste= new SearchTestExecutionPage(driver);
		
		ste.clickonTestAndSearchTestExecution();
		
		String xmlFormatExportType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE_TPE, "xmlFormat");
		
		ste.exportInDifferentFormat(xmlFormatExportType);
		
		bp.waitForElement();
		String csvFormatExportType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE_TPE, "csvFormat");
		
		ste.exportInDifferentFormat(csvFormatExportType);
		bp.waitForElement();
		String htmlFormatExportType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE_TPE, "htmlFormat");
		
		ste.exportInDifferentFormat(htmlFormatExportType);
		bp.waitForElement();
	}*/

	@Then("^Search With the different Status$")
	public void search_With_the_different_Status() throws Throwable {

		ste = new SearchTestExecutionPage(driver);
		bp = new CommonUtils();
		ste.clickonTestAndSearchTestExecution();
		String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String PASS = "PASS";
		boolean pass = ste.advancedSearch(Pname,PASS);
		
		if (pass == true)
		{
			System.out.println("pass cases sucessfully");
		}
		
		String FAIL = "FAIL";
		boolean fail = ste.advancedSearch(Pname,FAIL);
		
		if (fail == true)
		{
			System.out.println("fail cases sucessfully");
		}
		
		String WIP = "WIP";
		boolean wip = ste.advancedSearch(Pname,WIP);
		
		if (wip == true)
		{
			System.out.println("wip cases sucessfully");
		}
		
		String BLOCKED = "BLOCKED";
		boolean blocked = ste.advancedSearch(Pname,BLOCKED);
		
		if (blocked == true)
		{
			System.out.println("blocked cases sucessfully");
		}
				
		String UNEXECUTED = "UNEXECUTED";
		boolean unexecuted = ste.advancedSearch(Pname,UNEXECUTED);
		
		if (unexecuted == true)
		{
			System.out.println("unexecuted cases sucessfully");
		}
		
	}

	@Given("^User Navigates to ProjECT$")
	public void user_Navigates_to_ProjECT() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}
	
	@When("^User Clicks on Cycle Summary Page and ValIdate the page$")
	public void user_Clicks_on_Cycle_Summary_Page_and_ValIdate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User Creates New Cycle and Verifies thE Created Cycle$")
	public void user_Creates_New_Cycle_and_Verifies_thE_Created_Cycle() throws Throwable {
		try{
		/*	ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			String CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");*/
			
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User adds a test to the Test CyclE individually$")
	public void user_adds_a_test_to_the_Test_CyclE_individually() throws Throwable {
		try{
			
			/*ptcp = new PlanTestCyclePage(driver);
			
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");*/
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User clicks on STE page and directly execute a test in Execution Navigator$")
	public void user_clicks_on_STE_page_and_directly_execute_a_test_in_Execution_Navigator() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			ste = new SearchTestExecutionPage(driver);
			
			driver.switchTo().defaultContent();
			System.out.println("Out of Iframe");
			ste.launchSTEPage();
			ste.executeSingleExecution();
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	

	@Given("^User Navigates to ProjecT$")
	public void user_Navigates_to_ProjecT() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User ClicKs on Cycle SummarY Page and Validate the page$")
	public void user_ClicKs_on_Cycle_SummarY_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User CreatEs New CyclE and Verifies the Created Cycle$")
	public void user_CreatEs_New_CyclE_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			/*	ptcp = new PlanTestCyclePage(driver);
				String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
				String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
				String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
				String CycleName = cyclename+timestamp;
				String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
				String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
				String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
				String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
				String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOneID");
				ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
				ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
				log.info("New Cycle Created and Validated Successfully");*/
				
				 			    
				}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName);
					e.printStackTrace();
					
					driver.close();
					throw e;
					}
	}

	@When("^User addS a test tO the Test Cycle individually$")
	public void user_addS_a_test_tO_the_Test_Cycle_individually() throws Throwable {
try{
			
			/*ptcp = new PlanTestCyclePage(driver);
			
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");*/
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User clicks on STE page and Delete test executions in Bulk \\((\\d+) or more\\)$")
	public void user_clicks_on_STE_page_and_Delete_test_executions_in_Bulk_or_more(int arg1) throws Throwable {
try{
			
			ptcp = new PlanTestCyclePage(driver);
			ste = new SearchTestExecutionPage(driver);
			
			driver.switchTo().defaultContent();
			System.out.println("Out of Iframe");
			ste.launchSTEPage();
			ste.bulkDelete();
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

/*
	Scenario: Bulk change status on test executions with Test steps
	*/
	
	@Given("^User Navigates to ProJect$")
	public void user_Navigates_to_ProJect() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User ClicKs on Cycle SUmmary Page and Validate the page$")
	public void user_ClicKs_on_Cycle_SUmmary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User CreatEs New Cycle aNd Verifies the Created Cycle$")
	public void user_CreatEs_New_Cycle_aNd_Verifies_the_Created_Cycle() throws Throwable {
		try{
				ptcp = new PlanTestCyclePage(driver);
				String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
				String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
				String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
				String CycleName = cyclename+timestamp;
				String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
				String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
				String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
				String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
				String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOneID");
				ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
				ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
				log.info("New Cycle Created and Validated Successfully");
				
				 			    
				}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName);
					e.printStackTrace();
					
					driver.close();
					throw e;
					}
	}

	@When("^User addS a test to the TEst Cycle individually$")
	public void user_addS_a_test_to_the_TEst_Cycle_individually() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	

	@Then("^User clicks on STE page and Bulk change status on test executions with Test steps$")
	public void user_clicks_on_STE_page_and_Bulk_change_status_on_test_executions_with_Test_steps() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			ste = new SearchTestExecutionPage(driver);
			
			driver.switchTo().defaultContent();
			System.out.println("Out of Iframe");
			ste.launchSTEPage();
			ste.bulkExecuteStatus();
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	/*
	Scenario: Export test executions from Execution Navigator (Export in all 3 format)
	*/
	
	@Given("^User Navigates to ProjECt$")
	public void user_Navigates_to_ProjECt() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User ClicKs on Cycle Summary PaGE and Validate the page$")
	public void user_ClicKs_on_Cycle_Summary_PaGE_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User CreatEs New Cycle and VerifIEs the Created Cycle$")
	public void user_CreatEs_New_Cycle_and_VerifIEs_the_Created_Cycle() throws Throwable {
		try{
				ptcp = new PlanTestCyclePage(driver);
				String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
				String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
				String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
				String CycleName = cyclename+timestamp;
				String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
				String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
				String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
				String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
				String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOneID");
				ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
				ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
				log.info("New Cycle Created and Validated Successfully");
				
				 			    
				}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName);
					e.printStackTrace();
					
					driver.close();
					throw e;
					}
	}

	@When("^User addS a test to the Test CycLE individually$")
	public void user_addS_a_test_to_the_Test_CycLE_individually() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User clicks on STE page and Export test executions from Execution Navigator$")
	public void user_clicks_on_STE_page_and_Export_test_executions_from_Execution_Navigator() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			ste = new SearchTestExecutionPage(driver);
			
			driver.switchTo().defaultContent();
			System.out.println("Out of Iframe");
			ste.launchSTEPage();
			String xmlFormatExportType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE_TPE, "XML");
			
			ste.exportInAllFormat(xmlFormatExportType);
						 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Given("^User NavigatEs to Project$")
	public void user_NavigatEs_to_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User ClicKS on Cycle Summary Page and Validate the page$")
	public void user_ClicKS_on_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User CreatES New Cycle and Verifies the Created Cycle$")
	public void user_CreatES_New_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
				ptcp = new PlanTestCyclePage(driver);
				String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
				String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
				String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
				String CycleName = cyclename+timestamp;
				String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
				String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
				String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
				String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
				String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOneID");
				ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
				ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
				log.info("New Cycle Created and Validated Successfully");
				
				 			    
				}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName);
					e.printStackTrace();
					
					driver.close();
					throw e;
					}
	}

	@When("^User adDS a test to the Test Cycle individually$")
	public void user_adDS_a_test_to_the_Test_Cycle_individually() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User clicks on STE page and Bulk assignee to executions to current logged-in user$")
	public void user_clicks_on_STE_page_and_Bulk_assignee_to_executions_to_current_logged_in_user() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			ste = new SearchTestExecutionPage(driver);
			
			driver.switchTo().defaultContent();
			System.out.println("Out of Iframe");
			ste.launchSTEPage();
			ste.bulkAssignToLoggedInUser();
			
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}


////////////////////////
	
//Predefined filter///////////////////

      @Given("^Navigate to created project page\\(predefined filter\\)$")
      public void navigate_to_created_project_page_predefined_filter() throws Throwable {
       try{
           ptcp = new PlanTestCyclePage(driver);
           cip = new CreateIssuePage(driver);

           String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");

           ptcp.navigateToProject(Pname);
            log.info("Project Selected Successfully");
       }
       catch (Exception e) {
       lb.getScreenShot(fileName);
       e.printStackTrace();

       throw e;
}
}

      @When("^User navigate to STE page \\(predefined filter\\)$")
      public void user_navigate_to_STE_page_predefined_filter() throws Throwable {
       try {
            ste = new SearchTestExecutionPage(driver);
            ste.launchSTEPage();
            System.out.println("Navigate to SearchTestExecution successfull");
            driver.switchTo().defaultContent();
           System.out.println("Swtch to default frame");
 }
     catch (Exception e) {
     lb.getScreenShot(fileName);
     e.printStackTrace();
     throw e;
}
}

      @Then("^run predefined filter$")
      public void run_predefined_filter() throws Throwable {
      try {
          ste = new SearchTestExecutionPage(driver);
          ste.predefinedFilterSearch();
          log.info("Run predefined filter successfully");
        //switch to default content
 		 
 		 driver.switchTo().defaultContent();


    }
       catch (Exception e) {
       e.printStackTrace();

       //driver.close();
        throw e;
}

}

//completed/////////
      
    //Should able to execute a Test using [E] button in Execution Navigator
  	
  	@Given("^Navigate to created project page\\(E\\)$")
  	public void navigate_to_created_project_page_E() throws Throwable {
  		try{
  			ptcp = new PlanTestCyclePage(driver);
  			cip = new CreateIssuePage(driver);
  		
  			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
  			
  			ptcp.navigateToProject(Pname);
  			log.info("Project Selected Successfully");
  		}
  		catch (Exception e) {
  			lb.getScreenShot(fileName);
  			e.printStackTrace();
  			
  			throw e;
  			}
  	}

  	@When("^User navigate to STE page and click on E button$")
  	public void user_navigate_to_STE_page_and_click_on_E_button() throws Throwable {
  		 try {
  		    	ste = new SearchTestExecutionPage(driver);
  		    	ste.launchSTEPage();
  		    	System.out.println("Navigate to SearchTestExecution successfull");
  		    	driver.switchTo().defaultContent();
  		    	System.out.println("Swtch to default frame");
  		    	ste.navigate_to_executepage();
  		    	System.out.println("Click on E button from STE is success");
  		    	log.info("Navigate to Execute page Successfully");
  		    }
  		    catch (Exception e) {
  				lb.getScreenShot(fileName);
  				e.printStackTrace();
  				throw e;
  				}
  	    
  	}

  	@Then("^user execute the test in execute page$")
  	public void user_execute_the_test_in_execute_page() throws Throwable {
  		try {
  		ste = new SearchTestExecutionPage(driver);
  		etp=new ExecuteTestPage(driver);
  		etp.executeTest();
  	   log.info("Execution is executed Successfully");
  	//switch to default content
		 
		 driver.switchTo().defaultContent();

  		}
  		 catch (Exception e) {
	     lb.getScreenShot(fileName);
	     e.printStackTrace();
		 throw e;
				}
  	}
  	
  	
  	////completed///
  	
  	//Able to Execute Test and Steps in Search Execution Details View
  	
  	@Given("^Navigate to created project page and test steps$")
  	public void navigate_to_created_project_page_and_test_steps() throws Throwable {
  		try {
  			ste = new SearchTestExecutionPage(driver);
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   //
			etp.addsteptoTest(Test);
			ptcp.navigateToProject(project);
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
  	}

  	@When("^User Creates New Cycle and add test to cycle \\(detail view\\)$")
  	public void user_Creates_New_Cycle_and_add_test_to_cycle_detail_view() throws Throwable {
  		try {
  			ste = new SearchTestExecutionPage(driver);
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			System.out.println("Add test to cycle is successfull");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
  	}

  	@And("^User navigate to STE from cycle deeplink$")
  	public void user_navigate_to_STE_from_cycle_deeplink() throws Throwable {
  		try {
  			ste = new SearchTestExecutionPage(driver);
  			ste.navigateSTEfromptc();
  			log.info("Navigate to STE page successfull");
  		}
  		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
  	}

  	@Then("^User navigate Ste detail view and execute it$")
  	public void user_navigate_Ste_detail_view_and_execute_it() throws Throwable {
  	    try {
  	    	ste = new SearchTestExecutionPage(driver);
  	    	etp = new ExecuteTestPage(driver);
  	    	ste.navigatedetailview();
  	    	log.info("Navigate to ste detil view successfull");
  	    	
  	    	driver.switchTo().defaultContent();
  	    	
  	    	etp.executeTest();
  	    	log.info("Execute The execution successfull");
  	    	
  	    	driver.switchTo().defaultContent();
  	    	String status = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "status");
  	    	etp.executeTestStep(status);
  	    	log.info("Execute the step successfull");
  	    	
  	    //switch to default content
  			 
  			 driver.switchTo().defaultContent();

  	    }
  	  catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
  	}



}