package com.zephyr.selenium.pageobject;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;

import java.util.NoSuchElementException;

import javax.swing.Action;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class CreateZephyrTestPage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	ViewIssuePage vip;

	public CreateZephyrTestPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
		
	@FindBy(xpath = "//*[@id='opsbar-operations_more']")
	protected WebElement moreOptions;
	
	@FindBy(xpath = "//*[text()='Jira settings']")
	protected WebElement jiraSettings;
	
	@FindBy(xpath = "(//*[text()='Apps'])[1]")
	protected WebElement apps;
	
	@FindBy(xpath = "(//*[text()='General Configuration'])[1]")
	protected WebElement generalConfiguration;
	
	@FindBy(xpath = "//*[@id='create-zephyr-test-dropdown']")
	protected WebElement selectionOption;
	
	@FindBy(xpath ="//*[@id='create-zephyr-test-save']")
	protected WebElement savePreference;
	
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	protected WebElement productLogo;
	
	@FindBy(xpath ="(//*[@type='button'])[1]")
	protected WebElement expand1;
	
	@FindBy(xpath = "//*[@selected='selected' and @value='10002']")
	protected WebElement taskSelected;
	
	@FindBy(xpath = "//*[text()='Story']")
	protected WebElement story;
	
	//
	
	
	@FindBy(xpath = "//*[@id='createGlobalItem']")
	protected WebElement test;

	@FindBy(xpath = "(//*[text()='Create a Test'])")
	protected WebElement createTest;
	
	@FindBy(xpath = "(//*[@id='project-field'])")
	protected WebElement projectDropDown;
	
	@FindBy(xpath = "(//*[@id='issuetype-field'])")
	protected WebElement issueTypeFiledDropDown;
	
	@FindBy(xpath = "(//*[@id='summary'])")
	public WebElement summary;
	
	@FindBy(xpath = "(//input[@placeholder='What needs to be done?'])")
	public WebElement subtask_summary;

	@FindBy(xpath = "(//*[@id='create-issue-submit'])")
	public WebElement submit;
	
	@FindBy(xpath = "(//a[text()='Cancel'])")
	public WebElement cancel;
	
	@FindBy(xpath = "(//*[@class='qf-create-another']/input[1])")
	public WebElement createAnotherCheckbox;
	
	@FindBy(xpath = "(//button[@type='button'])")
	public WebElement expand;
	
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
    protected WebElement productLogoGlobalItem;
	
	@FindBy(xpath = "//*[text()='Search Tests']")
	protected WebElement searchTest;
	
	@FindBy(xpath ="//*[@id='layout-switcher-button']")
	protected WebElement switchLayout;
	
	@FindBy(xpath = "//*[text()='List View']")
	protected WebElement listView;
	
	@FindBy(xpath= "//*[text()='Detail View']")
	protected WebElement detailView;
	
	@FindBy(xpath = "//*[@id='customfield_10011']")
	protected WebElement epicName;
	
	//
	
	@FindBy(xpath = "//*[text()='Tests']")
	protected WebElement testmenu;
	
	@FindBy(xpath = "(//*[@data-id='issuetype'])[1]")
	protected WebElement issuetypedropdown;

	@FindBy(xpath="(//*[@class='check-list-item'])[1]")
	protected WebElement checkbox;
	
	@FindBy(xpath="(//span[@aria-label='Actions'])")
	protected WebElement contextmenu;
	
	@FindBy(xpath = "//*[@class='icon aui-icon aui-icon-small aui-iconfont-more']")
	protected WebElement menu;
	
	////*[text()='Create Zephyr Test']
	@FindBy(xpath="//*[text()='Create Zephyr Test']")
	protected WebElement createtestoption;
	
	@FindBy(xpath ="//*[text()='Switch to Basic']")
	protected WebElement basicSearch;
	
	
	@FindBy(xpath="//*[text()='Test_for_SubTask']")
	protected WebElement testSummary;
	
	@FindBy(xpath="//span[@aria-label='Create subtask']")
	protected WebElement subtaskOption;
	
	//(//*[@class='issue-link'])[2] or below one
	@FindBy(xpath="//*[text()='SubTask_Summary']")
	protected WebElement subTask;
	
	@FindBy(xpath ="//*[@id='layout-switcher-button']")
	protected WebElement switchlayoutOption;
	
	@FindBy(xpath = "//*[text()='List View']")
	protected WebElement listViewOption;

	@FindBy(xpath="//*[@class='icon aui-icon aui-icon-small aui-iconfont-more']")
	protected WebElement contextforSubtask;
	
	@FindBy(xpath="(//*[@class='sc-EHOje gxnAhk'])[2]")
	protected WebElement menuOption;
	
	
	@FindBy(xpath="//*[text()='Story']")
	protected WebElement storyOption;
	
	@FindBy(xpath="//*[text()='Bug']")
	protected WebElement bugOption;
	
	@FindBy(xpath="//*[text()='Task']")
	protected WebElement taskOption;
	
	@FindBy(xpath="//*[text()='Epic']")
	protected WebElement epicOption;
	
	@FindBy(xpath="//*[text()='Sub-task']")
	protected WebElement subTaskOption;
	
	@FindBy(xpath="(//*[@class='ItemParts__Content-sc-14xek3m-5 jRBaLt'])[3]")
	protected WebElement createzeTest;
	
	@FindBy(xpath="(//*[@class='check-list-item'])[2]")
	protected WebElement subtaskCB;
	
	
	//a[@class='switcher-item active ']
	@FindBy(xpath="//a[@class='switcher-item active ']")
	protected WebElement SwitchToZql;
	
	/******************************* String protected *******************************/
	protected String role;

	/*
	 * **************************************************** Method Name :
	 * enterUname(String userName) Purpose : To enter Username Author : OPAL1
	 * Date Created : 27/07/17 Date Modified : Reviewed By : Opal4
	 * ******************************************************
	 */
	
	
	
	
	public boolean createStory(String project, String issue, String Story) throws Exception {
		try {
			bp = new CommonUtils();
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			bp.waitForElement();
			Thread.sleep(5000);
			test.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			Thread.sleep(2000);
			summary.sendKeys(Story);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean createBug(String project, String issue, String Bug) throws Exception {
		try {
			bp = new CommonUtils();
			Thread.sleep(5000);
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			bp.waitForElement();
			test.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			Thread.sleep(2000);
			summary.sendKeys(Bug);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean createTask(String project, String issue, String Task) throws Exception {
		try {
			bp = new CommonUtils();
			Thread.sleep(5000);
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			bp.waitForElement();
			test.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			Thread.sleep(2000);
			summary.sendKeys(Task);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean createEpic(String project, String issue, String Epic) throws Exception {
		try {
			bp = new CommonUtils();
			Thread.sleep(5000);
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			bp.waitForElement();
			test.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			Thread.sleep(2000);
			//epicName.click();
			epicName.sendKeys("Epic name");
			epicName.sendKeys(Keys.ENTER);
			
			Thread.sleep(2000);
			summary.sendKeys(Epic);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean createSubTask(String project, String issue) throws Exception {
		try {
			bp = new CommonUtils();
			Thread.sleep(5000);
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			bp.waitForElement();
			test.click();
			bp.waitForElement();
			//First create test
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(2000);
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			Thread.sleep(2000);
			summary.sendKeys("Test_for_SubTask");
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			//System.out.println("Test  created successfully");
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			
			bp.waitForElement();
			switchlayoutOption.click();
			listViewOption.click();
			bp.waitForElement();
			System.out.println("Navigate to List view in view issue page");
			//for subtask
			testSummary.click();
			bp.waitForElement();
			bp.waitForElement();
			System.out.println("Test in view issue page");
			
			//contextforSubtask.click();
			bp.waitForElement();
			subtaskOption.click();
			
			bp.waitForElement();
			subtask_summary.sendKeys("SubTask_Summary");
			bp.waitForElement();
			subtask_summary.sendKeys(Keys.ENTER);
			bp.waitForElement();
			System.out.println("Subtask is created Successfully");
			Thread.sleep(5000);
			
		vip.goToSearchTest();
		Thread.sleep(5000);
		switchLayout.click();
		detailView.click();
		Thread.sleep(2000);
		issuetypedropdown.click();
		Thread.sleep(2000);
			subtaskCB.click();
			//subTask.click();
			//issuetypedropdown.click();
			bp.waitForElement();
			
			Thread.sleep(5000);
			
			//menuOption.click();
			/*String expectedoption="Create Zephyr Test";
			String actualoption=createtestoption.getText();
			assertEquals(expectedoption,actualoption);
			System.out.println("Create Zephyr Test option is present");*/
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	}
	
	
	public boolean createSubTask_for_deselect(String project, String issue) throws Exception {
		try {
			bp = new CommonUtils();
			Thread.sleep(5000);
			bp.waitForElement();
			test.click();
			bp.waitForElement();
			//First create test
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(2000);
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			Thread.sleep(2000);
			summary.sendKeys("Test_for_SubTask");
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			System.out.println("Test  created successfully");
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			
			bp.waitForElement();
			switchlayoutOption.click();
			listViewOption.click();
			bp.waitForElement();
			System.out.println("Navigate to List view in view issue page");
			//for subtask
			testSummary.click();
			bp.waitForElement();
			bp.waitForElement();
			System.out.println("Test in view issue page");
			
			//contextforSubtask.click();
			bp.waitForElement();
			subtaskOption.click();
			
			bp.waitForElement();
			summary.sendKeys("SubTask_Summary");
			summary.sendKeys(Keys.ENTER);
			bp.waitForElement();
			System.out.println("Subtask is created Successfully");
			Thread.sleep(5000);
			/*subTask.click();
			bp.waitForElement();
			Thread.sleep(5000);*/
			vip.goToSearchTest();
			Thread.sleep(5000);
			switchLayout.click();
			detailView.click();
			//listView.click();
			Thread.sleep(2000);
			issuetypedropdown.click();
			Thread.sleep(2000);
				subtaskCB.click();
				//subTask.click();
				//issuetypedropdown.click();
			
			//menuOption.click();
				contextmenu.click();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	}
	
	
public boolean create_test_from_story(String project, String issue,String Test) throws Throwable{
		
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			
			contextmenu.click();
			Thread.sleep(2000);
			createtestoption.click();
			//create test
            bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys(Test);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
		
		return true;
	
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
	}
}
	
	
	public boolean create_test_from_bug(String project, String issue,String Test) throws Throwable{
	
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		
		contextmenu.click();
		Thread.sleep(2000);
		createtestoption.click();
		//create test
        bp.waitForElement();
		
		projectDropDown.sendKeys(project);
		projectDropDown.sendKeys(Keys.ENTER);
			
		bp.waitForElement();
		
		issueTypeFiledDropDown.sendKeys(issue);
		issueTypeFiledDropDown.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
		
		summary.sendKeys(Test);
		summary.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
	
	
		
	
	return true;

	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
}
}

public boolean create_test_from_task(String project, String issue,String Test) throws Throwable{
	
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		
		contextmenu.click();
		Thread.sleep(2000);
		createtestoption.click();
		//create test
        bp.waitForElement();
        Thread.sleep(2000);
		projectDropDown.sendKeys(project);
		projectDropDown.sendKeys(Keys.ENTER);
			
		bp.waitForElement();
		Thread.sleep(2000);
		issueTypeFiledDropDown.sendKeys(issue);
		issueTypeFiledDropDown.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
		Thread.sleep(2000);
		summary.sendKeys(Test);
		summary.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
	
	
		
	
	return true;

	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
}
}


public boolean create_test_from_epic(String project, String issue,String Test) throws Throwable{
	
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		
		contextmenu.click();
		Thread.sleep(2000);
		createtestoption.click();
		//create test
        bp.waitForElement();
		
		projectDropDown.sendKeys(project);
		projectDropDown.sendKeys(Keys.ENTER);
			
		bp.waitForElement();
		Thread.sleep(2000);
		issueTypeFiledDropDown.sendKeys(issue);
		issueTypeFiledDropDown.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
		Thread.sleep(2000);
		summary.sendKeys(Test);
		summary.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
	
	
		
	
	return true;

	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
}
}


public boolean create_test_from_subtask(String project, String issue) throws Throwable{
	
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		
		/*menuOption.click();
		Thread.sleep(7000);*/
		//createtestoption.click();
		
		/*WebElement element=driver.findElement(By.linkText("Create Zephyr Test"));
		Thread.sleep(7000);
		element.click();*/
		
		contextmenu.click();
		Thread.sleep(2000);
		createtestoption.click();
		//create test
      //  bp.waitForElement();
		//create test
       // bp.waitForElement();
        Thread.sleep(2000);
		
		projectDropDown.sendKeys(project);
		projectDropDown.sendKeys(Keys.ENTER);
			
		bp.waitForElement();
		Thread.sleep(2000);
		issueTypeFiledDropDown.sendKeys(issue);
		issueTypeFiledDropDown.sendKeys(Keys.ENTER);
		Thread.sleep(2000);
		bp.waitForElement();
		
		summary.sendKeys("Test created from subtask");
		summary.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
	
	
		
	
	return true;

	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
}
}

	
	public boolean validateCreateZephyrTestOption() throws Throwable{
	
		try {
				bp = new CommonUtils();
				bp.waitForElement();
				bp.waitForElement();
		
				//menu.click();
				contextmenu.click();
				
				System.out.println("Clicked on context path");
				//String actual = "Create Zephyr Test";
				//WebElement element = driver.findElement(By.xpath("//Span[text()='Create Zephyr Test']"));
				//WebElement elemnt=driver.findElement(By.linkText("Create Zephyr Test"));
				WebElement element=driver.findElement(By.linkText("Create Zephyr Test"));
				
				
				if(element.isDisplayed()==true)
				{
					System.out.println("Create Zephyr Test found ");
				}
				else
				{
					System.out.println("Create Zephyr Test not found ");
				}
				
				
				return true;

		}
		catch (Exception e) {
			System.out.println("Create Zephyr Test not found");
			
			
		}
		return false;
		
	}


	
	public boolean validateCreateZephyrTestOption_in_subtask() throws Throwable{
		
		try {
				bp = new CommonUtils();
				bp.waitForElement();
				bp.waitForElement();
		
				//menuOption.click();
				contextmenu.click();
				
				System.out.println("Clicked on context path");
				//String actual = "Create Zephyr Test";
				//WebElement element = driver.findElement(By.xpath("//Span[text()='Create Zephyr Test']"));
				//WebElement elemnt=driver.findElement(By.linkText("Create Zephyr Test"));
				WebElement element=driver.findElement(By.linkText("Create Zephyr Test"));
				
				
				if(element.isDisplayed()==true)
				{
					System.out.println("Create Zephyr Test found ");
				}
				else
				{
					System.out.println("Create Zephyr Test not found ");
				}
				
				
				return true;

		}
		catch (Exception e) {
			System.out.println("Create Zephyr Test not found");
			
			
		}
		return false;
		
	}

	
	
	
	
	public boolean selectIssuetype_from_Dropdown() throws Throwable {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			/*SwitchToZql.click();
			System.out.println("Clicked on SwitchToZql");
		
			if(basicSearch.isDisplayed()) {
			basicSearch.click();*/
			
			
			if(SwitchToZql.isDisplayed()) {
				SwitchToZql.click();
			
			bp.waitForElement();
			Thread.sleep(2000);
			issuetypedropdown.click();
			bp.waitForElement();
			checkbox.click();
			Thread.sleep(2000);
			
			issuetypedropdown.click();
			}else {
				Thread.sleep(2000);
				issuetypedropdown.click();
				bp.waitForElement();
				checkbox.click();
				issuetypedropdown.click();
			}
			return true;
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean verify_CreateZephyrTest_option() throws Throwable {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			contextmenu.click();
			System.out.println();
			String expectedoption="Create Zephyr Test";
			String actualoption=createtestoption.getText();
			assertEquals(expectedoption,actualoption);
			System.out.println("Create Zephyr Test option is present");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	}

	
	

	
	public boolean navigateToGeneralConfiguration() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			bp.waitForElement();
			
//			if(expand1.isDisplayed())
//			{
//				expand1.click();
//			}
			
			productLogo.click();
			bp.waitForElement();
				
			
			jiraSettings.click();
			bp.waitForElement();
			
			apps.click();
			bp.waitForElement();
			
			generalConfiguration.click();
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}

	
	public boolean selectStory() throws Exception {
		try {
			
			WebElement test = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(test);
			
			System.out.println("switched to frame");
			
			Select story = new Select(selectionOption);
			
			
			Thread.sleep(2000);
			story.selectByVisibleText("Story");		
			/*bp.waitForElement();
			bp.waitForElement();*/
			Thread.sleep(2000);
			
			System.out.println("story selected");
			
			savePreference.click();
			/*bp.waitForElement();*/
			Thread.sleep(2000);
			
			System.out.println("Story preference saved successfully");
			
			driver.switchTo().defaultContent();
			/*bp.waitForElement();*/
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
		public boolean selectTask() throws Exception {
			try {
				
				WebElement test = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(test);
				
				System.out.println("switched to frame");
				
				Select task = new Select(selectionOption);
				
					task.selectByVisibleText("Task");		
					/*bp.waitForElement();
					bp.waitForElement();
					*/
					Thread.sleep(2000);
					savePreference.click();
					//bp.waitForElement();
					Thread.sleep(2000);
									
				
				System.out.println("task preference saved successfully");
				
				driver.switchTo().defaultContent();
				/*bp.waitForElement();*/
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
			
		}
			
			public boolean selectBug() throws Exception {
				try {
										
					WebElement test = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(test);
					
					System.out.println("switched to frame");
					
					Select story = new Select(selectionOption);
					story.selectByVisibleText("Bug");		
					/*bp.waitForElement();
					bp.waitForElement();*/
					
					Thread.sleep(2000);
					System.out.println("Bug selected");
					Thread.sleep(2000);
					savePreference.click();
					/*bp.waitForElement();*/
					Thread.sleep(2000);
					
					System.out.println("Bug preference saved successfully");
					
					driver.switchTo().defaultContent();
					/*bp.waitForElement();*/
					
					return true;
				} catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
				
			}	
				public boolean selectSubtask() throws Exception {
					try {
						
						WebElement test = driver.findElement(By.tagName("iframe"));
						driver.switchTo().frame(test);
						
						System.out.println("switched to frame");
						
						Select subtask = new Select(selectionOption);
						
							subtask.selectByVisibleText("Sub-task");		
							/*bp.waitForElement();
							bp.waitForElement();*/
							
							Thread.sleep(2000);
							savePreference.click();
							/*bp.waitForElement();*/
							Thread.sleep(2000);
						System.out.println("sub task preference saved successfully");
						
						driver.switchTo().defaultContent();
					/*	bp.waitForElement();*/
						
						return true;
					} catch (Exception e) {
						e.printStackTrace();
						throw e;
					}

				}
	
				public boolean selectEpic() throws Exception {
					try {
						
						
						WebElement test = driver.findElement(By.tagName("iframe"));
						driver.switchTo().frame(test);
						
						System.out.println("switched to frame");
						
						Select story = new Select(selectionOption);
						
						
						
						story.selectByVisibleText("Epic");		
						/*bp.waitForElement();
						bp.waitForElement();*/
						Thread.sleep(2000);
						System.out.println("Epic selected");
						
						savePreference.click();
						/*bp.waitForElement();*/
						Thread.sleep(2000);
						System.out.println("Epic preference saved successfully");
						
						driver.switchTo().defaultContent();
						/*bp.waitForElement();*/
						
						return true;
					} catch (Exception e) {
						e.printStackTrace();
						throw e;
					}
					
				}
				
				
				
				public boolean deselectStory() throws Exception {
					try {
						
						WebElement test = driver.findElement(By.tagName("iframe"));
						driver.switchTo().frame(test);
						
						System.out.println("switched to frame");
						
						Select story = new Select(selectionOption);
						//story.deselectAll();
						//story.selectByValue("Story");	
						/*story.selectByVisibleText("Story");
						story.selectByVisibleText("Story");*/
						storyOption.click();
						
						Thread.sleep(5000);
						System.out.println("story deselected");
						Thread.sleep(3000);
						savePreference.click();
						//bp.waitForElement();
						Thread.sleep(2000);
						System.out.println("Story deselected preference saved successfully");
						
						driver.switchTo().defaultContent();
						
						
						//bp.waitForElement();
					
						
						
						Thread.sleep(2000);
						return true;
					} catch (Exception e) {
						e.printStackTrace();
						throw e;
					}
					
				}
					public boolean deselectTask() throws Exception {
						try {
							
							WebElement test = driver.findElement(By.tagName("iframe"));
							driver.switchTo().frame(test);
							
							System.out.println("switched to frame");
							
							Select task = new Select(selectionOption);
								/*task.deselectByValue("Task");
									
								bp.waitForElement();
								bp.waitForElement();*/
								
							taskOption.click();
							Thread.sleep(3000);
							System.out.println("task deselected");
							Thread.sleep(2000);
							savePreference.click();
							
								
						   Thread.sleep(2000);
						   System.out.println("Task deselected preference saved successfully");
							
							driver.switchTo().defaultContent();
							//bp.waitForElement();
							Thread.sleep(2000);
							return true;
						} catch (Exception e) {
							e.printStackTrace();
							throw e;
						}
						
					}
						
						public boolean deselectBug() throws Exception {
							try {
													
								WebElement test = driver.findElement(By.tagName("iframe"));
								driver.switchTo().frame(test);
								
								System.out.println("switched to frame");
								
								Select story = new Select(selectionOption);
								/*story.deselectByValue("Bug");
									
								bp.waitForElement();
								bp.waitForElement();*/
								
								bugOption.click();
								Thread.sleep(3000);
								System.out.println("Bug deselected");
								Thread.sleep(2000);
								savePreference.click();
								//bp.waitForElement();
								Thread.sleep(2000);
								System.out.println("Bug deselected preference saved successfully");
								
								driver.switchTo().defaultContent();
								bp.waitForElement();
								
								return true;
							} catch (Exception e) {
								e.printStackTrace();
								throw e;
							}
							
						}	
							public boolean deselectSubtask() throws Exception {
								try {
									
									WebElement test = driver.findElement(By.tagName("iframe"));
									driver.switchTo().frame(test);
									
									System.out.println("switched to frame");
									Thread.sleep(5000);
									/*Actions act = new Actions(driver);
									act.moveToElement(story).sendKeys(Keys.CONTROL).click();
									Select subtask = new Select(selectionOption);
										subtask.deselectByValue("Sub-task");											
										bp.waitForElement();
										bp.waitForElement()*/;
										
										subTaskOption.click();
										Thread.sleep(3000);
										System.out.println("Bug deselected");
										Thread.sleep(2000);
										savePreference.click();
										//bp.waitForElement();
										Thread.sleep(2000);
													
									System.out.println("sub task preference saved successfully");
									
									driver.switchTo().defaultContent();
									bp.waitForElement();
									
									return true;
								} catch (Exception e) {
									e.printStackTrace();
									throw e;
								}

							}
				
							public boolean deselectEpic() throws Exception {
								try {
									
									
									WebElement test = driver.findElement(By.tagName("iframe"));
									driver.switchTo().frame(test);
									
									System.out.println("switched to frame");
									
									Select story = new Select(selectionOption);
									
									/*story.deselectByValue("Epic");
										
									bp.waitForElement();
									bp.waitForElement();*/
									
									epicOption.click();
									Thread.sleep(3000);
									System.out.println("Epic selected");
									Thread.sleep(2000);
									savePreference.click();
									//bp.waitForElement();
									Thread.sleep(2000);
									System.out.println("Epic deselected preference saved successfully");
									
									driver.switchTo().defaultContent();
									bp.waitForElement();
									
									return true;
								} catch (Exception e) {
									e.printStackTrace();
									throw e;
								}
								
							}
	
}
