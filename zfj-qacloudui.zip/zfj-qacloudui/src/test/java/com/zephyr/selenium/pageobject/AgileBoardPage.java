package com.zephyr.selenium.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class AgileBoardPage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;

	public AgileBoardPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	protected WebElement jirahomepage;
	
	
	@FindBy(xpath = "(//*[@class='css-17jvs9k'])[1]")
	protected WebElement allProjects;	
	
	@FindBy(xpath = "//*[@id='helpPanelContainer']/div/div[1]/div[1]/header/nav/div[3]/div[2]/div/button/span/span[1]")
	protected WebElement globalProject;
	
	
	@FindBy(xpath = "//*[text()='View all projects']")
//	@FindBy(xpath = "//span[contains(text(),'View all projects')]")
	protected WebElement viewAllProjects;
	
//	@FindBy(xpath = "//*[@id='helpPanelContainer']/div/div[1]/div[3]/div[1]/div/div[2]/div/table/tbody/tr/td[2]/a/div")
	@FindBy(xpath = "//*[text()='Automation Project']")
	protected WebElement clickselectedproject;
	
			
	@FindBy(xpath = "//*[@id='createGlobalItem']")
	protected WebElement test;
	
	@FindBy(xpath = "//div[contains(text(),'Projects')]")
	protected WebElement projects;
	
	@FindBy(xpath = "//input[@name='search']")
	protected WebElement searchproject;

	
	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	protected WebElement zephyrPage;
	
	
	@FindBy(xpath = "//div[contains(text(),'Search Tests')]")
	protected WebElement searchTestPage;
	
	@FindBy(xpath = "//*[@class='sc-gJqsIT jBovqy']")
//	@FindBy(xpath = "//td[@class='TableCell__TableBodyCell-sc-1mgclzx-0 gIZZXT']")
	protected WebElement clickselectedproject1;
	
	@FindBy(xpath = "//div[contains(text(),'Tests')]")
	protected WebElement Tests;
	

	@FindBy(xpath = "(//*[@class='css-1if1bv7'])[3]")
	protected WebElement testMenu;
	
	@FindBy(xpath = "(//*[text()='Create a Test'])")
	protected WebElement createTest;
	
	/*@FindBy(xpath = "(//*[@class='css-1olrtn'])[2]")
	protected WebElement createTest;*/

	@FindBy(xpath = "(//button[text()='Search'])")
	protected WebElement SearchButton;
	
	@FindBy(xpath = "(//*[@class='BreadcrumbsItem__BreadcrumbsItemElement-sc-1hh8yo5-0 fItpNE'])[3]")
	protected WebElement latestCreatedTest;
	
	////img[@class='sc-kLIISr hfWeWa'] 
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[2])")
//	@FindBy(xpath ="//*[@id='helpPanelContainer']/div/div[1]/div[3]/div[1]/div/div/div[2]/div/div[1]/div[1]/div/div[1]/div/div[3]/div/div[3]/div[2]/span/button")
	protected WebElement DIconButton;
	
	@FindBy(xpath = "(//*[@class='zephyr-action-column-wrapper'])[1]")
	protected WebElement CloneStep;
	
	@FindBy(xpath = "//*[@id='clone-insert-at']")
	protected WebElement CloneStepToValidNumber;
	
	@FindBy(xpath = "//*[@id='clone-append-above']")
	protected WebElement CloneStepAppendAtFirst;
	
	@FindBy(xpath = "//*[@id='ap-button-0']")
	protected WebElement ClickOnClone;
	
	@FindBy(xpath = "(//*[@id='project-field'])")
	protected WebElement projectDropDown;
	
	@FindBy(xpath = "(//*[@id='issuetype-field'])")
	protected WebElement issueTypeFiledDropDown;
	
	@FindBy(xpath = "(//*[@id='summary'])")
	public WebElement summary;

	
	@FindBy(xpath ="//*[@id='labels-textarea']")
	public WebElement labelField;
	
	@FindBy(xpath = "(//*[@id='create-issue-submit'])")
	public WebElement submit;
	
	
	@FindBy(xpath = "//*[@id='create-issue-submit']")
	protected WebElement clickOncreate;
	
	@FindBy(xpath = "//*[text()='Search Tests']")
	protected WebElement searchTest;
	
	@FindBy(xpath ="//*[@id='layout-switcher-button']")
	protected WebElement switchLayout;
	
	@FindBy(xpath = "//*[text()='List View']")
	protected WebElement listView;
	
	@FindBy(xpath ="(//*[text()='Test'])[1]")
	protected WebElement selectTest;
	
	@FindBy(xpath ="(//*[text()='Story'])[1]")
	protected WebElement selectStory;
	
	@FindBy(xpath ="(//*[text()='Bug'])[1]")
	protected WebElement selectBug;
	
	@FindBy(xpath ="(//*[text()='Task'])[1]")
	protected WebElement selectTask;
	
   @FindBy(xpath="//*[@id='newstep']")
	protected WebElement step;
	
	@FindBy(xpath="//*[@id='newdata']")
	protected WebElement data;

	@FindBy(xpath="//*[@id='newresult']")
	protected WebElement result;
	
	@FindBy(xpath="(//*[@class='data-column'])[2]/div[1]/p")
	protected WebElement stepEdit;
	
	@FindBy(xpath="(//*[@class='data-column'])[3]/div[1]/p")
	protected WebElement dataEdit;

	@FindBy(xpath="(//*[@class='data-column'])[4]/div[1]/p")
	protected WebElement resultEdit;
	
	@FindBy(xpath = "//*[@title='Add Steps']")
	protected WebElement addstep;
	
	@FindBy(xpath = "//*[@id='advanced-search']")
	protected WebElement seachField;
	
	@FindBy(xpath = "//*[text()='Edit']")
	protected WebElement clickOnEditOption;
	
	@FindBy(xpath="//*[@id='summary']")
	protected WebElement clickOnSummary;
	
	@FindBy(xpath="//*[@id='edit-issue-submit']")
	protected WebElement updateButton;
	
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
    protected WebElement productLogoGlobalItem;
	
	@FindBy(xpath = "//*[text()='bddScenarioTest']")
	protected WebElement scenarioTest;
	
	@FindBy(xpath = "//*[@title='BDD Scenarios']")
	protected WebElement clickOnBDDScenarioOption;
	
	@FindBy(xpath = "//*[@id='jira-issue-header-actions']/div/div/div[1]/div/div/button")
	protected WebElement ActionsContextMenu;

	@FindBy(xpath = "(//*[@class='data-column drag-image '])[4]")
	protected WebElement DragTestStep;
	
	@FindBy(xpath = "(//*[@class='data-column drag-image '])[2]")
	protected WebElement DropTestStep;	
	
	@FindBy(xpath = "//*[text()='Clone']")
	protected WebElement cloneTest;
	
	@FindBy(xpath = "//*[@id='clone-issue-submit']")
	protected WebElement cloneTestCreate;
	
	@FindBy(xpath = "//*[text()='Delete']")
	protected WebElement DeleteTestFromMenu;
	
	@FindBy(xpath = "(//*[text()='Delete'])[2]")
	protected WebElement DeleteTest;
	
	@FindBy(xpath = "//*[text()='Export Word']")
	protected WebElement ExportTestFromMenu;
			
	@FindBy(xpath = "//*[@id='searcher-query']")
	protected WebElement JirasearchBox;
	
	@FindBy(xpath = "//*[text()='Export']")
	protected WebElement ExportTest;	
	
	@FindBy(xpath = "//*[text()='Export Excel CSV (all fields)']")
	protected WebElement ExportTestExcel;	
	
	
	@FindBy(xpath = "//*[@class='add-attachments '])[1]")
	protected WebElement PlusAddAttachment;		
			
	//*[text()='Add files...']
	@FindBy(xpath = "//*[text()='Add files...']")
	protected WebElement AddFiles;	
	
	@FindBy(xpath = "(//*[@class='zephyr-action-column-wrapper'])[2]")
	protected WebElement DeleteStep;
	
	@FindBy(xpath = "//*[text()='Delete']")
	protected WebElement DeleteStep2;
	
	@FindBy(xpath = "(//*[text()=' attachments'])[1]")
	protected WebElement DeleteStepAttachment;
	
	@FindBy(xpath = "//*[@class='icon-delete entity-operations-delete ']")
	protected WebElement DeleteStepAttachment2;
	
	@FindBy(xpath = "//*[text()='Execute']")
	protected WebElement Execute;
	
	/*@FindBy(xpath = "//span[text()='Execute']")
	@FindBy(xpath = "//span[@class='css-j8fq0c']/span[text()='Execute']")
	@FindBy(xpath = "//span[contains(@class, 'css-t5emrf') and text()='Execute']")*/
	
	@FindBy(xpath = "//*[@class= 'ak-button ak-button__appearance-default css-p30t9v']/span/span")
	protected WebElement Execute2;
	
	@FindBy(xpath = "//*[text()='Add to Test Cycle(s)']")
	protected WebElement AddTestToCycle;
	
	@FindBy(xpath = "//*[@class='trigger-dropDown']")
	protected WebElement AssigneeDropdown;
			
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[1])")
	protected WebElement ZephyrAction;
			
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[3])")
	protected WebElement ZephyrExecutions;	
	
	@FindBy(xpath = "//*[text()='Backlog']")
	protected WebElement Backlog;
	
	@FindBy(xpath = "//*[text()='Create sprint']")
	protected WebElement CreateSprint;
	
	@FindBy(xpath = "//*[@id='com.thed.zephyr.je__topnav-agile-board-links-button']")
	protected WebElement TestView;
	
	@FindBy(xpath = "//*[@id='com.thed.zephyr.je__zephyr-sprint-agile-board']")
	protected WebElement SprintView;
	
	@FindBy(xpath = "//*[@id='com.thed.zephyr.je__zephyr-issue-agile-board']")
	protected WebElement IssueView;
	
	@FindBy(xpath = "//*[text()='Start sprint']")
	protected WebElement StartSprint;
	
	@FindBy(xpath = "(//*[@id='accordian-10164']/div/span)[1]")
	protected WebElement ExpandIssue;
	
	@FindBy(xpath = "(//*[@class='sc-kpOJdX fDFLMJ']/span)[1]")
	protected WebElement ClickOnstatusChange;
					
	@FindBy(xpath = "(//*[@class='sc-kGXeez loHOEd'])[1]")
	protected WebElement submitStatus;
	
	@FindBy(xpath = "(//*[text()='Create issue'])[1]")
	protected WebElement CreateIssue;
	
	@FindBy(xpath = "//*[@class='Droplist__Trigger-sc-1z05y4v-3 eteVrT']/div/button")
	protected WebElement linkTestToCycle;
	
	@FindBy(xpath = "//*[@class='Droplist__Content-sc-1z05y4v-1 gnGSyD']")
	protected WebElement linkTestCycle;
	
	@FindBy(xpath = "//*[@class='css-1pcexqc-container']")
	protected WebElement SelectProject;
	
	@FindBy(xpath = "(//*[@class='css-dnjv80'])[2]")
	protected WebElement SelectVersion;
	
	@FindBy(xpath = "(//*[@class='css-dnjv80'])[3]")
	protected WebElement SelectCycle;
	
	@FindBy(xpath = "(//*[@class='css-dnjv80'])[4]")
	protected WebElement Selectfolder;
	
	@FindBy(xpath = "//*[@id='link-more-cycles']")
	protected WebElement linkMoreCycle;
	
	@FindBy(xpath = "//*[@class='ak-button ak-button__appearance-default css-p30t9v']/span")
	protected WebElement linkTestToCycleSave;
	
	@FindBy(xpath = "//*[@class='delete-action cursor-pointer']")
	protected WebElement RemovelinkedCycle;
	
	@FindBy(xpath = "//*[text()='Delete']")
	protected WebElement DeletelinkedCycle;
	
	@FindBy(xpath = "//*[@class='progress-bar']")
	protected WebElement progressBar;
	
	@FindBy(xpath = "//*[@class='sc-bZQynM XSfNJ']/span")
	protected WebElement EButton;
	
	@FindBy(xpath = "//*[@id='actionGridBody']/div/div[1]/div/div[1]/a/img")
	protected WebElement EButton2;
	
	@FindBy(xpath = "//*[@class='css-kb4noc-placeholder zephyr-option__placeholder']")
	protected WebElement FilterByStatus;

	
	@FindBy(xpath = "//*[@class='dropDown-wrapper select-status']/span[3]")
	protected WebElement StatusDropDown;
	
	@FindBy(xpath = "//*[@class='dropDown-wrapper select-status']")
	protected WebElement ClickOnStatus;
	
	/******************************* String protected *******************************/
	protected String zqlFilter1="project = '";
	protected String zqlFilter2="'";
	
	
	public boolean navigateToProject(String projectname) throws Exception{		
		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(3000);


			bp.waitForElement();
			driver.navigate().refresh();
			bp.waitTillElementIsVisible(globalProject);
			globalProject.click();
			bp.waitForElement();
			System.out.println("Clicked on global project");
			viewAllProjects.click();
			bp.waitForElement();
			System.out.println("Clicked on view all Project");
			
			Actions act = new Actions(driver);
	//		Object wait;
	//		wait.until(ExpectedConditions.elementToBeClickable(element));
			act.moveToElement(searchproject).click().pause(1500).sendKeys(projectname).pause(1500).sendKeys(Keys.ENTER).perform();

			Thread.sleep(3000);
			clickselectedproject.click();
			System.out.println("Clicked on Automation Project");
			bp.waitForElement();
			return true;
		
		
	}



			catch (Exception e) {
			e.printStackTrace();
			throw e;	
			}
		}	
	
	
	public boolean validateAgileBoardPage() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);	
			
		//	zephyrPage.click();
		//	System.out.println("Navigated to Zephyr page");
			Backlog.click();
			System.out.println("Navigated to Backlog page");
			bp.waitForElement();
		
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		}
	

	public boolean createSprint() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
		//	Backlog.click();
			CreateSprint.click();
			CreateIssue.click();
			
			Actions act = new Actions(driver);
			act.sendKeys("StoryIssue").sendKeys(Keys.ENTER).perform();
			
		//	StartSprint.click();
			
			System.out.println("Successfully clicked on create sprint");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean linkSingleCycleToSprint() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			Actions act2 = new Actions(driver);
			act2.moveToElement(linkTestToCycle).click().moveToElement(linkTestCycle).click().perform();
			bp.waitForElement();
			Thread.sleep(2000);
			
			/*linkTestToCycle.click();
			linkTestCycle.click();
			SelectProject.click();*/
			
			Actions act = new Actions(driver);
			act.moveToElement(SelectProject).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectVersion).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectCycle).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.perform();
			
			linkMoreCycle.click();
			linkTestToCycleSave.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			
			System.out.println("Successfully linked cycle to sprint");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	public boolean linkCycleToSprint() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			Actions act2 = new Actions(driver);
			act2.moveToElement(linkTestToCycle).click().moveToElement(linkTestCycle).click().perform();
			bp.waitForElement();
			Thread.sleep(2000);
			
			/*linkTestToCycle.click();
			linkTestCycle.click();
			SelectProject.click();*/
			
			Actions act = new Actions(driver);
			act.moveToElement(SelectProject).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectVersion).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectCycle).pause(1000).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(3000)
			.perform();
			
			linkMoreCycle.click();
			linkTestToCycleSave.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			act.moveToElement(SelectProject).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectVersion).pause(1000).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectCycle).pause(1000).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(3000)
			.perform();
			
			
			linkMoreCycle.click();
			linkTestToCycleSave.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			System.out.println("Successfully linked cycles to sprint");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean linkFolderToSprint() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
		/*	TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(2000);*/
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			Actions act2 = new Actions(driver);
			act2.moveToElement(linkTestToCycle).click().moveToElement(linkTestCycle).click().perform();
			bp.waitForElement();
			Thread.sleep(2000);
			
			/*linkTestToCycle.click();
			linkTestCycle.click();
			SelectProject.click();*/
			
			Actions act = new Actions(driver);
			act.moveToElement(SelectProject).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectVersion).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectCycle).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.perform();
			
			linkMoreCycle.click();
			linkTestToCycleSave.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			act.moveToElement(SelectProject).pause(1000).click().sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectVersion).pause(1000).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(SelectCycle).pause(1000).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(3000)
			.moveToElement(Selectfolder).pause(1000).click().sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(3000)
			.perform();
			
			
			linkMoreCycle.click();
			linkTestToCycleSave.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			System.out.println("Successfully linked cycle to sprint");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean RemovelinkedcycleFolderToSprint() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			Actions act2 = new Actions(driver);
			act2.moveToElement(RemovelinkedCycle).click().pause(1000)
			.moveToElement(RemovelinkedCycle).click().perform();
			bp.waitForElement();
			Thread.sleep(2000);
			DeletelinkedCycle.click();
	
			System.out.println("Successfully removed linked cycle to sprint");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean ExecuteExecutionInSprintView() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(6000);
			
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			progressBar.click();
			
			Actions act = new Actions(driver);
			act.moveToElement(ClickOnstatusChange).pause(1500).click().pause(1500).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();

			submitStatus.click();
			
			System.out.println("Successfully executed execution");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	public boolean ExecuteExecutionByEbutton() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			progressBar.click();
		
			Actions act = new Actions(driver);
			act.moveToElement(EButton).pause(1500).click().perform();


			WebElement frame2 = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame2);
			System.out.println("Found Iframe");
					
					Thread.sleep(5000);
					bp.waitForElement();
				

					Actions act2 = new Actions(driver);	
					act2.moveToElement(StatusDropDown).pause(1500).click()
					.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
							
					System.out.println("Status Executed Successfully ");
					return true;
				}
				
				catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
			}	

	
	
	public boolean StatusFilter() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			SprintView.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			progressBar.click();
		
			Actions act = new Actions(driver);
			act.moveToElement(FilterByStatus).pause(1500).click().sendKeys(Keys.ENTER).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER)
			.perform();
			
			System.out.println("Filter By status Successfully");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean IssueView() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			TestView.click();
			IssueView.click();
			System.out.println("Successfully navigated to issue view");
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
				
				Thread.sleep(5000);
				bp.waitForElement();
			
			ExpandIssue.click();
		//	ClickOnstatusChange.click();
			
			Actions act = new Actions(driver);
			act.moveToElement(ClickOnstatusChange).pause(1500).click().pause(1500).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();

			
			submitStatus.click();
			
			System.out.println("Successfully executed execution");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean goToSearchTest() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(4000);
			productLogoGlobalItem.click();
			bp.waitForElement();
			testMenu.click();
			
			bp.waitForElement();
			searchTest.click();
			
			bp.waitForElement();
			System.out.println("Successfully launched Serach Test Page");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	public boolean goToListView() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			
			
				listView.click();

			
			System.out.println("Selected List View");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	

	public boolean clickOnProductLogoGlobalItem() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			productLogoGlobalItem.click();
					
			System.out.println("Successfully launched Product Logo Page");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	

	
	
	
	public boolean goToListViewAndSelectTest() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			bp.waitForElement();
			listView.click();
			System.out.println("Selected listview");
			
			bp.waitForElement();
			selectTest.click();			
			System.out.println("Test selected");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	

	public boolean goToListViewAndSelectStory() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			bp.waitForElement();
			listView.click();
			System.out.println("Selected listview");
			
			bp.waitForElement();
			selectStory.click();			
			System.out.println("Story selected");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	

	
	
//added new
	public boolean createTest(String project, String issue, String Test) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			jirahomepage.click();
			System.out.println("Navigate to Jira Home page");
			bp.waitForElement();
			
			test.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys(Test);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean addTestCases() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			
			WebElement test = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(test);
		
			createTest.click();
			clickOnSummary.sendKeys("summary");
			clickOncreate.click();
			
				
			driver.switchTo().defaultContent();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	}

		
	
}


