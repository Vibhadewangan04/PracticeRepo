package com.zephyr.selenium.pageobject;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class CreateIssuePage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;
	ViewIssuePage vip;
	CreateIssuePage cip;

	public CreateIssuePage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	protected WebElement jirahomepage;
	
	@FindBy(xpath = "//*[@id='createGlobalItem']")
	protected WebElement GlobalCreateTest;

	@FindBy(xpath = "(//*[text()='Create a Test'])")
	//div[contains(text(),'Create a Test')]
	protected WebElement ProjectLevelcreateTest;
	
	@FindBy(xpath = "(//*[@id='project-field'])")
	protected WebElement projectDropDown;
	
	@FindBy(xpath = "(//*[@id='issuetype-field'])")
	protected WebElement issueTypeFiledDropDown;
	
	@FindBy(xpath = "(//*[@id='summary'])")
	public WebElement summary;

	
	@FindBy(xpath ="//*[@id='labels-textarea']")
	public WebElement labelField;
	
	@FindBy(xpath = "(//*[@id='create-issue-submit'])")
	public WebElement submit;
	
	@FindBy(xpath = "(//a[text()='Cancel'])")
	public WebElement cancel;
	
	@FindBy(xpath = "(//*[@class='qf-create-another']/input[1])")
	public WebElement createAnotherCheckbox;
	
	@FindBy(xpath = "(//button[@type='button'])")
	public WebElement expand;

	@FindBy(xpath = "//*[@id='create-issue-submit']")
	public WebElement createButton;
	
	@FindBy(xpath = "//*[@id='scenario_name']")	
	public WebElement  scenarioName;
	

	@FindBy(xpath = "//*[text()='bddScenarioTest']")
	public WebElement Test;
	
	
	
	@FindBy(xpath = "//*[text()='bddScenarioTest']")
	protected WebElement scenarioTest;
	
	@FindBy(xpath = "(//*[@class='sc-dyGzUR hcyxmF'])[4]")
    public WebElement Actions;

    @FindBy(xpath = "//*[@id='execute']")
    public WebElement Execute;
 
    @FindBy(xpath = "//*[text()='Execute']")
    public WebElement ExecuteTest;
    
    @FindBy(xpath = "//*[@title='Test Details']")
    public WebElement testDetail;
   
    
    @FindBy(xpath = "//*[text()='Save']")
    public WebElement saveButton;
	
    
    @FindBy(xpath = "(//*[@data-id='issuetype'])[1]")
	protected WebElement issuetypedropdown;
    
    @FindBy(xpath="(//*[@class='check-list-item'])[1]")
	protected WebElement checkbox;
	
	@FindBy(xpath="(//*[@class='sc-iAyFgw bmCPMv'])[1]")
	protected WebElement contextmenu;
	
//	@FindBy(xpath = "//*[text()='BDD background']")
	@FindBy(xpath = "//*[@class='background-container']")
	protected WebElement backgroundbtn;
	
	@FindBy(xpath = "//*[@class=' ace_editor ace-jira']/textarea")
    public WebElement testDetailSection;
	
	@FindBy(xpath = "//*[@class='ak-button ak-button__appearance-subtle t_download_feature']")
	protected WebElement downloadFeatureFile;
	
	@FindBy(xpath = "//*[@class='scenario']/a")
	protected WebElement bddTest;
	
	//@FindBy(xpath ="//*[@class='ak-button ak-button__appearance-default first-btn']")
	@FindBy(xpath = "//*[text()='Save']")
   protected WebElement save;
	
	@FindBy(xpath = "//*[@id='background']/textarea")
    public WebElement backgroundTextarea;
	
	@FindBy(xpath = "//*[@title='BDD Scenarios']")
	public WebElement bddScenariobutton;
			
	@FindBy(xpath = "(//*[@class='BreadcrumbsItem__BreadcrumbsItemElement-sc-1hh8yo5-0 fItpNE'])[3]")
	protected WebElement latestCreatedTest;
    
	@FindBy(xpath = "//*[text()='See the old view']")
	public WebElement oldjiraview;
	
	//@FindBy(xpath = "(//*[@class='sc-kpOJdX jXyOHp'])[5]")
	//@FindBy(xpath = "(//*[@class='sc-dxgOiQ dhzxhs'])[5]")
	@FindBy(xpath = "//button[@aria-label='Actions']")
	public WebElement clickoncontext;
	
	@FindBy(xpath = "//*[@class='icon aui-icon aui-icon-small aui-iconfont-more']")
	public WebElement context2;
	
	@FindBy(xpath = "//*[@id='create-subtask']")
	public WebElement subtaskbtn;
	
	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	protected WebElement zephyrPage;

	@FindBy(xpath = "//div[contains(text(),'Search Tests')]")
	protected WebElement searchTestPage;
	/******************************* String protected *******************************/
	protected String role;


	//create test with global create Test button
	public boolean GlobalcreateTest(String project, String issue, String Test) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			GlobalCreateTest.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(Keys.CLEAR);
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(1000);
			issueTypeFiledDropDown.sendKeys(Keys.CLEAR);
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys(Test);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	//issue summary change
	public boolean CreateTestforExecution(String project, String issue, String Test) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			GlobalCreateTest.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(Keys.CLEAR);
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(1000);
			issueTypeFiledDropDown.sendKeys(Keys.CLEAR);
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys("TestWithExecution");
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	public boolean ProjectLevelcreateTest(String project, String issue, String Test) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			ProjectLevelcreateTest.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(Keys.CLEAR);
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(1000);
			issueTypeFiledDropDown.sendKeys(Keys.CLEAR);
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys(Test);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean createTestWithLabel(String project, String issue, String Test, String label) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			driver.navigate().refresh();
			
			bp.waitForElement();
			
			GlobalCreateTest.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(2000);
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();		
			summary.sendKeys(Test);		
			bp.waitForElement();
					
			labelField.sendKeys(label);
			labelField.sendKeys(Keys.TAB);
			bp.waitForElement();
			
			createButton.click();
			

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean createScenarioForStory() throws Exception {
	       try {
	           bp = new CommonUtils();
	           bp.waitForElement();

	           scenarioName.sendKeys("bddScenarioTest");
	           scenarioName.sendKeys(Keys.ENTER);
	           bp.waitForElement();

	           
	           Test.click();
	            Actions.click();
	            Execute.click();
	            ExecuteTest.click();
	           
	           
	           return true;
	       } catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }

	   }
	
	
	
	
	
	public boolean verifyBdd_Backgroundoption() throws Exception {
	       try {
	           bp = new CommonUtils();
	           bp.waitForElement();
	           
	           vip=new ViewIssuePage(driver);
				vip.goToSearchTest();
				Thread.sleep(2000);
				issuetypedropdown.click();
				System.out.println("issuetype dropdown is selected");
				checkbox.click();
				Thread.sleep(5000);
				issuetypedropdown.click();
				vip.goToListViewAndSelectStory();
				Thread.sleep(2000);
				/*contextmenu.click();
				System.out.println("clicked on context menu");
				*/
				/*WebElement element=driver.findElement(By.linkText("BDD background"));
				if(element.isDisplayed()==true)
				{
					System.out.println("Bdd backgroud option is present in menu ");
				}
				else
				{
					System.out.println("Bdd backgroud option is not present in menu ");
				}*/
				bddScenariobutton.click();
				 WebElement frame = driver.findElement(By.tagName("iframe"));
				   driver.switchTo().frame(frame);
				   System.out.println("switch to frame");
				
				String actual= backgroundbtn.getText();
				String expected = "Background +";
				assertEquals(expected,actual);
				System.out.println("BDD background option is present in menu");
				
				driver.switchTo().defaultContent();
				
	           return true;
	           
	       }
	       catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }
	}    

public boolean createBDDScenarioForStory() throws Exception {
	       try {
	           bp = new CommonUtils();
	           bp.waitForElement();
	           vip=new ViewIssuePage(driver);
	           
	         // vip.goToListView();
	           WebElement frame = driver.findElement(By.tagName("iframe"));
				
	           driver.switchTo().frame(frame);
	           
	           scenarioName.sendKeys("bddScenarioTest");
	           scenarioName.sendKeys(Keys.ENTER);
	           bp.waitForElement();
	           
	           System.out.println("Added BDD scenario for story successfully");
	           driver.switchTo().defaultContent();

	           return true;
	       } catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }

	   }
	
	
	
	public boolean dowloadFeatureFileFromStory() throws Exception {
	       try {
	           bp = new CommonUtils();
	           
	           WebElement frame = driver.findElement(By.tagName("iframe"));
				
	           driver.switchTo().frame(frame);
	           
	  
	           downloadFeatureFile.click();
	           
	           System.out.println("Downloaded feature file from story successfully");
	           
	           driver.switchTo().defaultContent();
	           
	           return true;
	       } catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }

	   }
	   
	   public boolean addScenarioForTest(String scenario) throws Exception {
	       try {
	           bp = new CommonUtils();
	           bp.waitForElement();
	           ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles()); 
	           driver.switchTo().window(tabs.get(1));
	           
	           testDetail.click();
	           	
	           WebElement frame = driver.findElement(By.tagName("iframe"));
			   driver.switchTo().frame(frame);
	           
	           
	           testDetailSection.sendKeys(scenario);
	           
	           bp.waitForElement();	  
	           
	           ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,saveButton);
	           
	           saveButton.click();
	           
	           driver.switchTo().defaultContent();
	           
	           
	           
	           

	           return true;
	       } catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }

	   }
	
	public boolean navigateToTest() throws Exception {
	       try {
	           bp = new CommonUtils();
	           bp.waitForElement();
	           WebElement frame = driver.findElement(By.tagName("iframe"));
			   driver.switchTo().frame(frame);
	           
	           bddTest.click();
	           bp.waitForElement();
	           
	           driver.switchTo().defaultContent();
	           

	           return true;
	       } catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }

	   }
	
	public boolean addScenarioOutline(String scenario) throws Exception {
	       try {
	           bp = new CommonUtils();
	           bp.waitForElement();
	           vip = new ViewIssuePage(driver);
	         //  vip.goToListView();
	           ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles()); 
	           driver.switchTo().window(tabs.get(1));
	           
	           testDetail.click();
	           	
	           WebElement frame = driver.findElement(By.tagName("iframe"));
			   driver.switchTo().frame(frame);
	           
	           
	           testDetailSection.sendKeys(scenario);
	           
	           bp.waitForElement();	
	           Thread.sleep(2000);
	           
	           
	          /* JavascriptExecutor jse = (JavascriptExecutor)driver;
	           jse.executeScript("window.scrollBy(0,250)", "saveButton");*/
	           
	           ((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,saveButton);
	           
	           //driver.switchTo().defaultContent();
	          // driver.switchTo().frame(frame);
	           saveButton.click();
	           
	           driver.switchTo().defaultContent();
	           
	           return true;
	       }
	       catch (Exception e) {
	           e.printStackTrace();
	           throw e;
	       }

}
	
	
	public boolean addBddBackgroundToStory() throws Exception {
		
		try {
		cip = new CreateIssuePage(driver);
		backgroundbtn.click();
		
         String scenario = 
      		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
      		   "When  User Navigates to the URL provided\r\n" + 
      		   "And   User Enters Username, Password and clicks on login";
         System.out.println(scenario);
         backgroundTextarea.sendKeys(scenario);         
         bp.waitForElement();	           
         save.click();
         System.out.println("addBddBackgroundToStory");
	
		return true;
		
	}
	
	catch (Exception e) {
        e.printStackTrace();
        throw e;
    }

	
}
	public boolean createsubtask(String project, String issue, String Test) throws Exception {
		try {
			bp = new CommonUtils();
			
			//create test
			GlobalCreateTest.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(Keys.CLEAR);
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			Thread.sleep(1000);
			issueTypeFiledDropDown.sendKeys(Keys.CLEAR);
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys(Test);
			summary.sendKeys(Keys.ENTER);
			
			log.info("Test Created Successfully");
			bp.waitForElement();
			zephyrPage.click();
			bp.waitForElement();
			searchTestPage.click();
			latestCreatedTest.click();
			Thread.sleep(10000);
			//switch to new tab
			ArrayList<String> tabs2 = new ArrayList<String> (driver.getWindowHandles());
		    driver.switchTo().window(tabs2.get(1));
		    log.info("Navigate to new tab");
		    bp.waitForElement();
		    Thread.sleep(5000);
		    clickoncontext.click();
		    bp.waitForElement();
		    oldjiraview.click();
		    bp.waitForElement();
		    Thread.sleep(7000);
		    context2.click();
		    bp.waitForElement();
		    subtaskbtn.click();
		    bp.waitForElement();
		    summary.sendKeys("Subtask summary");
			summary.sendKeys(Keys.ENTER);
		    log.info("Subtask Created Successfully");
			return true;
		}
		catch (Exception e) {
	        e.printStackTrace();
	        throw e;
	    }
	}
}
