package com.zephyr.selenium.stepdefinition;

import com.zephyr.selenium.pageobject.*;
import com.zephyr.selenium.utility.*;
import com.zephyr.selenium.utility.Property_Lib;
import java.time.LocalTime;
import cucumber.api.java.en.*;

public class Precondition extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	PreconditionPage pcp;
	
	String fileName1 = "Basedata";
	
	LocalTime todayDate = LocalTime.now();
	
	@Given("^User clicks on top navigation zephyr menu$")
	public void user_clicks_on_top_navigation_zephyr_menu() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
			
			pcp.navigateTopZephyr();
			System.out.println("Navigated to top level zephyr menu");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				driver.close();
				throw e;
				
				}		
		
	}

	@Then("^validate all zephyr apps$")
	public void click_on_all_the_zephyr_apps_and_validate() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
		
		pcp.validateAllZephyrApps();
		System.out.println("All apps launched successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			driver.close();
			throw e;
			
			}
	}



	@Given("^Create a project$")
	public void create_a_project() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
			
			//code for generating automatic projectname and keys based on timestamp
//			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
//					+ CONFIG_FILE, "projectName")+todayDate;
//			
//			String TempPkey = Property_Lib.getPropertyValue(CONFIG_PATH
//					+ CONFIG_FILE, "projectKey")+todayDate;
//			
//			String Pkey = TempPkey.substring(0, 3);
			
			
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
					String Pkey = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectKey");
			
			pcp.createProject(Pname,Pkey);
			System.out.println("Created Project Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				driver.close();
				throw e;
				
				}

			}
	
	@Given("^Add issue type Test to the created project$")
	public void add_issue_type_Test_to_the_created_project() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
			
			
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			pcp.AddIssueTypeToProject(Pname);
			System.out.println("Added Test issue type to the Project Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	
	@Given("^Create version$")
	public void create_version() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "versionOne");
			
			String Version2 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "versionTwo");
			
			pcp.createVersion(Pname,Version1,Version2);
			System.out.println("Created versions successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	@Given("^Create components$")
	public void create_components() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			String Component1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "componentOne");
			
			String Component2 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "componentTwo");
			
			
			pcp.createComponent(Pname,Component1,Component2);
			System.out.println("Created components successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	@Given("^Enable timetracking$")
	public void enable_timetracking() throws Throwable {
	  
		try{
			pcp = new PreconditionPage(driver);
			pcp.enableTimetracking();
			System.out.println("Enabled Time tracking successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	
	
	@Given("^Add timetracking to screen$")
	public void add_timetracking_to_screen() throws Throwable {
	    
		
		try{
			pcp = new PreconditionPage(driver);
			String Screenkey = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectScreenKey");
			
			String Pkey = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectKey");
			
			pcp.timetrackingScreen(Screenkey, Pkey);
			System.out.println("Added timetracking app to the screen");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	

	@Given("^Create filter$")
	public void create_filter() throws Throwable {
	    
		
		try{
			pcp = new PreconditionPage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			String Fname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "filterName1");
			
			pcp.createFilter(Pname,Fname);
			System.out.println("Created Filter");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	
	@Then("^validate api keys$")
	public void validate_api_keys() throws Throwable {
		try{
			pcp = new PreconditionPage(driver);
				
			pcp.validatApiKeys();
			System.out.println("Api keys validated successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}


	
}