package com.zephyr.selenium.utility;


	public interface AutomationConstants {

		public static final String CONFIG_PATH = "./src/test/resources/Config_Files/";
		public static final String CONFIG_FILE = "config.properties";
		public static final String CONFIG_FILE_TPE = "config.properties";

		public static final String CONFIG_FILE_REQ = "config.properties";
		public static final String CONFIG_FILE_DASH = "config.properties";
		public static final String CONFIG_FILE_DT = "config.properties";

		public static final String CONFIG_FILE2 = "config2.properties";

		public static final String DRIVER_PATH = "./Drivers/";
		public static final String CHROME_FILE = "chromedriver.exe";

		public static final String GECKO_FILE = "geckodriver.exe";
		public static final String IE_FILE = "IEDriverServer.exe";

		public static final String INPUT_PATH = "./src/test/resources/User_Input/inputs.xlsx";
		public static final String INPUT_PATH_1 = "./src/test/resources/User_Input/inputs_1.xlsx";
		public static final String INPUT_PATH_2 = "./src/test/resources/User_Input/inputs_2.xlsx";
		public static final String INPUT_PATH_3 = "./src/test/resources/User_Input/Inputs_3.xlsx";
		public static final String INPUT_PATH_4 = "./src/test/resources/User_Input/input_4.xlsx";
		public static final String INPUT_PATH_5 = "./src/test/resources/User_Input/Inputs_5.xlsx";

		public static final String INPUT_PATH_6 = "./src/test/resources/User_Input/input_6.xlsx";
		public static final String INPUT_PATH_7 = "./src/test/resources/User_Input/input_7.xlsx";
		public static final String INPUT_PATH_8 = "./src/test/resources/User_Input/input_8.xlsx";
		public static final String INPUT_PATH_9 = "./src/test/resources/User_Input/input_9.xlsx";
		public static final String INPUT_PATH_10 = "./src/test/resources/User_Input/input_10.xlsx";
		public static final String CHROME_KEY = "webdriver.chrome.driver";;
		public static final String GECKO_KEY = "webdriver.gecko.driver";

		public static final String IE_KEY = "webdriver.ie.driver";

		public static final String CONFIG_PATH1 = "./src/test/resources/ConfigFiles/config2.properties";
		public static String UNIQUE = "Auto_"
				+ Property_Lib.getPropertyValue(CONFIG_PATH1, "Count");
		public static final int EXPLICIT = Integer.parseInt(Property_Lib
				.getPropertyValue(CONFIG_PATH + CONFIG_FILE_TPE, "EXPLICIT"));
		public static final int MAX_EXPLICIT = Integer.parseInt(Property_Lib
				.getPropertyValue(CONFIG_PATH + CONFIG_FILE_TPE, "MAXEXPLICIT"));

		public static final int FLUENTWAIT = Integer.parseInt(Property_Lib
				.getPropertyValue(CONFIG_PATH + CONFIG_FILE_TPE, "FLUENTWAIT"));
		
		public static final int POLLINGWAIT = Integer.parseInt(Property_Lib
				.getPropertyValue(CONFIG_PATH + CONFIG_FILE_TPE, "POLLINGWAIT"));
		
		public static final String UPLOAD_FILE_LOCATION = "\\src\\test\\resources\\Upload_Files";

	

}
