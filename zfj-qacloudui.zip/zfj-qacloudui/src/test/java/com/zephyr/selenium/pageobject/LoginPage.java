package com.zephyr.selenium.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class LoginPage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;

	public LoginPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}

	/******************************* protected WebElement *******************************/
	@FindBy(xpath = "(//input[@id='username'])")
	protected WebElement username;

	@FindBy(xpath = "(//*[text()='Continue'])")
	protected WebElement UserContinue;
	
	@FindBy(xpath = "(//input[@id='password'])")
	protected WebElement password;
	
	@FindBy(xpath = "(//span[text()='Log in'])")
	protected WebElement loginButton;
	
	@FindBy(xpath = "((//*[@class='css-164r41r'])[5])")
	public WebElement user_option;

	@FindBy(xpath = "(//*[text()='Log out'])")
	public WebElement logout;

	/******************************* String protected *******************************/
	protected String role;

	/*
	 * **************************************************** Method Name :
	 * enterUname(String userName) Purpose : To enter Username Author : OPAL1
	 * Date Created : 27/07/17 Date Modified : Reviewed By : Opal4
	 * ******************************************************
	 */
	public boolean enterUname(String userName) throws Exception {
		try {
			bp = new CommonUtils();
			bp.explicitWait(username);
			username.sendKeys(userName);
			UserContinue.click();			
			bp.waitForElement();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	

	/*
	 * **************************************************** Method Name
	 * :enterPass(String passWord) Purpose : To enter Password Author : OPAL1
	 * Date Created : 27/07/17 Date Modified : Reviewed By : Opal4
	 * ******************************************************
	 */
	public boolean enterPass(String passWord) throws Exception {
		try {
			bp = new CommonUtils();
			bp.explicitWait(password);
			password.sendKeys(passWord);

			bp.waitForElement();
			bp.waitForElement();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/*
	 * **************************************************** Method Name
	 * :clickOnLogin() Purpose : To click On Login Author : OPAL1 Date Created :
	 * 27/07/17 Date Modified : Reviewed By : Opal4
	 * ******************************************************
	 */
	public boolean clickOnLogin() throws Exception {
		try {
			bp = new CommonUtils();
			bp.explicitWait(loginButton);
			loginButton.click();

			bp.waitForElement();
			log.info("Successfully Landed to Jira Home Page");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/*
	 * **************************************************** Method Name
	 * :enterUnameAndPassword(String name,String passWord) Purpose : To enter
	 * Username And Password Author : OPAL1 Date Created : 27/07/17 Date
	 * Modified : Reviewed By : Opal4
	 * ******************************************************
	 */
	public boolean enterUnameAndPassword(String name, String passWord)
			throws Exception {
		try {
			bp = new CommonUtils();
			bp.explicitWait(username);
			username.sendKeys(name);
			bp.waitForElement();
			password.sendKeys(passWord);
			bp.waitForElement();
			loginButton.click();
			bp.waitForElement();
			log.info("Successfully Landed to Jira Home Page");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}

	/*
	 * **************************************************** Method Name :
	 * verifyLoginTitle() Purpose : To verify Login Title Author : OPAL1 Date
	 * Created : 27/07/17 Date Modified : Reviewed By : Opal4
	 * ******************************************************
	 */
	public boolean verifyLoginTitle() throws Exception {
		try {
			String titleLogin = driver.getTitle();
			log.info(titleLogin);
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
}
