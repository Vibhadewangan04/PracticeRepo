package com.zephyr.selenium.pageobject;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.zephyr.selenium.stepdefinition.CreateIssue;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.pageobject.PlanTestCyclePage;
import com.zephyr.selenium.stepdefinition.PlanTestCycle;
import org.openqa.selenium.interactions.Actions;



public class ExecuteTestPage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	PlanTestCyclePage ptcp;
	CreateIssue cri;
	ViewIssuePage vip;
	
	public ExecuteTestPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}

	/******************************* protected WebElement *******************************/
	//@FindBy(xpath = "//*[@data-action='Execute data-customevent=']")
	@FindBy(xpath = "//*[@title='Execute']")
	protected WebElement Ebutton;

	@FindBy(xpath="(//*[@class='trigger-dropDown'])[1]")
	//@FindBy(xpath= "//*[contains(text(),'UNEXECUTED')]")
	protected WebElement statusDropdown;
	
	
	//click on x button
	@FindBy(xpath="(//span[@class='remove-data '])[2]")
	protected WebElement xIcon;
	
	@FindBy(xpath="(//*[@class='trigger-dropDown'])[2]")
	protected WebElement assigneeDropdown;
	
	//@FindBy(xpath="//div[@id='root']/div[2]")
	@FindBy(xpath="//*[@class='list-container']")
	protected WebElement assigneeName;

	@FindBy(xpath="//*[text()='Create New Issue']")
	protected WebElement createIssue;
	
	@FindBy(xpath = "(//*[@id='issuetype-field'])")
	protected WebElement issueTypeFiledDropDown;
	
	@FindBy(xpath = "(//*[@id='summary'])")
	public WebElement summary;
	
	//@FindBy(xpath="//*[@id='editableField']")
	@FindBy(xpath= "(//*[@class='editable-field empty'])[1]")
	protected WebElement commentField;
	
	@FindBy(xpath= "//*[@class='cell-editMode']")
	protected WebElement editcomment;
	
	@FindBy(xpath="(//*[@class='editable-field empty'])[2]")
	protected WebElement commentFieldatstep;
	
	//Teststep statusdropdown
	@FindBy(xpath="(//*[@class='trigger-dropDown'])[3]")
	protected WebElement stepStatusDropdwn;
	
	@FindBy(xpath="(//*[@class='trigger-dropDown'])[4]")
	protected WebElement stepStatusDropdwn1;
	
	@FindBy(xpath="(//*[@class='trigger-dropDown'])[5]")
	protected WebElement stepStatusDropdwn2;
	
	
	@FindBy(xpath="//*[text()='Execute']")
	protected WebElement executeButton;
	
	@FindBy(xpath="(//*[@class='attachment-icon-wrapper'])[1]")
	protected WebElement executionAttachment;
	
	//@FindBy(xpath="(//*[@class='_26Rfe1lar9WC5NDEeARvBy'])[2]")
	@FindBy(xpath="//*[text()='Add files...']")
	protected WebElement addFilesbtn;
	
	//@FindBy(xpath="(//*[@class='_26Rfe1lar9WC5NDEeARvBy'])[4]")
	@FindBy(xpath="//*[text()='Attach']")
	protected WebElement attachButton;
	
	
	@FindBy(xpath = "(//*[@id='project-field'])")
	protected WebElement projectDropDown;
	
	//@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	@FindBy(xpath = "//a[@data-testid='NavigationItem']//*[contains(text(),'Zephyr')]")
	protected WebElement zephyrPage;
	
	
	@FindBy(xpath = "//*[text()='Search Tests']")
	protected WebElement searchtestbtn;
	
	@FindBy(xpath = "(//*[@class='BreadcrumbsItem__BreadcrumbsItemElement-sc-1hh8yo5-0 fItpNE'])[3]")
	protected WebElement latestCreatedTest;
	
	@FindBy(xpath="//*[@id='newstep']")
	protected WebElement step;
	
	@FindBy(xpath="//*[@id='newdata']")
	protected WebElement data;

	@FindBy(xpath="//*[@id='newresult']")
	protected WebElement result;
	
	@FindBy(xpath = "//*[@title='Add Steps']")
	protected WebElement addstep;
	
	@FindBy(xpath = "//*[@class='css-z8pkji']")
	protected WebElement expander;
	
	
	@FindBy(xpath = "//*[@aria-expanded='true']")
	protected WebElement expandertrue;
	
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[2])")
	//@FindBy(xpath = "(//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[2]")
	protected WebElement dbutton;
	
	@FindBy(xpath = "//*[@class='css-dnjv80 zephyr-option__value-container zephyr-option__value-container--is-multi']")
	protected WebElement executedefectsearch;
	
	@FindBy(xpath = "(//*[@class='defectIcons create'])[1]")
	protected WebElement stepdefectarrow;
	
	
	@FindBy(xpath = "(//*[text()='Create defect'])[1]")
	protected WebElement stepCreateDefectBtn;
	
	@FindBy(xpath = "(//*[@class='ajax-input'])[2]")
	protected WebElement stepdefectsearch;
	
	
	@FindBy(xpath = "(//*[@class='defectId'])[1]")
	protected WebElement stepdefectid;
	
	
	@FindBy(xpath = "(//button[text()='Search'])")
	protected WebElement SearchButton;
	
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[2])")
	protected WebElement DIconButton;
	
	@FindBy(xpath="//*[@class='testStepFocus-btn ']")
  	protected WebElement AddstepLink;
	
	/******************************* String protected *******************************/
	
	public String status1 = "//li[@id='";
	public String status2 = "']";
	
	public String verifystatus1 = "//span[@title='";
	public String verifystaus2 = "']";
	
	//public String assignee1= "//*[@data-displayname='";
	public String assignee1 ="//*[@class='list-wrapper'and @data-displayname='";
	
	// (//li[@data-content='custom'])[1]
	public String step1 ="(//li[@data-content='";
	public String step2 = "'])[1]";
	
	protected String role;

	
	
	 	public boolean validateExecuteTest() throws Throwable {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			//added
			//driver.switchTo().frame(0);
			Thread.sleep(5000);
			Ebutton.click();
			bp.waitForElement();
			Thread.sleep(2000);
			String expectedtitle="Test Execution - Jira";
			String actualtitle=driver.getTitle();
			assertEquals(actualtitle, expectedtitle);
			System.out.println("Navigate to Executepage Successfully");
		
			
            return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
     
	 	public boolean executeTest() throws Exception {
			try {
				bp = new CommonUtils();
				List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(12000);
				
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				/*statusDropdown.click();
				Thread.sleep(3000);*/
				Actions act = new Actions(driver);
				act.moveToElement(statusDropdown).click().pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
				
				Thread.sleep(2000);
				return true;
	
			}
			catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
		}
	 	
	 	
	 	public boolean executeTest_NewStatus(String status) throws Exception{
	 		try {
	 		bp = new CommonUtils();
	 		
	 		List<WebElement> frame = driver.findElements(By.tagName("iframe"));
			System.out.println("The total number of iframes are " + frame.size());
			Thread.sleep(20000);
			driver.switchTo().frame(0);
			Thread.sleep(20000);
			statusDropdown.click();
			Thread.sleep(3000);
			WebElement newstatus = driver.findElement(By.xpath(status1 + status + status2));
			newstatus.click();
			
			Thread.sleep(3000);
			WebElement Verifynewstatus = driver.findElement(By.xpath(verifystatus1 + status + status2));
		   boolean statusverify =Verifynewstatus.isDisplayed();
		    if (statusverify)
		  {
			log.info("Validated the Executionlevel Customstatus has been Updated");
		  }else {
			log.info("Executionlevel Customstatus has not Updated:Fail");
		  }
	 		return true;
	 	  }
	 	
	 	 catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 		
	 	}
	 	public boolean unassignexecution() throws Exception{
	 		try {
	 			bp = new CommonUtils();
	 			//bp.explicitWait(xIcon);
	 			Thread.sleep(12000);
	 			Actions action=new Actions(driver);
	 			action.moveToElement(xIcon).pause(3000).click().perform();
	 			Thread.sleep(2000);
	 			
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
		
	 	public boolean assignexecutionto_otheruser(String userUsername) throws Exception{
	 		try {
	 			bp = new CommonUtils();
	 			
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(20000);
				driver.switchTo().frame(0);
				Thread.sleep(15000);
	 			
				/*Actions action1=new Actions(driver);
	 			action1.moveToElement(xIcon).pause(3000).click().perform();
	 			Thread.sleep(4000);*/
	 			
	 			Actions action = new Actions(driver);
	 		    action.moveToElement(assigneeDropdown).click().pause(5000).sendKeys(userUsername).perform();
	 		  //WebElement currentUser = driver.findElement(By.xpath(assignee1 + user + status2));  
	 		   WebElement otheruser = driver.findElement(By.xpath(assignee1 + userUsername + status2));
	 			log.info("xpath= "+otheruser);
	 			action.pause(5000).moveToElement(otheruser).click().perform();
	 			log.info("Clicked on Currentuser");
	 			
	 			//WebElement VerifyassignetoCurrentuser = driver.findElement(By.xpath(assignee1 + user + status2));
	 			String Verifyassignetootheruser =userUsername;
	 		    boolean currentuserverify =Verifyassignetootheruser.contains(userUsername);
	 		    if (currentuserverify)
	 		  {
	 			log.info("Validated the Execution has been assigned to Other user");
	 		  }else {
	 			log.info("Validated the Execution has not assigned to Other user");
	 			
	 		  }
	 		   Thread.sleep(3000);
	 		   Actions act = new Actions(driver);
			   act.moveToElement(statusDropdown).click().pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
				
	 			bp.waitForElement();
	 			
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 		
	 	}
	 	
	 	public boolean assign_executionto_current_user(String user) throws Exception{
	 		try {
	 			bp = new CommonUtils();
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(20000);
				driver.switchTo().frame(0);
				Thread.sleep(12000);
	 			
	 			Actions action = new Actions(driver);
	 		    action.moveToElement(assigneeDropdown).click().pause(5000).sendKeys(user).perform();
	 			
	 		    //xpath -//*[@class='list-wrapper'and @data-displayname='Zephyr QA']
	 			WebElement currentUser = driver.findElement(By.xpath(assignee1 + user + status2));
	 			log.info("xpath= "+currentUser);
	 			//currentUser.click();
	 			action.pause(3000).moveToElement(currentUser).click().perform();
	 			log.info("Clicked on Currentuser");
	 			
	 			//WebElement VerifyassignetoCurrentuser = driver.findElement(By.xpath(assignee1 + user + status2));
	 			String VerifyassignetoCurrentuser =user;
	 		    boolean currentuserverify =VerifyassignetoCurrentuser.contains(user);
	 		    if (currentuserverify)
	 		  {
	 			log.info("Validated the Execution has been assigned to Current user");
	 		  }else {
	 			log.info("Validated the Execution has not assigned to Current user");
	 			
	 		  }
	 		    Thread.sleep(2000);
	 		   Actions act = new Actions(driver);
			   act.moveToElement(statusDropdown).click().pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
				
	 			bp.waitForElement();
	 			return true;
	 			
	 		}
	 		
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 		
	 	}
	 	
	 	public boolean add_newDefect_at_execution(String project, String issue,  String Bug) throws Throwable{
	 		try {
	 			bp = new CommonUtils();
	 			bp.waitForElement();
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(12000);
				driver.switchTo().frame(0);
				Thread.sleep(10000);
	 			createIssue.click();
	 			
	 			driver.switchTo().defaultContent();
	 			
	 			bp.waitForElement();
	 			projectDropDown.sendKeys(Keys.CLEAR);
				projectDropDown.sendKeys(project);
				projectDropDown.sendKeys(Keys.ENTER);
					
				bp.waitForElement();
				Thread.sleep(1000);
				issueTypeFiledDropDown.sendKeys(Keys.CLEAR);
				issueTypeFiledDropDown.sendKeys(issue);
				issueTypeFiledDropDown.sendKeys(Keys.ENTER);
				
				bp.waitForElement();
				
				summary.sendKeys(Bug);
				summary.sendKeys(Keys.ENTER);
				
				bp.waitForElement();
				
				System.out.println("New defect is added at Execution level  successfully");	
				
				//driver.switchTo().frame(frame);
				return true;
	 		
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 		
	 	}
	 	
	 	public boolean add_comment_at_execution() throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			Thread.sleep(12000);
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(12000);
				driver.switchTo().frame(0);
				Thread.sleep(12000);
	 			
	 			Actions act=new Actions(driver);
	 			act.moveToElement(commentField).pause(4000).click().pause(12000).sendKeys("Add the comment at execution level").sendKeys(Keys.TAB).build().perform();
	 			
	 			log.info("Comment added to the execution level is successfully");
	 			
	 			
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	
	 	public boolean addcomment_steplevel() throws Exception {
	 		try {
	 			
	 			Thread.sleep(10000);
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(15000);
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
				
				Actions act=new Actions(driver);
	 			act.moveToElement(commentFieldatstep).click().pause(12000).sendKeys("Add the comment at Step level").sendKeys(Keys.TAB).build().perform();
	 			log.info("Comment added to the Step level is successfully");
	 			
	 		return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	
	 	
	 	public boolean editExecutionComment() throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			Thread.sleep(10000);
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(12000);
				driver.switchTo().frame(0);
				Thread.sleep(12000);
	 			
				Actions act=new Actions(driver);
	 			act.moveToElement(commentField).click().sendKeys("-add comment at execution").sendKeys(Keys.TAB).build().perform();
	 			log.info("Comment added to the execution level is successfully");
	 			//commentField.clear();
	 			//bp.waitForElement();
	 			Thread.sleep(4000);
	 			bp.eraseText(commentField);
	 			
				//editcomment.sendKeys("Edit comment at execution");
	 			act.sendKeys(Keys.TAB).pause(4000).moveToElement(commentField).click().sendKeys("-edit comment at execution").sendKeys(Keys.TAB).build().perform();
	 			log.info("Execution level Comment is edited Successfully");
				//act.sendKeys("Edit comment at execution").sendKeys(Keys.TAB);
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	
	 	public boolean editcommentsteplevel() throws Exception {
	 		try {
	 			Thread.sleep(10000);
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(10000);
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
				
				Actions act=new Actions(driver);
	 			act.moveToElement(commentFieldatstep).click().pause(12000).sendKeys("Step").sendKeys(Keys.TAB).build().perform();
	 			log.info("Comment added to the Step level is successfully");
	 			
	 			//to scroll down
	 			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
	 			
	 			Thread.sleep(5000);
	 			act.moveToElement(commentFieldatstep).click().pause(2000).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.BACK_SPACE).sendKeys(Keys.TAB).build().perform();
	 			//bp.eraseText(commentFieldatstep);
	 			//act.sendKeys(Keys.TAB).perform();
	 			Thread.sleep(5000);
	 			//to scroll down
	 			((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
	 			
	 			act.moveToElement(commentFieldatstep).click().sendKeys("-edit comment at step").sendKeys(Keys.TAB).build().perform();
	 			log.info("Step level Comment is edited Successfully");
	 			
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	
	 	
	 	public boolean addsteptoTest(String issue) throws Exception {
	 		try {
	 			
	 			/*bp = new CommonUtils();
				bp.waitForElement();
				
				zephyrPage.click();
				bp.waitForElement();
				searchtestbtn.click();
				//latestCreatedTest.click();
				log.info("Click on Test");
				Thread .sleep(8000);
				
				bp.waitForElement();
				
				dbutton.click();
				dbutton.click();
				log.info("Click on D icon");
				
				Thread.sleep(5000);
				WebElement frame = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame);
				
				for(int i=1 ; i<2 ;i++)
				{
					//bp.waitForElement();
					bp.fluentWait(step);
					bp.maxExplicitWait(step);
					bp.waitTillElementIsVisible(step);
					step.click();
					step.sendKeys("Test");
					
					bp.waitForElement();
					step.sendKeys(Keys.TAB);
					System.out.println("test step added successfully");
								
					data.click();
					data.sendKeys("data");
					bp.waitForElement();
					data.sendKeys(Keys.TAB);		
					System.out.println("test data added successfully");
					
					result.click();
					result.sendKeys("result");
					bp.waitForElement();
					result.sendKeys(Keys.TAB);
					System.out.println("test result added successfully");
					
					addstep.click();
					addstep.click();
					log.info("Teststep created Successfully");
					}	
					
					log.info("Teststep created Successfully2");
					driver.switchTo().defaultContent();          ;
          return true;*/
	 			
	 			//new added
	 			bp = new CommonUtils();
				bp.waitForElement();
				zephyrPage.click();
				bp.waitForElement();
				//to select newly created test/ top one test
				//SearchButton.click();
				searchtestbtn.click();
			//	driver.navigate().refresh();
				   Thread.sleep(6000);
					DIconButton.click();
					Thread.sleep(9000);
					bp.waitForElement();
					System.out.println("teststep block seen");
				
				WebElement frame = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame);
				System.out.println("iframe found");
				
				// to find below xpath under iframe
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", AddstepLink);
			
				Actions act = new Actions(driver);
				act.moveToElement(AddstepLink).click().pause(2000)
				.sendKeys("Test").sendKeys(Keys.TAB).pause(1000)
				.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
				.sendKeys("result").sendKeys(Keys.TAB)
				.sendKeys(Keys.ENTER)
				.perform();
				
				log.info("Teststep1 created Successfully");
				
				bp.waitForElement();
				
				act.pause(1000).sendKeys("Teststep2").sendKeys(Keys.TAB).pause(1000)
				.sendKeys("data2").sendKeys(Keys.TAB).pause(1000)
				.sendKeys("result2").sendKeys(Keys.TAB)
				.sendKeys(Keys.ENTER)
				.perform();
				System.out.println(" 2 Teststep created Successfully");
				bp.waitForElement();
			
				driver.switchTo().defaultContent();
				return true;
	 			
	 			
	 			
	 			
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	
	 	public boolean executeTestStep(String status) throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			Thread.sleep(10000);
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(15000);
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
				stepStatusDropdwn.click();
				Thread.sleep(3000);
				WebElement newstatus1 = driver.findElement(By.xpath(step1 + status + step2));
				
				
				//js.executeScript("window.scrollBy(0,3000)");
				//js.executeScript("window.scrollTo(0, document.body.scrollHeight)");
				//js.executeScript("arguments[0].scrollIntoView();", newstatus);
				
				Thread.sleep(3000);
				newstatus1.click();
				Thread.sleep(3000);
				WebElement Verifystepstatus = driver.findElement(By.xpath(step1 + status + step2));
				boolean stepstatusverify =Verifystepstatus.isDisplayed();
			    if (stepstatusverify)
			  {
				log.info("Validated the Steplevel Customstatus has been Updated");
			  }else {
				log.info("Steplevel Customstatus has not Updated:Fail");
			  }
				
				return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	public boolean executeAllStepWithSameStatus() throws Exception{
	 		try {
	 			
	 			bp = new CommonUtils();
	 			Thread.sleep(10000);
	 			
	 	        List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(15000);
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
				//stepStatusDropdwn.click();
				Thread.sleep(3000);
			
				Actions act = new Actions(driver);
	 			act.moveToElement(stepStatusDropdwn).click().pause(12000).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
	 			Thread.sleep(10000);
	 			act.moveToElement(stepStatusDropdwn1).click().pause(12000).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
	 			
	 			//act.moveToElement(stepStatusDropdwn2).click().pause(12000).sendKeys(Keys.ARROW_DOWN).pause(5000).sendKeys(Keys.DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
	 			
				//Thread.sleep(8000);
	 			//to scroll up
				JavascriptExecutor js1 = (JavascriptExecutor) driver;       		
		     
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", executeButton);
				
				Thread.sleep(3000);
	 			executeButton.click();
	 			log.info("Steps executed with single status and Overall Execution status is updated Successfully");
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	public boolean addAttachment_to_Execution(String filePath) throws Exception{
	 		try {
				
	 			bp = new CommonUtils();

                   Thread.sleep(10000);
	 			
	 	           List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				   System.out.println("The total number of iframes are " + frame.size());
				   Thread.sleep(15000);
				   driver.switchTo().frame(0);
				   Thread.sleep(8000);
				   bp.waitForElement();
				
					executionAttachment.click();
		 			bp.waitForElement();
		 			
		 			Actions act =new Actions(driver);
				    act.moveToElement(executionAttachment).click().sendKeys(Keys.PAGE_UP).perform();
						//executionAttachment.click();
			 	    bp.waitForElement();
			 			
			 		log.info("Click on add attachment at execution");
		 			
		 			/*JavascriptExecutor js = (JavascriptExecutor) driver;
					((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
		                      ,addFilesbtn);*/
					
					Thread.sleep(3000);
		 			//addFilesbtn.click();
		 			act.moveToElement(addFilesbtn).pause(3000).click().build().perform();
                    log.info("Click on Add files button in popup");

					bp.waitForElement();
					bp.waitForElement();
                    Thread.sleep(3000);
					bp.uploadFile(filePath);

					bp.waitForElement();
					attachButton.click();

				System.out.println("File Uploaded Successfully");

				return true;
			}
	 		
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	public boolean associatesubtask(String subtask) throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			bp.waitForElement();
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(12000);
				driver.switchTo().frame(0);
				Thread.sleep(12000);
	 			
	 			//executedefectsearch.click();
	 			//executedefectsearch.sendKeys(subtask);
	 			Actions acts = new Actions(driver);
				bp.waitForElement();
				acts.moveToElement(executedefectsearch).click().pause(1200).sendKeys(subtask).pause(12000).sendKeys(Keys.ENTER).perform();
				log.info("Associate Subtask to the Execution Successfully");
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	public boolean associate_existdefect_to_execution(String bug) throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			bp.waitForElement();
	 			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(12000);
				driver.switchTo().frame(0);
				Thread.sleep(12000);
	 			
				Actions acts = new Actions(driver);
				bp.waitForElement();
				acts.moveToElement(executedefectsearch).click().pause(1200).sendKeys(bug).pause(12000).sendKeys(Keys.ENTER).perform();
				log.info("Associate Existing bug to the Execution Successfully");
	 			return true;
	 		}catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	public boolean associate_NewDefect_Steplevel(String project, String issue,  String Bug) throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			Thread.sleep(10000);
	 			
	 	        List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(15000);
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
				//stepStatusDropdwn.click();
				Thread.sleep(3000);
			
				Actions act = new Actions(driver);
				act.moveToElement(stepdefectarrow).click().pause(2000).moveToElement(stepCreateDefectBtn).click().perform();
				
                driver.switchTo().defaultContent();
	 			
	 			bp.waitForElement();
	 			projectDropDown.sendKeys(Keys.CLEAR);
				projectDropDown.sendKeys(project);
				projectDropDown.sendKeys(Keys.ENTER);
					
				bp.waitForElement();
				Thread.sleep(1000);
				issueTypeFiledDropDown.sendKeys(Keys.CLEAR);
				issueTypeFiledDropDown.sendKeys(issue);
				issueTypeFiledDropDown.sendKeys(Keys.ENTER);
				
				bp.waitForElement();
				
				summary.sendKeys(Bug);
				summary.sendKeys(Keys.ENTER);
				
				bp.waitForElement();
				
				System.out.println("New defect is added at Step level  successfully");	
	 			
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
	 	
	 	
	 	public boolean associate_existbug_atstep() throws Exception {
	 		try {
	 			bp = new CommonUtils();
	 			Thread.sleep(10000);
	 			
	 	        List<WebElement> frame = driver.findElements(By.tagName("iframe"));
				System.out.println("The total number of iframes are " + frame.size());
				Thread.sleep(15000);
				driver.switchTo().frame(0);
				Thread.sleep(7000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
	                      ,stepStatusDropdwn);
				//stepStatusDropdwn.click();
				Thread.sleep(3000);
			
				Actions act = new Actions(driver);
				act.moveToElement(stepdefectarrow).click().pause(5000).moveToElement(stepdefectsearch).click().pause(3000).sendKeys("bug").pause(10000).moveToElement(stepdefectid).pause(3000).click().perform();
				
	 			log.info("Existing defect is associate to steps is successfully");
	 			
	 			return true;
	 		}
	 		catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	 	}
}