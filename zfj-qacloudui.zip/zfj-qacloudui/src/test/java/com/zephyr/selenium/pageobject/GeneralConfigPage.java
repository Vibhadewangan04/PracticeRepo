package com.zephyr.selenium.pageobject;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;


public class GeneralConfigPage {
	
	private static final String Test = null;
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;
	ViewIssuePage vip;
	AppsPage appp;
	GeneralConfigPage gcp;
	
	public GeneralConfigPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	
	@FindBy(xpath = "//input[@id='zephyr-issuelink-check']")
	protected WebElement issuelink;
	
	@FindBy(xpath = "//input[@id='zephyr-ril-check']")
	protected WebElement remotelink;
	
	@FindBy(xpath = "//button[@id='zephyr-clear-cache']")
	protected WebElement clearcache;
	
	@FindBy(xpath = "//div[@id='progressMsgDiv']")
	protected WebElement progressmessage;
	
	


	public boolean validateIssueLink() throws Exception {
	
		
		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			
			driver.switchTo().frame(0);
			System.out.println("Switched to iframe successfully");
			Thread.sleep(2000);
			bp.waitForElement();
			
			Actions act = new Actions(driver);
			boolean checkboxstatus = issuelink.isSelected();
			
			if(checkboxstatus==true) {
				bp.waitForElement();
				System.out.println("issue link is in enabled mode");	
				act.moveToElement(issuelink).click().perform();
				System.out.println("issue link disabled");	
				act.moveToElement(issuelink).click().perform();
				System.out.println("issue link re-enabled");
			}
			else
			{
				bp.waitForElement();
				System.out.println("issue link is in disabled mode");
				
				act.moveToElement(issuelink).click().perform();
				System.out.println("issue link enabled");
				
			}
			driver.navigate().refresh();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}	
		
	}


public boolean validateRemoteLink() throws Exception {
	
		
		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			
			driver.switchTo().frame(0);
			System.out.println("Switched to iframe successfully");
			Thread.sleep(2000);
			bp.waitForElement();
			
			Actions act = new Actions(driver);
			boolean checkboxstatus = remotelink.isSelected();
			
			if(checkboxstatus==true) {
				bp.waitForElement();
				System.out.println("remote link is in enabled mode");	
				act.moveToElement(remotelink).click().perform();
				System.out.println("remote link disabled");	
				act.moveToElement(remotelink).click().perform();
				System.out.println("issue link re-enabled");
			}
			else
			{
				bp.waitForElement();
				System.out.println("remote link is in disabled mode");
				
				act.moveToElement(remotelink).click().perform();
				System.out.println("remote link enabled");
				
			}
			driver.navigate().refresh();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}	
		
	}
	
	
public boolean validateClearCache() throws Exception {
	
	
	try{
		bp = new CommonUtils();
		bp.waitForElement();
		Thread.sleep(2000);
		
		driver.switchTo().frame(0);
		System.out.println("Switched to iframe successfully");
		Thread.sleep(2000);
		bp.waitForElement();
		
		clearcache.click();
		bp.waitForElement();
		
		boolean validateprogressmsg = progressmessage.isDisplayed();
		bp.waitForElement();
		Assert.assertEquals((progressmessage.getText()),"Cleared cache successfully.");
		
		driver.navigate().refresh();
		return true;
	}
	
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}	
	
}




	

}
