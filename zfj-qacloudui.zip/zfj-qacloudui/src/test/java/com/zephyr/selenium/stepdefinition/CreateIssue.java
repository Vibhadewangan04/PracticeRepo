package com.zephyr.selenium.stepdefinition;
import com.zephyr.selenium.pageobject.CreateIssuePage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;

import cucumber.api.java.en.*;

public class CreateIssue extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CreateIssuePage cip;
	
	String fileName = "CreateIssue";

	@Given("^User Selects Project, Issue Type, Enter Summary and Clicks on Create button$")
	public void user_clicks_on_Tests_clicks_on_Create_Test() throws Throwable {
	  
	cip = new CreateIssuePage(driver);
	String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
			+ CONFIG_FILE, "projectName");
	String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
			+ CONFIG_FILE, "issueTypeTest");
	String Test = "Test";
	cip.GlobalcreateTest(projectName, issueType, Test);
//	cip.ProjectLevelcreateTest(projectName, issueType, Test);
	System.out.println("Test created successfully");
	   
	    
	}
 
	@And("^User Selects Project, Issue Type Bug, Enter Summary and Clicks on Create button$")
	public void user_Selects_Project_Issue_Type_Bug_Enter_Summary_and_Clicks_on_Create_button() throws Throwable {
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeBug = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeBug");
		String Bug = "Bug";
		cip.GlobalcreateTest(projectName, issueTypeBug, Bug);
		System.out.println("Bug created successfully");
	}

	@And("^User Selects Project, Issue Type Story, Enter Summary and Clicks on Create button$")
	public void user_Selects_Project_Issue_Type_Story_Enter_Summary_and_Clicks_on_Create_button() throws Throwable {
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		cip.GlobalcreateTest(projectName, issueTypeStory, Story);
		System.out.println("Story created successfully");
	}
	
	@And("^User Selects Project, Issue Type Task, Enter Summary and Clicks on Create button$")
	public void user_Selects_Project_Issue_Type_Task_Enter_Summary_and_Clicks_on_Create_button() throws Throwable {
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeTask = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeTask");
		String Task = "Task";
		cip.GlobalcreateTest(projectName, issueTypeTask, Task);
		System.out.println("Task created successfully");
	}

	@And("^User Selects Project, Issue Type Epic, Enter Summary and Clicks on Create button$")
	public void user_Selects_Project_Issue_Type_Epic_Enter_Summary_and_Clicks_on_Create_button() throws Throwable {
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeEpic = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeEpic");
		String Epic = "Epic";
		cip.GlobalcreateTest(projectName, issueTypeEpic, Epic);
		System.out.println("Epic created successfully");
	}

	/*@Given("^verify Bdd_Background option in menu$")
	public void verify_Bdd_Background_option_in_menu() throws Throwable {
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		cip.verifyBdd_Backgroundoption();
	}*/

	@Given("^User Create Subtask$")
	public void user_Create_Subtask() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeSubtask = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeSubTask");
		String Subtask = "Sub-task";
		cip.GlobalcreateTest(projectName, issueTypeSubtask, Subtask);
//		cip.ProjectLevelcreateTest(projectName, issueType, Test);
		System.out.println("Subtask created successfully");
		
	}

}