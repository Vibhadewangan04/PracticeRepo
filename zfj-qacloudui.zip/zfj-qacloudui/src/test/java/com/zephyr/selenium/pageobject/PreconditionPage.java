package com.zephyr.selenium.pageobject;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;


public class PreconditionPage {
	
	private static final String Test = null;
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;

	public PreconditionPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	//@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	@FindBy(xpath = "//a[@href='/jira']")
	protected WebElement jirahomepage;
	
	@FindBy(xpath = "//span[contains(text(),'Apps')]")
	protected WebElement apps;
	
	@FindBy(xpath = "//span[contains(text(),'Zephyr')]")
	protected WebElement zephyrtop;
	
	@FindBy(xpath = "//span[contains(text(),'Projects')]")
	protected WebElement projects;

	@FindBy(xpath = "//span[contains(text(),'Create project')]")
	protected WebElement createproject;
	
	@FindBy(xpath = "//span[contains(text(),'View all projects')]")
	protected WebElement viewallproject;
	
	@FindBy(xpath = "//span[@aria-label='Warning']")
	protected WebElement projectexists;
	
	@FindBy(xpath = "//div[text()='A version with this name already exists in this project.']")
	protected WebElement versionexists;
	
	@FindBy(xpath = "//span[@aria-label='warning']")
	protected WebElement compexists;
	
	
	@FindBy(xpath = "//span[@aria-label='Close']")
	protected WebElement pclose;

	
	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	protected WebElement Zephyr;
	
	@FindBy(xpath = "//*[contains(text(),'Search Tests')]")
	protected WebElement searchtests;
	
	
	//@FindBy(xpath = "//div[contains(text(),'Classic project')]")
	@FindBy(xpath = "//span[contains(text(),'Select classic')]")
	protected WebElement classicproject;
	
	@FindBy(xpath = "//span[contains(text(),'Change template')]")
	protected WebElement changetemplate;
	
	@FindBy(xpath = "//*[text() = 'Scrum']")
	protected WebElement selectscrum;
	
	//@FindBy(xpath = "(//input[@value=''])[2]")
	@FindBy(xpath = "(//input[@placeholder=\"Enter a project name\"]")
	protected WebElement enterprojectname;
	
	@FindBy(xpath = "//*[text() = 'Advanced']")
	protected WebElement advancedbutton;
	
	@FindBy(xpath = "(//*[text() ='Create'])[2]")
	protected WebElement createbutton;
	
	@FindBy(xpath = "//*[text()='Project settings']")
	protected WebElement projectsettings;	
	
	@FindBy(xpath = "//*[text()='Issue types']")
	protected WebElement issuetypes;	
	
	@FindBy(xpath = "//*[@id='project-config-tab-actions']")
	protected WebElement actionsbutton;
	
	@FindBy(xpath = "//*[@id='project-config-issuetype-scheme-edit']")
	protected WebElement editissuetype;
	
	@FindBy(xpath = "//*[@id='selectedOptionsAddAll']")
	protected WebElement addallissuetype;
	
	@FindBy(xpath = "//*[@id='submitSave']")
	protected WebElement saveissuetype;
	
	@FindBy(xpath = "//input[@name='search']")
	protected WebElement searchproject;
	
	//@FindBy(xpath = "(//span[@aria-label='More'])[1]")
	@FindBy(xpath = "//span[contains(text(),'Automation Project')]")
	protected WebElement clickselectedproject;
		
	@FindBy(xpath = "//div[text()='Releases']")
	protected WebElement releases;
	
	@FindBy(xpath = "//*[text()='Create version']")
	protected WebElement createversion;
	
	@FindBy(xpath = "//*[@id='jira']/div[5]/div[2]/div/div[3]/div[2]/div/div/div[2]/div/div/div/div[1]/div/div/div/input")
	protected WebElement versionname;
	
	@FindBy(xpath = "//*[@id='jira']/div[5]/div[2]/div/div[3]/div[2]/div/div/div[2]/div/div/div/div[3]/div/div/div/input")
	protected WebElement versiondescription;	
	
	@FindBy(xpath = "//*[text()='Save']")
	protected WebElement windowsave;
	
	@FindBy(xpath = "//span[text()='Cancel']")
	protected WebElement windowcancel;
	
	
	@FindBy(xpath = "//div[text()='Components']")
	protected WebElement components;
	
	@FindBy(xpath = "//*[text()='Create component']")
	protected WebElement createcomponent;
	
	@FindBy(xpath = "//*[@id='jira']/div[3]/div[3]/div/div[3]/div[2]/div/div/div[2]/div/div/div/div[1]/div/div/div/input")
	protected WebElement componentname;
	
	@FindBy(xpath = "//span[@aria-label='Settings']")
	protected WebElement jirasettings;
	
	@FindBy(xpath = "//span[contains(text(),'Issues')]")
	protected WebElement issues;
	
	@FindBy(xpath = "//div[contains(text(),'Time tracking')]")
	protected WebElement timetracking;
	
	@FindBy(xpath = "//*[@id='time-tracking-enabled-toggle-input']")
	protected WebElement enabletimetracking;
	
	@FindBy(xpath = "//div[10]/a/div/div")
	protected WebElement screens;
	
	
	
	@FindBy(xpath = "//*[@id='field-picker-field']")
	protected WebElement selectfield;
	
	@FindBy(xpath = "//td[text()='Time tracking']")
	protected WebElement timetrackexists;
	

	@FindBy(xpath = "//*[@id='filter-screens']//input")
	protected WebElement searchscheme;
	
	@FindBy(xpath = "//*[@id='toggle-description-container']/div")
	protected WebElement timetrackingdescription;
	
	//@FindBy(xpath = "//a[@data-id='basic']")
	//protected WebElement advancedsearch;
	
	@FindBy(xpath = "//*[@id='search-header-view']//button")
	protected WebElement savefilterbutton;
	
	@FindBy(xpath = "//input[@type='text']")
	protected WebElement filtertextfield;
	
	@FindBy(xpath = "//input[@type='submit']")
	protected WebElement submitfilter;
	
	
	@FindBy(xpath = "//*[@id='filterName']")
	protected WebElement enterfiltername;
	
	@FindBy(xpath = "//a[@data-id='basic']")
	protected WebElement basicviewbutton;
	
	@FindBy(xpath = "//*[@id='advanced-search']")
	protected WebElement advancesearch;
	
	@FindBy(xpath = "//div[@class='error']")
	protected WebElement filtererror;
	
	@FindBy(xpath = "//*[@id='save-filter-form']/div[3]/div/a")
	protected WebElement cancelbutton;
	
	@FindBy(xpath = "//h1[@class='search-title']")
	protected WebElement filtersearchtext;
	
	//top menu xpath
	@FindBy(xpath = "//*[@id='com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__cycle-summary-nav-top-adg']")
	protected WebElement cylesummary;
	
	@FindBy(xpath = "//*[@id=\'com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__search-test-executions-projectCentric\']")
	protected WebElement searchtestexecution;
	
	@FindBy(xpath = "//*[@id='com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__manage-execution-filters-projectCentric']")
	protected WebElement managefilters;
	
	@FindBy(xpath = "//*[@id='com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__test-metrics']")
	protected WebElement testmetrics;
	
	@FindBy(xpath = "//*[@id=\'com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__tests-test-summary-nav-top-adg\']")
	protected WebElement testsummary;
	
	@FindBy(xpath = "//*[@id='com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__tests-traceability-nav-top-adg']")
	protected WebElement traceability;
	
	@FindBy(xpath = "//*[@id='com.atlassian.plugins.atlassian-connect-plugin:com.thed.zephyr.je__zephyr-apikey']")
	protected WebElement apikeys;
	
	@FindBy(xpath = "//*[@id='apiKeyRemoveAdgIcon']")
	protected WebElement deletepath;
	
	@FindBy(xpath = "//button[@id='api-key-delete-dialog-delete-button']")
	protected WebElement deletebutton;
	
	@FindBy(xpath = "//*[@id='create-user-key']")
	protected WebElement generatenewkey;
	
	@FindBy(xpath = "//*[@id='creations_date']")
	protected WebElement creationdate;
	
	@FindBy(xpath = "//*[@id='api-key-dialog-close-button']")
	protected WebElement closedialog;
	
	
	
	
	
	/********* For Selecting Configure option **********/
	
	protected String valConfigure1 = "//*[@id='configure_fieldscreen_";
	protected String  valConfigure2= ": Scrum Default Issue Screen']";
	
	protected String zqlFilter1 = "project = '";
	protected String  zqlFilter2= "' AND issuetype = Test";
	

		
	
	public boolean createProject(String projectname, String projectkey) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			projects.click();
			System.out.println("Clicked on Projects Menu");
			//Thread.sleep(2000);
			bp.waitForElement();
			createproject.click();
			
			System.out.println("Clicked on create project button");
			bp.waitForElement();
			Thread.sleep(2000);
			classicproject.click();
			System.out.println("Clicked on classic project sytle");
			bp.waitForElement();
			changetemplate.click();
			System.out.println("clicked on change template");
			bp.waitForElement();
			selectscrum.click();
			bp.waitForElement();
			Actions act = new Actions(driver);
			act.sendKeys(projectname).pause(1200).sendKeys(Keys.TAB).perform();
			Thread.sleep(2000);
			
			bp.waitForElement();
			
			boolean pexists = projectexists.isEnabled();
			
			if(pexists) {		
				pclose.click();
				System.out.println("Project already exists");
				return true;			
			}
			else {
			
			
			act.sendKeys(Keys.BACK_SPACE).pause(1400).sendKeys(projectkey).perform();
			Thread.sleep(2000);
			bp.waitForElement();
			
			createbutton.click();	
			
			return true;
			
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		}


	public boolean NavigateToProject(String projectname) throws Exception{
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			driver.navigate().refresh();
			bp.waitForElement();
			
			jirahomepage.click();
			System.out.println("Navigate to Jira Home page");
			bp.waitForElement();
			
			projects.click();
			System.out.println("Clicked on Projects Menu");
			bp.waitForElement();
			Thread.sleep(1000);
			
			viewallproject.click();
			bp.waitForElement();
			System.out.println("Clicked on all projects list");
			
			Actions act = new Actions(driver);
			act.moveToElement(searchproject).click().pause(1200).sendKeys(projectname).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			bp.waitForElement();
			clickselectedproject.click();
			
			bp.waitForElement();
			System.out.println("Clicked on selected project");
			//System.out.println("Clicked on more options");
			
			return true;
			
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		
		
		
	}
	
	
	
	
	
	
	
	public boolean AddIssueTypeToProject(String projectname) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
//			projects.click();
//			System.out.println("Clicked on Projects Menu");
//			bp.waitForElement();
//			
//			viewallproject.click();
//			bp.waitForElement();
//			System.out.println("Clicked on all projects list");
//			
//			Actions act = new Actions(driver);
//			act.moveToElement(searchproject).click().pause(1200).sendKeys(projectname).pause(1200).sendKeys(Keys.ENTER).perform();
//			Thread.sleep(2000);
//			
//			clickselectedproject.click();
//			
//			bp.waitForElement();
//			System.out.println("Clicked on more options");
//			
//			projectsettings.click();
//			bp.waitForElement();
//			System.out.println("Clicked on project settings >> landed to selected project page");
			
			NavigateToProject(projectname);
			bp.waitForElement();
		
			projectsettings.click();
			bp.waitForElement();
			System.out.println("Clicked on project settings");
			
			issuetypes.click();
			bp.waitForElement();
			System.out.println("Clicked on Issue type");
			
			actionsbutton.click();
			bp.waitForElement();
			System.out.println("Clicked on actions button");
			
			editissuetype.click();
			bp.waitForElement();
			System.out.println("Clicked on edit issue type");
			
			addallissuetype.click();			
			bp.waitForElement();
			
			saveissuetype.click();
			
			return true;
	}
		 catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}


	public boolean createVersion(String projectname, String version1, String version2) throws Exception {
		
		try {
			bp = new CommonUtils();
			//bp.waitForElement();
			
//			driver.navigate().refresh();
//			bp.waitForElement();
//			
//			jirahomepage.click();
//			System.out.println("Navigate to Jira Home page");
//			bp.waitForElement();
//			
//			Thread.sleep(2000);
//			projects.click();
//			System.out.println("Clicked on Projects Menu");
//			bp.waitForElement();
//
//			viewallproject.click();
//			bp.waitForElement();
//			System.out.println("Clicked on all projects list");
//			
//			Actions act = new Actions(driver);
//			act.moveToElement(searchproject).click().pause(1200).sendKeys(projectname).pause(1200).sendKeys(Keys.ENTER).perform();
//			Thread.sleep(2000);
//			
//			clickselectedproject.click();
//			
//			bp.waitForElement();
//			
//			bp.waitForElement();
//			System.out.println("Clicked on more options");
//			
//			projectsettings.click();
//			bp.waitForElement();
//			System.out.println("Clicked on project settings >> landed to selected project page");
//			
			
			NavigateToProject(projectname);
			bp.waitForElement();
			
			releases.click();
		    System.out.println("Clicked on Releases");
		    
		    System.out.println("creating version");
		    bp.waitForElement();
		    
		    createversion.click();
		    bp.waitForElement();
		    Thread.sleep(2000);
		    Actions act = new Actions(driver);
		    act.sendKeys(version1).pause(3000).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			
			bp.waitForElement();
			windowsave.click();
			
			bp.waitForElement();
			
			boolean verexist = versionexists.isEnabled();
			
			if(verexist)
			{
				System.out.println("Version already exists");
				windowcancel.click();
				bp.waitForElement();	
			}
			
			else
			{
				System.out.println("Creating another version");
			}
			
			createversion.click();
			bp.waitForElement();
			
			act.sendKeys(version2).pause(3000).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			
			bp.waitForElement();
			windowsave.click();
			
			bp.waitForElement();
			
			boolean verexist1 = versionexists.isEnabled();
			
			if(verexist1)
			{
				System.out.println("Version already exists");
				windowcancel.click();
				bp.waitForElement();	
			}
			
			else
			{
				System.out.println("OOPS version already present");
			}
			
			
		return true;
			
		
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
}
	
	
public boolean createComponent(String projectname, String component1, String component2) throws Exception {
		
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
//			driver.navigate().refresh();
//			bp.waitForElement();
//			
//			jirahomepage.click();
//			System.out.println("Navigate to Jira Home page");
//			bp.waitForElement();
//			
//			Thread.sleep(2000);
//			projects.click();
//			System.out.println("Clicked on Projects Menu");
//			
//			Actions act = new Actions(driver);
//			act.moveToElement(searchproject).click().pause(1200).sendKeys(projectname).pause(1200).sendKeys(Keys.ENTER).perform();
//			Thread.sleep(2000);
//			
//			clickselectedproject.click();
//			
//			bp.waitForElement();
//			
//			bp.waitForElement();
//			System.out.println("Clicked on more options");
//			
//			projectsettings.click();
//			bp.waitForElement();
//			System.out.println("Clicked on project settings >> landed to selected project page");
			
			NavigateToProject(projectname);
			bp.waitForElement();
			
			components.click();
		    System.out.println("Clicked on Components");
		    
		    System.out.println("creating components");
		    
		    createcomponent.click();
		    bp.waitForElement();
		    Actions act = new Actions(driver);
		    act.sendKeys(component1).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			
			bp.waitForElement();
			windowsave.click();
			bp.waitForElement();
			boolean compexist = compexists.isEnabled();
			
			if(compexist)
			{
				System.out.println("component already exists");
				windowcancel.click();
				bp.waitForElement();	
			}
			
			else
			{
				System.out.println("Creating another component");
			}
			
			bp.waitForElement();
			createcomponent.click();
			bp.waitForElement();
			
			
			act.sendKeys(component2).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			
			bp.waitForElement();
			windowsave.click();
			bp.waitForElement();
			boolean compexist1 = compexists.isEnabled();
			
			if(compexist1)
			{
				System.out.println("component already exists");
				windowcancel.click();
				bp.waitForElement();	
			}
			
			else
			{
				System.out.println("OOPS component already present");
			}
			
			
		return true;
			
		
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
}
	

public boolean enableTimetracking() throws Exception {
	
	try {
		
	
		bp = new CommonUtils();
		bp.waitForElement();
		
		driver.navigate().refresh();
		bp.waitForElement();
		
		jirahomepage.click();
		System.out.println("Navigate to Jira Home page");
		bp.waitForElement();
		
		jirasettings.click();
		System.out.println("Clicked on Jira Settings");
		bp.waitForElement();
		
		issues.click();
		System.out.println("Clicked on Issues");
		bp.waitForElement();
		
		timetracking.click();
		System.out.println("Clicked on Timetracking Menu");
		bp.waitForElement();
		
		 System.out.println("By default Time tracking is enabled for all projects");
			
		//String toggletext = timetrackingdescription.getText();
		//System.out.println("Toggle text is" +toggletext);
		//String actualtext = "Time tracking is currently enabled for all projects.";
		
//		if (toggletext.equals(actualtext))
//		{
//			 System.out.println("Time tracking is already enabled for all projects");
//		 }
//		 else
//		 {			
//			 bp.waitForElement();
//			 Thread.sleep(2000);
//		     enabletimetracking.click();
//		 }	
//		
//		bp.waitForElement();		
	return true;
		
	
}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
} 




public boolean timetrackingScreen(String projectscreenkey, String projectkey) throws Exception {
	
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		driver.navigate().refresh();
		bp.waitForElement();
		
		jirahomepage.click();
		System.out.println("Navigate to Jira Home page");
		bp.waitForElement();
		
		jirasettings.click();
		System.out.println("Clicked on Jira Settings");
		bp.waitForElement();
		
		issues.click();
		System.out.println("Clicked on Issues");
		bp.waitForElement();
		
		screens.click();
		System.out.println("Clicked on Screens Menu");
		Thread.sleep(2000);
		bp.waitForElement();
		
		Actions act = new Actions(driver);
		act.moveToElement(searchscheme).click().pause(1200).sendKeys(projectscreenkey).pause(1200).sendKeys(Keys.ENTER).perform();
		Thread.sleep(2000);
		
		bp.waitForElement();
		
		//configure.click();
		driver.findElement(By.xpath(valConfigure1 + projectkey + valConfigure2))
		.click();
		
		bp.waitForElement();
		
		boolean trimtrack = timetrackexists.isDisplayed();
		
		if(trimtrack)
		{
			System.out.println("Time tracking is already enabled");
		}
		
		else
		{
		act.moveToElement(selectfield).click().pause(1200).sendKeys("Time Tracking").pause(1200).sendKeys(Keys.ENTER).perform();
		bp.waitForElement();
		
		}
				
	return true;
		
	
}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}	
	



public boolean createFilter(String projectname, String filtername) throws Exception {
	
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
//		driver.navigate().refresh();
//		bp.waitForElement();
//		
//		jirahomepage.click();
//		System.out.println("Navigate to Jira Home page");
//		bp.waitForElement();
		
		NavigateToProject(projectname);
		bp.waitForElement();
		
		Zephyr.click();
		System.out.println("Clicked on Zephyr Menu");
		
		bp.waitForElement();
		
		searchtests.click();
		System.out.println("Clicked on Search Issues Menu");
		bp.waitForElement();
		
		String searchtype = basicviewbutton.getText();
		String actualtext = "Advanced";
		
		if (searchtype.equals(actualtext))
		{
			 System.out.println("user is in basic view, switching to advanced view");
			 basicviewbutton.click();
			 bp.waitForElement();
		 }
		 else
		 {			
			 System.out.println("User is already in advanced view");
			 bp.waitForElement();
			 
		 }	
		
		bp.waitForElement();
		Actions act = new Actions(driver);
		act.moveToElement(advancesearch).click().perform();
		//bp.waitForElement();
		
		//bp.eraseText(advancesearch);
		advancesearch.clear();
		
		bp.waitForElement();
		String zqlfilter = zqlFilter1+projectname+zqlFilter2;
		
		act.moveToElement(advancesearch).click().pause(1200).sendKeys(zqlfilter).pause(1200).sendKeys(Keys.ENTER).perform();
		
		bp.waitForElement();
		
		savefilterbutton.click();
		System.out.println("Saving filter");
		bp.waitForElement();
		Thread.sleep(2000);
		
		
		filtertextfield.sendKeys(filtername);
		bp.waitForElement();
		submitfilter.sendKeys(Keys.ENTER);
		
		bp.waitForElement();
		Thread.sleep(2000);
		
		if(filtersearchtext.getAttribute("title").equals(filtername))
		{
			return true;
		}
		
		else{
		
		System.out.println(filtererror.getText());
		
		boolean status = filtererror.isDisplayed();
		
		if(status)
		{
			bp.waitForElement();
			Thread.sleep(2000);
			act.sendKeys(Keys.TAB).pause(1200).sendKeys(Keys.TAB).pause(1200).sendKeys(Keys.ENTER).perform();
			
		}
		
		else
		{
			System.out.println("Filter already present");
			
			
		}

		return true;
		}
}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	
}


public boolean navigateTopZephyr() throws Exception {
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		driver.navigate().refresh();
		bp.waitForElement();
		
		apps.click();
		log.info(apps);
		bp.waitForElement();
		zephyrtop.click();
		log.info(zephyrtop);
		
		return true;
		
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	
}


public boolean validateAllZephyrApps() throws Exception {
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		bp.waitForElement();
		
		cylesummary.click();
		log.info(cylesummary);
		log.warn(cylesummary, null);
		bp.waitForElement();
		
		searchtestexecution.click();
		log.info(searchtestexecution);
		log.warn(searchtestexecution, null);
		bp.waitForElement();
		
		managefilters.click();
		log.info(managefilters);
		log.warn(managefilters, null);
		bp.waitForElement();
		
		testmetrics.click();
		log.info(testmetrics);
		log.warn(testmetrics, null);
		bp.waitForElement();
		
		testsummary.click();
		log.info(testsummary);
		log.warn(testsummary, null);
		bp.waitForElement();
		
		traceability.click();
		log.info(traceability);
		log.warn(traceability, null);
		bp.waitForElement();
		
		return true;
		
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
}


public boolean validatApiKeys() throws Exception {
	try {
		bp = new CommonUtils();
		bp.waitForElement();
		
		apikeys.click();
		log.info(apikeys);
		log.warn(apikeys, null);
		bp.waitForElement();
		Thread.sleep(2000);
		//driver.switchTo().defaultContent();
		
		driver.switchTo().frame(1);	
		
		System.out.println("switched to iframe successfully");
		bp.waitForElement();
		
		Thread.sleep(2000);
		driver.findElement(By.cssSelector("#apiKeyRemoveAdgIcon path")).click();
		bp.waitForElement();
		
		deletebutton.click();
		bp.waitForElement();
		
		generatenewkey.click();
		bp.waitForElement();
		
		String crdate = creationdate.getText();
		System.out.println("Api keys creation date is" +crdate);
		
	/*	System.out.println("converting creation date in hh:mm format");
		
		
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");  
		LocalDateTime now = LocalDateTime.now();  
		System.out.println(now);
		System.out.println(dtf.format(now));
		
		String actualdate=dtf.format(crdate);
		String expecteddate=dtf.format(now);
		
		if(actualdate==expecteddate) {
			
			System.out.println("api keys creation date validates successfully");
			
		}
		
		else {
			
			System.out.println("api keys creation date not validated successfully");
		}

	*/	
	    bp.waitForElement();
	    closedialog.click();
	    bp.waitForElement();
		return true;
		
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
}	
	


}