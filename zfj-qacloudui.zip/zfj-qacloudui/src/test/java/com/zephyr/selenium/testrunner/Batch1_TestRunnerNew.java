package com.zephyr.selenium.testrunner;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;

@RunWith(Cucumber.class)
@CucumberOptions(features = { "src/test/java/Batch1_Features" },
//tags={"@Create"},
tags = { "@ViewIssue2" }, 
glue = { "com.zephyr.selenium.stepdefinition" }, plugin = {
		"html:target/cucumber-html-report", "junit:target/cucumber_batch1.xml",
		"pretty:target/cucumber-pretty.txt", "rerun:target/rerun.txt",
		"usage:target/cucumber-usage.json", "json:target/cucumber25.json" }, monochrome = false)
public class Batch1_TestRunnerNew extends AbstractTestNGCucumberTests {

}
