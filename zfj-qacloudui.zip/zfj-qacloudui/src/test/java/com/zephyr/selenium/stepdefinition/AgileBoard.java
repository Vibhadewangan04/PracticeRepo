package com.zephyr.selenium.stepdefinition;
import java.io.File;

import org.testng.asserts.SoftAssert;

import com.zephyr.selenium.pageobject.AgileBoardPage;
import com.zephyr.selenium.pageobject.CreateIssuePage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.pageobject.PlanTestCyclePage;
import com.zephyr.selenium.pageobject.SearchTestExecutionPage;
import com.zephyr.selenium.pageobject.ViewIssuePage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;


import cucumber.api.java.en.*;

public class AgileBoard extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CreateIssue ci;
	SearchTestExecutionPage ste;
	ViewIssuePage vip;
	PlanTestCyclePage ptps;
	CreateIssuePage cip;
	AgileBoardPage agp;
	SoftAssert soft = new SoftAssert();
	
	String fileName = "ViewIssue";
	
	/*@Given("^Navigate to created project$")
	public void navigate_to_created_project() throws Throwable {
	    
		try{
			vip = new ViewIssuePage(driver);
			
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			vip.navigateToProject(Pname);
			System.out.println("check page-view issue Page Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

			}
	*/
	
	
	@Given("^Agile User Navigates to Project$")
public void navigate_project_for_view_issue() throws Throwable {
	    
		try{
			agp = new AgileBoardPage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			agp.navigateToProject(Pname);
			System.out.println("Navigated to project Successfully");    
			}
		 
			catch (Exception e) {
				/*lb.getScreenShot(fileName);
				e.printStackTrace();
				*/
				driver.close();
				throw e;
				}
	
	}
	
	
	
	@When("^Agile-User is under zephyr menu$")
	public void user_is_in_ZephyrMenu_Page() throws Throwable {
		ci = new CreateIssue();
		agp = new AgileBoardPage(driver);
		agp.validateAgileBoardPage();
		log.info("Zephyr Page and Validated page Successfully");
	
	}
	

		@When("^User is in Backlog Page and Validate the page$")
		public void user_is_in_View_Issue_Page() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.validateAgileBoardPage();
			
			log.info("user in AgileBoardPage and Validated page Successfully");
			
			/*ci.user_clicks_on_Tests_clicks_on_Create_Test();
			vip.goToSearchTest();
			vip.goToListView();*/
		}
		
	

		@Then("^Create sprint$")
		public void Create_sprint() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.createSprint();
			
			log.info("created sprint Successfully");
		
		}
		
		@Then("^Quick Execute Execution in By Issue view$")
		public void Quick_Execute_Execution() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.IssueView();
			
			log.info("Successfully executed");
		
		}

		@Then("^Link Cycle To Sprint$")
		public void LinkCycle_To_Sprint() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.linkSingleCycleToSprint();
			
			log.info("Successfully linked cycle to sprint");
		
		}
		
		@Then("^Link multiple Cycle To Sprint$")
		public void LinkCycless_To_Sprint() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.linkCycleToSprint();
		//	agp.linkFolderToSprint();
			
			log.info("Successfully linked cycles  to sprint");
		
		}
		
		@Then("^Execute Execution By E button$")
		public void Execute_Execution_By_Ebutton() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.ExecuteExecutionByEbutton();
			
			log.info("Successfully executed");
		
		}
		
		@Then("^Filter By status$")
		public void Filter_By_status() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.StatusFilter();
			
			log.info("Filter By status Successfully");
		
		}
		
		@Then("^Remove Linked Cycle To Sprint$")
		public void Remove_Linked_Cycle_To_Sprint() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.RemovelinkedcycleFolderToSprint();
			log.info("Successfully removed linked cycle to sprint");
		
		}

		@Then("^Quick Execute Execution in By Sprint view$")
		public void Execute_Execution_in_sprintView() throws Throwable {
			agp = new AgileBoardPage(driver);
			agp.ExecuteExecutionInSprintView();
			log.info("Successfully executed");
		
		}
				
		@Then("^agile Add the test cases$")
		public void user_clicks_on_GlobalCreate_Test() throws Throwable {
			  
			cip = new CreateIssuePage(driver);
			vip = new ViewIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			cip.GlobalcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");			    
			}
		
		
		
		@Then("^agile Add the test cases at projectLevel$")
		public void user_clicks_on_Tests_clicks_on_Create_Test() throws Throwable {
			  
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			cip.ProjectLevelcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");    
			}
			    

		
		

	

}