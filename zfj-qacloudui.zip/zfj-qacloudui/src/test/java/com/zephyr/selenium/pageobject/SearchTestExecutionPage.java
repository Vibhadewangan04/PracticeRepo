package com.zephyr.selenium.pageobject;

import java.io.File;

import javax.swing.Action;

import org.apache.log4j.Logger;
import org.apache.xmlbeans.soap.SOAPArrayType;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import static org.testng.Assert.assertEquals;
import java.util.List;


public class SearchTestExecutionPage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;

	public SearchTestExecutionPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	@FindBy(xpath = "(//*[text()='Tests'])")
	protected WebElement test;

	@FindBy(xpath = "(//*[text()='Search Test Executions'])")
	protected WebElement searchTestExecution;
	
	
	//@FindBy(xpath = "((//*[@class='_2po-RCTEyN6ZJsP-FepcJZ'])[1])")
	//@FindBy(xpath = "//*[@class='GridElement__Grid-sc-6y1aox-0 elhvIs']")
		
	@FindBy(xpath = "(//*[@class='Icon__IconWrapper-dyhwwi-0 bcqBjl'])[1]")
	protected WebElement expand;

	@FindBy(xpath = "(//a[text()='Advanced'])")
	protected WebElement advanced1;
	
	@FindBy(xpath = "//div[@class='search-type']/a")
	protected WebElement advancesearch;
	
	
	
	@FindBy(xpath = "(//*[text()='Filters'])")
	protected WebElement Filter;
	
	
	@FindBy(xpath = "//*[@id='zqltext']")
	protected WebElement clickOnSearchTextArea;
	
	@FindBy(xpath = "(//a[text()='My Executed Tests'])")
	protected WebElement myExecutedTests;
	
	@FindBy(xpath = "(//a[text()='My Failed Executions'])")
	protected WebElement myFailedExecutions;
	
	@FindBy(xpath = "(//*[text()='All Unexecuted Tests'])")
	protected WebElement allUnexecutedTests;
	
	@FindBy(xpath = "(//*[text()='All Executed Tests'])")
	protected WebElement allExecutedTests;
	
	@FindBy(xpath = "(//*[text()='All Failed Executions'])")
	protected WebElement allFailedExecutions;
	
	@FindBy(xpath = "(//*[text()='Assigned To Me'])")
	protected WebElement assignedToMe;
	
	
	@FindBy(xpath = "//*[@id='zephyr-transform-all']")
	protected WebElement searchButton;
	
	@FindBy(xpath = "//span[text()='XML']")
	protected WebElement xmlExport;
	
	@FindBy(xpath = "//span[text()='CSV']")
	protected WebElement csvExport;
	
	@FindBy(xpath = "//span[text()='HTML']")
	protected WebElement htmlExport;
	
	@FindBy(xpath = "((//*[@class='_1ZXZv2ZGgC5zQ-hMZNRnip'])[4])")
	protected WebElement Export;
	
	@FindBy(xpath = "//*[contains(text(),'Search Test Executions')]")
	protected WebElement launchSTEPage;
	
	@FindBy(xpath = "(//*[contains(text(),'Execution Status')])[2]")
	protected WebElement checkExecutionDisplay;
		
	@FindBy(xpath = "(//span[@class='custom-lozenges'])[1]")
	protected WebElement clickOnStatusDropDown;
	
	@FindBy(xpath = "(//button[@type='submit'])[2]")
	protected WebElement selectStatus;
	
	@FindBy(xpath = "(//input[@type='checkbox'])[1]")
	protected WebElement selectCheckbox;
	
	
	@FindBy(xpath = "//*[contains(text(),'Tools')]")
	protected WebElement selectTools;
			
	@FindBy(xpath = "//*[@id='uid2']/span[1]/span/span")
	protected WebElement selectStatusFromTools;
	
	@FindBy(xpath = "//*[@id='uid2']/span[4]/span/span")
	protected WebElement selectAssignExecutionsFromTools;
	
	@FindBy(xpath = "//*[@id='uid2']/span[7]/span/span")
	protected WebElement selectDeleteFromTools;
		
	@FindBy(xpath = "(//*[contains(text(),'Select...')])[2]")
	protected WebElement selectStatusDropDown;
	
	@FindBy(xpath = "(//*[contains(text(),'Delete')])[2]")
	protected WebElement selectDelete;
	
	@FindBy(xpath = "//*[contains(text(),'Close')]")
	protected WebElement selectClose;
	
	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	protected WebElement zephyrPage;
	
	@FindBy(xpath = "(//*[text()='E'])[1]")
	protected WebElement Ebtn;
	
	//
	@FindBy(xpath = "(//a[@target='_parent'])[1]")
	protected WebElement cyclename;
	
	@FindBy(xpath = "(//*[@class='Icon__IconWrapper-dyhwwi-0 bcqBjl'])[3]")
	protected WebElement button;
	
	@FindBy(xpath = "//*[text()='Detail View']")
	protected WebElement detailview;
	
	@FindBy(xpath = "//*[contains(text(),'Assign Executions')]")
	protected WebElement bulkAssign;
	
	@FindBy(xpath = "//*[@class='trigger-dropDown']")
	protected WebElement bulkAssignDropDown;
	
	/******************************* String protected *******************************/
	protected String zqlFilter1 = "project = '";
	
	protected String  zqlFilter2= "' AND executionStatus = '";
	
	protected String zqlFilter3 = "'";

	public String assignee1 ="//*[@class='list-wrapper'and @data-displayname='";
	public String assignee2 ="']";
	
	
	public boolean exportInDifferentFormat(String exportType) throws Exception {
		try {
			bp = new CommonUtils();

			
			bp.waitForElement();
			
			if (exportType.equalsIgnoreCase("xmlFormat")) 
			{
				
				WebElement iframe = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(iframe);
				bp.waitForElement();
				bp.waitForElement();
				bp.explicitWait(Export);
				Export.click();
				bp.waitForElement();
				xmlExport.click();
				Thread.sleep(50000);
				System.out.println("File: xml format exported successfully");
				driver.navigate().refresh();
				
			}	
			else if (exportType.equalsIgnoreCase("csvFormat"))
			{
				WebElement iframe = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(iframe);
				bp.waitForElement();
				bp.waitForElement();
				bp.explicitWait(Export);
				Export.click();
				bp.waitForElement();
				csvExport.click();
				Thread.sleep(50000);
				bp.waitForElement();
				System.out.println("File: csv format exported successfully");
				driver.navigate().refresh();
			}
			else 
			{
			    	
				WebElement iframe = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(iframe);
				bp.waitForElement();
				bp.waitForElement();
				bp.explicitWait(Export);
				Export.click();
				bp.waitForElement();
				htmlExport.click();
				Thread.sleep(50000);
				bp.waitForElement();
				System.out.println("File: html format exported successfully");
				driver.navigate().refresh();
			}
				
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("export in diff format unsuccessfull");
			throw e;
		}
	}
	
	public boolean exportInAllFormat(String exportType) throws Exception {
		try {
			bp = new CommonUtils();

			
			bp.waitForElement();
			
				
				/*WebElement iframe = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(iframe);*/
				bp.waitTillElementIsVisible(selectCheckbox);
				Thread.sleep(2000);	
				
				selectCheckbox.click();
				bp.waitForElement();
				bp.waitForElement();
				bp.explicitWait(Export);
				Export.click();
				bp.waitForElement();
				xmlExport.click();
				Thread.sleep(50000);
				System.out.println("File: xml format exported successfully");
				
				Export.click();
				bp.waitForElement();
				csvExport.click();
				Thread.sleep(50000);
				System.out.println("File: csv format exported successfully");
				
				Export.click();
				bp.waitForElement();
				htmlExport.click();
				Thread.sleep(50000);
				System.out.println("File: html format exported successfully");
				
	
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("export in diff format unsuccessfull");
			throw e;
		}
	}
	

	public boolean clickonTestAndSearchTestExecution() throws Exception {
		try {
			bp = new CommonUtils();

			//expand.click();
			bp.waitForElement();
			test.click();
			bp.waitForElement();
			searchTestExecution.click();
			
			bp.waitForElement();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("clickonTestAndSearchTestExecution successfull");
			throw e;
		}
	}
	
	public boolean bulkExecuteStatus() throws Exception {
		try {
			bp = new CommonUtils();

			
			bp.waitForElement();
			bp.waitForElement();
			Thread.sleep(2000);	
			bp.waitTillElementIsVisible(selectCheckbox);
			
			
			selectCheckbox.click();
			bp.waitForElement();
			selectTools.click();
			bp.waitForElement();
			selectStatusFromTools.click();
			bp.waitForElement();
			//selectStatusDropDown.click();
			Actions act = new Actions(driver);
			act.moveToElement(selectStatusDropDown)
			.pause(1200).click().sendKeys("PASS")
			.pause(1200).sendKeys(Keys.ENTER)
			.pause(1200).sendKeys(Keys.TAB)
			.pause(1200).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			Thread.sleep(20000);	
			selectClose.click();
						
			bp.waitForElement();
			Thread.sleep(20000);
				
			
			System.out.println("Bulk Executed successfully");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("clickonTestAndSearchTestExecution successfull");
			throw e;
		}
	}
	
	public boolean launchSTEPage() throws Exception {
		try {
			bp = new CommonUtils();
			zephyrPage.click();
			//expand.click();
			bp.waitForElement();
			launchSTEPage.click();
			driver.switchTo().frame(0);
			
			System.out.println("Found STE page Iframe");
			
			bp.waitTillElementIsVisible(checkExecutionDisplay);
			
			System.out.println(checkExecutionDisplay.getText());
			Thread.sleep(5000);
			
			bp.waitForElement();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Navigate to SearchTestExecution successfull");
			throw e;
		}
	}
		
	public boolean executeSingleExecution() throws Exception {
		try {
			bp = new CommonUtils();

			
			bp.waitForElement();
			bp.waitTillElementIsVisible(clickOnStatusDropDown);
			Actions act = new Actions(driver);
			act.moveToElement(clickOnStatusDropDown)
			.pause(1500).doubleClick().click()
			.pause(1500).sendKeys(Keys.UP)
			.pause(1500).sendKeys(Keys.ENTER)
			.pause(1200).sendKeys(selectStatus).perform();
			Thread.sleep(2000);		
			
			System.out.println("Executed successfully");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("clickonTestAndSearchTestExecution successfull");
			throw e;
		}
	}
	
	public boolean bulkDelete() throws Exception {
		try {
			bp = new CommonUtils();

			
			bp.waitForElement();
			bp.waitForElement();
			bp.waitTillElementIsVisible(selectCheckbox);
			Thread.sleep(2000);	
			
			selectCheckbox.click();
			bp.waitForElement();
			selectTools.click();
			bp.waitForElement();
			selectDeleteFromTools.click();
			bp.waitForElement();
			selectDelete.click();
			Thread.sleep(20000);
			selectClose.click();
						
			Thread.sleep(2000);		
			
			System.out.println("Bulk Deleted successfully");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("clickonTestAndSearchTestExecution successfull");
			throw e;
		}
	}
	
	public boolean advancedSearch(String projectname, String status) throws Exception {
		try {
			
			bp.waitForElement();	
			driver.navigate().refresh();
			WebElement iframe = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(iframe);
			bp.explicitWait(advancesearch);
			advancesearch.click();
			
			String zqlfilter = zqlFilter1+projectname+zqlFilter2+status+zqlFilter3;
			System.out.println(zqlfilter);

			clickOnSearchTextArea.sendKeys(zqlfilter);
			
			clickOnSearchTextArea.sendKeys(Keys.ENTER);

			bp.waitForElement();
			
		
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Failed to retrieve test case");
			throw e;
		}

	}
	
	
	public boolean predefinedFilterSearch() throws Exception {
		try {
			bp = new CommonUtils();
			
			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
		    System.out.println("The total number of iframes are " + frame.size());
			 Thread.sleep(15000);
			 driver.switchTo().frame(0);
			/*WebElement allUnexecutedTestsiframe = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(allUnexecutedTestsiframe);*/
			 log.info("switch to frame");
			 Thread.sleep(7000);
			
			/*bp.waitForElement();
			bp.explicitWait(expand);
			expand.click();*/
		 /*Actions act =new Actions(driver);
				act.moveToElement(expand).click().perform();*/
	           expand.click();
			 
			bp.waitForElement();
			expand.click();
			bp.waitForElement();
			allUnexecutedTests.click();
			Thread.sleep(10000);
			System.out.println("Retrieved allUnexecutedTests cases");
			bp.waitForElement();
			
		
			bp.waitForElement();
			myExecutedTests.click();
			Thread.sleep(10000);
			System.out.println("Retrieved myExecutedTests cases");
			bp.waitForElement();
			
			
			
		//	expand.click();
			bp.waitForElement();
			myFailedExecutions.click();
			Thread.sleep(10000);
			System.out.println("Retrieved myFailedTests cases");
			bp.waitForElement();
			
			
			
			
			//expand.click();
			bp.waitForElement();
			allExecutedTests.click();
			Thread.sleep(10000);
			System.out.println("Retrieved allExecutedTests cases");
			bp.waitForElement();
			
			
			
			//expand.click();
			bp.waitForElement();
			allFailedExecutions.click();
			Thread.sleep(10000);
			System.out.println("Retrieved allFailedExecutions cases");
			bp.waitForElement();
			
			
			bp.waitForElement();
			assignedToMe.click();
			Thread.sleep(10000);
			System.out.println("Retrieved assignedToMe cases");
			bp.waitForElement();
			driver.navigate().refresh();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Unable to Retrieve Predefined Cases");
			throw e;
		}

	}
	
        public boolean navigate_to_executepage() throws Exception {
		
		try {
			
            bp = new CommonUtils();
			
			bp.waitForElement();
			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
		    System.out.println("The total number of iframes are " + frame.size());
		    Thread.sleep(10000);
			driver.switchTo().frame(0);
			log.info("Switch to the Frame");
			Thread.sleep(3000);
			Ebtn.click();
			log.info("Click on E button");
			Thread.sleep(2000);
			String expectedtitle="Test Execution - Jira";
			String actualtitle=driver.getTitle();
			assertEquals(actualtitle, expectedtitle);
			System.out.println("Navigate to Executepage Successfully");
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			
			throw e;
		}
	}
        
        public boolean navigateSTEfromptc() throws Exception {
        	try {
        		bp = new CommonUtils();
    			bp.waitForElement();
    			cyclename.click();
    			log.info("Click on cycle name link");
    			Thread.sleep(10000);
    			/*List<WebElement> frame = driver.findElements(By.tagName("iframe"));
    		    System.out.println("The total number of iframes are " + frame.size());
    		    Thread.sleep(10000);
    			driver.switchTo().frame(0);
    			log.info("Switch to the Frame");
    			log.info("Navigate to Ste page successfully");
    			*/
        		return true;
        	}
        	catch (Exception e) {
    			e.printStackTrace();
    			throw e;
    		}
        }
        
        public boolean navigatedetailview() throws Exception {
        	try {
        		bp = new CommonUtils();
    			List<WebElement> frame = driver.findElements(By.tagName("iframe"));
    		    System.out.println("The total number of iframes are " + frame.size());
    		    Thread.sleep(10000);
    			driver.switchTo().frame(0);
    			log.info("Switch to the Frame");
    			Thread.sleep(5000);
    			button.click();
    			bp.waitForElement();
    			detailview.click();
    			log.info("Navigate to STE detil view is successfull");
        		
        		return true;
        	}
        	catch (Exception e) {
    			e.printStackTrace();
    			throw e;
    		}
        }
		
		public boolean bulkAssignToLoggedInUser() throws Exception {
		try {
			bp = new CommonUtils();

			
			bp.waitForElement();
			bp.waitForElement();
			bp.waitTillElementIsVisible(selectCheckbox);
			Thread.sleep(2000);	
			
			selectCheckbox.click();
			bp.waitForElement();
			selectTools.click();
			bp.waitForElement();
			bulkAssign.click();
			bp.waitForElement();
			Actions act = new Actions(driver);
					
			WebElement LoggedInUser = driver.findElement(By.xpath(assignee1 + "Zephyr QA" + assignee2));
			
 		    act.moveToElement(bulkAssignDropDown).pause(1200).click().sendKeys(LoggedInUser).click().perform();
						
			System.out.println("Bulk Assigned successfully");
			Thread.sleep(20000);
			selectClose.click();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("clickonTestAndSearchTestExecution successfull");
			throw e;
		}
	}
}
