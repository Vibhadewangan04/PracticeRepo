package com.zephyr.selenium.pageobject;

import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class ViewIssuePage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;

	public ViewIssuePage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	protected WebElement jirahomepage;
	
	
	@FindBy(xpath = "(//*[@class='css-17jvs9k'])[1]")
	protected WebElement allProjects;	
	
	////div[@data-testid='atlassian-navigation--primary-actions']//*[text()='Projects']
	@FindBy(xpath = "//*[@id='helpPanelContainer']/div/div[1]/div[1]/header/nav/div[3]/div[2]/div/button/span/span[1]")
	protected WebElement globalProject;
	
	@FindBy(xpath = "//*[text()='View all projects']")
//	@FindBy(xpath = "//span[contains(text(),'View all projects')]")
	protected WebElement viewAllProjects;
			
	@FindBy(xpath = "//*[@id='createGlobalItem']")
	protected WebElement test;
	
	@FindBy(xpath = "//div[contains(text(),'Projects')]")
	protected WebElement projects;
	
	@FindBy(xpath = "//input[@name='search']")
	protected WebElement searchproject;
	 
//	@FindBy(xpath = "//*[@id='helpPanelContainer']/div/div[1]/div[3]/div[1]/div/div[2]/div/table/tbody/tr/td[2]/a/div")
	@FindBy(xpath = "//*[text()='Automation Project']")
	protected WebElement clickselectedproject;
	
	@FindBy(xpath = "(//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])")
	protected WebElement zephyrPage1;
	
//	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	@FindBy(xpath = "//div[@data-testid='Navigation']//*[text() = 'Zephyr']")
	protected WebElement zephyrPage;
	
	@FindBy(xpath = "//a[contains(@href,'issuetype=Test')]")
	protected WebElement searchTestPage;
	
	@FindBy(xpath = "//div[contains(text(),'Search Tests')]")
	protected WebElement searchTestPage1;
	
	@FindBy(xpath = "//*[@class='sc-gJqsIT jBovqy']")
//	@FindBy(xpath = "//td[@class='TableCell__TableBodyCell-sc-1mgclzx-0 gIZZXT']")
	protected WebElement clickselectedproject1;
	
	@FindBy(xpath = "//div[contains(text(),'Tests')]")
	protected WebElement Tests;
	

	@FindBy(xpath = "(//*[@class='css-1if1bv7'])[3]")
	protected WebElement testMenu;
	
	@FindBy(xpath = "(//*[text()='Create a Test'])")
	protected WebElement createTest;
	
	/*@FindBy(xpath = "(//*[@class='css-1olrtn'])[2]")
	protected WebElement createTest;*/

	@FindBy(xpath = "(//button[text()='Search'])")
	protected WebElement SearchButton;
	
	@FindBy(xpath = "(//*[@class='BreadcrumbsItem__BreadcrumbsItemElement-sc-1hh8yo5-0 fItpNE'])[3]")
	protected WebElement latestCreatedTest;
	
	////img[@class='sc-kLIISr hfWeWa'] 
//	(//*[@class='sc-fwNAQS eimrvu']/div//img)[2]
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[2])")
	protected WebElement DIconButton;
	
	@FindBy(xpath = "(//*[@class='sc-fwNAQS eimrvu']/div//img)[2]")
	protected WebElement DIconButton2;
	
	@FindBy(xpath = "(//*[@class='zephyr-action-column-wrapper'])[1]")
	protected WebElement CloneStep;
	
	@FindBy(xpath = "//*[@id='clone-insert-at']")
	protected WebElement CloneStepToValidNumber;
	
	@FindBy(xpath = "//*[@class='text']")
	protected WebElement CloneStepToValidNumber2;
	
	@FindBy(xpath = "//*[@id='clone-append-above']")
	protected WebElement CloneStepAppendAtFirst;
	
//	@FindBy(xpath = "//*[@id='ap-button-0']")
	@FindBy(xpath = "//*[text()='Clone']")
	protected WebElement ClickOnClone;
	
	@FindBy(xpath = "(//*[@id='project-field'])")
	protected WebElement projectDropDown;
	
	@FindBy(xpath = "(//*[@id='issuetype-field'])")
	protected WebElement issueTypeFiledDropDown;
	
	@FindBy(xpath = "(//*[@id='summary'])")
	public WebElement summary;

	
	@FindBy(xpath ="//*[@id='labels-textarea']")
	public WebElement labelField;
	
	@FindBy(xpath = "(//*[@id='create-issue-submit'])")
	public WebElement submit;
	
	
	@FindBy(xpath = "//*[@id='create-issue-submit']")
	protected WebElement clickOncreate;
	
	@FindBy(xpath = "//*[text()='Search Tests']")
	protected WebElement searchTest;
	
	@FindBy(xpath ="//*[@id='layout-switcher-button']")
	protected WebElement switchLayout;
	
	@FindBy(xpath = "//*[text()='List View']")
	protected WebElement listView;
	
	@FindBy(xpath ="(//*[text()='Test'])[1]")
	protected WebElement selectTest;
	
	@FindBy(xpath ="(//*[text()='Story'])[1]")
	protected WebElement selectStory;
	
	@FindBy(xpath ="(//*[text()='Bug'])[1]")
	protected WebElement selectBug;
	
	@FindBy(xpath ="(//*[text()='Task'])[1]")
	protected WebElement selectTask;
	
	@FindBy(xpath="//*[@class='testStepFocus-btn ']")
  	protected WebElement AddstepLink;
	
   @FindBy(xpath="//*[@id='newstep']")
  	protected WebElement step;
   
	@FindBy(xpath=" (//*[@class='data-column new-column ']/textarea)[1]")
	protected WebElement Teststep;
		   
	@FindBy(xpath="//*[@id='newdata']")
	protected WebElement data;

	@FindBy(xpath="//*[@id='newresult']")
	protected WebElement result;
	
	@FindBy(xpath="(//*[@class='data-column '])[2]/div[1]/p")
	protected WebElement stepEdit;
	
	@FindBy(xpath="(//*[@class='data-column '])[3]/div[1]/p")
	protected WebElement dataEdit;

	@FindBy(xpath="(//*[@class='data-column '])[4]/div[1]/p")
	protected WebElement resultEdit;
	
	@FindBy(xpath = "//*[@title='Add Steps']")
	protected WebElement addstep;
	
	@FindBy(xpath = "//*[@id='advanced-search']")
	protected WebElement seachField;
	
	@FindBy(xpath = "//*[text()='Edit']")
	protected WebElement clickOnEditOption;
	
	@FindBy(xpath = "//*[@class='ReadViewContentWrapper-xymwx5-0 kLiHRY']/h1")
	protected WebElement EditTestSummary;
	
	@FindBy(xpath="//*[@id='summary']")
	protected WebElement clickOnSummary;
	
	@FindBy(xpath="//*[@id='edit-issue-submit']")
	protected WebElement updateButton;
	
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
    protected WebElement productLogoGlobalItem;
	
	@FindBy(xpath = "//*[text()='bddScenarioTest']")
	protected WebElement scenarioTest;
	
	@FindBy(xpath = "//*[@title='BDD Scenarios']")
	protected WebElement clickOnBDDScenarioOption;
	
	@FindBy(xpath = "//*[@id='jira-issue-header-actions']/div/div/div[1]/div/div/button")
	protected WebElement ActionsContextMenu1;
	
	@FindBy(xpath = "//*[@class='css-1akzpg4']/span/span/span")
	protected WebElement ActionsContextMenu;

	@FindBy(xpath = "(//*[@class='data-column drag-image '])[4]/img")
	protected WebElement DragTestStep;
	
	@FindBy(xpath = "(//*[@class='data-column drag-image '])[2]/img")
	protected WebElement DropTestStep;	
	
	@FindBy(xpath = "//*[text()='Clone']")
	protected WebElement cloneTest;
	
	@FindBy(xpath = "//*[@id='clone-issue-submit']")
	protected WebElement cloneTestCreate;
	
	@FindBy(xpath = "//*[text()='Delete']")
	protected WebElement DeleteTestFromMenu;
	
	@FindBy(xpath = "(//*[text()='Delete'])[2]")
	protected WebElement DeleteTest;
	
	@FindBy(xpath = "//*[text()='Export Word']")
	protected WebElement ExportTestFromMenu;
			
	@FindBy(xpath = "//*[@id='searcher-query']")
	protected WebElement JirasearchBox;
	
	@FindBy(xpath = "//*[text()='Switch to basic']")
	protected WebElement SwitchToBasic;
	
	@FindBy(xpath = "//*[text()='Switch to JQL']")
	protected WebElement SwitchToJQL;
	
	@FindBy(xpath = "//*[text()='Export']")
	protected WebElement ExportTest;	
	
	@FindBy(xpath = "//*[text()='Export Excel CSV (all fields)']")
	protected WebElement ExportTestExcel;	
	
	
	@FindBy(xpath = "//*[@class='add-attachments']/span")
	protected WebElement PlusAddAttachment;		
	
	@FindBy(xpath="(//*[@class='attachment-icon-wrapper'])[1]")
	protected WebElement executionAttachment;
	
	//@FindBy(xpath="(//*[@class='_26Rfe1lar9WC5NDEeARvBy'])[2]")
	@FindBy(xpath="//*[text()='Add files...']")
	protected WebElement addFilesbtn;
	
	//@FindBy(xpath="(//*[@class='_26Rfe1lar9WC5NDEeARvBy'])[4]")
	@FindBy(xpath="//*[text()='Attach']")
	protected WebElement attachButton;
	
	@FindBy(xpath = "(//*[@class='zephyr-action-column-wrapper'])[2]")
	protected WebElement DeleteStep;
	
	@FindBy(xpath = "//*[text()='Delete']")
	protected WebElement DeleteStep2;
	
	@FindBy(xpath = "(//*[text()=' attachments'])[1]")
	protected WebElement ClickOnStepAttachment;
	
	@FindBy(xpath = "//*[@class='icon-delete entity-operations-delete ']/img")
	protected WebElement DeleteStepAttachment2;
	
	@FindBy(xpath = "//*[text()='Delete']")
	protected WebElement ClickOnDeleteStepAttachment;
	
	@FindBy(xpath = "//*[text()='Execute']")
	protected WebElement Execute;
	
	/*@FindBy(xpath = "//span[text()='Execute']")
	@FindBy(xpath = "//span[@class='css-j8fq0c']/span[text()='Execute']")
	@FindBy(xpath = "//span[contains(@class, 'css-t5emrf') and text()='Execute']")*/
	
	@FindBy(xpath = "//*[@class= 'ak-button ak-button__appearance-default css-p30t9v']/span/span")
	protected WebElement Execute2;
	
	@FindBy(xpath = "//*[text()='Add to Test Cycle(s)']")
	protected WebElement AddTestToCycle;
	
//	@FindBy(xpath = "//*[@class='trigger-dropDown']")
	@FindBy(xpath = "//*[@class='dropDown-wrapper']//span/img")
	protected WebElement AssigneeDropdown;
			
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[1])")
	protected WebElement ZephyrAction;
			
	@FindBy(xpath = "((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[3])")
	protected WebElement ZephyrExecutions;	
	
	@FindBy(xpath = "//*[@class='action-outer-wrapper']/div/a")
	protected WebElement EButton;
	
	@FindBy(xpath = "//*[@id='actionGridBody']/div/div[1]/div/div[1]/a/img")
	protected WebElement EButton2;
	
	//*[@class='row-column grid-column status-column ']/div/div/div/span/img)[1]
//	@FindBy(xpath = "//*[@class='dropDown-wrapper select-status']/span[3]")
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/span[3]")
	protected WebElement StatusDropDown;

	
	@FindBy(xpath = "//*[@class='dropDown-wrapper select-status']")
	protected WebElement ClickOnStatus;
	
	
	@FindBy(xpath = "//div[text()= 'Status']")
	protected WebElement ClickOnStatusHead;
	
	@FindBy(xpath = "//*[@id='helpPanelContainer']/div/div[1]/div[2]/div[1]/div/div[2]/div/div[2]/div/div/div/div[7]/a/div/div")
	protected WebElement searchTestpage;
	
	@FindBy(xpath = "//*[contains(text(),'Feature content')]")
	protected WebElement clickOnFeatureContent;
	
	@FindBy(xpath = "//*[@class='zephyr-attachment-thumb']")
	protected WebElement mousehover;
	
	@FindBy(xpath = "//*[@class='list-container']")
	protected WebElement AssigneeListmousehover;
	
	@FindBy(xpath = "//*[text()='Test Result']")
	protected WebElement saveEditedSteps;
	
	@FindBy(xpath = "//*[@title='Large View']/img")
	protected WebElement StepLargeView;
	
	
	@FindBy(xpath = "(//*[@class='radio'])[2]")
	protected WebElement StepCloneRadioButton;
	
	/******************************* String protected *******************************/
	protected String zqlFilter1="project = '";
	protected String zqlFilter2="'";
	
	protected String selectBDD1 = "//*[contains(text(),'";
	protected String selectBDD2="')]";
			
	
	public boolean clickOnBDDScenarioOption() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			clickOnBDDScenarioOption.click();
			bp.waitForElement();
			
			System.out.println("Successfully clicked on BDD scenarios option");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean goToSearchTest() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(4000);
			productLogoGlobalItem.click();
			bp.waitForElement();
			testMenu.click();
			
			bp.waitForElement();
			searchTest.click();
			
			bp.waitForElement();
			System.out.println("Successfully launched Serach Test Page");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	public boolean goToListView() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			
			
				listView.click();

			
			System.out.println("Selected List View");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	

	public boolean clickOnProductLogoGlobalItem() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			Thread.sleep(2000);
			productLogoGlobalItem.click();
					
			System.out.println("Successfully launched Product Logo Page");
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	

	public boolean goToListViewAndSelectTask() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			
			bp.waitForElement();
			if (listView.isDisplayed()==false)
			{
				listView.click();
			}
				
			bp.waitForElement();
			selectTask.click();
			
			System.out.println("Selected List View");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	public boolean goToListViewAndSelectTest() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			bp.waitForElement();
			listView.click();
			System.out.println("Selected listview");
			
			bp.waitForElement();
			selectTest.click();			
			System.out.println("Test selected");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	

	public boolean goToListViewAndSelectStory() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			bp.waitForElement();
			listView.click();
			System.out.println("Selected listview");
			
			bp.waitForElement();
			selectStory.click();			
			System.out.println("Story selected");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	

	public boolean goToListViewAndSelectBug() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			switchLayout.click();
			
			bp.waitForElement();
			if (listView.isDisplayed()==false)
			{
				listView.click();
			}
				
			bp.waitForElement();
			selectBug.click();
			
			System.out.println("Selected Bug View");
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
//added new
	public boolean createTest(String project, String issue, String Test) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			jirahomepage.click();
			System.out.println("Navigate to Jira Home page");
			bp.waitForElement();
			
			test.click();
			bp.waitForElement();
			
			projectDropDown.sendKeys(project);
			projectDropDown.sendKeys(Keys.ENTER);
				
			bp.waitForElement();
			
			issueTypeFiledDropDown.sendKeys(issue);
			issueTypeFiledDropDown.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			summary.sendKeys(Test);
			summary.sendKeys(Keys.ENTER);
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	
	public boolean addTestCases() throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			
			WebElement test = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(test);
		
			createTest.click();
			clickOnSummary.sendKeys("summary");
			clickOncreate.click();
			
				
			driver.switchTo().defaultContent();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	}

	

	
	//working
	public boolean addTestStepsToTest1(String projectName) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2500);
			SearchButton.click();
		//	latestCreatedTest.click();
			Thread.sleep(2500);
			DIconButton.click();
			Thread.sleep(4000);
			System.out.println("test step block seen");
			
			/*WebElement element = driver.findElement(By.xpath("((//img[contains(@src,'zephyr4jiracloud.com/connect/assets/images/icons')])[2])"));
			Actions actions = new Actions(driver);
			actions.moveToElement(element).click().build().perform();
			*/

			WebElement test = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(test);
			
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", Teststep);
			
		//	AddstepLink.click();
		//	Teststep
						
			/*JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,1000)");
			System.out.println("page scrolled successfully");*/
			
			for(int i=1 ; i<2 ;i++)
			{
			bp.waitForElement();
			Actions act = new Actions(driver);
			act.moveToElement(Teststep).pause(1000).click().perform();
			step.click();
			step.sendKeys("Test");
			
			bp.waitForElement();
			step.sendKeys(Keys.TAB);
			System.out.println("test step added successfully");
						
			data.click();
			data.sendKeys("data");
			bp.waitForElement();
			data.sendKeys(Keys.TAB);
			
			System.out.println("test data added successfully");
			
			result.click();
			result.sendKeys("result");
			bp.waitForElement();
			result.sendKeys(Keys.TAB);
			System.out.println("test result added successfully");
			
			addstep.click();
			System.out.println("teststeps created successfully");
			}		
			driver.switchTo().defaultContent();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	//working in all
	public boolean AddStepsToTest(String projectname) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			//to select newly created test/ top one test
			SearchButton.click();
		//	driver.navigate().refresh();
			   Thread.sleep(6000);
				DIconButton.click();
				Thread.sleep(9000);
				bp.waitForElement();
				/*SearchButton.click();
				Thread.sleep(5000);
						DIconButton.click();
						Thread.sleep(6000);*/
				System.out.println("teststep block seen");
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("iframe found");
			
			// to find below xpath under iframe
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", AddstepLink);
			
			Actions act = new Actions(driver);
			act.moveToElement(AddstepLink).click().pause(2000)
			.sendKeys("Test").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("result").sendKeys(Keys.TAB)
			.sendKeys(Keys.ENTER)
			.perform();
		
			//	addstep.click();
			log.info("Teststep created Successfully");
		
			driver.switchTo().defaultContent();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean AddmultipleStepsToTest(String projectname) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			//to select newly created test/ top one test
			SearchButton.click();
		//	driver.navigate().refresh();
			   Thread.sleep(6000);
				DIconButton.click();
				Thread.sleep(9000);
				bp.waitForElement();
				/*SearchButton.click();
				Thread.sleep(5000);
						DIconButton.click();
						Thread.sleep(6000);*/
				System.out.println("teststep block seen");
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("iframe found");
			
			// to find below xpath under iframe
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", AddstepLink);
			
			Actions act = new Actions(driver);
			act.moveToElement(AddstepLink).click().pause(2000)
			.sendKeys("Test step 1").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("result").sendKeys(Keys.TAB)
			.sendKeys(Keys.ENTER)
			.perform();
			System.out.println(" 1 Teststep created Successfully");
			bp.waitForElement();
			
			act.pause(1000).sendKeys("Teststep2").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("result").sendKeys(Keys.TAB)
			.sendKeys(Keys.ENTER)
			.perform();
			System.out.println(" 2 Teststep created Successfully");
			bp.waitForElement();
			
			act.pause(1000).sendKeys("Test step3").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("result").sendKeys(Keys.TAB)
			.sendKeys(Keys.ENTER)
			.perform();
			System.out.println(" 3 Teststep created Successfully");
			bp.waitForElement();
			
			act.pause(1000).sendKeys("Test step4").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("result").sendKeys(Keys.TAB)
			.sendKeys(Keys.ENTER)
			.perform();
		
			//	addstep.click();
			System.out.println(" 4 Teststeps created Successfully");
		
			driver.switchTo().defaultContent();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	public boolean editSteps(String projectname) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			//to select newly created test/ top one test
			SearchButton.click();
		//	driver.navigate().refresh();
			   Thread.sleep(6000);
				DIconButton.click();
				Thread.sleep(9000);
				bp.waitForElement();
				System.out.println("teststep block seen");
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("iframe found");
			
			// to find below xpath under iframe
			JavascriptExecutor executor = (JavascriptExecutor) driver;
			executor.executeScript("arguments[0].click();", AddstepLink);
			
			Actions act = new Actions(driver);
			act.moveToElement(AddstepLink).click().pause(2000)
			.sendKeys("Test").sendKeys(Keys.CLEAR)
			.sendKeys(" edited test").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("Data").sendKeys(Keys.DELETE)
			.sendKeys(" edited data").sendKeys(Keys.TAB).pause(1000)
			.sendKeys("Result").sendKeys(Keys.DELETE)
			.sendKeys(" edited result").sendKeys(Keys.TAB).pause(1000)
			.sendKeys(Keys.ENTER)
			.perform();
			
			//	addstep.click();
			System.out.println("test step edited successfully");
		
			driver.switchTo().defaultContent();
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean editTestStepsToTest(String projectName) throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			SearchButton.click();
			   Thread.sleep(2500);
			latestCreatedTest.click();
				Thread.sleep(2500);
			
			//driver.navigate().refresh();
			/*WebElement test = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(test);*/
			
		 
			DIconButton.click();
			log.info("clicked on d buton");  
			driver.navigate().refresh();
		//	Thread.sleep(2500);
			
			bp.waitForElement();
			step.click();
			step.sendKeys("Test");
			
			stepEdit.click();
			bp.eraseText(stepEdit);
			stepEdit.sendKeys("Test edited");
			
			bp.waitForElement();
			stepEdit.sendKeys(Keys.TAB);
			System.out.println("test step edited successfully");
						
			dataEdit.click();
			bp.eraseText(stepEdit);
			dataEdit.sendKeys("data edited");
			bp.waitForElement();
			dataEdit.sendKeys(Keys.TAB);
			
			System.out.println("test data edited successfully");
			
			resultEdit.click();
			bp.eraseText(stepEdit);
			resultEdit.sendKeys("result edited");
			bp.waitForElement();
			resultEdit.sendKeys(Keys.TAB);
			System.out.println("test result edited successfully");
			
			
					
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean CloneTestStep(String projectName) throws Exception {
		try {
			bp = new CommonUtils();
			
			bp.waitForElement();
			
			//driver.navigate().refresh();
			//WebElement test = driver.findElement(By.tagName("iframe"));
			//driver.switchTo().frame(test);
			
			/*SearchButton.click();
			latestCreatedTest.click();*/
			Thread.sleep(2500);
			DIconButton.click();
	//		Thread.sleep(2500);
			
			bp.waitForElement();
			/*step.click();
			step.sendKeys("Test");
			
			bp.waitForElement();
			step.sendKeys(Keys.TAB);
			System.out.println("test step added successfully");
						
			data.click();
			data.sendKeys("data");
			bp.waitForElement();
			data.sendKeys(Keys.TAB);
			
			System.out.println("test data added successfully");
			
			result.click();
			result.sendKeys("result");
			bp.waitForElement();
			result.sendKeys(Keys.TAB);
			System.out.println("test result added successfully");
			
			addstep.click();
			System.out.println("teststeps created successfully");*/
			
			WebElement test = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(test);
			
			CloneStep.click();
			
			Actions act = new Actions(driver);		
			act.moveToElement(CloneStepToValidNumber).pause(1000).click().sendKeys(Keys.TAB)
			 .sendKeys("2").sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			/*CloneStepToValidNumber.click();
			CloneStepToValidNumber.sendKeys("2");
			ClickOnClone.click();*/
			log.info("Teststep cloned Successfully");
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	

// to edit summary
		public boolean editTestSummary() throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				SearchButton.click();
				Thread.sleep(5000);
				
				/*WebElement test = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(test);*/
			
				/*bp.waitForElement();
				EditTestSummary.click();
				System.out.println("clicked on edit option");
				bp.waitForElement();
				clickOnSummary.sendKeys("Edited Test");
				System.out.println("Edited summary");
				bp.waitForElement();
				clickOnSummary.sendKeys(Keys.ENTER);
				System.out.println("Updated summary successfully");
				*/
				
				Actions act = new Actions(driver);		
				act.moveToElement(EditTestSummary).pause(1000).click()
				 .sendKeys("Edited Test summary ").sendKeys(Keys.ENTER).perform();
				
				//to remove and write new summary
				/*act.moveToElement(EditTestSummary).pause(1000).click().sendKeys(Keys.CONTROL,"a")
				 .sendKeys(Keys.DELETE).pause(1000).sendKeys("Edited Test").sendKeys(Keys.ENTER).perform();*/
				
				System.out.println("edited test summary");

				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}

		public boolean c (String projectname) throws Exception{

			try{
				bp = new CommonUtils();
				bp.waitForElement();
				Thread.sleep(2000);
				jirahomepage.click();
				
				System.out.println("Navigate to Jira Home page");
				bp.waitForElement();
				
				Thread.sleep(2000);
				projects.click();
				System.out.println("Clicked on Projects Menu");
				
				Actions act = new Actions(driver);
		    	act.moveToElement(searchproject).click().pause(1200).sendKeys(projectname).pause(1200).sendKeys(Keys.ENTER).perform();
				Thread.sleep(2000);
				
				clickselectedproject.click();
				System.out.println("Clicked on Automation Project");
				bp.waitForElement();
					
				
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	
		public boolean navigateToProject(String projectname) throws Exception{		
				try{
					bp = new CommonUtils();
					bp.waitForElement();
					Thread.sleep(3000);

					/*jirahomepage.click();
					System.out.println("Navigate to Jira Home page");
					bp.waitForElement();
					Thread.sleep(2000);
					projects.click();
					System.out.println("Clicked on Projects Menu");*/
					bp.waitForElement();
					driver.navigate().refresh();
					bp.waitTillElementIsVisible(globalProject);
					globalProject.click();
					bp.waitForElement();
					System.out.println("Clicked on global project");
					viewAllProjects.click();
					bp.waitForElement();
					System.out.println("Clicked on view all Project");
					
					Actions act = new Actions(driver);
			//		Object wait;
			//		wait.until(ExpectedConditions.elementToBeClickable(element));
					act.moveToElement(searchproject).click().pause(1500).sendKeys(projectname).pause(1500).sendKeys(Keys.ENTER).perform();

					Thread.sleep(3000);
					clickselectedproject.click();
					System.out.println("Clicked on Automation Project");
					bp.waitForElement();
					return true;
				
				
			}

		
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		
			
		}
		}	
		
		
		public boolean validateZephyrMenuPage() throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				Thread.sleep(2000);
			
				zephyrPage.click();
				System.out.println("validated to Zephyr page");
				bp.waitForElement();
			
				return true;
				
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
				}
			
			}
		
		
		
		public boolean validateViewIssuePage() throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				Thread.sleep(2000);	
				
				zephyrPage.click();
				System.out.println("Navigated to Zephyr page");
				searchTestPage.click();
				System.out.println("Navigated to search test page");
				bp.waitForElement();
			
				return true;
				
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
			
			}
		
		
			
		
		public boolean cloneTestSteps2(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
							
					/*SearchButton.click();
					Thread.sleep(2500);*/
					DIconButton.click();
					Thread.sleep(2500);
				
				WebElement test = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(test);
				
				
				for(int i=1 ; i<2 ;i++)
				{
				bp.waitForElement();
			//	bp.waitTillElementIsVisible(step);
				step.click();
				step.sendKeys("Test");
				
				bp.waitForElement();
				step.sendKeys(Keys.TAB);
				System.out.println("test step added successfully");
							
				data.click();
				data.sendKeys("data");
				bp.waitForElement();
				data.sendKeys(Keys.TAB);
				
				System.out.println("test data added successfully");
				
				result.click();
				result.sendKeys("result");
				bp.waitForElement();
				result.sendKeys(Keys.TAB);
				System.out.println("test result added successfully");
				
				addstep.click();
			//	addstep.click();
				log.info("Teststep created Successfully");
				}
		
				bp.waitTillElementIsVisible(CloneStep);
				CloneStep.click();
				bp.waitForElement();
				
				
				
			/*	WebElement frame2 = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame2);*/
				
				Actions act = new Actions(driver);		
				act.sendKeys(Keys.TAB).pause(1500).click()
				 .sendKeys("2").sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
				
				/*Actions act = new Actions(driver);		
				act.moveToElement(CloneStepToValidNumber2).pause(1500).click()
				 .sendKeys("2").sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();*/
									
			
				log.info("Teststep cloned Successfully");
				driver.switchTo().defaultContent();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		public boolean cloneTestStepsByEnteringNumber(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
							
						SearchButton.click();
						Thread.sleep(6000);
						DIconButton.click();
						Thread.sleep(9000);
						bp.waitForElement();
						System.out.println("teststep block seen");
					
					WebElement frame = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(frame);
					System.out.println("iframe found");
					bp.waitForElement();
					
					// to find below xpath under iframe
					JavascriptExecutor executor = (JavascriptExecutor) driver;
					executor.executeScript("arguments[0].click();", AddstepLink);
					
					Actions act = new Actions(driver);
					act.moveToElement(AddstepLink).click().pause(2000)
					.sendKeys("Test").sendKeys(Keys.TAB).pause(1000)
					.sendKeys("data").sendKeys(Keys.TAB).pause(1000)
					.sendKeys("result").sendKeys(Keys.TAB)
					.sendKeys(Keys.ENTER)
					.perform();
				
					//	addstep.click();
					log.info("Teststep created Successfully");
					
				bp.waitTillElementIsVisible(CloneStep);
				act.moveToElement(CloneStep).click().perform();
			//	CloneStep.click();/
				bp.waitForElement();
			//	StepCloneRadioButton
							
			//	Actions act = new Actions(driver);		
				act.click().sendKeys(Keys.TAB).pause(1500)
				 .sendKeys("2").sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
				
						
				log.info("Teststep cloned Successfully");	
				driver.switchTo().defaultContent();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		public boolean cloneTestStepInsertAfter(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
							
					/*SearchButton.click();
					Thread.sleep(2500);*/
					DIconButton.click();
					Thread.sleep(2500);
				
				WebElement test = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(test);
				
				
				/*for(int i=1 ; i<2 ;i++)
				{
				bp.waitForElement();
			//	bp.waitTillElementIsVisible(step);
				step.click();
				step.sendKeys("Test");
				
				bp.waitForElement();
				step.sendKeys(Keys.TAB);
				System.out.println("test step added successfully");
							
				data.click();
				data.sendKeys("data");
				bp.waitForElement();
				data.sendKeys(Keys.TAB);
				
				System.out.println("test data added successfully");
				
				result.click();
				result.sendKeys("result");
				bp.waitForElement();
				result.sendKeys(Keys.TAB);
				System.out.println("test result added successfully");
				
				addstep.click();
				log.info("Teststep created Successfully");
				}*/
		
				bp.waitTillElementIsVisible(CloneStep);
				CloneStep.click();
				bp.waitForElement();

				Actions act = new Actions(driver);		
				act.sendKeys(Keys.ENTER).perform();
				
			//	ClickOnClone.click();
				log.info("Teststep cloned after step Successfully");
				
				driver.switchTo().defaultContent();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		public boolean cloneTestStepAppendASLastStep(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
							
					/*SearchButton.click();
					Thread.sleep(2500);*/
					DIconButton.click();
					Thread.sleep(2500);
				
				WebElement test = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(test);
				
				
				for(int i=1 ; i<2 ;i++)
				{
				bp.waitForElement();
				step.click();
				step.sendKeys("Test");
				
				bp.waitForElement();
				step.sendKeys(Keys.TAB);
				System.out.println("test step added successfully");
							
				data.click();
				data.sendKeys("data");
				bp.waitForElement();
				data.sendKeys(Keys.TAB);
				
				System.out.println("test data added successfully");
				
				result.click();
				result.sendKeys("result");
				bp.waitForElement();
				result.sendKeys(Keys.TAB);
				System.out.println("test result added successfully");
				
				addstep.click();
				System.out.println("Teststep created Successfully");
				}
		
				bp.waitTillElementIsVisible(CloneStep);
				CloneStep.click();
				bp.waitForElement();

				Actions act = new Actions(driver);		
				act.click().sendKeys(Keys.TAB).sendKeys(Keys.TAB).click()
				.sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
				System.out.println("Teststep cloned Successfully");
				driver.switchTo().defaultContent();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		public boolean RearrangeTestSteps(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
							
				//to select newly created test/ top one test
				SearchButton.click();
				Thread.sleep(6000);
					DIconButton.click();
					Thread.sleep(9000);
					bp.waitForElement();
					System.out.println("teststep block seen");
				
				WebElement frame = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame);
				System.out.println("iframe found");
				
				/*// to find below xpath under iframe
				JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", AddstepLink);*/
						
	//			driver.manage().timeouts().implicitlyWait(10000, TimeUnit.MILLISECONDS);
				driver.manage().window().maximize();
				
				// to find below xpath under iframe
				/*JavascriptExecutor executor = (JavascriptExecutor) driver;
				executor.executeScript("arguments[0].click();", AddstepLink);*/
				
				Actions act = new Actions(driver);	
				//act.dragAndDrop(DragTestStep, DropTestStep).build().perform();
				act.clickAndHold(DragTestStep).pause(1000)
				.moveToElement(DropTestStep)
				.release(DropTestStep)
				.build()
				.perform();
				
				System.out.println("re-arranged steps Successfully");
								
				driver.switchTo().defaultContent();
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		

		public boolean cloneTest(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				
				driver.navigate().refresh();
				Thread.sleep(2500);	
				SearchButton.click();
				Thread.sleep(2500);	
			/*	latestCreatedTest.click();
				Thread.sleep(2500);		
				
				Actions act = new Actions(driver);
				bp.waitForElement();
				act.moveToElement(ActionsContextMenu).click().perform();*/
				
				ActionsContextMenu.click();
				cloneTest.click();
				cloneTestCreate.click();
				log.info("Cloned Test successfully");
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		//remove2 nember
		public boolean SearchTestInBasic(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				Thread.sleep(2500);	
				JirasearchBox.click();
				JirasearchBox.sendKeys("Test");
				bp.waitForElement();
				JirasearchBox.sendKeys(Keys.ENTER);
				
			/*	Actions act = new Actions(driver);		
				act.moveToElement(EditTestSummary).pause(1000).click()
				 .sendKeys("Edited Test summary ").sendKeys(Keys.ENTER).perform();*/
				
				System.out.println("searched Test by keyword 'Test' Successfully");
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		public boolean SearchTest(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				Thread.sleep(2500);	
				SwitchToBasic.click();
				JirasearchBox.click();
				JirasearchBox.sendKeys("Test");
				bp.waitForElement();
				JirasearchBox.sendKeys(Keys.ENTER);
			
			
			/*	Actions act = new Actions(driver);		
				act.moveToElement(EditTestSummary).pause(1000).click()
				 .sendKeys("Edited Test summary ").sendKeys(Keys.ENTER).perform();*/
				
				System.out.println("searched Test by keyword 'Test' Successfully");
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		public boolean DeleteTest(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				
					//driver.navigate().refresh();
					bp.waitForElement();
					SearchButton.click();
					Thread.sleep(6000);	
					latestCreatedTest.click();
					Thread.sleep(5000);	
					
				ActionsContextMenu.click();
				DeleteTestFromMenu.click();
				DeleteTest.click();
				log.info("Deleted Test successfully");
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		
		public boolean ExportTest(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
				
				bp.waitForElement();
				SearchButton.click();
				Thread.sleep(6000);	
				latestCreatedTest.click();
				Thread.sleep(5000);	
					
					ExportTest.click();
					ExportTestExcel.click();
				log.info("Exported Test successfully");
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		public boolean AddStepAttachment(String filePath) throws Exception {
			try {
				
				bp = new CommonUtils();
				bp.waitForElement();
				
				//to select newly created test/ top one test
				SearchButton.click();
				Thread.sleep(6000);
				DIconButton.click();
					Thread.sleep(9000);
					bp.waitForElement();
					System.out.println("teststep block seen");
					
					WebElement frame = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(frame);
					System.out.println("iframe found");
					bp.waitForElement();
					
			 			Actions act =new Actions(driver);
			 		    act.moveToElement(PlusAddAttachment).pause(2000).click().perform();
				 	    bp.waitForElement();	
				 		log.info("Click on add attachment");
			 			
			 			/*JavascriptExecutor js = (JavascriptExecutor) driver;
						((JavascriptExecutor)driver).executeScript("arguments[0].scrollIntoView();"
			                      ,addFilesbtn);*/
						
						Thread.sleep(3000);
			 			//addFilesbtn.click();
			 			act.moveToElement(addFilesbtn).pause(3000).click().build().perform();
	                    log.info("Click on Add files button in popup");

						bp.waitForElement();
						bp.waitForElement();
						bp.uploadFile(filePath);

						bp.waitForElement();
						attachButton.click();
						
						driver.switchTo().defaultContent();
					System.out.println("File Uploaded Successfully");
			
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		

		public boolean DeleteStepAttachment(String projectname) throws Exception {
			try {
				bp = new CommonUtils();
				bp.waitForElement();
		
					driver.navigate().refresh();
					Thread.sleep(2500);
					//bp.waitForElement(); */
				//	bp.waitTillElementIsVisible(DIconButton);
					DIconButton.click();
					Thread.sleep(2500);
				/*	latestCreatedTest.click();
					Thread.sleep(2500);*/
//					Actions act2 = new Actions(driver);
//					bp.waitForElement();
//					act2.moveToElement(DIconButton2).click().perform();
//					Thread.sleep(2500);
					
					/*bp.waitTillElementIsVisible(DIconButton);
					DIconButton.click();
					Thread.sleep(2500);*/
					
					WebElement test = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(test);
					System.out.println("Found Iframe");
					Thread.sleep(2000);
					
					/*JavascriptExecutor js = (JavascriptExecutor) driver; 
					js.executeScript("arguments[0].scrollIntoView()", ClickOnStepAttachment);*/
			//		js.executeScript("window.scrollBy(440,0)"); 
					Thread.sleep(2000);
					
					/*WebElement test2 = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(test2);
					System.out.println("Found Iframe");*/
					
					Actions act =new Actions(driver);
				    act.moveToElement(ClickOnStepAttachment).click().build().perform();
			 	    bp.waitForElement();
			 	    log.info("Clicked on attachment");
					Thread.sleep(1000);
					bp.waitForElement();
					
					//mousehover on attachment
					act.moveToElement(mousehover).perform();
					act.moveToElement(DeleteStepAttachment2).click().build().perform();
					bp.waitForElement();
					
					/*WebElement frame1 = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(frame1);
					System.out.println("Found Iframe");*/
					//driver.switchTo().defaultContent();
					Thread.sleep(3000);
					act.sendKeys(Keys.PAGE_DOWN).pause(2000).moveToElement(ClickOnDeleteStepAttachment).click().build().perform();
					driver.switchTo().defaultContent();
					
				log.info("Deleted StepAttachment successfully");
				
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		public boolean ScheduleTest2wrking(String projectname) throws Exception{

			try{
				bp = new CommonUtils();
				bp.waitForElement();
				
				driver.navigate().refresh();
				bp.waitForElement();
		/*		latestCreatedTest.click();
				Thread.sleep(4000);	*/
				
			ActionsContextMenu.click();
	//		ZephyrAction.click();
			Thread.sleep(2000);
			Execute.click();
			Thread.sleep(3000);
			
			WebElement frame1 = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame1);
			System.out.println("Found Iframe");
			
			Actions act = new Actions(driver);
			bp.waitForElement();
			act.moveToElement(Execute2).click().perform();
			
	
			driver.switchTo().defaultContent();
				log.info("added test to cycle");
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
	
		public boolean ScheduleTest(String projectname) throws Exception{

			try{
				bp = new CommonUtils();
				bp.waitForElement();
				
		//		driver.navigate().refresh();
		//		bp.waitForElement();
		/*		latestCreatedTest.click();
				Thread.sleep(4000);	*/
				
			ActionsContextMenu.click();
			Thread.sleep(2000);
			Execute.click();
			Thread.sleep(3000);
			
			WebElement frame1 = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame1);
			System.out.println("Found Iframe");
			
		//	AssigneeDropdown.click();
			
			Actions act = new Actions(driver);
			bp.waitForElement();
			bp.waitForElement();
			
			
		//	act.moveToElement(Execute2).click().perform();
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1000)");
			
			act.moveToElement(AssigneeDropdown).click().pause(1200).sendKeys("Zephyr QA").sendKeys(Keys.DOWN).pause(1200).click()
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.click()
			.perform();
			
			/*Actions act = new Actions(driver);
			bp.waitForElement();
			act.moveToElement(AssigneeDropdown).click().pause(1200).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			Execute2.click();*/
	
			driver.switchTo().defaultContent();
				log.info("added test to cycle");
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		public boolean addTestToCycle(String projectname) throws Exception{

			try{
				bp = new CommonUtils();
				bp.waitForElement();
					
				driver.navigate().refresh();
				bp.waitForElement();
				Thread.sleep(2000);
		/*		latestCreatedTest.click();
				Thread.sleep(4000);	*/
				
				JirasearchBox.click();
				JirasearchBox.sendKeys("TestWithExecution");
				bp.waitForElement();
				Thread.sleep(2000);
				JirasearchBox.sendKeys(Keys.ENTER);
				bp.waitForElement();
				Thread.sleep(4000);
				
			ActionsContextMenu.click();
	//		ZephyrAction.click();
			Thread.sleep(2000);
			Execute.click();
			Thread.sleep(3000);
			
			WebElement frame1 = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame1);
			System.out.println("Found Iframe");
			
			Actions act = new Actions(driver);
			bp.waitForElement();
			act.moveToElement(Execute2).click().perform();
			
	
			driver.switchTo().defaultContent();
				log.info("added test to cycle");
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		public boolean addTestToCycleWithAssignee(String projectname) throws Exception{

			try{
				bp = new CommonUtils();
				bp.waitForElement();
				
				driver.navigate().refresh();
				bp.waitForElement();
		/*		latestCreatedTest.click();
				Thread.sleep(4000);	*/
				
				ActionsContextMenu.click();
				Thread.sleep(2000);
			//	AddTestToCycle.click();
				Execute.click();
				Thread.sleep(3000);
				
				WebElement frame1 = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame1);
				System.out.println("Found Iframe");
			//	Execute2.click();
				//AssigneeDropdown.click();
				
				
				String currentWindow = driver.getWindowHandle();// get handle of current window
				System.out.println(currentWindow + "1st");
				Set<String> handles = driver.getWindowHandles();// get handle of all windows
				System.out.println(handles + "all");
				Iterator<String> it = handles.iterator();
				while (it.hasNext()) {
				if (currentWindow == it.next()) {
				continue;
				}
				
				
				Actions act = new Actions(driver);
				bp.waitForElement();
				act.moveToElement(AssigneeDropdown).click().pause(1200)
				.sendKeys("Zephyr QA").pause(1200).moveToElement(AssigneeListmousehover).click()
				.perform();
				Thread.sleep(2000);
				
				Execute2.click();
				
				}
				driver.switchTo().window(currentWindow);//switch back to original window
		
				driver.switchTo().defaultContent();
					log.info("added test to cycle");
					return true;
				}
			
			
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	
		
		public boolean addTesttoCyclewithassignee2(String projectname) throws Exception{

			try{
				bp = new CommonUtils();
				bp.waitForElement();
				
				
			ActionsContextMenu.click();
			Thread.sleep(2000);
			Execute.click();
			Thread.sleep(3000);
			
			WebElement frame1 = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame1);
			System.out.println("Found Iframe");
			
		//	AssigneeDropdown.click();
			
			Actions act = new Actions(driver);
			bp.waitForElement();
			bp.waitForElement();
			
			
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("window.scrollBy(0,1000)");
			
			act.moveToElement(AssigneeDropdown).click().pause(1200).sendKeys("Zephyr QA").sendKeys(Keys.DOWN).pause(1200).click()
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.sendKeys(Keys.TAB)
			.click()
			.perform();
			
			/*Actions act = new Actions(driver);
			bp.waitForElement();
			act.moveToElement(AssigneeDropdown).click().pause(1200).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			Execute2.click();*/
	
			driver.switchTo().defaultContent();
				log.info("added test to cycle");
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
		
		
		
		public boolean ExecuteTestExecutionInViewIssue() throws Exception {

			try{
				
				
				bp = new CommonUtils();
				bp.waitForElement();
				
			/*	driver.navigate().refresh();
				bp.waitForElement(); */
			//	latestCreatedTest.click();
				Thread.sleep(5000);
				
				
				JirasearchBox.click();
				JirasearchBox.sendKeys("TestWithExecution");
				bp.waitForElement();
				Thread.sleep(2000);
				JirasearchBox.sendKeys(Keys.ENTER);
				bp.waitForElement();
				Thread.sleep(6000);
				
				ZephyrExecutions.click();
				Thread.sleep(6000);
				bp.waitForElement();

				System.out.println("Clicking on zephyr execution in View issue");
				bp.waitForElement();
				Thread.sleep(2000);
				
				 WebElement frame = driver.findElement(By.tagName("iframe"));
					driver.switchTo().frame(frame);
					System.out.println("Found Iframe");
					
					Thread.sleep(3000);
					bp.waitForElement();
			//		ClickOnStatusHead.click();
			//		System.out.println("clicked on status");
				
				Actions act = new Actions(driver);
				act.moveToElement(StatusDropDown).pause(1500).click()
				.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
						
				System.out.println("Status Executed Successfully ");
				
				/*//to execute fail
				act.moveToElement(StatusDropDown).pause(1500).click()
				.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();
				//to execute wip
				act.moveToElement(StatusDropDown).pause(1500).click()
				.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).build().perform();*/
				
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}	

		
		
		public boolean ExecuteTestFromEButton() throws Exception {

			try{
				
				
				bp = new CommonUtils();
				bp.waitForElement();
				
				JirasearchBox.click();
				JirasearchBox.sendKeys("TestWithExecution");
				bp.waitForElement();
				Thread.sleep(2000);
				JirasearchBox.sendKeys(Keys.ENTER);
				Thread.sleep(4000);
				bp.waitForElement();
				
	//			latestCreatedTest.click();

				Actions act = new Actions(driver);
				act.moveToElement(ZephyrExecutions).pause(1500).click().perform();
				
	//			ZephyrExecutions.click();
				Thread.sleep(6000);
				bp.waitForElement();
				
			/*	WebElement frame = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame);
				System.out.println("Found Iframe");*/

				act.moveToElement(EButton2).pause(1500).click().perform();
				bp.waitForElement();
				Thread.sleep(5000);
				bp.waitForElement();
				
				WebElement frame2 = driver.findElement(By.tagName("iframe"));
				driver.switchTo().frame(frame2);
				System.out.println("Found Iframe");
				Thread.sleep(2000);
				bp.waitForElement();
									
				act.moveToElement(StatusDropDown).pause(1500).click()
				.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
						
				System.out.println("Status Executed Successfully ");
				return true;
			}
			
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}	

	
		
		public boolean goToSearchTestPage() throws Exception {
			try {
				bp = new CommonUtils();
				
				bp.waitForElement();
				Thread.sleep(1200);
				
				searchTestpage.click();

				bp.waitForElement();
				System.out.println("Launched Search Test Page Successfully");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}

		}
		
		public boolean selectFeature(String FeatureName) throws Exception {
			try {
				bp = new CommonUtils();
				
				bp.waitForElement();
				WebElement bddFeature = driver.findElement(By.xpath(selectBDD1 + FeatureName + selectBDD2));

				bddFeature.click();
				
				System.out.println("Selected Feature");
							
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}

		}
		
		public boolean clickOnFeatureContent() throws Exception {
			try {
				bp = new CommonUtils();
				
				bp.waitForElement();
				Thread.sleep(2000);
				clickOnFeatureContent.click();
				bp.waitForElement();
				
				System.out.println("Successfully clicked on BDD scenarios option");
				return true;
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}

		}
}
		



