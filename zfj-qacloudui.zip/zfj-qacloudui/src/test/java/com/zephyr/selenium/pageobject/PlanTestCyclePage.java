package com.zephyr.selenium.pageobject;

import static org.testng.Assert.assertEquals;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;


public class PlanTestCyclePage {
	
	private static final String Test = null;
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;
	ViewIssuePage vip;
	
	
	public PlanTestCyclePage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);
		

	}


	/******************************* protected WebElement *******************************/
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	protected WebElement jirahomepage;
	
	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	protected WebElement zephyrPageold;
	
	@FindBy(xpath = "//a[@data-testid='NavigationItem']//*[contains(text(),'Zephyr')]")
	protected WebElement zephyrPage;
	
	@FindBy(xpath = "//div[contains(text(),'Cycle Summary')]")
	protected WebElement cyclesummaryPage;
	
	
	@FindBy(xpath = "//*[@id='tree-container']/div[2]/button")
	protected WebElement createButtonVisible;
	
	@FindBy(xpath = "//div[contains(text(),'Projects')]")
	protected WebElement projects;
	
	
	@FindBy(xpath = "//*[@id='helpPanelContainer']/div/div[1]/div[1]/header/nav/div[3]/div[2]/div/button/span/span[1]")
	protected WebElement globalProject;
	
	@FindBy(xpath = "//span[contains(text(),'View all projects')]")
	protected WebElement viewAllProjects;
	
	
	@FindBy(xpath = "//input[@name='search']")
	protected WebElement searchproject;
	
	//@FindBy(xpath = "//*[@id='jira-frontend']//table/tbody/tr/td[1]/div/a")
	//@FindBy(xpath = "//td[@class='TableCell__TableBodyCell-sc-1mgclzx-0 gIZZXT']")
	@FindBy(xpath = "//span[@class='sc-dBAPYN bgxDJL']")
	protected WebElement clickselectedproject;
	
	@FindBy(xpath = "//div[contains(text(),'Tests')]")
	protected WebElement Tests;
	
	@FindBy(xpath = "//div[contains(text(),'Plan Test Cycle')]")
	protected WebElement plantestcycle;
	//span[contains(text(),'Cycle Summary')]
	
	
	//@FindBy(xpath = "//*[@id='root']//span[8]")
	@FindBy(xpath = "//h2[contains(text(),'Cycle Summary')]")
	public WebElement cyclesummarymoduleheading;
		
	//@FindBy(xpath = "//*[@class='breadcrumbs-content-current-page']")
	@FindBy(xpath = "//*[@class='BreadcrumbsContainer-tgj96-0 eiYreW']")
	public WebElement cyclesummarybreadcrumb;
	
	//@FindBy(xpath = "//*[@id='root']//button[2]")
	@FindBy(xpath = "//span[contains(text(),'Create New Test Cycle')]")	
	public WebElement createnewcycle;
	
	//(//div[@class='css-1s6vx3l-control'])[3]
	////div[@class='jkVhDS']
	//@FindBy(xpath = "(//div[@class='css-1s6vx3l-control'])[3]")
	@FindBy(xpath = "//div[@class='css-1tqx6ej-indicatorContainer']")
	public WebElement selectversion;
	
	@FindBy(xpath = "(//div[@class='css-1tqx6ej-indicatorContainer'])[1]")
	public WebElement selectAnotherCycleVersion;
	
	@FindBy(xpath = "(//div[@class='css-1tqx6ej-indicatorContainer'])[2]")
	public WebElement selectAnotherCycleName;
	
	@FindBy(xpath = "(//div[@class='css-1tqx6ej-indicatorContainer'])[3]")
	public WebElement selectAnotherCycleFolderName;
	
	@FindBy(xpath = "(//div[@class='css-1tqx6ej-indicatorContainer'])[4]")
	public WebElement selectAnotherCycleAssignedTo;
	
	@FindBy(xpath = "(//div[@class='css-1tqx6ej-indicatorContainer'])[4]")
	public WebElement selectLabel;
		
	@FindBy(xpath = "//input[@id='defects']//parent::div/label")
	public WebElement selectLinkedDefectCheckBox;
		
	@FindBy(xpath = "//*[@id='name']")
	public WebElement cyclename;
	
	@FindBy(xpath = "//*[@id='description']")
	public WebElement cycledescription;
	
	@FindBy(xpath = "//*[@id='build']")
	public WebElement buildname;
	
	@FindBy(xpath = "//*[@id='environment']")
	public WebElement environment;
	
	//@FindBy(xpath = "//*[@id='root']/descendant::button[text()='Save']")
	@FindBy(xpath = "//button[@class= 'ak-button ak-button__appearance-primary']")
	public WebElement savebutton;
	
	@FindBy(xpath = "//span[@title='ZFJC 3.2 build']")
	public WebElement verifybuildname;
	
	@FindBy(xpath = "//span[@class='Icon__IconWrapper-dyhwwi-0 jdkWJB']")
	public WebElement expandUnreleasedVersion;
		
	
	@FindBy(xpath = "//*[@id='10440']/div[2]/button/span/span/span")
	public WebElement expandVersion;
	
	//*[@id="10006_868b1726-0a9c-4c59-801c-e21424d561c1"]/div[5]/div/div/div/div[1]/div/div/span
	
	@FindBy(xpath = "//span[@title='Zephyr QA']")
	public WebElement verifycreatedby;
	
	@FindBy(xpath = "//span[@title='Automation description']")
	public WebElement verifydescription;
	
	@FindBy(xpath = "//span[@title='CLOUD environment']")
	public WebElement verifyenvironment;
	
	@FindBy(xpath = "//button[@class='addTest-btn']")
	public WebElement addtestsbutton;
	
	
	@FindBy(xpath = "(//*[text()='Select...'])[1]")
	public WebElement searchindividualtest;
	
	@FindBy(xpath = "(//*[text()='Select...'])[2]")
	public WebElement assigntoindividual;
	
	@FindBy(xpath = "//div[@class='modal-footer']/button[1]")
	public WebElement addbutton;
	
	@FindBy(xpath = "//div[@class='modal-footer']/button[2]")
	public WebElement cancelbutton;
		
	@FindBy(xpath = "//span[contains(text(),'Close')]")
	public WebElement closebutton;
	
	@FindBy(xpath = "//*[text()='Cycle Summary']")
	public WebElement cycleSummary;
	
	@FindBy(xpath = "//div[contains(text(),'Via Search Filter')]")
	public WebElement searchviafilter;
	
	@FindBy(xpath = "//div[contains(text(),'From Another Cycle')]")
	public WebElement fromAnotherCycle;
	
	//@FindBy(xpath = "(//input[@value=''])[3]")
	@FindBy(xpath = "(//*[text()='Select...'])[1]")
	public WebElement selectsearchfilter;
	
	@FindBy(xpath = "(//input[@value=''])[3]")
	public WebElement assigntofilter;
	
	@FindBy(xpath = "//*[@class='ak-field-date ak-field__width-medium']")
	public WebElement searchcreatedcycle;
	
	@FindBy(xpath = "//div[@class='individualNodeItem text-ellipses']")
	public WebElement findcyclenametoedit;
	
	@FindBy(xpath = "//div[@class='context-wrapper']")
	public WebElement contextwrapper;
	
	//(//div[@class='context-wrapper'])[2]
	//(//div[@title='folder for bdd']
	@FindBy(xpath = "(//div[@class='context-wrapper'])[3]")
	public WebElement contextwrapper1;
	
	@FindBy(xpath = "//span[text()='Edit']")
	public WebElement editcycle;
	
	@FindBy(xpath = "//span[text()='Move']")
	public WebElement moveCycle;
	
	@FindBy(xpath = "//span[text()='Clone']")
	public WebElement clonecycle;
	
	
	@FindBy(xpath = "//*[@id='copyCustomField']")
	public WebElement copyCustomFields;
	
	@FindBy(xpath = "//span[text()='Delete']")
	public WebElement deletecycle;
	
	@FindBy(xpath = "//span[text()='Export']")
	public WebElement exportcycle;
	
	//@FindBy(xpath = "//span[text()='Add Folder']")
	@FindBy(xpath = "//*[text()='Add Folder']")
	public WebElement addfolder;
	
	@FindBy(xpath = "//p[contains(text(),'sec')]")
	public WebElement timetaken;
	
	
	@FindBy(xpath = "(//span[@class='_7QLRwe2RhZI5KWZF0kwnF'])[1]")
	public WebElement cycleexpander;
	
	@FindBy(xpath = "//div[@title='All Versions']")
	public WebElement allversion;
	
	@FindBy(xpath = "(//span[@class='_3oWQF5W5kZzJBpObJfEzGt _37ccNB_mPuor8FT7FPGHGL'])[3]")
	public WebElement ellipsisfromsearch;
	
	@FindBy(xpath = "(//button[text()='Delete'])[2]")
	public WebElement deletebutton;
	
	
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/span[3]/img")
	public WebElement statusDropDownSelection;
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/span[3]")
	public WebElement statusDropDownForPass;
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[2]/div/div/span[3]")
	public WebElement statusDropDownForFail;
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/div/ul/li[2]")
	public WebElement selectFailStatus;
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[3]/div/div/span[3]")
	public WebElement statusDropDownForWip;
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[4]/div/div/span[3]")
	public WebElement statusDropDownForBlocked;
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[2]/div[5]/div/div/span[3]")
	public WebElement statusDropDownForCustom;
	
	@FindBy(xpath = "//*[@id='actionGridBody']/div/div[1]/div/div[1]/a/img")
	public WebElement clickOnExecuteButton;
	
	@FindBy(xpath = "//*[@id='description-option-outer-container']/div[1]/span[1]")
	public WebElement clickOnSkipButton;
	
	@FindBy(xpath = "//*[@class='dropDown-wrapper select-status']/span[3]")
	public WebElement clickOnStatusDropDown;
	
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[6]/div[1]/div/div/span[3]")
	public WebElement clickOnTestStepStatusDropDownForPass;
	
	
	@FindBy(xpath = "//*[@id='unfreezedGridBody']/div[6]/div[2]/div/div/span[3]")
	public WebElement clickOnTestStepStatusDropDownForFail;
	
	@FindBy(xpath = "(//div[@class='context-wrapper'])[1]")
	
	//*[@id="root"]/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/div[2]/div/div/div/div/div/div[1]/div/div[1]/div/div[3]/div/div/div[3]/div[1]/div/div[4]/div
	//@FindBy(xpath="//div[@class='Droplist__Trigger-sc-1z05y4v-3 eteVrT']")
	//@FindBy(xpath="//*[@id=\"root\"]/div/div/div[2]/div/div[2]/div/div/div/div/div[2]/div[2]/div/div/div/div/div/div[1]/div/div[1]/div/div[3]/div/div/div[4]/div[1]/div/div[3]/div")
	//@FindBy(xpath="//span/div/div/div/div/div/div/span")
	public WebElement cycleContextmenu;
	
	 //span[@title='Automation Cycle']
	
	@FindBy(xpath="//span[@title='Automation Cycle']")
	public WebElement clickOnCycle;
	
	@FindBy(xpath = "//*[@id='name']")	
	public WebElement foldername;
	
	
	@FindBy(xpath="//*[text()='Add']")
	public WebElement folderAddbtn;
	
	@FindBy(xpath = "//*[@id='createGlobalItem']")
	protected WebElement test;
	
//	@FindBy(xpath = "(//*[text()='Next'])[1]")
	@FindBy(xpath = "//*[@class='navigation-img next']")
	protected WebElement nextarrow;
	
	@FindBy(xpath = "//*[text()='Delete Folder']")
	protected WebElement deleteFolder;
	
	@FindBy(xpath ="(//*[text()='Delete'])[2]")
	protected WebElement deltefolderbtn;
	
	@FindBy(xpath = "//*[text()='Download Feature File']")
	protected WebElement downloadFeatureoption;
	
	@FindBy(xpath = "//*[text()='Upload Cucumber Results']")
	protected WebElement uploadcucumberresult;
	
	@FindBy(xpath = "//div[text()='UNEXECUTED']")
	protected WebElement unexecuted;
	
	@FindBy(xpath = "//div[text()='PASS']")
	protected WebElement pass;
	
	@FindBy(xpath = "//div[text()='FAIL']")
	protected WebElement fail;
	
	//*[@class='ak-button ak-button__appearance-default css-173r301']
	@FindBy(xpath = "//*[@title='Tree View']")
	protected WebElement contextmenu;
	
	@FindBy(xpath = "//*[@class='treebeard']/ul/li/div[2]/ul/li/div[2]/ul/li/div[2]/ul/li/div[1]/div[1]/div")
	protected WebElement downarrowforFolder;
	
	@FindBy(xpath = "//*[text()='folder for bdd']")
	protected WebElement folderName;
	
	
	@FindBy(xpath = "(//*[@class='css-kb4noc-placeholder'])[3]")
	protected WebElement AddTestIndividually;

	
	@FindBy(xpath = "//*[@title='Tree View']")
	protected WebElement TreeView;
	
	@FindBy(xpath = "//*[@title='List View']")
	protected WebElement ListView;
	
	@FindBy(xpath = "//*[@title='Automation folder' and  @id= 'folder-0965f2cc-802d-4ee2-b54b-ed3978203300']")
	protected WebElement selectAutomationFolder;
	
	
	@FindBy(xpath = "//*[@class='ak-field-date ak-field__width-medium']")
	protected WebElement searchCycleFolder;
	
	@FindBy(xpath="(//*[@class='search-wrapper']//*[@type='button'])[1]")
	protected WebElement view;
	
	@FindBy(xpath="(//*[@class= 'css-1g760b7'])[4]")
	protected WebElement ExpandVersionV1;
	
	@FindBy(xpath="//button[@class='blue-theme-bg']")
	protected WebElement cycleDetail;
	
	@FindBy(xpath="//button[@class='backbutton blue-theme-bg']")
	protected WebElement cycleList;
	
	@FindBy(xpath="//div[contains(text(),'Select...')]")
	protected WebElement addExistingDefect;
	
	
	@FindBy(xpath="//*[@id='type']/div/div[2]/div")
	protected WebElement selectExportType;
	
	@FindBy(xpath = "//button[contains(text(),'Export')]")
	public WebElement clickOnExport;
	
	@FindBy(xpath = "//span[contains(text(),'Close')]")
	public WebElement exportCloseButton;
	
	@FindBy(xpath = "//*[@id='Background']")
	public WebElement appTourIcon;
	
	@FindBy(xpath = "//*[@class='knowledge-tour-options']/div[1]")
	public WebElement takeAFeatureTourOption;
	
	@FindBy(xpath = "//*[@class='knowledge-tour-options']/div[2]")
	public WebElement showNewFeaturePageOption;
	
	@FindBy(xpath = "//*[text()='Skip Tour']")
	public WebElement skipTour;
	
	@FindBy(xpath = "//*[text()='Show more page(s)']")
	public WebElement showMorePages;
	
	@FindBy(xpath = "//*[text()='Next feature >']")
	public WebElement showNextFeature;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-0']")
	public WebElement breadcrum;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-1']")
	public WebElement searchFilter;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-2']")
	public WebElement contextMenu;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-3']")
	public WebElement columnChooser;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-4']")
	public WebElement stepResultSection;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-5']")
	public WebElement treeDock;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-6']")
	public WebElement treeScroll;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-7']")
	public WebElement gridPagination;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-8']")
	public WebElement cycleDescription;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-9']")
	public WebElement switchToDetail;
	
	@FindBy(xpath = "//*[@id='walkthrough-item-description-10']")
	public WebElement navigateToSTE;
		
	@FindBy(xpath = "//*[@id='walkthrough-main-outer-container']/div[2]")
	public WebElement closeAppTour;
	
	
	@FindBy(xpath = "//*[@id='description-option-outer-container']/div[2]")
	public WebElement nextFeature;
	
	@FindBy(xpath = "//*[contains(text(),'Standalone Execution')]")
	public WebElement standaloneExecution;
	
	@FindBy(xpath = "//*[contains(text(),'Close')]")
	public WebElement close;
	
	@FindBy(xpath = "//h2[@class='modal-title']")
	public WebElement contextWrapperWindow;
	
	//******************************************************************
	
	public String version1 = "//*[@id='";
	public String version2 = "']/div[2]/button/span/span/span";
	
	public String cycleName1 = "//div[@title='";
	public String cycleName2 = "']";
	
	public String build1 = "//span[@title='";
	public String build2 = "']";
	
	public String Environment1 = "//span[@title='";
	public String Environment2 = "']";

	public String createdBy1 = "//span[@title='";
	public String createdBy2 = "']";
	
	public String CycleContextWrapper1 = "//div[@title='";
	public String CycleContextWrapper2 = "']/following-sibling::div/div/div/div/div[1]/div/div/span";
	
	public String cycleNameLink1 = "//a[@title='";
	public String cycleNameLink2 = "']//parent::span";
	
	//a[@title='Automation Cycle2020_09_11__12_20_33']//parent::span
	
	//span[contains(text(),'PlanCycle')]
		
	public String clickselectedproject1 = "//span[contains(text(),'";
	public String clickselectedproject2 = "')]";
	
	public boolean goToCycleSummary() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			cycleSummary.click();
					
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean navigateToJiraHomePage() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			jirahomepage.click();
			
			System.out.println("Navigate to Jira Home page");			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean navigateToProject(String projectname) throws Exception{

		try{
			bp = new CommonUtils();
			Thread.sleep(2000);
			/*jirahomepage.click();
			
			System.out.println("Navigate to Jira Home page");
			bp.waitForElement();
			
			Thread.sleep(2000);
			projects.click();
			System.out.println("Clicked on Projects Menu");*/
			//driver.navigate().refresh();
			bp.waitForElement();
			driver.navigate().refresh();
			bp.waitTillElementIsVisible(globalProject);
			globalProject.click();
			bp.waitForElement();
			
			bp.waitTillElementIsVisible(viewAllProjects);
			viewAllProjects.click();
			bp.waitForElement();
			
			Actions act = new Actions(driver);
			act.moveToElement(searchproject).click().pause(1500).sendKeys(projectname).pause(1500).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			
			bp.waitForElement();

			
			WebElement clickselectedproject = driver.findElement(By.xpath(clickselectedproject1 + projectname + clickselectedproject2));

			
			clickselectedproject.click();
			System.out.println("Clicked on Automation Project");
			bp.waitForElement();
				
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean validatePlanTestCycle() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			/*jirahomepage.click();
			System.out.println("Navigate to Jira Home page");
			bp.waitForElement();
			
			Tests.click();
			System.out.println("Clicked on Tests");
			bp.waitForElement();
			plantestcycle.click();
			System.out.println("Clicked on Plan test cycle page, validating plan test cycle page");
						
			String validateText = 	driver.getTitle();
			assertEquals(validateText, "Plan Test Cycle - Jira");
			System.out.println("Plan Test cycle page title validated succesfully");*/
			
			
			zephyrPage.click();
			System.out.println("Navigated to Zephyr page");
			bp.waitTillElementIsVisible(cyclesummaryPage);
			cyclesummaryPage.click();
			
			System.out.println("Navigated to Cycle Summary page");
			bp.waitForElement();
			bp.waitTillElementIsVisible(cyclesummaryPage);
			//WebElement frame = driver.findElement(By.tagName("iframe"));
						
			driver.switchTo().frame(0);
			
			System.out.println("Found Iframe");
			boolean status = cyclesummarybreadcrumb.isDisplayed();
			if (status) {
				System.out.println("Validated Cycle Summary breadcrumb");
			 }
			 else
			 {
				 System.out.println("Cycle Summary breadcrumb not present");
			 }
			
			bp.waitForElement();
			
			boolean status1 = cyclesummarymoduleheading.isDisplayed();
			if (status1 == true) {
				System.out.println("Validated Cycle Summary heading");
			 }
			 else
			 {
				 System.out.println("Cycle Summary heading not present");
			 }
			
		
			bp.waitForElement();
			
			
			
			return true;
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		}
		
		

	public boolean createNewCycle(String version1, String cycname, String cycdesc, String build, String env) throws Exception {
		try{
			//validatePlanTestCycle();
					
			bp = new CommonUtils();
			bp.waitForElement();
						
			bp.waitTillElementIsVisible(createnewcycle);
			createnewcycle.click();
			System.out.println("Clicked on create new cycle button");
			bp.waitForElement();
			Thread.sleep(1000);
			Actions act = new Actions(driver);
			act.moveToElement(selectversion).click().pause(1200).sendKeys(version1).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);			
					
			cyclename.sendKeys(cycname);
			bp.waitForElement();
			cycledescription.sendKeys(cycdesc);
			bp.waitForElement();
			
			buildname.sendKeys(build);
			bp.waitForElement();
			
			environment.sendKeys(env);
			bp.waitForElement();
		  			
			savebutton.click();
			
			
			return true;
		
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	
	}

	public boolean verifyCreatedCycle(String version, String cyclename, String build, String Environment, String createdBy) throws Exception{
	
		try{
							
			bp = new CommonUtils();
			bp.waitForElement();
			bp.waitForElement();

			System.out.println("Validating the created cyccle");
			
			bp.waitForElement();
			
			Actions actions = new Actions(driver);
			actions.sendKeys(Keys.PAGE_UP).pause(3000).moveToElement(expandUnreleasedVersion).pause(1200).click().build().perform();
			
			bp.waitForElement();
			System.out.println("Unreleased Version Expanded Successfully");
			
			bp.waitForElement();
			
			WebElement expandVersion = driver.findElement(By.xpath(version1 + version + version2));
							
			expandVersion.click();
			
			
			System.out.println("Version Expanded Successfully");
			
			
			
			bp.waitForElement();
			bp.waitForElement();
			
			WebElement cycleName = driver.findElement(By.xpath(cycleName1 + cyclename + cycleName2));
			cycleName.click();	
			
			System.out.println(cyclename + ": Created");
			
			System.out.println("Clicked on Newly Created Cycle Successfully");
			
			WebElement verifyCycleName = driver.findElement(By.xpath(cycleName1 + cyclename + cycleName2));
						
			WebElement verifybuildname = driver.findElement(By.xpath(build1 + build + build2));
			
			WebElement verifyEnvironment = driver.findElement(By.xpath(Environment1 + Environment + Environment2));
						
			WebElement verifycreatedby = driver.findElement(By.xpath(createdBy1 + createdBy + createdBy2));
					
				
			boolean Cycle = verifyCycleName.isDisplayed();
			
			
			if (Cycle) {
				System.out.println(cyclename + ": Validated Cycle Name Successfully");
			 }
			 else
			 {
				 System.out.println("Cycle Name verification failed");
			 }

			bp.waitForElement();
			
			boolean buildName = verifybuildname.isDisplayed();
			
			
			if (buildName) {
				System.out.println(build + ": Validated Build Name Successfully");
			 }
			 else
			 {
				 System.out.println("Build Name verification failed");
			 }

			bp.waitForElement();
			
			boolean description = verifydescription.isDisplayed();
			
			if (description) {
				System.out.println(Environment + ": Validated Cycle Description Name Successfully");
			 }
			 else
			 {
				 System.out.println("Cycle Description Name verification failed");
			 }
			bp.waitForElement();
			
			boolean createdByName = verifycreatedby.isDisplayed();
			
			if (createdByName) {
				System.out.println(createdBy + ": Validated Created By Successfully");
			 }
			 else
			 {
				 System.out.println("Created By verification failed");
			 }
			
			boolean environment = verifyEnvironment.isDisplayed();
			if (environment) {
				System.out.println(Environment + ": Validated Environment");
			 }
			 else
			 {
				 System.out.println("Environment verification failed");
			 }
			
			return true;
		
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	
	}
	
	public boolean collapseVersion(String version, String cyclename, String build, String Environment, String createdBy) throws Exception{
		
		try{
							
			bp = new CommonUtils();
			bp.waitForElement();
			bp.waitForElement();

			System.out.println("Collapsing the Version and Unreleased version the created cyccle");
			
			bp.waitForElement();
			
			WebElement expandVersion = driver.findElement(By.xpath(version1 + version + version2));
			
			expandVersion.click();
			
			
			System.out.println("Version Collapsed Successfully");
			
			Actions actions = new Actions(driver);
			actions.moveToElement(expandUnreleasedVersion).pause(1200).click().build().perform();
			
			bp.waitForElement();
			System.out.println("Unreleased Version Collapsed Successfully");
			
			bp.waitForElement();
			
			
			
			
			return true;
		
	} catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	
	}


	public boolean addTestToCycle(String issue) throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(1200);
			//to scroll up
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
	    	((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", addtestsbutton);
	    	
			Actions act = new Actions(driver);	
			act.moveToElement(addtestsbutton).pause(1200).click().perform();
			
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to cycle");
			//bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
			
			      		
	    	
			
			bp.waitForElement();
			act.moveToElement(searchindividualtest).click().pause(1200).sendKeys(issue).pause(2000).sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			log.info("Added Tests Individually and Assigned to Zephyr QA");
			/*bp.waitForElement();
			act.moveToElement(assigntoindividual).click().pause(1200).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			addbutton.click();
			Thread.sleep(2000);*/
			
			
			bp.waitForElement();	
			bp.waitForElement();
			bp.waitForElement();
			bp.waitForElement();
			act.moveToElement(closebutton).pause(2000).click().perform();
			log.info("Clicked on Close button");
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean addMultipleTestToCycle() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to cycle");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
			

			Actions act = new Actions(driver);
			bp.waitForElement();
			act.moveToElement(searchindividualtest).click().pause(1200)
			.sendKeys("Test1").pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER)
			.sendKeys("Test2").pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER)
			.sendKeys("Test3").pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER)
			.sendKeys("Test4").pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER)
			.sendKeys("Test5").pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER)
			.sendKeys(Keys.TAB).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			log.info("Added Tests Individually and Assigned to Zephyr QA");
			/*bp.waitForElement();
			act.moveToElement(assigntoindividual).click().pause(1200).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			addbutton.click();
			Thread.sleep(2000);*/
			
			
			bp.waitForElement();	
			bp.waitForElement();
			bp.waitForElement();
			bp.waitForElement();
			act.moveToElement(closebutton).pause(2000).click().perform();
			bp.waitForElement();
			bp.waitForElement();
			bp.waitForElement();
			log.info("Clicked on Close button");
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean addTestToCycleViaJiraSearch(String filterName1) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
						
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Clicking on Via Search Filter option");
			bp.waitForElement();
			Thread.sleep(2000);
			searchviafilter.click();
			bp.waitForElement();
			Thread.sleep(5000);	
			
			Actions act = new Actions(driver);
			
			act.moveToElement(selectsearchfilter).click().pause(1200).sendKeys(filterName1).pause(1200).sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys("Zephyr QA").sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			log.info("Added Tests via Search Filter and Assigned to Zephyr QA");
			/*
			act.moveToElement(selectsearchfilter).click().pause(1200).sendKeys(filterName1).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);	
			bp.waitForElement();
						
			act.moveToElement(assigntofilter).click().pause(1200).sendKeys("qa").sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			addbutton.click();
			Thread.sleep(10000);
			
			bp.explicitWait(timetaken);*/
			bp.waitForElement();
			act.moveToElement(closebutton).pause(2000).click().perform();
			log.info("Clicked on Close button");
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean addTestToCycleViaAnotherCycle(String versionName, String cycleName, String assignee) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
						
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Clicking on From Another Cycle option");
			bp.waitForElement();
			Thread.sleep(2000);
			fromAnotherCycle.click();
			bp.waitForElement();
			Thread.sleep(5000);	
			
			Actions act = new Actions(driver);
			act.moveToElement(selectAnotherCycleVersion).click().pause(1200).sendKeys(versionName).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);			
			
			bp.waitForElement();
			
			act.moveToElement(selectAnotherCycleName).click().pause(1200).sendKeys(cycleName).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);			
			
			bp.waitForElement();
			
			act.moveToElement(selectAnotherCycleAssignedTo).click().pause(1200).sendKeys(assignee).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);			
		  			
			savebutton.click();
			
			bp.waitForElement();	
			bp.waitForElement();
			bp.waitForElement();
			bp.waitForElement();
			act.moveToElement(closebutton).pause(2000).click().perform();
			log.info("Clicked on Close button");
			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean addTestToCycleViaAnotherCycleByFilteringDefects(String versionName, String cycleName, String assignee) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
					
			bp.waitTillElementIsVisible(addtestsbutton);
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Clicking on From Another Cycle option");
			bp.waitForElement();
			Thread.sleep(2000);
			fromAnotherCycle.click();
			bp.waitForElement();
			Thread.sleep(5000);	
			
			Actions act = new Actions(driver);
			act.moveToElement(selectAnotherCycleVersion).click().pause(1200).sendKeys(versionName).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);			
			
			bp.waitForElement();
			
			act.moveToElement(selectAnotherCycleName).click().pause(1200).sendKeys(cycleName).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);			
			
			bp.waitForElement();
			act.moveToElement(selectAnotherCycleAssignedTo).click().pause(1200).sendKeys(assignee).pause(1200).sendKeys(Keys.ENTER).pause(1200).perform();
			
			Thread.sleep(2000);			
		  
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
	        WebElement DefectCheckboxElement = driver.findElement(By.xpath("//input[@id='defects']//parent::div/label"));

	        //This will scroll the page till the element is found		
	        js.executeScript("arguments[0].scrollIntoView();", DefectCheckboxElement);
	        bp.waitForElement();
	        bp.waitTillElementIsVisible(selectLinkedDefectCheckBox);
			
			selectLinkedDefectCheckBox.click();
			
			savebutton.click();
			
			bp.waitForElement();	
			bp.waitTillElementIsVisible(closebutton);
			act.moveToElement(closebutton).pause(2000).click().perform();
			log.info("Clicked on Close button");
			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	public boolean editTestCycle() throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				    
			System.out.println("Creating new cycle for editing");
			createNewCycle("unscheduled","new cycle", "description", "ZFJC PROD", "ENV");
			
			System.out.println("Created cycle");
			bp.waitForElement();
			Thread.sleep(2000);
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("new cycle").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			
			findcyclenametoedit.click();
			bp.waitForElement();
			
			contextwrapper.click();
			bp.waitForElement();
			
				
			editcycle.click();
			bp.waitForElement();
			bp.eraseText(cyclename); 
				
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String cycleName= "Edited cycleName" + timestamp;
			String cycleDescription= "Edited cycleDescription" + timestamp;
			String cycleBuildNumber= "Edited cycleBuildNumber" + timestamp;
			String cycleEnvironment= "Edited cycleEnvironment" + timestamp;
			
			cyclename.sendKeys(cycleName);
			bp.waitForElement();
			
			bp.eraseText(cycledescription);
			cycledescription.sendKeys(cycleDescription);
			bp.waitForElement();
			bp.eraseText(buildname);
			
			buildname.sendKeys(cycleBuildNumber);
			bp.waitForElement();
			bp.eraseText(environment);
			
			environment.sendKeys(cycleEnvironment);
			bp.waitForElement();  			
			savebutton.click();			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean editTestCycle(String cycleName, String editCycleDetails) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				    
			/*System.out.println("Creating new cycle for editing");
			createNewCycle("unscheduled","new cycle", "description", "ZFJC PROD", "ENV");
			
			System.out.println("Created cycle");
			bp.waitForElement();
			Thread.sleep(2000);
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("new cycle").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			
			findcyclenametoedit.click();
			bp.waitForElement();
			
			contextwrapper.click();
			bp.waitForElement();*/
			
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
				
			editcycle.click();
			
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
			
			js.executeScript("arguments[0].scrollIntoView();", contextWrapperWindow);

			System.out.println("Edit Cycle Window Displayed");
			
			bp.waitForElement();
			bp.eraseText(cyclename); 
				
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String CycleName= "Edited cycleName" + timestamp;
			String cycleDescription= "Edited cycleDescription" + timestamp;
			String cycleBuildNumber= "Edited cycleBuildNumber" + timestamp;
			String cycleEnvironment= "Edited cycleEnvironment" + timestamp;
			
			cyclename.sendKeys(CycleName);
			bp.waitForElement();
			
			bp.eraseText(cycledescription);
			cycledescription.sendKeys(cycleDescription);
			bp.waitForElement();
			bp.eraseText(buildname);
			
			buildname.sendKeys(cycleBuildNumber);
			bp.waitForElement();
			bp.eraseText(environment);
			
			environment.sendKeys(cycleEnvironment);
			bp.waitForElement();  			
			savebutton.click();			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	

	
	public boolean moveCycle(String cycleName, String movetoVersionName) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
/*			
			System.out.println("Creating new cycle for cloning");
			createNewCycle("unscheduled","new cycle1", "description", "ZFJC PROD", "ENV");
			
			System.out.println("Created cycle");
			bp.waitForElement();
			
			searchcreatedcycle.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			bp.eraseText(searchcreatedcycle);
			bp.waitForElement();
			Thread.sleep(2000);
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("new cycle1").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			
			findcyclenametoedit.click();
			bp.waitForElement();
			
			contextwrapper.click();
			bp.waitForElement();*/
			
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
			editcycle.click();
			bp.waitForElement();
			bp.waitForElement();
			
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
			
			js.executeScript("arguments[0].scrollIntoView();", contextWrapperWindow);

			System.out.println("Edit Cycle Window Displayed");
			
			Actions act = new Actions(driver);
			act.moveToElement(selectversion).click().pause(1200).sendKeys(movetoVersionName).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String CycleName= "Moved cycleName" + timestamp;
			String cycleDescription= "Moved cycleDescription" + timestamp;
			String cycleBuildNumber= "Moved cycleBuildNumber" + timestamp;
			String cycleEnvironment= "Moved cycleEnvironment" + timestamp;
			
			bp.eraseText(cyclename); 			
			cyclename.sendKeys(CycleName);
			bp.waitForElement();
			
			bp.eraseText(cycledescription);
			cycledescription.sendKeys(cycleDescription);
			bp.waitForElement();
			
			bp.eraseText(buildname);			
			buildname.sendKeys(cycleBuildNumber);
			bp.waitForElement();
			
			bp.eraseText(environment);			
			environment.sendKeys(cycleEnvironment);
			bp.waitForElement();  			
			savebutton.click();	
			
			
			
			
			return true;
			
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
		
	public boolean moveCycle(String version1) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			
			System.out.println("Creating new cycle for cloning");
			createNewCycle("unscheduled","new cycle1", "description", "ZFJC PROD", "ENV");
			
			System.out.println("Created cycle");
			bp.waitForElement();
			
			searchcreatedcycle.click();
			bp.waitForElement();
			Thread.sleep(2000);
			
			bp.eraseText(searchcreatedcycle);
			bp.waitForElement();
			Thread.sleep(2000);
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("new cycle1").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			
			findcyclenametoedit.click();
			bp.waitForElement();
			
			contextwrapper.click();
			bp.waitForElement();
			
			editcycle.click();
			bp.waitForElement();
			
			act.moveToElement(selectversion).click().pause(1200).sendKeys(version1).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);
			bp.eraseText(cyclename); 
					
			cyclename.sendKeys("Moved cycle");
			bp.waitForElement();
			savebutton.click();			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
		

	
	public boolean cloneCycle(String cycleName) throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			System.out.println("Creating new cycle for cloning");
			createNewCycle("unscheduled","new cycle2", "description", "ZFJC PROD", "ENV");
			
			System.out.println("Created cycle");
			bp.waitForElement();
			searchcreatedcycle.click();
			bp.waitForElement();
			bp.eraseText(searchcreatedcycle);
			bp.waitForElement();
					
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("new cycle2").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			
			findcyclenametoedit.click();
			bp.waitForElement();
			
			contextwrapper.click();
			bp.waitForElement();
			
			clonecycle.click();
			bp.waitForElement();
			
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
			
			js.executeScript("arguments[0].scrollIntoView();", contextWrapperWindow);

			System.out.println("Edit Cycle Window Displayed");
			
			bp.eraseText(cyclename);		
			
			cyclename.sendKeys("cloned cycle");
			bp.waitForElement();
			
			savebutton.click();	
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
		
	public boolean cloneCycle(String cycleName, String cloneCycleName) throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
			clonecycle.click();
			bp.waitForElement();
		
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
			
			js.executeScript("arguments[0].scrollIntoView();", contextWrapperWindow);

			System.out.println("Edit Cycle Window Displayed");
			
			bp.eraseText(cyclename);		
			
			cyclename.sendKeys(cloneCycleName);
			bp.waitForElement();
			
			savebutton.click();	
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
		
	public boolean cloneCycleWithCustomFields(String cycleName, String cloneCycleName) throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
			clonecycle.click();
			bp.waitForElement();
		
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
			
			js.executeScript("arguments[0].scrollIntoView();", contextWrapperWindow);

			System.out.println("Edit Cycle Window Displayed");
			
			bp.eraseText(cyclename);		
			
			cyclename.sendKeys(cloneCycleName);
			
			copyCustomFields.click();
			
			bp.waitForElement();
			
			savebutton.click();	
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
	
	public boolean appTour() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
		
			Actions act = new Actions(driver);
			act.moveToElement(appTourIcon).pause(1200).click().perform();
			bp.waitForElement();
			act.moveToElement(takeAFeatureTourOption).pause(1200).click().perform();
			bp.waitForElement();
			
			if(skipTour.isDisplayed())
			{
				System.out.println("skipTour is displayed");
			}
			else
			{
				System.out.println("skipTour is NOT displayed");
			}
			
			if(showMorePages.isDisplayed())
			{
				System.out.println("showMorePages is displayed");
			}
			else
			{
				System.out.println("showMorePages is NOT displayed");
			}
			
			if(showNextFeature.isDisplayed())
			{
				System.out.println("showNextFeature is displayed");
			}
			else
			{
				System.out.println("showNextFeature is NOT displayed");
			}
					
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean showNewPageFeatures() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			Actions act = new Actions(driver);
			act.moveToElement(appTourIcon).pause(1200).click().perform();
			bp.waitForElement();
			act.moveToElement(showNewFeaturePageOption).pause(1200).click().perform();
			bp.waitForElement();
	
			if(breadcrum.isDisplayed())
			{
				System.out.println(breadcrum.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(breadcrum.getText() + "--> Not Displayed");
			}
			
			if(searchFilter.isDisplayed())
			{
				System.out.println(searchFilter.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(searchFilter.getText() + "--> Not Displayed");
			}
			
			if(contextMenu.isDisplayed())
			{
				System.out.println(contextMenu.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(contextMenu.getText() + "--> Not Displayed");
			}
			
			if(treeDock.isDisplayed())
			{
				System.out.println(treeDock.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(treeDock.getText() + "--> Not Displayed");
			}
			
			if(treeScroll.isDisplayed())
			{
				System.out.println(treeScroll.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(treeScroll.getText() + "--> Not Displayed");
			}
			
			if(gridPagination.isDisplayed())
			{
				System.out.println(gridPagination.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(gridPagination.getText() + "--> Not Displayed");
			}
			
			if(cycleDescription.isDisplayed())
			{
				System.out.println(cycleDescription.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(cycleDescription.getText() + "--> Not Displayed");
			}
			
			if(switchToDetail.isDisplayed())
			{
				System.out.println(switchToDetail.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(switchToDetail.getText() + "--> Not Displayed");
			}
			
			act.moveToElement(closeAppTour,0,75).pause(1200).click().perform();
			bp.waitForElement();
						
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean deleteCycle() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			bp.waitForElement();
			searchcreatedcycle.click();
			bp.waitForElement();
			
			bp.eraseText(searchcreatedcycle);
			bp.waitForElement();
			Thread.sleep(2000);
			
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("new cycle2").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			
			findcyclenametoedit.click();
			bp.waitForElement();
			
			contextwrapper.click();
			bp.waitForElement();
			
			deletecycle.click();
			bp.waitForElement();
						
			deletebutton.click();
			bp.waitForElement();
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
	

	public boolean ExecuteTestFromPTC() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			
			Actions act = new Actions(driver);
			act.moveToElement(statusDropDownForPass).pause(1200).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			System.out.println("Status changed to PASS");
			act.moveToElement(statusDropDownForFail).pause(1200).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			System.out.println("Status changed to FAIL");
			act.moveToElement(statusDropDownForWip).pause(1200).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			System.out.println("Status changed to WIP");
			act.moveToElement(statusDropDownForBlocked).pause(1200).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			System.out.println("Status changed to BLOCKED");
			act.moveToElement(statusDropDownForCustom).pause(1200).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN)
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			System.out.println("Status changed to CUSTOM");
			
			/*bp.waitTillElementIsVisible(statusDropDownForPass);
			statusDropDownForPass.click();
			bp.waitForElement();
			
			driver.findElement(By.xpath("//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/div/ul/li[1]")).click();			
			bp.waitForElement();
			System.out.println("Status changed to PASS");*/
						
			
			/*bp.waitTillElementIsVisible(statusDropDownForFail);
			statusDropDownForFail.click();
			bp.waitForElement();
			
			WebElement Fail = driver.findElement(By.xpath("//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/div/ul/li[2]"));
			bp.waitTillElementIsVisible(Fail);
			Fail.click();
			bp.waitForElement();
			System.out.println("Status changed to FAIL");*/
			
			/*bp.waitTillElementIsVisible(statusDropDownForWip);
			statusDropDownForWip.click();
			bp.waitForElement();
			
			driver.findElement(By.xpath("//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/div/ul/li[3]")).click();
			bp.waitForElement();
			System.out.println("Status changed to WIP");
			
			bp.waitTillElementIsVisible(statusDropDownForBlocked);
			statusDropDownForBlocked.click();
			bp.waitForElement();
			
			driver.findElement(By.xpath("//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/div/ul/li[4]")).click();
			bp.waitForElement();
			System.out.println("Status changed to BLOCKED");
			
			bp.waitTillElementIsVisible(statusDropDownForcustom);
			statusDropDownForcustom.click();
			bp.waitForElement();
			
			driver.findElement(By.xpath("//*[@id='unfreezedGridBody']/div[2]/div[1]/div/div/div/ul/li[5]")).click();
			bp.waitForElement();
			System.out.println("Status changed to Custom");*/
				
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
	
	
	
	public boolean ExecuteTestFromEoption() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			bp.waitTillElementIsVisible(clickOnExecuteButton);
			clickOnExecuteButton.click();
			
			 WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			Thread.sleep(5000);
			bp.waitForElement();
				
			//bp.waitTillElementIsVisible(clickOnSkipButton);
			/*boolean SkipButton = clickOnSkipButton.isDisplayed();
			if (SkipButton) 
			{
			
			clickOnSkipButton.click();
			Actions act = new Actions(driver);
			act.moveToElement(clickOnStatusDropDown).pause(1200).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			}
			else
			{
				Actions act = new Actions(driver);
				act.moveToElement(clickOnStatusDropDown).pause(1200).click()
				.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
			}*/
			
			Actions act = new Actions(driver);
			
			act.moveToElement(clickOnStatusDropDown).pause(1500).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform();
					
			System.out.println("Status Executed to PASS Successfully ");
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
	
	public boolean showMorePagesInExecutePage() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			bp.waitTillElementIsVisible(clickOnExecuteButton);
			clickOnExecuteButton.click();
			
			 WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			
			Thread.sleep(5000);
			bp.waitForElement();
				
			Actions act = new Actions(driver);
			act.moveToElement(appTourIcon).pause(1200).click().perform();
			bp.waitForElement();
			act.moveToElement(showNewFeaturePageOption).pause(1200).click().perform();
			bp.waitForElement();
			
			
			
			if(contextMenu.isDisplayed())
			{
				System.out.println(contextMenu.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(contextMenu.getText() + "--> Not Displayed");
			}
			
			if(columnChooser.isDisplayed())
			{
				System.out.println(columnChooser.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(columnChooser.getText() + "--> Not Displayed");
			}
			
			if(stepResultSection.isDisplayed())
			{
				System.out.println(stepResultSection.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(stepResultSection.getText() + "--> Not Displayed");
			}
			
			if(treeScroll.isDisplayed())
			{
				System.out.println(treeScroll.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(treeScroll.getText() + "--> Not Displayed");
			}
			
			
			if(cycleDescription.isDisplayed())
			{
				System.out.println(cycleDescription.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(cycleDescription.getText() + "--> Not Displayed");
			}
			
			if(switchToDetail.isDisplayed())
			{
				System.out.println(switchToDetail.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(switchToDetail.getText() + "--> Not Displayed");
			}
			
			if(navigateToSTE.isDisplayed())
			{
				System.out.println(navigateToSTE.getText() + "--> Displayed");
			}
			else
			{
				System.out.println(navigateToSTE.getText() + "--> Not Displayed");
			}
			
			act.moveToElement(closeAppTour).pause(1200).click().perform();
			bp.waitForElement();
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
	
	public boolean takeAFeatureTour() throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			Thread.sleep(5000);
			bp.waitForElement();
				
			Actions act = new Actions(driver);
			act.moveToElement(appTourIcon).pause(1200).click().perform();
			bp.waitForElement();
			act.moveToElement(takeAFeatureTourOption).pause(1200).click().perform();
			bp.waitForElement();
						
			act.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click().pause(8000).perform();
			
			bp.waitTillElementIsVisible(nextFeature);
			
			act.moveToElement(nextFeature).pause(1200).click().pause(5000)
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(standaloneExecution).pause(1200).click().pause(8000).perform();
			
			 WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
				
			Thread.sleep(5000);
			bp.waitForElement();
				
				
			bp.waitTillElementIsVisible(nextFeature);
			act.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(nextFeature).pause(1200).click()
			.moveToElement(close).pause(1200).click().perform();
			
			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean ExecuteTestStepInDetailView() throws Exception {

		try{
			
			bp = new CommonUtils();
			bp.waitForElement();
	
			cycleDetail.click();
			bp.waitForElement();
			System.out.println("Clicking on Cycle Summary Detail View");
			bp.waitForElement();
			Thread.sleep(2000);
						
			Actions act = new Actions(driver);
			
			act.moveToElement(clickOnTestStepStatusDropDownForPass).pause(1500).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform(); //Status Executed to PASS Successfully
			act.moveToElement(clickOnTestStepStatusDropDownForFail).pause(1500).click()
			.sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).perform(); //Status Executed to FAIL Successfully
					
			System.out.println("Test Step Status Executed Successfully ");
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
	
	public boolean cycleExport(String cycleName,String ExportType) throws Exception {

		try{
			
			bp = new CommonUtils();
			bp.waitForElement();
	
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
			bp.waitTillElementIsVisible(exportcycle);
			exportcycle.click();
			
			Actions act1 = new Actions(driver);
			act1.moveToElement(selectExportType).pause(1200).sendKeys(ExportType).pause(2000).sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).click().perform();
			
			bp.waitForElement();
			Thread.sleep(4000);
			bp.waitTillElementIsVisible(exportCloseButton);
			exportCloseButton.click();
			
			bp.waitForElement();
			
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean deleteCycle(String cycleName, String deleteCycleName) throws Exception {

		try{
			
			
			bp = new CommonUtils();
			bp.waitForElement();
			
			/*WebElement searchcreatedcycle = driver.findElement(By.xpath(cycleName1 + cycleName + cycleName2));
			
			searchcreatedcycle.click();
			bp.waitForElement();
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys(cloneCycleName).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();*/
			
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
			deletecycle.click();
			bp.waitForElement();
						
			deletebutton.click();
			bp.waitForElement();	
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}	
		

	public boolean createFolder() throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			
			//validatePlanTestCycle();
			/*bp.waitForElement();
			System.out.println("Navigate to Plan cycle page");
			bp.waitForElement();
			createNewCycle("unscheduled","Automation Cycle", "description", "ZFJC PROD", "ENV");
			System.out.println("New cycle  created for Folder");
			
			System.out.println("Created cycle");*/
			/*bp.waitForElement();
			Thread.sleep(2000);
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("Automation Cycle").pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();*/
			
			//contextwrapper.click();
			cycleContextmenu.click();
			bp.waitForElement();
			System.out.println("Clicked context menu");
			
			
			addfolder.click();
			bp.waitForElement();
	
			Actions act1 = new Actions(driver);
			act1.moveToElement(foldername).pause(2000).sendKeys("Automation folder").pause(2000).moveToElement(folderAddbtn).click().perform();
			
			bp.waitForElement();
			return true;
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	
}

	public boolean deleateFolder() throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			
			nextarrow.click();
			System.out.println("Cycle Nextarrow is clickable sucessfully");
			bp.waitForElement();
			contextwrapper.click();
			bp.waitForElement();
			deleteFolder.click();
			bp.waitForElement();
			deltefolderbtn.click();
			bp.waitForElement();
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	
}
	
	
	public boolean upload_cucumber_result() throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				    
			validatePlanTestCycle();
			bp.waitForElement();
			System.out.println("Navigate to Plan cycle page");
			bp.waitForElement();
			
			/*System.out.println("Creating new cycle for editing");
			createNewCycle("unscheduled","cycle for bdd", "description", "ZFJC PROD", "ENV");
			
			System.out.println("Created cycle");
			bp.waitForElement();*/
			Thread.sleep(7000);
			
			Actions act = new Actions(driver);
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("cycle for bdd").pause(1200).sendKeys(Keys.ENTER).perform();
			
			/*searchcreatedcycle.click();
			Thread.sleep(5000);
			searchcreatedcycle.sendKeys("cycle for bdd");
			bp.waitForElement();
			Thread.sleep(5000);
			searchcreatedcycle.click();*/
			
			Thread.sleep(2000);
			contextwrapper.click();
			bp.waitForElement();
			
			uploadcucumberresult.click();
			bp.waitForElement();
			Thread.sleep(3000);
		
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
}
	
	public boolean createFolder(String FolderName, String CycleName) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + CycleName + CycleContextWrapper2));
			
			cycleContextWrapper.click();
			bp.waitForElement();
			
			System.out.println("Clicked context menu");
			
			
			addfolder.click();
			bp.waitForElement();
	
			Actions act1 = new Actions(driver);
			act1.moveToElement(foldername).pause(2000).sendKeys(FolderName).pause(2000).moveToElement(folderAddbtn).click().perform();
			
			bp.waitForElement();
			return true;
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	
}

	public boolean upload_cucumber_result(String cycleName) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				    
			
			
			
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
			WebElement cycleContextWrapper = driver.findElement(By.xpath(CycleContextWrapper1 + cycleName + CycleContextWrapper2));
			 js.executeScript("arguments[0].scrollIntoView();", cycleContextWrapper);
			cycleContextWrapper.click();
			bp.waitForElement();
			
			/*JavascriptExecutor js = (JavascriptExecutor) driver;       		
	        WebElement uploadcucumberresult = driver.findElement(By.xpath("//*[text()='Upload Cucumber Results']"));

	        //This will scroll the page till the element is found		
	        js.executeScript("arguments[0].scrollIntoView();", uploadcucumberresult);*/
			uploadcucumberresult.click();
			
			/*String fileLocation = System.getProperty("user.dir");
			String uploadFileLocation = fileLocation + AutomationConstants.UPLOAD_FILE_LOCATION + Filepath;
			
			uploadcucumberresult.sendKeys(uploadFileLocation);*/
			bp.waitForElement();
			Thread.sleep(3000);
		
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
}

	public boolean uploadBDDResults(String FilePath) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();

			
			bp.waitForElement();
			bp.waitForElement();
			
		
			bp.uploadFile(FilePath);
				
			System.out.println(FilePath);

			bp.waitForElement();
			

			log.info("File Uploaded Successfully");

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.info("File is not Uploaded");
			throw e;

		}

	}
	
	public boolean verify_bddfeature_passstatus_incycle() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			
			 Thread.sleep(5000);
			/* if(pass.equals("PASS")) {
				 System.out.println("Cycle status is updated with Pass status");
			 }
			 else {
				 System.out.println("Cycle status is not updated ");
			 }*/
			 
			 WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
				 Thread.sleep(5000);
				 
			 String actual = pass.getText();
			 String expected = "PASS";
			 assertEquals(expected,actual);
			 System.out.println("Cycle status is updated with Pass status");
			 
			 driver.switchTo().defaultContent();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean verify_bddfeature_failstatus_incycle() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			Thread.sleep(5000);
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
		    driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
		    Thread.sleep(5000);
				 
			 String actual = fail.getText();
			 String expected = "FAIL";
			 assertEquals(expected,actual);
			 System.out.println("Cycle status is updated with Fail status");
			 
			 driver.switchTo().defaultContent();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean verify_bddfeature_undefinedstatus_incycle() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			
			 Thread.sleep(5000);
			
			 WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
				 Thread.sleep(5000);
				 
			 String actual = unexecuted.getText();
			 String expected = "UNEXECUTED";
			 assertEquals(expected,actual);
			 System.out.println("Cycle status is updated with Unexecuted status");
			 
			 driver.switchTo().defaultContent();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean upload_cucumber_result_to_folder() throws Exception{
            try{
			bp = new CommonUtils();
			bp.waitForElement();
				    
			validatePlanTestCycle();
			bp.waitForElement();
			System.out.println("Navigate to Plan cycle page");
			bp.waitForElement();
			
            Thread.sleep(7000);
			
			Actions act = new Actions(driver);
			contextmenu.click();
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("cycle for folder").pause(1200).sendKeys(Keys.ENTER).pause(1200).perform();
			//nextarrow.click();
			downarrowforFolder.click();
			Thread.sleep(3000);
			//act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("folder for bdd").pause(1200).sendKeys(Keys.ENTER).perform();
	
			bp.eraseText(searchcreatedcycle);
			Thread.sleep(2000);
			
			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("folder for bdd").pause(1200).sendKeys(Keys.ENTER).perform();
			
			contextwrapper1.click();
			bp.waitForElement();
			
			uploadcucumberresult.click();
			bp.waitForElement();
			Thread.sleep(3000);
		
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean verify_bddfeature_pass_status_infolder() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			Thread.sleep(5000);
			folderName.click();
			
			/*WebElement frame = driver.findElement(By.tagName("iframe"));
		    driver.switchTo().frame(frame);
			System.out.println("Found Iframe");*/
		    Thread.sleep(5000);
				 
			 String actual = pass.getText();
			 String expected ="PASS";
			 assertEquals(expected,actual);
			 System.out.println("Folder status is updated with Pass status");
			 
			 driver.switchTo().defaultContent();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean verify_bddfeature_fail_status_infolder() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			Thread.sleep(5000);
			folderName.click();
			
			/*WebElement frame = driver.findElement(By.tagName("iframe"));
		    driver.switchTo().frame(frame);
			System.out.println("Found Iframe");*/
		    Thread.sleep(5000);
				 
			 String actual = fail.getText();
			 String expected ="FAIL";
			 assertEquals(expected,actual);
			 System.out.println("Folder status is updated with fail status");
			 
			 driver.switchTo().defaultContent();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	
	public boolean verify_bddfeature_undefined_status_infolder() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			Thread.sleep(5000);
			folderName.click();
			
			/*WebElement frame = driver.findElement(By.tagName("iframe"));
		    driver.switchTo().frame(frame);
			System.out.println("Found Iframe");*/
		    Thread.sleep(5000);
				 
			 String actual = unexecuted.getText();
			 String expected ="UNEXECUTED";
			 assertEquals(expected,actual);
			 System.out.println("Folder status is updated with unexecuted status");
			 
			 driver.switchTo().defaultContent();
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	
	
	
	public boolean uploadAttachement(String filePath) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();

			
			Actions a3 = new Actions(driver);
			for (int i = 1; i <= 3; i++) {
				a3.sendKeys(Keys.DOWN).perform();
			}
			bp.waitForElement();
			bp.waitForElement();
				bp.uploadFile(filePath);
				
				System.out.println(filePath);

				bp.waitForElement();
			

			log.info("File Uploaded Successfully");

			return true;
		} catch (Exception e) {
			e.printStackTrace();
			log.info("File is not Uploaded");
			throw e;

		}

	}
	
	public boolean addBDDTestToCycle(String issue) throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			System.out.println("Found Iframe");
			Thread.sleep(5000);
		//	bp.waitForElement();

			clickOnCycle.click();
	
			cycleContextmenu.click();
			bp.waitForElement();
			System.out.println("Clicked context menu");
			
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to cycle");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
			
			Actions act = new Actions(driver);
			
			act.moveToElement(searchindividualtest).click().pause(1200).sendKeys(issue).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);	
			bp.waitForElement();
						
			act.moveToElement(assigntoindividual).click().pause(1200).sendKeys("zephyr qa").sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			addbutton.click();
			Thread.sleep(2000);
			
			
			bp.waitForElement();		
			act.moveToElement(closebutton).pause(2000).click().perform();
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean downloadFeatureFileFromCycle() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				
			contextwrapper.click();			
			bp.waitForElement();
			
			downloadFeatureoption.click();
						
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean selectCycleUpload() throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			
//			
//			Actions act = new Actions(driver);
//			act.moveToElement(searchcreatedcycle).pause(1200).click().sendKeys("Automation Cycle").pause(1200).sendKeys(Keys.ENTER).perform();
//						
			contextwrapper.click();
			bp.waitForElement();
			
			uploadcucumberresult.click();
			bp.waitForElement();
			Thread.sleep(3000);
		
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
}


	public boolean addTestTofolder(String issue) throws Exception{
		// TODO Auto-generated method stub
		
		
		try{
			bp = new CommonUtils();
			bp.waitForElement();
				
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to folder");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
			
			Actions act = new Actions(driver);
			
			act.moveToElement(searchindividualtest).click().pause(1200).sendKeys(issue).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);	
			bp.waitForElement();
						
			act.moveToElement(assigntoindividual).click().pause(1200).sendKeys("qa").sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			addbutton.click();
			Thread.sleep(2000);
			
			
			bp.waitForElement();		
			act.moveToElement(closebutton).pause(2000).click().perform();
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	public boolean addBDDTestToFolder(String issue) throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to folder");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
			
			Actions act = new Actions(driver);
			
			act.moveToElement(searchindividualtest).click().pause(1200).sendKeys(issue).sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			Thread.sleep(2000);	
			bp.waitForElement();
						
			act.moveToElement(assigntoindividual).click().pause(1200).sendKeys("zephyr qa").sendKeys(Keys.ARROW_DOWN).pause(1200).sendKeys(Keys.ENTER).perform();
			bp.waitForElement();
			addbutton.click();
			Thread.sleep(2000);
			
			
			bp.waitForElement();		
			act.moveToElement(closebutton).pause(2000).click().perform();
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	
	
	public boolean downloadFeatureFileFromFolder() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
				
			contextwrapper1.click();			
			bp.waitForElement();
			
			downloadFeatureoption.click();
						
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean addDefectToExecution(String Bug,String cycleName) throws Exception {

		try{
			bp = new CommonUtils();
			bp.waitForElement();
	
			cycleDetail.click();
			bp.waitForElement();
			System.out.println("Clicking on Cycle Summary Detail View");
			bp.waitForElement();
			Thread.sleep(2000);
						
			Actions act = new Actions(driver);
			
			/*act.moveToElement(addExistingDefect).click().pause(1200).sendKeys(Bug).pause(1200).sendKeys(Keys.ARROW_DOWN).sendKeys(Keys.ENTER).pause(1200).perform();
			bp.waitForElement();
			Thread.sleep(2000);
			log.info("Added Defect to Execution Successfully");
			
			log.info("Clicking on Cycle Summary List View");
			bp.waitForElement();
			bp.waitForElement();*/

			WebElement cycleNameLink = driver.findElement(By.xpath(cycleNameLink1 + cycleName + cycleNameLink2));
			
			//cycleNameLink.click();
			
			act.moveToElement(cycleNameLink).pause(1200).click().perform();
			
			bp.waitForElement();
			
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	public boolean navigateToPlanCycleListView() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
		Thread.sleep(2000);
		
		String viewtype =view.getAttribute("title");
		
		System.out.println(viewtype);

//    boolean status3 = ListView.isDisplayed();
			if (viewtype.equalsIgnoreCase("List View")) {
				System.out.println("validated List view");
				Thread.sleep(2000);
				Actions act = new Actions(driver);
				act.moveToElement(searchCycleFolder).click().pause(1200).sendKeys("Automation folder").pause(1200).sendKeys(Keys.ENTER).perform();
				Thread.sleep(2000);
				
				createFolder();
				System.out.println("Folder is created sucessfully");
				
				selectAutomationFolder.click();	
				bp.waitForElement();
				return true;
			 }
			else
			 {
				 System.out.println("validated Tree view");
				 TreeView.click(); 
				 System.out.println("Navigate to listview");
				 bp.waitForElement();
				    Thread.sleep(2000);
				    ExpandVersionV1.click();
				    System.out.println("ExpandVersionV1 successfully");
				    
				    
				    
					Actions act = new Actions(driver);
					act.moveToElement(searchCycleFolder).click().pause(1200).sendKeys("Automation folder").pause(1200).sendKeys(Keys.ENTER).perform();
					Thread.sleep(2000);
					System.out.println(" searched searchCycleFolder in planCycle listview");
					
					createFolder();
					System.out.println("Folder is created sucessfully");
			
					selectAutomationFolder.click();	
					bp.waitForElement();
					return true;
			 }
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean addTestToCycleWithoutAssignee(String issue) throws Exception{
		try{
			/*bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(7000);
			Actions act1 = new Actions(driver);
			act1.sendKeys(Keys.PAGE_UP).pause(2000).perform();
			addtestsbutton.click();
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to cycle");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(1200);
			Actions act = new Actions(driver);	
			//add
			//driver.switchTo().frame(0);
			//act.sendKeys(Keys.PAGE_UP).pause(3000).perform();
			//add
			WebElement frame = driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(frame);
			
			act.moveToElement(addtestsbutton).pause(1200).click().perform();
			
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to cycle");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
				
			//Actions act = new Actions(driver);
			bp.waitForElement();
			Thread.sleep(3000);
			act.moveToElement(searchindividualtest).click().pause(1200).sendKeys(issue).sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			log.info("Added Tests Individually and Assigned to Zephyr QA");
			Thread.sleep(2000);
			bp.waitForElement();		
			act.moveToElement(closebutton).pause(4000).click().perform();
			log.info("Clicked on Close button");
			return true;*/
			
			//added
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(1200);
			//to scroll up
			JavascriptExecutor js = (JavascriptExecutor) driver;       		
	      //  WebElement addtestbtnElement = driver.findElement(By.xpath("//input[@id='defects']//parent::div/label"));
	        //This will scroll the page till the element is found		
	      //  js.executeScript("arguments[0].scrollIntoView();", addtestsbutton);
			//js.executeScript(window.scrollTo(0,document.body.scrollTop));
			
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(false);", addtestsbutton);
			
			Actions act = new Actions(driver);	
			act.moveToElement(addtestsbutton).pause(1200).click().perform();
			
			bp.waitForElement();
			System.out.println("Searching for Individual Test to add to cycle");
			bp.waitTillElementIsVisible(searchindividualtest);
			bp.waitForElement();
			Thread.sleep(5000);	
			
			
			bp.waitForElement();
			act.moveToElement(searchindividualtest).click().pause(1200).sendKeys(issue).sendKeys(Keys.ARROW_DOWN).pause(1200)
			.sendKeys(Keys.ENTER).sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.ENTER).perform();
			
			log.info("Added Tests Individually ");
			
			bp.waitForElement();	
			bp.waitForElement();
			bp.waitForElement();
			bp.waitForElement();
			act.moveToElement(closebutton).pause(2000).click().perform();
			log.info("Clicked on Close button");
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
public boolean versionExpandCheck(String version, String cyclename, String build, String Environment, String createdBy) throws Exception{
		
		try{
							
			bp = new CommonUtils();
			bp.waitForElement();
			bp.waitForElement();

			System.out.println("Entered Check Method");
			
			
			bp.waitForElement();
			
			Actions actions = new Actions(driver);
			
			String unreleasedarialabel= expandUnreleasedVersion.getAttribute("aria-label");
			
			System.out.println("unreleasedarialabel is: " + unreleasedarialabel);
			
			
			if(unreleasedarialabel.contains("Expand")) {
			
				actions.moveToElement(expandUnreleasedVersion).pause(1500).click().build().perform();
				bp.waitForElement();
				System.out.println("Unreleased Version Expanded Successfully");			
			}
			
			else {
				System.out.println("Unreleased Version is in Expanded state");	
			}
			
			String versionExpand= driver.findElement(By.xpath(version1 + version + version2)).getAttribute("aria-label");
			System.out.println("arialabel is: " + versionExpand);
			
			if(versionExpand.contains("Expand"))
			{
				WebElement expandVersion = driver.findElement(By.xpath(version1 + version + version2));
				
				actions.moveToElement(expandVersion).pause(1500).click().build().perform();
				bp.waitForElement();
				System.out.println("Version Expanded Successfully");					
			}
			else
			{
				System.out.println("Version is in Expanded state");
			}
			
			return true;
		
			} catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}
				
	

	public boolean notificationPopup() throws Exception{

		try{
			Robot robot = new Robot();
			
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(2000); 
			robot.keyPress(KeyEvent.VK_TAB);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_ENTER);
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
}
