package com.zephyr.selenium.stepdefinition;

import com.zephyr.selenium.pageobject.*;
import com.zephyr.selenium.utility.*;
import com.zephyr.selenium.utility.Property_Lib;
import java.time.LocalTime;
import cucumber.api.java.en.*;

public class Apps extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	AppsPage appp;
	
	String fileName1 = "Basedata";
	
	LocalTime todayDate = LocalTime.now();


@Given("^Navigate to apps$")
public void navigate_to_apps() throws Throwable {
    
	try{
		appp = new AppsPage(driver);
		
		appp.navigateToJiraAppsPage();
		System.out.println("Navigated to Jira Apps page Successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			driver.close();
			throw e;
			
			}
	
	
}

@When("^user is in customize Test status page$")
public void user_is_in_customize_Test_status_page() throws Throwable {
	try{
		appp = new AppsPage(driver);
		
		appp.navigateToCustomizeTestStatusPage();
		System.out.println("Navigated to customize Test status page Successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			driver.close();
			throw e;
			
			}
}

@When("^user is in customize Step status page$")
public void user_is_in_customize_Step_status_page() throws Throwable {
	try{
		appp = new AppsPage(driver);
		
		appp.navigateToCustomizeStepStatusPage();
		System.out.println("Navigated to customize Test status page Successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			driver.close();
			throw e;
			
			}
}


@And("^user is in General Config page$")
public void user_is_in_General_Config_page() throws Throwable {
	try{
		appp = new AppsPage(driver);
		
		appp.navigateToGeneralConfigPage();
		System.out.println("Navigated to General configuration page Successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			driver.close();
			throw e;
			
			}
}


}
