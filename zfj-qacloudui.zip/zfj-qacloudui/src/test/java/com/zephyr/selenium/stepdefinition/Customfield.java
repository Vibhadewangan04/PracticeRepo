package com.zephyr.selenium.stepdefinition;


import com.zephyr.selenium.pageobject.CustomfieldPage;

import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;

import cucumber.api.java.en.Given;


public class Customfield extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CustomfieldPage csp;
	//String fileName = "Login";

	
	
	

	@Given("^Add the Customfields at execution level$")
	public void add_the_Customfields_at_execution_level() throws Throwable {
	  try {
		  csp = new CustomfieldPage(driver);
		 // String name[]  = {"Text1","Test2","Text3"};
		  String singleline="SingleLineTextCustomField";
		  String multiline="MultiLineTextCutomField";
		  String number="NumberCustomField";
		  String radiobutton="RadioButtonCustomField";
		  String checkbox ="CheckBoxCustomField";
		  String singlechoice="SelectSingleListCustomField";
		  String multichoice="SelectMultiListCustomField";
		  String datepicker="DatePickerCustomField";
		  String datetime="DateTimePickerCustomField";
		 /* ArrayList<String> name = new ArrayList<String>();

		  name.add("txt customfield1");
		  name.add("txt customfield1");*/
		  
		  String des ="Description of execution cutomfield";
		  csp.executioncustomfield(singleline, multiline, number, radiobutton,checkbox,singlechoice,multichoice,datepicker,datetime,des);
		 // csp.single_multilinetextcustomfield(multiline, des);
		 // csp.single_multilinetextcustomfield(number, des);
		 
	  }
	  catch (Exception e)
	  {
		  lb = new LaunchBrowser();
			//lb.getScreenShot(filename);
			e.printStackTrace();
			driver.close();
			Relogin rl = new Relogin();
			rl.reLogin();
			throw e;
	  }
	}


	
	@Given("^Add the customfields at step level$")
	public void add_the_customfields_at_step_level() throws Throwable {
		try {
			 csp = new CustomfieldPage(driver);
			 String stepDes ="Description of step level cutomfield";
			 String stepmultiline="MultiLineTextCutomField";
			 String stepnumber="NumberCustomField";
			 String stepradiobutton="RadioButtonCustomField";
			 String stepsinglechoice="SelectMultiListCustomField";
			 String stepdatetime="DatePickerCustomField";
			 String stepsinglinetxt="SingleLineTextCustomField";
			 csp.create_stepcCustomfield(stepDes, stepmultiline, stepnumber, stepradiobutton,stepsinglechoice,stepdatetime,stepsinglinetxt);
			 
		}
		
		catch (Exception e)
		  {
			  lb = new LaunchBrowser();
				//lb.getScreenShot(filename);
				e.printStackTrace();
				driver.close();
				Relogin rl = new Relogin();
				rl.reLogin();
				throw e;
		  }
	}

	
	@Given("^Enable customfields for both execution and steplevel$")
	public void enable_customfields_for_both_execution_and_steplevel() throws Throwable{
		try {
			
			csp = new CustomfieldPage(driver);
			String projectName  =Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			csp.enablecustomfield(projectName);
		}
		catch (Exception e)
		  {
			  lb = new LaunchBrowser();
				//lb.getScreenShot(filename);
				e.printStackTrace();
				/*driver.close();
				Relogin rl = new Relogin();
				rl.reLogin()*/;
				throw e;
		  }
		
	}
	
}


