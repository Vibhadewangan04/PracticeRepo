package com.zephyr.selenium.stepdefinition;
import com.zephyr.selenium.pageobject.AppsPage;
import com.zephyr.selenium.pageobject.CustomizeStatusesPage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CustomizeStatuses extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CustomizeStatusesPage csp;
	//String fileName = "Login";

	
	
	

	@Then("^Add the testCustomStatus$")
	public void add_the_testCustomStatus() throws Throwable {
	  try {
		  csp = new CustomizeStatusesPage(driver);
		  String customstatus  =Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "status");
		  String colorcode =Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "colorcode");
		  csp.customizeTestStatus(customstatus, colorcode);
		  System.out.println("Created new status successfully");
		  
		 
	  }
	  catch (Exception e)
	  {
		  lb = new LaunchBrowser();
			//lb.getScreenShot(filename);
			e.printStackTrace();
			/*driver.close();
			Relogin rl = new Relogin();
			rl.reLogin()*/;
			throw e;
	  }
	}

	
	@Then("^Add the stepCustomStatus$")
	public void add_the_stepCustomStatus() throws Throwable {
		try {
			  csp = new CustomizeStatusesPage(driver);
			  String customstatus  =Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "status");
			  String colorcode =Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "colorcode");
			  csp.customizeTestStatus(customstatus, colorcode);
			  
			 
		  }
		  catch (Exception e)
		  {
			  lb = new LaunchBrowser();
				//lb.getScreenShot(filename);
				e.printStackTrace();
				driver.close();
				Relogin rl = new Relogin();
				rl.reLogin();
				throw e;
		  }
	}
	
	
	@Then("^customize default Test level execution Status$")
	public void customize_default_Test_level_execution_Status() throws Throwable {
		try{
			csp = new CustomizeStatusesPage(driver);
			
			csp.updateExecutionStatus();
			System.out.println("Updated default status");
			   			    
			}
		 
			catch (Exception e) {
				//lb.getScreenShot(fileName1);
				e.printStackTrace();
				driver.close();
				throw e;
				
				}
	}
	
	@Then("^customize default Test step level execution Status$")
	public void customize_default_Test_step__level_execution_Status() throws Throwable {
		try{
			csp = new CustomizeStatusesPage(driver);
			
			csp.updateStepExecutionStatus();
			System.out.println("Updated default status");
			   			    
			}
		 
			catch (Exception e) {
				//lb.getScreenShot(fileName1);
				e.printStackTrace();
				driver.close();
				throw e;
				
				}
	}
	
}



