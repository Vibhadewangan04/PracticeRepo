package com.zephyr.selenium.stepdefinition;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.WebDriver;

import com.zephyr.selenium.pageobject.CreateIssuePage;
import com.zephyr.selenium.pageobject.ExecuteTestPage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.pageobject.PlanTestCyclePage;
import com.zephyr.selenium.pageobject.ViewIssuePage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;
import com.zephyr.selenium.stepdefinition.PlanTestCycle;

import cucumber.api.java.en.*;

public class ExecuteTest extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	ExecuteTestPage etp;
	Relogin relgn;
	CreateIssuePage cip;
	PlanTestCyclePage ptcp;
	String fileName = "ExecuteTest";
    String Test;
    String Bug;
    String Subtask;
    
//String Test1;
	String CycleName;
	String fileName1 = "ExecuteTest";
	//WebDriver driver;
	PlanTestCycle PTC;
	ViewIssuePage vip;
	
	@Given("^Navigate to created project page$")
	public void Navigate_to_created_project_page() throws Throwable{
		
	    try {
	    	ptcp = new PlanTestCyclePage(driver);
		String projectname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		ptcp.navigateToProject(projectname);
	        }
	    
	    catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	@Then("^User clicks on E button navigate to execute page$")
	public void user_clicks_on_E_button_navigate_to_execute_page() throws Throwable  {
	  try {
		etp = new ExecuteTestPage(driver);
		
	String projectname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
	String version1 = Property_Lib.getPropertyValue(CONFIG_PATH
			+ CONFIG_FILE, "versionOne");
	
	
	String issueSummary = Property_Lib.getPropertyValue(CONFIG_PATH
			+ CONFIG_FILE, "issueSummary");
	//etp.validateExecuteTest(version1,issueSummary,projectname);
	System.out.println("Navigate to Execution page successfully");
	  }
	  
	  catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
 
	//Scenario: User execute the testacse 
	
	 @Given("^User execute the testcase$")
	 public void user_execute_the_testcase() throws Throwable {
        try {
		etp = new ExecuteTestPage(driver);
		//String status="PASS";
		//etp.executeTest();
		System.out.println("Execution is Executed sucessfully");
		driver.switchTo().defaultContent();
        }
        catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		}
///=====================================
	 //Should be able to Execute Test with a New status added- User defined
	 
	 
	 @Given("^User Navigates to Created Project$")
	 public void user_Navigates_to_Created_Project() throws Throwable  {
			try{
				etp = new ExecuteTestPage(driver);
				ptcp = new PlanTestCyclePage(driver);
				cip = new CreateIssuePage(driver);
				PTC = new PlanTestCycle();
				String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
				
				ptcp.navigateToProject(Pname);
				log.info("Project Selected Successfully");
				
				String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
				String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
				String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
				Test = "New Test" + timestamp;
				cip.GlobalcreateTest(project, Issue, Test);
				log.info(Test + ": Test Created Successfully");
				
				
				
			}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName1);
					e.printStackTrace();
					
					driver.close();
					throw e;
				}
		}
	 
	 @When("^User Clicks on Cycle Summary Page and Validates it$")
	 public void user_Clicks_on_Cycle_Summary_Page_and_Validates_it() throws Throwable {
			try{
				etp = new ExecuteTestPage(driver);
				ptcp = new PlanTestCyclePage(driver);
				//ptcp.validatePlanTestCycle();
				PTC = new PlanTestCycle();
				//PTC.user_Click_on_Cycle_Summary_Page_and_Validates_it();
				PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
				log.info("Cycle Summary Page and Validated page Successfully");
						    
				}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName1);
					e.printStackTrace();
					
					driver.close();
					throw e;
					}

		}
	 
	 @And("^User Creates New Cycle and add test to cycle$")
		public void user_Creates_New_Cycle_and_add_test_to_cycle() throws Throwable {
			try{
				etp = new ExecuteTestPage(driver);
				ptcp = new PlanTestCyclePage(driver);
				PTC = new PlanTestCycle();
				
				//PTC.user_creates_new_Cycle_and_Verifies_the_Created_Cycle();
			
				//driver.switchTo().frame(0);
				
               // PTC.user_adds_a_test_to_the_Test_Cycle_individually();
				
				PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
				ptcp.addTestToCycle(Test);
				
				
				}
			 
				catch (Exception e) {
				//	lb.getScreenShot(fileName1);
					e.printStackTrace();
					
					driver.close();
					throw e;
					}

		}

	
	 @Then("^User click on \\[E\\] and change test status to User defined$")
	 public void user_click_on_E_and_change_test_status_to_User_defined() throws Throwable {
		 try {
			 etp = new ExecuteTestPage(driver);
			
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");
			String status = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "status");
			
			 etp.executeTest_NewStatus(status);
			 log.info("User Execute the execution status with user defined staus Successfully");
             //switch to default content
			 
			 driver.switchTo().defaultContent();
			 
		 }
		 catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	 }
	 
	 //=============================================================
	
	//Scenario: Unassign the execution
	
	@Given("^User unassign the execution$")
	public void user_unassign_the_execution() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		etp.unassignexecution();
		System.out.println("Execution is Unassigned sucessfully");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	//Scenario: User assignee the execution to user
	
	@Given("^User assign the execution to user$")
	public void user_assign_the_execution_to_user() throws Throwable{
		try {
		etp = new ExecuteTestPage(driver);
		String userUsername = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "userUsername");
		etp.assignexecutionto_otheruser(userUsername);
		System.out.println("Execution is Assigned to Other User sucessfully");
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	//========================================================================
	//Scenario: User assignee the execution to current user and execute it
	
	
	@Given("^User Navigates to Created Project \\(current assignee\\)$")
	public void user_Navigates_to_Created_Project_current_assignee() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		cip = new CreateIssuePage(driver);
		PTC = new PlanTestCycle();
	
		String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
		
		ptcp.navigateToProject(Pname);
		log.info("Project Selected Successfully");
		
		String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
		String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
		String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
		Test = "New Test" + timestamp;
		cip.GlobalcreateTest(project, Issue, Test);
		log.info(Test + ": Test Created Successfully");
	   
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	

	@And("^User Creates New Cycle and add test to cycle and click on E$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_and_click_on_E() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		PTC = new PlanTestCycle();
		PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
		log.info("Cycle Summary Page and Validated page Successfully");
		//PTC.user_Creates_New_Cycle_and_Verifies_the_Created_Cycle();
		PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
		//ptcp.addTestToCycle(Test);
		ptcp.addTestToCycleWithoutAssignee(Test);
		etp.validateExecuteTest();
		System.out.println("Navigate to Execution page successfully");		    
	   
	}catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	}

	@Then("^assign execution to current user and execute it$")
	public void assign_execution_to_current_user_and_execute_it() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		String currentUser = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "currentUser");
		etp.assign_executionto_current_user(currentUser);
		System.out.println("Execution is Assigned to Current User sucessfully");
		
		//switch to default content
		 
		 driver.switchTo().defaultContent();
	}catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	}


	
	
	//========================
	
	
	//==Execute a test by updating re-assignee to different user
	
	@Given("^User Navigates to Created Project \\(re-assignee user\\)$")
	public void user_Navigates_to_Created_Project_re_assignee_user() throws Throwable {
	    
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}

	@And("^User Creates New Cycle and add test to cycle with current user and click on E$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_with_current_user_and_click_on_E() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		PTC = new PlanTestCycle();
		PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
		log.info("Cycle Summary Page and Validated page Successfully");
		Thread.sleep(3000);
		PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
		ptcp.addTestToCycle(Test);
		
		etp.validateExecuteTest();
		System.out.println("Navigate to Execution page successfully");	
	    
	}catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
	}
	
	@Then("^re-assign execution to diff-user and execute it$")
	public void re_assign_execution_to_diff_user_and_execute_it() throws Throwable {
	    
	    try {
	    	etp = new ExecuteTestPage(driver);
	    	etp = new ExecuteTestPage(driver);
			String otherUser = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "userUsername");
			etp.assignexecutionto_otheruser(otherUser);
			System.out.println("Execution is Re-Assigned to Other User sucessfully");
			//switch to default content
			 
			 driver.switchTo().defaultContent();
			
	    	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	///complete/////////////////////////
	
	//Scenario: Add New defect at execution level
	
	
	@Given("^User Navigates to Created Project \\(new defect\\)$")
	public void user_Navigates_to_Created_Project_new_defect() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		
	}
	
	@And("^User Creates New Cycle and add test to cycle and click on E for new defect$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_and_click_on_E_for_new_defect() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			//PTC.user_Creates_New_Cycle_and_Verifies_the_Created_Cycle();
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			//ptcp.addTestToCycle(Test);
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");		    
		   
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	    }
	
	@Then("^add new defect at execution level$")
	public void add_new_defect_at_execution_level() throws Throwable {
	   
		try {
			etp = new ExecuteTestPage(driver);
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeBug = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeBug");
			Bug = "Bug at Execution" + timestamp;
			etp.add_newDefect_at_execution( projectName,issueTypeBug, Bug);
			
			System.out.println("New defect is added to the execution successfully");
			 //switch to default content
			 
			 driver.switchTo().defaultContent();
			}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}
	 ////////////////////completed////////////////////
	
	//Scenario: Add comment at execution level
	
	@Given("^User add comment at execution$")
	public void user_add_comment_at_execution() throws Throwable{
		try {
		etp = new ExecuteTestPage(driver);
		etp.add_comment_at_execution();
		System.out.println("Comment is added at Execution level sucessfully");
		 //switch to default content
		 
		 driver.switchTo().defaultContent();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	
	// Scenario: Edit comment at execution level
	
	@Given("^User edit the execution comment$")
	public void user_edit_the_execution_comment() throws Throwable{
		try {
		etp = new ExecuteTestPage(driver);
		etp.editExecutionComment();
		System.out.println("Execution comment is edited sucessfully");
		 //switch to default content
		 
		 driver.switchTo().defaultContent();
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	//Scenario: Execute the test step to any status
	
	
	@Given("^User Navigates to Created Project and create to the test$")
	public void user_Navigates_to_Created_Project_and_create_to_the_test() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	    
	}
	
	@And("^add teststeps to tests$")
	public void add_teststeps_to_tests() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		cip = new CreateIssuePage(driver);
		PTC = new PlanTestCycle();
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH+ CONFIG_FILE, "projectName");
		//
		etp.addsteptoTest(Test);
		ptcp.navigateToProject(projectName);
		//vip.addTestStepsToTest1(projectName);
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@When("^User Creates New Cycle and add test to cycle \\(for step\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_for_step() throws Throwable {
	    
	    try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Then("^User execute the step with user-defined staus$")
	public void user_execute_the_step_with_user_defined_staus() throws Throwable {
	    try {
	    	etp = new ExecuteTestPage(driver);
			String status = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "status");
			etp.executeTestStep(status);
			System.out.println("Step level Status is updated Sucessfully");
			 //switch to default content
			 
			 driver.switchTo().defaultContent();
	    	
	    	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}
	
	///////////////completed/////////////////////////
	
	//Scenario: Execute all test step to same status
	
	
	@Given("^User Navigates to Created Project and create test with steps$")
	public void user_Navigates_to_Created_Project_and_create_test_with_steps() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   //
			etp.addsteptoTest(Test);
			ptcp.navigateToProject(project);
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	    
	    
	}

	@When("^User Creates New Cycle and add test to cycle \\(same status\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_same_status() throws Throwable {
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}

	@Then("^User execute all step with same status$")
	public void user_execute_all_step_with_same_status() throws Throwable {
	    try {
	    	
	    	etp = new ExecuteTestPage(driver);
	    	etp.executeAllStepWithSameStatus();
	    	System.out.println("All steps executed with same status and Executions also executed with same status");
	    	 //switch to default content
			 
			 driver.switchTo().defaultContent();
	    	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}


	//Scenario: Add attachment at Execution level
	
		
		@Given("^User Navigates to Created Project and create test \\(attachment\\)$")
		public void user_Navigates_to_Created_Project_and_create_test_attachment() throws Throwable {
			try {
				etp = new ExecuteTestPage(driver);
				ptcp = new PlanTestCyclePage(driver);
				cip = new CreateIssuePage(driver);
				PTC = new PlanTestCycle();
			
				String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
				
				ptcp.navigateToProject(Pname);
				log.info("Project Selected Successfully");
				
				String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
				String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
				String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
				Test = "New Test" + timestamp;
				cip.GlobalcreateTest(project, Issue, Test);
				log.info(Test + ": Test Created Successfully");
			   
			}
				catch (Exception e) {
					e.printStackTrace();
					throw e;
				}
		}
		

		@When("^User Creates New Cycle and add test to cycle \\(attachment\\)$")
		public void user_Creates_New_Cycle_and_add_test_to_cycle_attachment() throws Throwable {
			try {
		    	etp = new ExecuteTestPage(driver);
				ptcp = new PlanTestCyclePage(driver);
				PTC = new PlanTestCycle();
				PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
				log.info("Cycle Summary Page and Validated page Successfully");
				
				PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
				
				ptcp.addTestToCycleWithoutAssignee(Test);
				etp.validateExecuteTest();
				System.out.println("Navigate to Execution page successfully");	
		    }catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}

		@Then("^User add the Attachment to Execution level$")
		public void user_add_the_Attachment_to_Execution_level() throws Throwable {
			try {
				etp = new ExecuteTestPage(driver);
				String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath");
				etp.addAttachment_to_Execution(filePath);
				System.out.println("Upload the attachment at Execution Sucessfully ");
				 //switch to default content
				 
				 driver.switchTo().defaultContent();
			}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
		}
	
		
	
	
	
	//Associate an existing defect of type "subtask" to the test during execution at test level
	
	@Given("^User Navigates to Created Project for subtask$")
	public void user_Navigates_to_Created_Project_for_subtask() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	   
	}

	@And("^create test and subtask$")
	public void create_test_and_subtask() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		cip = new CreateIssuePage(driver);
		PTC = new PlanTestCycle();
		String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
		String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
		String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
		Test = "New Test" + timestamp;
		cip.createsubtask(project, Issue, Test);
	    
	}catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
   
}

	@When("^User Creates New Cycle and add test to cycle \\(for subtask\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_for_subtask() throws Throwable {
	    
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Then("^User associate subtask to execution$")
	public void user_associate_subtask_to_execution() throws Throwable {
	    try {
	    	etp = new ExecuteTestPage(driver);
	    	etp.associatesubtask("Subtask");
	    	log.info("Subtask is associate to Execution Successfully");
	    	//switch to default content
			 
			 driver.switchTo().defaultContent();
	    	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}
	
	
	//////Completed/////////////////////
	
	//Verify that able to associate an existing defect to test level execution
	
	@Given("^User Navigates to Created Project and create test and bug$")
	public void user_Navigates_to_Created_Project_and_create_test_and_bug() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			Thread.sleep(3000);
			//create defect
			String Issuebug = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeBug");
			Bug = "Bug" + timestamp;
			cip.GlobalcreateTest(project, Issuebug, Bug);
			log.info(Bug + ": Bug Created Successfully");
			
			
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}

	@When("^User Creates New Cycle and add test to cycle \\(exist defect\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_exist_defect() throws Throwable {
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	    
	}

	@Then("^User associate existing defect to execution$")
	public void user_associate_existing_defect_to_execution() throws Throwable {
		try {
		etp = new ExecuteTestPage(driver);
		etp.associate_existdefect_to_execution(Bug);
		System.out.println("Associate existing defect to execution successfully");
		//switch to default content
		 
		 driver.switchTo().defaultContent();
	    
	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}
	
	//////completed ///////////////////////////////////////
	
	//Should able to add an New defect to step level execution(New Defect)
	
	@Given("^User Navigates to Created Project and create test and steps$")
	public void user_Navigates_to_Created_Project_and_create_test_and_steps() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   //
			etp.addsteptoTest(Test);
			ptcp.navigateToProject(project);
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}

	
	@When("^User Creates New Cycle and add test to cycle \\(new defect at step\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_new_defect_at_step() throws Throwable {
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	@Then("^User add new defect at step level$")
	public void user_add_new_defect_at_step_level() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeBug = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeBug");
			Bug = "Bug at StepLevel" + timestamp;
			etp.associate_NewDefect_Steplevel(projectName, issueTypeBug, Bug);
			System.out.println("New defect added to the step level is success");
			 //switch to default content
			 
			 driver.switchTo().defaultContent();
			
			
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}

   /////////completed//////////////////////////
	
	//Verify that able to associate an existing defect to step level execution
	
	@Given("^User Navigates to Created Project and create test to the steps$")
	public void user_Navigates_to_Created_Project_and_create_test_to_the_steps() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			
			Thread.sleep(3000);
			//create defect
			String Issuebug = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeBug");
			Bug = "Bug" + timestamp;
			cip.GlobalcreateTest(project, Issuebug, Bug);
			log.info(Bug + ": Bug Created Successfully");
			log.info("Bug id = "+ Bug);
		   //
			etp.addsteptoTest(Test);
			ptcp.navigateToProject(project);
		}
			catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}

	@When("^User Creates New Cycle and add test to cycle \\(exist defect at step\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_exist_defect_at_step() throws Throwable {
	    
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Then("^User associate existing defect at step level$")
	public void user_associate_existing_defect_at_step_level() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			etp.associate_existbug_atstep();
			System.out.println("Existing defect is associate to step is success");
			 //switch to default content
			 
			 driver.switchTo().defaultContent();
			
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	   
	}


	//////////////completed////////////////////////
	
	//Verify that able to add a comment at test and step execution

	@Given("^User Navigates to Created Project and create test to the steps for add comment$")
	public void user_Navigates_to_Created_Project_and_create_test_to_the_steps_for_add_comment() throws Throwable {
	   try {
		   etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
		   //
			etp.addsteptoTest(Test);
			ptcp.navigateToProject(project);
	   }
	   catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	   
	}

	@When("^User Creates New Cycle and add test to cycle \\(add comment\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_add_comment() throws Throwable {
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Then("^User add comment at execution and step level$")
	public void user_add_comment_at_execution_and_step_level() throws Throwable {
	   try {
		   etp = new ExecuteTestPage(driver);
		   etp.add_comment_at_execution();
		   System.out.println("Comment added to the execution is success");
		   driver.switchTo().defaultContent();
		   log.info("Switchback to Default frame");
		   etp.addcomment_steplevel();
		   System.out.println("Comment added to the step is success");
		   //switch to default content
		 driver.switchTo().defaultContent();
		   
	   }
	   catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

 //////////////Completed///////////////////
	
	//Verify that able to edit comment at test level and step level execution
	
	@Given("^User Navigates to Created Project and create test to the steps for edit comment$")
	public void user_Navigates_to_Created_Project_and_create_test_to_the_steps_for_edit_comment() throws Throwable {
		try {
			   etp = new ExecuteTestPage(driver);
				ptcp = new PlanTestCyclePage(driver);
				cip = new CreateIssuePage(driver);
				PTC = new PlanTestCycle();
			
				String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
				
				ptcp.navigateToProject(Pname);
				log.info("Project Selected Successfully");
				
				String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
				String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
				String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
				Test = "New Test" + timestamp;
				cip.GlobalcreateTest(project, Issue, Test);
				log.info(Test + ": Test Created Successfully");
			   //
				etp.addsteptoTest(Test);
				ptcp.navigateToProject(project);
		   }
		   catch (Exception e) {
				e.printStackTrace();
				throw e;
			}
	}

	@When("^User Creates New Cycle and add test to cycle \\(edit comment\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_edit_comment() throws Throwable {
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycleWithoutAssignee(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Then("^User edit comment at execution and step level$")
	public void user_edit_comment_at_execution_and_step_level() throws Throwable {
	    try {
	    	etp = new ExecuteTestPage(driver);
	    	etp.editExecutionComment();
	    	System.out.println("Edit the comment at the execution is success");
	    	driver.switchTo().defaultContent();
 			log.info("Switchback to Default frame");
 			etp.editcommentsteplevel();
 			System.out.println("Edit the comment at the step is suucess");
			 //switch to default content
			 driver.switchTo().defaultContent();
	    }
	    catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}
	
	/////completed/////////////////////////////
	
	//Verify that able to Execute a Test with Status, assignee as different user, Defect, Comment and Attachment to test level execution
	
	@Given("^User Navigates to Created Project and create test to the steps for mentioned fields$")
	public void user_Navigates_to_Created_Project_and_create_test_to_the_steps_for_mentioned_fields() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			PTC = new PlanTestCycle();
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			Thread.sleep(3000);
			//create defect
			String Issuebug = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeBug");
			Bug = "Bug" + timestamp;
			cip.GlobalcreateTest(project, Issuebug, Bug);
			log.info(Bug + ": Bug Created Successfully");
			
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@When("^User Creates New Cycle and add test to cycle \\(mentioned fields\\)$")
	public void user_Creates_New_Cycle_and_add_test_to_cycle_mentioned_fields() throws Throwable {
		try {
	    	etp = new ExecuteTestPage(driver);
			ptcp = new PlanTestCyclePage(driver);
			PTC = new PlanTestCycle();
			PTC.user_clicks_on_Cycle_Summary_Page_and_Validate_the_page();
			log.info("Cycle Summary Page and Validated page Successfully");
			
			PTC.user_creates_New_Cycle_and_Verifies_the_Created_Cycle();
			
			ptcp.addTestToCycle(Test);
			etp.validateExecuteTest();
			System.out.println("Navigate to Execution page successfully");	
	    }catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	   
	}

	@Then("^User perform operation on mentioned fields$")
	public void user_perform_operation_on_mentioned_fields() throws Throwable {
		try {
			etp = new ExecuteTestPage(driver);
			
			//execute the test
			etp.executeTest();
			System.out.println("Execution is Executed sucessfully");
			
			driver.switchTo().defaultContent();
 			log.info("Switchback to Default frame");
 			
 			//assign to different user
 			String otherUser = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "userUsername");
			etp.assignexecutionto_otheruser(otherUser);
			System.out.println("Execution is Re-Assigned to Other User sucessfully");
			
			driver.switchTo().defaultContent();
 			log.info("Switchback to Default frame");
 			
 			
 			//add comment
 			etp.add_comment_at_execution();
 			System.out.println("Comment added to execution successfully");
 			
 			
 			driver.switchTo().defaultContent();
 			log.info("Switchback to Default frame");
 			
 			//link defect
 			etp.associate_existdefect_to_execution(Bug);
 			System.out.println("Associate existing defect to execution successfully");
 			
 			driver.switchTo().defaultContent();
 			log.info("Switchback to Default frame");
 			
 			//add attachment
 			String filePath = Property_Lib.getPropertyValue(CONFIG_PATH+ CONFIG_FILE,"FilePath");
 			etp.addAttachment_to_Execution(filePath);
 			System.out.println("Attachment added to execution successfully");
 			//switch to default content
			 
			 driver.switchTo().defaultContent();
 			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	    
	}


}