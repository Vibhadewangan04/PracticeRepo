package com.zephyr.selenium.stepdefinition;

import com.zephyr.selenium.pageobject.*;
import com.zephyr.selenium.utility.*;
import com.zephyr.selenium.utility.Property_Lib;
import java.time.LocalTime;
import cucumber.api.java.en.*;

public class GeneralConfig extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	GeneralConfigPage gcp;
	
	String fileName1 = "Generalconfig";
	
	LocalTime todayDate = LocalTime.now();
	
	@Then("^enable or disable issue link from issues to tests$")
	public void enable_or_disable_issue_link_from_issues_to_tests() throws Throwable {
		try{
			gcp = new GeneralConfigPage(driver);
				
			gcp.validateIssueLink();
			System.out.println("enable or disable issue link from issues to tests validated successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
		
		
	}
	
	
	@Then("^enable or disable remote link from issues to test executions$")
	public void enable_or_disable_remote_link_from_issues_to_test_executions() throws Throwable {
		try{
			gcp = new GeneralConfigPage(driver);
				
			gcp.validateRemoteLink();
			System.out.println("enable or disable remote link from issues to test executions validated successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
		
		
	}
	
	
	@Then("^validate clear cache$")
	public void validate_clear_cache() throws Throwable {
		try{
			gcp = new GeneralConfigPage(driver);
				
			gcp.validateClearCache();
			System.out.println("validated clear cache successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
		
		
	}
	
	
}