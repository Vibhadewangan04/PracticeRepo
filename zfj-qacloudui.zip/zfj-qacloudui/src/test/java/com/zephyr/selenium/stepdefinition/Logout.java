package com.zephyr.selenium.stepdefinition;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;


import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Logout extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;

	String fileName = "Logout";
	
	@When("^User Clicks on logout Icon$")
	public void user_Clicks_on_logout_Icon() throws Throwable {
		try {
			bp = new CommonUtils();
			lp = new LoginPage(driver);
			bp.waitForElement();
			bp.waitForElement();
			lp.user_option.click();
			bp.waitForElement();
			log.info("Pass - clicked on Logout user Option");
		} catch (Exception e) {
			lb = new LaunchBrowser();
			//lb.getScreenShot(filename);
			e.printStackTrace();
			driver.close();
			Relogin rl = new Relogin();
			rl.reLogin();
			throw e;
		}
	}

	@When("^User clicks on Logout Option$")
	public void user_clicks_on_Logout_Option() throws Throwable {
		try {
			bp = new CommonUtils();
			lp.logout.click();
			bp.waitForElement();
			log.info("Pass - clicked on Logout Successfully");
			
		} catch (Exception e) {
			lb = new LaunchBrowser();
			//lb.getScreenShot(filename);
			e.printStackTrace();
			driver.close();
			Relogin rl = new Relogin();
			rl.reLogin();
			throw e;
		}
	}


}