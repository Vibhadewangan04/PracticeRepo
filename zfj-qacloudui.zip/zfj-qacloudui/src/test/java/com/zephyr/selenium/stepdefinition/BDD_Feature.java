package com.zephyr.selenium.stepdefinition;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.zephyr.selenium.pageobject.BDDFeaturePage;
import com.zephyr.selenium.pageobject.CreateIssuePage;
import com.zephyr.selenium.pageobject.CreateZephyrTestPage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.pageobject.PlanTestCyclePage;
import com.zephyr.selenium.pageobject.ViewIssuePage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;


import cucumber.api.java.en.*;

public class BDD_Feature extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CreateIssuePage cip;
	CreateZephyrTestPage cztp;
	ViewIssuePage vip;
	PlanTestCyclePage ptcp;
	BDDFeaturePage bdd;
	String CycleName;
	String FolderName;
	
	String fileName = "BDD Feature";
	
	@Given("^User NavigateS to Project$")
	public void user_NavigateS_to_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User is in BDD/Cucumber Page and Validate the page$")
	public void user_is_in_BDD_Cucumber_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			bdd = new BDDFeaturePage(driver);
			
			bdd.LaunchBDDCucumberPage();
			
			log.info("BDD/Cucumber Page launched Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User Creates a BDD Feature, Adds BDD Scenario and BDD Background$")
	public void user_Creates_a_BDD_Feature_Adds_BDD_Scenario_and_BDD_Background() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			bdd = new BDDFeaturePage(driver);
			vip = new ViewIssuePage(driver);
			cztp = new CreateZephyrTestPage(driver);
			cip = new CreateIssuePage(driver);
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String FeatureName = "BDD Feature" + timestamp;
			
			bdd.CreateBDDFeature(FeatureName);
			
			vip.goToSearchTestPage();
			cztp.selectIssuetype_from_Dropdown();
			vip.selectFeature(FeatureName);
			vip.clickOnFeatureContent();
			cip.createBDDScenarioForStory();
			cip.addBddBackgroundToStory();
			
			driver.switchTo().defaultContent();
			
			System.out.println("User Added the BDD-Scenario and BDD-Background for Feature successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	@Given("^User create the story with Bdd-feature label$")
	public void user_create_the_story_with_Bdd_feature_label() throws Throwable {
			cip = new CreateIssuePage(driver);
			vip = new ViewIssuePage(driver);
			cztp = new CreateZephyrTestPage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeStory");
			String Story = "Story";
			String label = "BDD_Feature";
			cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
			
			System.out.println("Story created successfully");
			
		
	}
	
	
	@Given("^User navigates to ProjecT$")
	public void user_navigates_to_ProjecT() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			log.info("****  Scenario-1 Started: Create a new Test Cycle cleanly in a selected Version  **********");
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clicks on Cycle Summary Page and Validate the pagE$")
	public void user_clicks_on_Cycle_Summary_Page_and_Validate_the_pagE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
					    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creates New Cycle and Verifies the Created CyclE$")
	public void user_creates_New_Cycle_and_Verifies_the_Created_CyclE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User Uploads Result file to Cycle and Folder$")
	public void user_Uploads_Result_file_to_Cycle_and_Folder() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			String FilePath = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "cycleUploadFilePath");

			ptcp.upload_cucumber_result(CycleName);

			ptcp.uploadBDDResults(FilePath);
			
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			
			FolderName = FolderName +timestamp;
			
			ptcp.createFolder(FolderName,CycleName);

			ptcp.upload_cucumber_result(FolderName);

			ptcp.uploadBDDResults(FilePath);

			driver.switchTo().parentFrame();
			log.info("Out of iFrame");  
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^Label should be added successfully$")
	public void label_should_be_added_successfully() throws Throwable {
	    System.out.println("Label added successfully");
	}

	@Given("^User creates the story with Bdd-feature label$")
	public void user_creates_the_story_with_Bdd_feature_label() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		
		
	}
	
	@Then("^User Add the BDD-Scenario for story successfully$")
	public void user_Add_the_BDD_Scenario_for_story_successfully() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		
		ptcp.navigateToJiraHomePage();
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListViewAndSelectStory();
		vip.clickOnBDDScenarioOption();
		cip.createBDDScenarioForStory();
		System.out.println("User Add the BDD-Scenario for story successfully successfully");
	}

	
	
	@Given("^User navigate to test$")
	public void user_navigate_to_test() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		
		/*
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);*/
		System.out.println("Story created successfully");
		ptcp.navigateToJiraHomePage();
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListView();
		vip.goToListViewAndSelectStory();
		vip.clickOnBDDScenarioOption();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		
	}

	@Then("^User add the Scenarios to test successfully$")
	public void user_add_the_Scenarios_to_test_successfully() throws Throwable {
		cip = new CreateIssuePage(driver);
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When User Navigates to the URL provided\r\n" + 
     		   "And User Enters Username, Password and clicks on login";
		cip.addScenarioForTest(scenario);
	}

	@Given("^Navigate to story$")
	public void navigate_to_story() throws Throwable {
	    
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created successfully");
		ptcp.navigateToJiraHomePage();
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListView();
		vip.goToListViewAndSelectStory();
		vip.clickOnBDDScenarioOption();
		
		
	}

	@Given("^Add scenarios for story$")
	public void add_scenarios_for_story() throws Throwable {
		
		cip.createBDDScenarioForStory();
		
	}

	@Then("^Download the Featue file successfully$")
	public void download_the_Featue_file_successfully() throws Throwable {
		cip.dowloadFeatureFileFromStory();
	}

	@Given("^Upload the feature file to any cycle$")
	public void upload_the_feature_file_to_any_cycle() throws Throwable {
	   cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created successfully");
		ptcp.navigateToJiraHomePage();
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListViewAndSelectStory();
		vip.clickOnBDDScenarioOption();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When User Navigates to the URL provided\r\n" + 
     		   "And User Enters Username, Password and clicks on login";
		cip.addScenarioForTest(scenario);
		ptcp.validatePlanTestCycle();
		
		String version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		ptcp.createNewCycle(version1, cyclename, cycledescription, buildname, environment);
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		
		ptcp.addBDDTestToCycle(issue);
		ptcp.upload_cucumber_result(); 
	}

	@Then("^Result should be updated in Unscheduled-Adhoc cyle$")
	public void result_should_be_updated_in_Unscheduled_Adhoc_cyle() throws Throwable {
	    ptcp = new PlanTestCyclePage(driver);
		String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE,"FilePath3");
		
		ptcp.selectCycleUpload();
		ptcp.uploadAttachement(filePath);
		driver.navigate().refresh();
		System.out.println("Cucumber result is uploaded successfully for cycle");
	}

	@Given("^User create cycle$")
	public void user_create_cycle() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created successfully");
		ptcp.navigateToJiraHomePage();
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListView();
		vip.goToListViewAndSelectStory();
		vip.clickOnBDDScenarioOption();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When User Navigates to the URL provided\r\n" + 
     		   "And User Enters Username, Password and clicks on login";
		cip.addScenarioForTest(scenario);
		ptcp.validatePlanTestCycle();
		
		String version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		ptcp.createNewCycle(version1, cyclename, cycledescription, buildname, environment);
		
		
	}

	@Then("^add test to cycle successfully$")
	public void add_test_to_cycle_successfully() throws Throwable {
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		
		ptcp.addBDDTestToCycle(issue);
	}

	@Given("^Create cycle and add test to cycle$")
	public void create_cycle_and_add_test_to_cycle() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created successfully");
		ptcp.navigateToJiraHomePage();
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListView();
		vip.goToListViewAndSelectStory();
		vip.clickOnBDDScenarioOption();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When User Navigates to the URL provided\r\n" + 
     		   "And User Enters Username, Password and clicks on login";
		cip.addScenarioForTest(scenario);
		ptcp.validatePlanTestCycle();
		
		String version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		ptcp.createNewCycle(version1, cyclename, cycledescription, buildname, environment);
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		
		ptcp.addBDDTestToCycle(issue);
	}

	@Then("^Download the feature file successfully$")
	public void download_the_feature_file_successfully() throws Throwable {
	    ptcp.downloadFeatureFileFromCycle();
	}

	//Scenario: User Upload the cucumber result to cycle having cycle id
	@Given("^Create cycle, add test to cycle$")
	public void create_cycle_add_test_to_cycle() throws Throwable {
	    
	}

	@Given("^Upload the feature file successfully$")
	public void upload_the_feature_file_successfully() throws Throwable {
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath");
			 String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);
			ptcp.upload_cucumber_result();
			ptcp.uploadAttachement(filePath);
			driver.navigate().refresh();
			System.out.println("Cucumber result is uploaded successfully for cycle");
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	
	@Given("^verify cycle status with pass$")
	public void verify_cycle_status_with_pass() throws Throwable {
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath");
			 String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);
			ptcp.upload_cucumber_result();
			 
			ptcp.uploadAttachement(filePath);
			System.out.println("Cucumber result uploaded to cycle");
			driver.navigate().refresh();
			ptcp.verify_bddfeature_passstatus_incycle();
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	@Given("^verify cycle status with fail$")
	public void verify_cycle_status_with_fail() throws Throwable {
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath1");
			 String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);
			ptcp.upload_cucumber_result();
			 
			ptcp.uploadAttachement(filePath1);
			System.out.println("Cucumber result uploaded to cycle");
			driver.navigate().refresh();
			ptcp.verify_bddfeature_failstatus_incycle();
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Given("^verify cycle status with undefined$")
	public void verify_cycle_status_with_undefined() throws Throwable{
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath2 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath2");
			 String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);
			ptcp.upload_cucumber_result();
			 
			ptcp.uploadAttachement(filePath2);
			System.out.println("Cucumber result uploaded to cycle");
			driver.navigate().refresh();
			ptcp.verify_bddfeature_undefinedstatus_incycle();
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	@Given("^User navigate to execute page$")
	public void user_navigate_to_execute_page() throws Throwable {
	    
	}

	@Given("^verify status of Bdd feature$")
	public void verify_status_of_Bdd_feature() throws Throwable {
	    
	}

	@Given("^User create Folder$")
	public void user_create_Folder() throws Throwable {		
	
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		ptcp = new PlanTestCyclePage(driver);
		ptcp.navigateToProject(projectName);
		ptcp.validatePlanTestCycle();
		
		String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		
		ptcp.createNewCycle(Version1, cyclename, cycledescription, buildname, environment);
		System.out.println("Cycle is created  sucessfully");
		
		Thread.sleep(2000);
		
		
		ptcp.navigateToPlanCycleListView();
		System.out.println("navigateToPlanCycleListView sucessfully");
		
		ptcp.createFolder();
		System.out.println("Folder is created sucessfully");
	    
	}

	@Then("^add test to Folder successfully$")
	public void add_test_to_Folder_successfully() throws Throwable {
		
		/*ptcp = new PlanTestCyclePage(driver);
		cip = new CreateIssuePage(driver);
		
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListViewAndSelectStory();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When User Navigates to the URL provided\r\n" + 
     		   "And User Enters Username, Password and clicks on login";
		cip.addScenarioForTest(scenario);
		ptcp.validatePlanTestCycle();
		*/
		
		//create new cycle
		/*String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		ptcp.createNewCycle(Version1, cyclename, cycledescription, buildname, environment);
		Thread.sleep(2000);
		
		ptcp.createFolder();
		System.out.println("Folder is created sucessfully");*/
		
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
	
		ptcp.addBDDTestToFolder(issue);
		//added
		
	    
	}


	@Given("^Create Folder and add test to Folder$")
	public void create_Folder_and_add_test_to_Folder() throws Throwable {
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		ptcp = new PlanTestCyclePage(driver);
		ptcp.navigateToProject(projectName);
	/*	
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		String projectName1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName1, issueTypeStory, Story, label);
		
		System.out.println("bdd test is created  sucessfully");*/
		
		
		ptcp.validatePlanTestCycle();
		
		String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		ptcp.createNewCycle(Version1, cyclename, cycledescription, buildname, environment);
		System.out.println("Cycle is created  sucessfully");
		
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		ptcp.addBDDTestToCycle(issue);
		
		Thread.sleep(2000);
		
		ptcp.navigateToPlanCycleListView();
		System.out.println("navigateToPlanCycleListView sucessfully");
		
		/*ptcp.createFolder();
		System.out.println("Folder is created successfully");
		
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		
		ptcp.addBDDTestToFolder(issue);*/
		
	}

	@Then("^Download the feature file from folder successfully$")
	public void download_the_feature_file_from_folder_successfully() throws Throwable {
		 ptcp.downloadFeatureFileFromFolder();
	}

	@Given("^Create Folder to cycle, add test to folder$")
	public void create_Folder_to_cycle_add_test_to_folder() throws Throwable {
	    
	}

	@Given("^Upload the cucumber result to folder successfully$")
	public void upload_the_cucumber_result_to_folder_successfully() throws Throwable {
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath3 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath3");
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);
			
			
			ptcp.upload_cucumber_result_to_folder();
			ptcp.uploadAttachement(filePath3);
			driver.navigate().refresh();
			System.out.println("Cucumber result is uploaded successfully for folder");
		}catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
		}
	
	
	@Given("^verify folder status with pass$")
	public void verify_folder_status_with_pass() throws Throwable {
		try {
			ptcp = new PlanTestCyclePage(driver);
			String FilePath3 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath3");
			String filePath3 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath3");
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);
			
			ptcp.upload_cucumber_result_to_folder();
			 
			ptcp.uploadAttachement(FilePath3);
			System.out.println("Cucumber result uploaded to folder");
			//driver.navigate().refresh();
			
			ptcp.verify_bddfeature_pass_status_infolder();
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	@Given("^verify folder status with fail$")
	public void verify_folder_status_with_fail() throws Throwable {
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath1");
			 String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);	
			
			ptcp.upload_cucumber_result_to_folder();
			 
			ptcp.uploadAttachement(filePath1);
			System.out.println("Cucumber result uploaded to folder");
			//driver.navigate().refresh();
			
			ptcp.verify_bddfeature_fail_status_infolder();
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Given("^verify folder status with undefined$")
	public void verify_folder_status_with_undefined() throws Throwable{
		try {
			ptcp = new PlanTestCyclePage(driver);
			String filePath2 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath2");
			 String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
						+ CONFIG_FILE, "projectName");
			ptcp.navigateToProject(projectName);			
			
			ptcp.upload_cucumber_result_to_folder();
			 
			ptcp.uploadAttachement(filePath2);
			System.out.println("Cucumber result uploaded to folder");
			//driver.navigate().refresh();
			
			ptcp.verify_bddfeature_undefined_status_infolder();
			
			
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	
	
	}
	

	@Given("^User launches search test page$")
	public void user_launches_search_test_page() throws Throwable {
	    String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		ptcp = new PlanTestCyclePage(driver);
		ptcp.navigateToProject(projectName);
		
		System.out.println("Navigate to search test page sucessfully");
	}

	@Then("^check the Bdd_Background option in menu successfully$")
	public void check_the_Bdd_Background_option_in_menu_successfully() throws Throwable {
		
		cip = new CreateIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		cip.verifyBdd_Backgroundoption();
	}
	    
	

	@Given("^User creates story, BDD_Feature label$")
	public void user_creates_story_BDD_Feature_label() throws Throwable {
		
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String Label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueType, Story, Label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		vip.goToListViewAndSelectStory();
		cip.createScenarioForStory();
		
		
	    
	}

	@Given("^User Add the BDD_Scenarios to story$")
	public void user_Add_the_BDD_Scenarios_to_story() throws Throwable {
		
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
	
		cip.createBDDScenarioForStory();
		
		
	    
	}

	@Given("^User Adds the test to cycle$")
	public void user_Adds_the_test_to_cycle() throws Throwable {
	 
		ptcp = new PlanTestCyclePage(driver);
		
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		
		ptcp.addBDDTestToCycle(issue);	
	    
	}

	@Then("^Upload the result to cycle successfully$")
	public void upload_the_result_to_cycle_successfully() throws Throwable {
	    
	}

	@Given("^creates story and BDD_Feature label$")
	public void creates_story_and_BDD_Feature_label() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String Label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueType, Story, Label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		vip.goToListViewAndSelectStory();
		cip.createScenarioForStory();
		
	    
	}

	@Given("^Add the BDD_Scenarios to story$")
	public void add_the_BDD_Scenarios_to_story() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String Label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueType, Story, Label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		vip.goToListViewAndSelectStory();
		cip.createScenarioForStory();
	    
	}

	@Given("^User Adds the test to folder$")
	public void user_Adds_the_test_to_folder() throws Throwable {
		ptcp = new PlanTestCyclePage(driver);
		
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
		
		ptcp.addBDDTestToCycle(issue);	
	    
	    
	}

	@Then("^Upload the result to folder successfully$")
	public void upload_the_result_to_folder_successfully() throws Throwable {
	    
	}

	@Given("^User Adds the BDD_Scenarios to story$")
	public void user_Adds_the_BDD_Scenarios_to_story() throws Throwable {
	    
	}

	@Given("^User Adds the test to adhoc cycle$")
	public void user_Adds_the_test_to_adhoc_cycle() throws Throwable {
	    
	}

	@Then("^Upload the result to adhoc cycle successfully$")
	public void upload_the_result_to_adhoc_cycle_successfully() throws Throwable {
	    
	}

	@Given("^Create story with Bdd_Feature label$")
	public void create_story_with_Bdd_Feature_label() throws Throwable {
	    
	}

	@When("^Add scenario outline to the story$")
	public void add_scenario_outline_to_the_story() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		//user_Create_story_with_Bdd_Feature_label() ;
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created with label");
		
		vip.goToSearchTest();
		Thread.sleep(3000);
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListView();
		vip.goToListViewAndSelectStory();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When user enter <username> and <password>\r\n" + 
     		   "And User login successfully\r\n" +
		"Examples:\r\n" +

			"| username | password |\r\n" +
			" user1 | password1|\r\n" +
			" user2 | password2 | " ;
		//cip.addScenarioForTest(scenario);
		cip.addScenarioOutline(scenario);
		System.out.println("Scenario outline is added to story");
	    
	}

	@Given("^User Create story with Bdd_Feature label$")
	public void user_Create_story_with_Bdd_Feature_label() throws Throwable {
		  
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String Label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueType, Story, Label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		vip.goToListViewAndSelectStory();
		cip.createScenarioForStory();
		   
		
	}

	@Given("^Add BDD-scenario to the story$")
	public void add_BDD_scenario_to_the_story() throws Throwable {
	    
	}
	

	@Given("^User create cycle  and folder$")
	public void user_create_cycle_and_folderr() throws Throwable {
		ptcp = new PlanTestCyclePage(driver);
		String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleDescription");
		
		String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "buildName");
		
		String environment = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "environment");
		
		
		ptcp.createNewCycle(Version1, cyclename, cycledescription, buildname, environment);
		System.out.println("Cycle is created  sucessfully");
		
		ptcp.createFolder();
		System.out.println("Folder is created sucessfully");
		
	}
	

	@Then("^add test to folder1 successfully$")
	public void add_test_to_folder1_successfully1() throws Throwable {
		ptcp = new PlanTestCyclePage(driver);
		cip = new CreateIssuePage(driver);
		
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListViewAndSelectStory();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When User Navigates to the URL provided\r\n" + 
     		   "And User Enters Username, Password and clicks on login";
		cip.addScenarioForTest(scenario);
		ptcp.validatePlanTestCycle();
		
		ptcp.createFolder();
		System.out.println("Folder is created sucessfully");
		
		String issue = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "bddIssue");
	
		ptcp.addBDDTestToFolder(issue);
		//added
	}
	
	
	
	@Given("^User creates story with BDD_Feature label$")
	public void user_create_story_with_BDD_Feature() throws Throwable{
		
cip = new CreateIssuePage(driver);
		
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created with label successfully");
		
	}
	
	@Then("^User Adds the Bdd_Background scenario successfully$")
	public void User_Adds_the_Bdd_Background_scenario_successfully() throws Throwable {
		
		
		
	}

	
	
	//Add BDD-test to cycle via view issue page
//	@Given("^User Create story with Bdd_Feature label$")
	public void user_Create_story_with_Bdd_Feature_label2() throws Throwable {
		  
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String Label = "BDD_Feature";
		cip.createTestWithLabel(projectName, issueType, Story, Label);
		System.out.println("Story created successfully");
		
		vip.goToSearchTest();
		vip.goToListViewAndSelectStory();
		cip.createScenarioForStory();
	}
	
	

//	@When("^Add BDD-scenario to the story$")
	public void add_scenario_to_the_story1() throws Throwable {
		cip = new CreateIssuePage(driver);
		vip = new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		ptcp = new PlanTestCyclePage(driver);
		//user_Create_story_with_Bdd_Feature_label() ;
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		String label = "BDD_Feature";
		
		cip.createTestWithLabel(projectName, issueTypeStory, Story, label);
		System.out.println("Story created with label");
		
		vip.goToSearchTest();
		Thread.sleep(3000);
		cztp.selectIssuetype_from_Dropdown();
		vip.goToListView();
		vip.goToListViewAndSelectStory();
		cip.createBDDScenarioForStory();
		cip.navigateToTest();
		String scenario = 
     		   "Given User Selects the Browser, Launches it and Maximises it\r\n" + 
     		   "When user enter <username> and <password>\r\n" + 
     		   "And User login successfully\r\n" ;
		
		//cip.addScenarioForTest(scenario);
		cip.addScenarioOutline(scenario);
		System.out.println("Scenario outline is added to story");
	    
	}
	
	
	
}


	
	
	
	
