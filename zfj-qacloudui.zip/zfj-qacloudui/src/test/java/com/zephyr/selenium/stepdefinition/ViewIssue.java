package com.zephyr.selenium.stepdefinition;
import java.io.File;

import org.testng.asserts.SoftAssert;

import com.zephyr.selenium.pageobject.CreateIssuePage;
import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.pageobject.PlanTestCyclePage;
import com.zephyr.selenium.pageobject.SearchTestExecutionPage;
import com.zephyr.selenium.pageobject.ViewIssuePage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;


import cucumber.api.java.en.*;

public class ViewIssue extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CreateIssue ci;
	SearchTestExecutionPage ste;
	ViewIssuePage vip;
	PlanTestCyclePage ptps;
	CreateIssuePage cip;
	SoftAssert soft = new SoftAssert();
	
	String fileName = "ViewIssue";
	
	/*@Given("^Navigate to created project$")
	public void navigate_to_created_project() throws Throwable {
	    
		try{
			vip = new ViewIssuePage(driver);
			
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			vip.navigateToProject(Pname);
			System.out.println("check page-view issue Page Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

			}
	*/
	
	
	@Given("^User Navigates to Projectq$")
public void navigate_project_for_view_issue() throws Throwable {
	    
		try{
			vip = new ViewIssuePage(driver);
			
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			vip.navigateToProject(Pname);
			System.out.println("Navigated to project Successfully");

		//	System.out.println("check page-view issue Page Selected Successfully");

			   			    
			}
		 
			catch (Exception e) {
				/*lb.getScreenShot(fileName);
				e.printStackTrace();
				*/
				driver.close();
				throw e;
				}
	
	}
	
	
	
	@When("^User is under zephyr menu$")
	public void user_is_in_ZephyrMenu_Page() throws Throwable {
		ci = new CreateIssue();
		vip = new ViewIssuePage(driver);
		vip.validateZephyrMenuPage();
		log.info("Zephyr Page and Validated page Successfully");
	
	}
	

		@When("^User is in View Issue Page and Validate the page$")
		public void user_is_in_View_Issue_Page() throws Throwable {
			ci = new CreateIssue();
			vip = new ViewIssuePage(driver);
			vip.validateViewIssuePage();
			
			log.info("Search Test Page and Validated page Successfully");
			
			/*ci.user_clicks_on_Tests_clicks_on_Create_Test();
			vip.goToSearchTest();
			vip.goToListView();*/
		}
		
	
		
		@Then("^Add the test cases$")
		public void user_clicks_on_GlobalCreate_Test() throws Throwable {
			  
			cip = new CreateIssuePage(driver);
			vip = new ViewIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			cip.GlobalcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");			    
			}
		
		/*@Then("^Add the test cases at project level$")
		public void user_clicks_on_SearchTest_then_Create_Test() throws Throwable {
			  
			cip = new CreateIssuePage(driver);
			vip = new ViewIssuePage(driver);
		}*/
		
		@Then("^Add the test cases at projectLevel$")
		public void user_clicks_on_Tests_clicks_on_Create_Test() throws Throwable {
			  
			cip = new CreateIssuePage(driver);
			vip = new ViewIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			cip.ProjectLevelcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");    
			}
			    

		
		@Then("^Add the test case and Edit the Summary Of Test$")
		public void add_testcases_and_Edit_Summary() throws Throwable {
			vip = new ViewIssuePage(driver);
		
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";

			cip.GlobalcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");    
			vip.editTestSummary();
			log.info("edited summary");
		}
		

		
		@Then("^Add the test case with test steps$")
		public void add_the_test_cases_with_testSteps() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			//cip.GlobalcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");
			    	
			vip.AddStepsToTest(projectName);
			
			//to add more steps
		//	vip.AddmultipleStepsToTest(projectName);
			
		}
		
		

		@Then("^Add the test cases with test steps and modify it$")
		public void add_the_test_cases_with_moifiedtestSteps() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
		//	cip.GlobalcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");
			    
		//	vip.AddStepsToTest(projectName);
			vip.editSteps(projectName);
	
		}
		
		
		@And("^Clone a Test step by entered a valid step number$")
		public void Clone_testSteps() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			cip.GlobalcreateTest(projectName, issueType, Test);
			System.out.println("Test created successfully");
		
			vip.cloneTestStepsByEnteringNumber(projectName);
			
			//to clone after step
		//	vip.cloneTestStepInsertAfter(projectName);
		//	vip.cloneTestStepAppendASLastStep(projectName);
		}
		
		
		
		@Then("^Re-arrange steps$")
		public void Rearrange_TestSteps() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			cip.GlobalcreateTest(projectName, issueType, Test);
			vip.AddmultipleStepsToTest(projectName);
			vip.RearrangeTestSteps(projectName);
			log.info("re-arranged steps Successfully");
		}
		
		
		
		@And("^Clone a Test with steps$")
		public void Clone_tests() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			cip.GlobalcreateTest(projectName, issueType, Test);
			vip.AddStepsToTest(projectName);
			vip.cloneTest(projectName);
			log.info("clone Test successfully");
		}
		
		
		@And("^Search test using a keyword$")
		public void Search_test_using_keyword() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
//			cip.GlobalcreateTest(projectName, issueType, Test);
			vip.SearchTestInBasic(projectName);
			log.info("Searched Test successfully");
		}
	
		

		@And("^Delete Test issue$")
		public void Delete_Test() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			cip.GlobalcreateTest(projectName, issueType, Test);
			vip.DeleteTest(projectName);
			log.info("Deleted Test successfully");
		}
		
		
		@And("^Export Test$")
		public void Export_Test() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
		//	cip.GlobalcreateTest(projectName, issueType, Test);
		//	vip.AddStepsToTest(projectName);
			vip.ExportTest(projectName);
			log.info("Export Test successfully");
			
		}
		
		@And("^add attachment to step$")
		public void AddAttachment_to_step() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath");
			cip.GlobalcreateTest(projectName, issueType, Test);
			vip.AddStepsToTest(projectName);
			vip.AddStepAttachment(filePath);
			log.info("Upload the attachment to teststeps Sucessfully ");
			
		}
		
		
		@And("^Delete attachment to step$")
		public void DeleteAttachment_to_step() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE,"FilePath");
			cip.GlobalcreateTest(projectName, issueType, Test);
			vip.AddStepsToTest(projectName);
			
			vip.AddStepAttachment(filePath);
			vip.DeleteStepAttachment(projectName);
			log.info("deleted the attachment to teststeps Sucessfully ");
			
		}
		
		@And("^Add test to cycle$")
		public void AddTest_to_cycle() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			cip.CreateTestforExecution(projectName, issueType, Test);
	//		vip.ScheduleTest2(projectName)
			vip.addTestToCycle(projectName);
			log.info("added Test to execution successfully");
		}
		
		
		@And("^Add same test to cycle$")
		public void AddSameTest_to_cycle() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
			vip.addTestToCycle(projectName);
			log.info("added Test to execution successfully");
		}

		
		
		@And("^Add test to muliple cycle$")
		public void AddTest_to_multiplecycle() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";	
	//		cip.CreateTestforExecution(projectName, issueType, Test);
			vip.addTestToCycle(projectName);
			vip.addTestToCycle(projectName);
			
		}
		
		@And("^Execute test execution$")
		public void Execute_test_execution() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			
			//to run this should have test with executions  to run individual uncomment below 2 method
		//	cip.CreateTestforExecution(projectName, issueType, Test);
		//	vip.addTestToCycle(projectName);
			
			vip.ExecuteTestExecutionInViewIssue();
			log.info("Test execution executed successfully");
			
		}
		
		@And("^Execute test by EButton$")
		public void Execute_test_by_EButton() throws Throwable {
			vip = new ViewIssuePage(driver);
			cip = new CreateIssuePage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			
			//to run this should have test with executions  to run individual uncomment below 2 method
			//	cip.CreateTestforExecution(projectName, issueType, Test);
			//	vip.addTestToCycle(projectName);
			
			vip.ExecuteTestFromEButton();
			log.info(" Navigated to 'Test execution' by Click On E then Test execution executed successfully");
			
		}
		
		

		@Then("^Enable the custom fields in the test$")
		public void enable_the_custom_fields_in_the_test() throws Throwable {
			vip = new ViewIssuePage(driver);
			//vip.enableTestStepCustomFieldInViewIssue();
		}

		@Then("^Add the test steps with custom fields$")
		public void add_the_test_cases_with_custom_fields() throws Throwable {
			vip = new ViewIssuePage(driver);
			
			//vip.addTestStepsToTestWithCustomField();
		}

		@Then("^Clone test step with custom fields$")
		public void clone_test_case_with_custom_fields() throws Throwable {
		    
			vip = new ViewIssuePage(driver);
			//vip.cloneTestSteps();
		}

		@Then("^Copy Zephyr Test Steps With Custom fields$")
		public void copy_Zephyr_Test_Steps_With_Custom_fields() throws Throwable {
			vip = new ViewIssuePage(driver);
			String issueId = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueId");
			//vip.copyZephyrTestSteps(issueId);
			
		}
		
		@Then("^Add the test cases with custom fields values in Large view$")
		public void add_the_test_cases_with_custom_fields_values_in_Large_view() throws Throwable {
			vip = new ViewIssuePage(driver);
			//vip.addTestStepsToTestInLargeView();
		}

		@Then("^Clone test case with custom fields in Large view$")
		public void clone_test_case_with_custom_fields_in_Large_view() throws Throwable {
		    
			vip = new ViewIssuePage(driver);
			//vip.cloneTestStepsInLargeView();
		}



		@Then("^Delete test step with custom fields$")
		public void delete_test_case_with_custom_fields() throws Throwable {
			vip = new ViewIssuePage(driver);
			//vip.deleteTestSteps();
			
		    
		}

	
	

	

}