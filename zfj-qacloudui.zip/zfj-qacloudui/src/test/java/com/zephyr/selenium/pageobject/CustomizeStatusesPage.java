package com.zephyr.selenium.pageobject;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.Colors;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.zephyr.selenium.utility.CommonUtils;

public class CustomizeStatusesPage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;

	public CustomizeStatusesPage(WebDriver driver) {
		this.driver=driver;
		PageFactory.initElements(driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);
		
		
		}
	
	
	/******************************* protected WebElement *******************************/
	

	@FindBy(xpath = "//button[@aria-controls='uid4']")
	//@FindBy(xpath = "//tbody/tr[5]/td[4]")
	protected WebElement wipstatus;
	
	@FindBy(xpath = "//span[text()='Edit']")
	protected WebElement editstatus;
	
	@FindBy(xpath = "//input[@id='statusNameEdit']")
	protected WebElement statusname;
	
	@FindBy(xpath = "//input[@id='statusDescriptionEdit']")
	protected WebElement statusdesc;
	
	@FindBy(xpath = "//button[text()='Update']")
	protected WebElement Updatebutton;
	
	@FindBy(xpath = "//p[text()='Successfully updated execution status']")
	protected WebElement msgbutton;
	
	@FindBy(xpath = "//p[text()='Successfully updated step status']")
	protected WebElement stepmsgbutton;
	
	
	@FindBy(xpath = "//button[text()='Close']")
	protected WebElement closebutton;

	/******************************* protected WebElement *******************************/
//click on jira setting
//@FindBy(xpath="(//*[@id='navigation-app']//div[1]/../div[5]/a)")
@FindBy(xpath="//*[text()='Jira settings']")	

protected WebElement navigation;

//click on Apps
//@FindBy (xpath= "(//*[@id='navigation-app']//div[1]/../div[6]/a)")
@FindBy (xpath= "//*[text()='Apps']")
protected WebElement app;



@FindBy(xpath = "//input[@placeholder='Status']")
protected WebElement status;

@FindBy(xpath = "//input[@placeholder='Description (Optional)']")
protected WebElement statusDescription;


@FindBy(xpath = "//input[@placeholder='Status Color']")
protected WebElement teststatuscolor;

@FindBy(xpath = "//button[text()='Add']")
protected WebElement addbutton;

/*

/*
 * **************************************************** Method Name*/

public boolean customizeTestStatus(String customstatus,String colorcode) throws Exception {
	try {
		bp = new CommonUtils();
		bp = new CommonUtils();
		bp.waitForElement();
		Thread.sleep(2000);
		
		driver.switchTo().frame(0);
		Thread.sleep(2000);
		
		status.click();
		status.sendKeys(customstatus);
		
		//Adding Description to Test Status
		statusDescription.click();
		statusDescription.sendKeys("Adding Description");
		
		//Adding Color code to Test 
		teststatuscolor.click();
		teststatuscolor.sendKeys(colorcode);
		//Thread.sleep(1000);
		bp.explicitWait(addbutton);
		addbutton.click();
		
		//switch to default frame
		driver.switchTo().defaultContent();
		
		
		return true;
       
	  }
	catch(Exception e)
	{
		e.printStackTrace();
		throw e;
	}
}
	
	
	public boolean updateExecutionStatus() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			
			driver.switchTo().frame(0);
			Thread.sleep(2000);
			wipstatus.click();
			bp.waitForElement();
			System.out.println("Clicked on wip status to change");
			editstatus.click();
			System.out.println("Clicked on edit button");
			bp.waitForElement();
			
			
			String name = "WIP status edited" + System.currentTimeMillis();
			Actions act = new Actions(driver);
			statusname.clear();
			bp.waitForElement();
			act.moveToElement(statusname).click().pause(1000).sendKeys(name).perform();
			bp.waitForElement();
			
			statusdesc.clear();
			act.moveToElement(statusdesc).click().pause(1000).sendKeys("wip description-Edited").perform();
			bp.waitForElement();
			
			Updatebutton.click();
			bp.waitForElement();
			System.out.println("Clicked on Update the status");
			
			boolean msgexists = msgbutton.isEnabled();
			bp.waitForElement();
			if(msgexists) {	
				
				System.out.println("updated status msg is present");
				driver.navigate().refresh();
				System.out.println("closed popup successfully");
				return true;			
			}
			else {
				System.out.println("not closed popup successfully");
			return true;
			}
		}
			
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	public boolean updateStepExecutionStatus() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			
			driver.switchTo().frame(0);
			Thread.sleep(2000);
			wipstatus.click();
			bp.waitForElement();
			System.out.println("Clicked on wip status to change");
			editstatus.click();
			System.out.println("Clicked on edit button");
			bp.waitForElement();
			
			
			String name = "WIP status edited" + System.currentTimeMillis();
			Actions act = new Actions(driver);
			statusname.clear();
			bp.waitForElement();
			act.moveToElement(statusname).click().pause(1000).sendKeys(name).perform();
			bp.waitForElement();
			
			statusdesc.clear();
			act.moveToElement(statusdesc).click().pause(1000).sendKeys("wip description-Edited").perform();
			bp.waitForElement();
			
			Updatebutton.click();
			bp.waitForElement();
			System.out.println("Clicked on Update the status");
			
			boolean msgexists = stepmsgbutton.isEnabled();
			bp.waitForElement();
			if(msgexists) {	
				
				System.out.println("updated status msg is present");
				driver.navigate().refresh();
				System.out.println("closed popup successfully");
				return true;			
			}
			else {
				System.out.println("not closed popup successfully");
			return true;
			}
		}
			
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
}







