package com.zephyr.selenium.stepdefinition;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.openqa.selenium.Alert;

import com.zephyr.selenium.pageobject.*;
import com.zephyr.selenium.utility.*;


import cucumber.api.java.en.*;

public class PlanTestCycle extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	PlanTestCyclePage ptcp;
	CreateIssuePage cip;
	String Test;
	String Bug;
	String Test1;
	String CycleName;
	String NewCycleName;
	String buildname ;
	String environment ;
	String createdBy;
	String versionID ;
	
	String fileName1 = "PlanTestCycle";

	
	@Given("^USEr NaVIgates to Project$")
	public void user_NaVIgates_to_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			log.info("****  Scenario-1 Started: Create a new Test Cycle cleanly in a selected Version  **********");
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User Create a new Test for Cycle Summary Cases$")
	public void user_Create_a_new_Test_for_Cycle_Summary_Cases() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			
			String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			String IssueBug = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeBug");
			Test = "New Test" + timestamp;
			Bug = "New Bug" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			
			Thread.sleep(3000);
			cip.GlobalcreateTest(project, IssueBug, Bug);
			log.info(Test + ": Bug Created Successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	
	@Given("^User Navigates to Project$")
	public void user_Navigates_to_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			log.info("****  Scenario-1 Started: Create a new Test Cycle cleanly in a selected Version  **********");
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			 System.out.println("Test is: " + Test);  			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

	}

	@When("^User Clicks on Cycle Summary Page and Validate the page$")
	public void user_Clicks_on_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
					    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

	}

	@Then("^User Creates New Cycle and Verifies the Created Cycle$")
	public void user_Creates_New_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename + ":"+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			//ptcp.verifyCreatedCycle(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			//ptcp.collapseVersion(versionID,CycleName,buildname,environment,createdBy);
			driver.switchTo().parentFrame();
			log.info("Out of iFrame");  
			log.info("****  Scenario-1 Ended: Create a new Test Cycle cleanly in a selected Version  **********");
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

	}

	@Given("^User navigates to Project$")
	public void user_navigates_to_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
		/*	String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User clicks on Cycle Summary Page and Validate the page$")
	public void user_clicks_on_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User creates New Cycle and Verifies the Created Cycle$")
	public void user_creates_New_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			String CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			
			log.info("New Cycle Created and Validated Successfully");
			
			 			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User adds a test to the Test Cycle individually$")
	public void user_adds_a_test_to_the_Test_Cycle_individually() throws Throwable {
		try{
			
			ptcp = new PlanTestCyclePage(driver);
			
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			
			log.info("Successfully Added Test to the cycle Individually");
			Thread.sleep(2000);	    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
		
	}

	@Given("^User navigates To Project$")
	public void user_navigates_To_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			String Label = "New Label" + timestamp;
			cip.createTestWithLabel(project, Issue, Test, Label);
			log.info(Test + ": Test Created Successfully");
			
			Test1 = "New Test" + timestamp;
			String Label1 = "New Label" + timestamp;
			cip.createTestWithLabel(project, Issue, Test1, Label1);
			log.info(Test1 + ": Test Created Successfully");*/
			
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}
	}

	@When("^User clicks On Cycle Summary Page and Validate the page$")
	public void user_clicks_On_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creates new Cycle and Verifies the Created Cycle$")
	public void user_creates_new_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			String CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			
			log.info("New Cycle Created and Validated Successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle Via Saved JIRA search$")
	public void user_Adds_Test_to_the_Cycle_Via_Saved_JIRA_search() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String filterName1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "filterName1");
			ptcp.addTestToCycleViaJiraSearch(filterName1);
			log.info("Added Tests to the cycle via saved jira search");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();		    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	@Given("^User Navigate to Project and Create Test$")
	public void user_Navigate_to_Project_and_Create_Test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			 		 
		/*	String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

	}

	@Then("^User Click on Cycle Summary Page and Validates it$")
	public void user_Click_on_Cycle_Summary_Page_and_Validates_it() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Create New Cycle and Verifies the Created Cycle$")
	public void user_Create_New_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Add Tests to Cycle and Clones a Cycle$")
	public void user_Add_Tests_to_Cycle_and_Clones_a_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String CloneCycle= "Clone Cycle" + timestamp;
			ptcp.cloneCycle(CycleName, CloneCycle);
			log.info("Plan Test Cycle Page Selected Successfully");
			Thread.sleep(2000);
			 driver.switchTo().defaultContent();			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

	}


	@Given("^User Navigate to Project and Create a Test$")
	public void user_Navigate_to_Project_and_Create_a_Test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
						 
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Click on cycle Summary Page and Validates it$")
	public void user_Click_on_cycle_Summary_Page_and_Validates_it() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Create New cycle and Verifies the Created Cycle$")
	public void user_Create_New_cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User adds Tests to Cycle and Deletes a Cycle$")
	public void user_adds_Tests_to_Cycle_and_Deletes_a_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String deleteCycle= "Delete Cycle" + timestamp;			
			ptcp.deleteCycle(CycleName, deleteCycle);
			log.info("Deleted cycle successfully");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	@Given("^User NavigatE to Project and Create a Test$")
	public void user_NavigatE_to_Project_and_Create_a_Test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			 			 
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User ClicK on cycle Summary Page and Validates it$")
	public void user_ClicK_on_cycle_Summary_Page_and_Validates_it() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User CreatE New cycle and Verifies the Created Cycle$")
	public void user_CreatE_New_cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User adds Tests to Cycle and Edits a Cycle$")
	public void user_adds_Tests_to_Cycle_and_Edits_a_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String editCycle= "Edit Cycle" + timestamp;			
			ptcp.editTestCycle(CycleName, editCycle);
			log.info("Edited cycle successfully");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Given("^User NAvigatE to Project and Create a Test$")
	public void user_NAvigatE_to_Project_and_Create_a_Test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");
			 		 
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User CLicK on cycle Summary Page and Validates it$")
	public void user_CLicK_on_cycle_Summary_Page_and_Validates_it() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User CReatE New cycle and Verifies the Created Cycle$")
	public void user_CReatE_New_cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User adds Tests to Cycle and Move a Cycle from Unscheduled to another version$")
	public void user_adds_Tests_to_Cycle_and_Move_a_Cycle_from_Unscheduled_to_another_version() throws Throwable {
		try{
					
			ptcp = new PlanTestCyclePage(driver);
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String moveCycle= "Move Cycle" + timestamp;
			String version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionTwo");
			ptcp.moveCycle(CycleName, version);
			log.info("Moved edited cycle from unscheduled to v1 version successfully");
			Thread.sleep(2000);	
			driver.switchTo().defaultContent(); 
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	
	
	@Given("^User nAvigates To Project$")
	public void user_nAvigates_To_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			Test = "New Test" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			*/
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clIcks On Cycle Summary Page and Validate the page$")
	public void user_clIcks_On_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creAtes new Cycle and Verifies the Created Cycle$")
	public void user_creAtes_new_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle Via Another Cycle$")
	public void user_Adds_Test_to_the_Cycle_Via_Another_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			String NewCycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			
			ptcp.createNewCycle(Version1, NewCycleName,cycledescription,buildname,environment);
			
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String assignee = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "Assignee");
			ptcp.addTestToCycleViaAnotherCycle(versionID, CycleName, assignee);
			log.info("Added Tests to the cycle via From Another Cycle");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();	
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	/*
	 Scenario: Able to Execute Test using [E] and change test status to any
	*/
	
	@Given("^User nAVigates To Project$")
	public void user_nAVigates_To_Project() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			String IssueBug = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeBug");
			Test = "New Test" + timestamp;
			Bug = "New Bug" + timestamp;
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");
			Thread.sleep(2000);
			cip.GlobalcreateTest(project, IssueBug, Bug);
			log.info(Test + ": Bug Created Successfully");*/
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clIckS On Cycle Summary Page and Validate the page$")
	public void user_clIckS_On_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creAteS new Cycle and Verifies the Created Cycle$")
	public void user_creAteS_new_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
			ptcp.addDefectToExecution(Bug,CycleName);
			log.info("Successfully Added Defect to the Execution");
			
			
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle Via Another Cycle by filtering linked defects$")
	public void user_Adds_Test_to_the_Cycle_Via_Another_Cycle_by_filtering_linked_defects() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			NewCycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			
			ptcp.createNewCycle(Version, NewCycleName,cycledescription,buildname,environment);
			
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String assignee = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "Assignee");
			ptcp.addTestToCycleViaAnotherCycleByFilteringDefects(versionID, CycleName, assignee);
			log.info("Added Tests to the cycle via From Another Cycle");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	/*
	 Scenario: Able to Execute Test using [E] and change test status to any
	*/

	@Given("^User nAVigates To Project and Creates (\\d+) test$")
	public void user_nAVigates_To_Project_and_Creates_test(int arg1) throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			
		/*	String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			String IssueBug = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeBug");
			cip.GlobalcreateTest(project, Issue, Test1);
			log.info(Test+ ": Test Created Successfully");*/
			
			
			
		}
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clIckS ON Cycle Summary Page and Validate the page$")
	public void user_clIckS_ON_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creAteS New Cycle and Verifies the Created Cycle$")
	public void user_creAteS_New_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			String filterName1 = Property_Lib.getPropertyValue(CONFIG_PATH+ CONFIG_FILE, "filterName3");
			log.info("New Cycle Created and Validated Successfully");	
			
			ptcp.addTestToCycleViaJiraSearch(filterName1);
			log.info("Successfully Added Test to the cycle");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and Assign to Other than logged in user and Execute with different status$")
	public void user_Adds_Test_to_the_Cycle_and_Assign_to_Other_than_logged_in_user_and_Execute_with_different_status() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.ExecuteTestFromPTC();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();	
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	/*
	 Scenario: Able to Execute Test using [E] and change test status to any
	*/
	
	@Given("^User nAVigates To Project and Creates a test$")
	public void user_nAVigates_To_Project_and_Creates_a_test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			
			Test = "New Test" + timestamp;
			
			cip.GlobalcreateTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	@When("^User clIcKS ON Cycle Summary Page and Validate the page$")
	public void user_clIcKS_ON_Cycle_Summary_Page_and_Validate_the_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creAtES New Cycle and Verifies the Created Cycle$")
	public void user_creAtES_New_Cycle_and_Verifies_the_Created_Cycle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and Execute the Test by using \\[E\\]$")
	public void user_Adds_Test_to_the_Cycle_and_Execute_the_Test_by_using_E() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.ExecuteTestFromEoption();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();		    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	/*
	 Scenario: Able to Execute test step and change Teststep status to any
	 */
	
	@Given("^User navigatE To Project and Creates a test$")
	public void user_navigatE_To_Project_and_Creates_a_test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			
			Test = "New Test" + timestamp;
			
			cip.createTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clickS ON Cycle Summary Page and Validate the pagE$")
	public void user_clickS_ON_Cycle_Summary_Page_and_Validate_the_pagE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User createS New Cycle and Verifies the Created CyclE$")
	public void user_createS_New_Cycle_and_Verifies_the_Created_CyclE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and Execute test step and change Teststep status to any$")
	public void user_Adds_Test_to_the_Cycle_and_Execute_test_step_and_change_Teststep_status_to_any() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.ExecuteTestStepInDetailView();
			Thread.sleep(2000);
			driver.switchTo().defaultContent();	
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	/*
	 Scenario: Should able to Export the Test Cycle (Export in all 3 format)
	*/
	
	@Given("^User navigatES To Project and Creates a test$")
	public void user_navigatES_To_Project_and_Creates_a_test() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			
			Test = "New Test" + timestamp;
			
			cip.createTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clicKS ON Cycle Summary Page and Validate the pagE$")
	public void user_clicKS_ON_Cycle_Summary_Page_and_Validate_the_pagE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creaTS New Cycle and Verifies the Created CyclE$")
	public void user_creaTS_New_Cycle_and_Verifies_the_Created_CyclE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and Should able to Export the Test Cycle \\(Export in all (\\d+) format\\)$")
	public void user_Adds_Test_to_the_Cycle_and_Should_able_to_Export_the_Test_Cycle_Export_in_all_format(int arg1) throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String exportTypeCSV = "CSV";
			String exportTypeHTML ="HTML";
			String exportTypeXML = "XML";
			
			ptcp.cycleExport(CycleName,exportTypeXML);
			ptcp.cycleExport(CycleName,exportTypeHTML);
			ptcp.notificationPopup();
			ptcp.cycleExport(CycleName,exportTypeCSV);
			
		
			
			log.info("Allowed alert popup");
			
			log.info("Exported Cycle with XML/HTML/CSV format successfulyy");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();	
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}
	
	/*
	 Scenario: While cloning the cycle enable copy custom fields check box ,then custom-field values also clone
	*/
	
	@Given("^User navigatES To ProjecT$")
	public void user_navigatES_To_ProjecT() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
			/*String timestamp = new SimpleDateFormat("YYYYMMDDhhmmss").format(new Date());
			String project = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "projectName");
			String Issue = Property_Lib.getPropertyValue(CONFIG_PATH  + CONFIG_FILE, "issueTypeTest");
			
			Test = "New Test" + timestamp;
			
			cip.createTest(project, Issue, Test);
			log.info(Test + ": Test Created Successfully");*/
			
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clicKS ON Cycle Summary PagE and Validate the pagE$")
	public void user_clicKS_ON_Cycle_Summary_PagE_and_Validate_the_pagE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creaTS New Cycle and VerifieS the Created CyclE$")
	public void user_creaTS_New_Cycle_and_VerifieS_the_Created_CyclE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and While cloning the cycle enables copy custom fields check box ,then custom-field values also clone$")
	public void user_Adds_Test_to_the_Cycle_and_While_cloning_the_cycle_enables_copy_custom_fields_check_box_then_custom_field_values_also_clone() throws Throwable {
		
			try{
				ptcp = new PlanTestCyclePage(driver);
				String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
				String CloneCycle= "Clone Cycle" + timestamp;
				ptcp.cloneCycleWithCustomFields(CycleName, CloneCycle);
				log.info("Plan Test Cycle Page Selected Successfully");
				Thread.sleep(2000);
				driver.switchTo().defaultContent();
				Thread.sleep(2000);
				}
			 
				catch (Exception e) {
					lb.getScreenShot(fileName1);
					e.printStackTrace();
					
					driver.close();
					throw e;
				}	    
			
	}
	
	
	/*
	Scenario: In 'Take a feature tour ' option skip, show more page, next feature links are present
	*/
	
	@Given("^User navigatES To ProjeCt$")
	public void user_navigatES_To_ProjeCt() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
					
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clicKS ON Cycle Summary PagE and Validate the paGE$")
	public void user_clicKS_ON_Cycle_Summary_PagE_and_Validate_the_paGE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	

	@Then("^User Adds Test to the Cycle and validate in Take a feature tour, option skip/show more page/next feature links are present$")
	public void user_Adds_Test_to_the_Cycle_and_validate_in_Take_a_feature_tour_option_skip_show_more_page_next_feature_links_are_present() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			ptcp.appTour();
			log.info("Validated Skip/ Show more page/ Next feature links Successfully");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();		
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}	
	}

	/*
	Scenario: From 'show the new page feature' option all new features of that page highlights clearly and properly
	*/
	
	
	@Given("^User navigatES To ProJect$")
	public void user_navigatES_To_ProJect() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
					
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clicKS ON Cycle SUmmary PagE and Validate the paGE$")
	public void user_clicKS_ON_Cycle_SUmmary_PagE_and_Validate_the_paGE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creaTS New Cycle and VerifieS the Created CYCle$")
	public void user_creaTS_New_Cycle_and_VerifieS_the_Created_CYCle() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and validate From show the new page feature option all new features of that page highlights clearly and properly$")
	public void user_Adds_Test_to_the_Cycle_and_validate_From_show_the_new_page_feature_option_all_new_features_of_that_page_highlights_clearly_and_properly() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			ptcp.showNewPageFeatures();
	
			log.info("Validated Show more page Texts Successfully");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();	
			Thread.sleep(2000);
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}	
	}

	@Given("^User navigatES To ProJects$")
	public void user_navigatES_To_ProJects() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			cip = new CreateIssuePage(driver);
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Project Selected Successfully");			 
					
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User clicKS ON Cycle SUmmary PagE and Validate the PaGE$")
	public void user_clicKS_ON_Cycle_SUmmary_PagE_and_Validate_the_PaGE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Cycle Summary Page and Validated page Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@When("^User creaTS New Cycle and VerifieS the Created CYClE$")
	public void user_creaTS_New_Cycle_and_VerifieS_the_Created_CYClE() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			String timestamp = new SimpleDateFormat("yyyy_MM_dd__hh_mm_ss").format(new Date());
			String Version = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleName");
			CycleName = cyclename+timestamp;
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "cycleDescription");
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "buildName");
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "environment");
			String createdBy = Property_Lib.getPropertyValue(CONFIG_PATH + CONFIG_FILE, "createdBy");
			String versionID = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "VersionOneID");
			ptcp.createNewCycle(Version, CycleName,cycledescription,buildname,environment);
			ptcp.versionExpandCheck(versionID,CycleName,buildname,environment,createdBy);
			log.info("New Cycle Created and Validated Successfully");	
			String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");
			ptcp.addTestToCycle(Test);
			log.info("Successfully Added Test to the cycle Individually");
						   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}
	}

	@Then("^User Adds Test to the Cycle and validate From show the new page feature option all new features of that page highlights clearly and properly in Execute Test Page$")
	public void user_Adds_Test_to_the_Cycle_and_validate_From_show_the_new_page_feature_option_all_new_features_of_that_page_highlights_clearly_and_properly_in_Execute_Test_Page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			ptcp.showMorePagesInExecutePage();
			log.info("Validated Show more page Texts Successfully");
			Thread.sleep(2000);
			driver.switchTo().defaultContent();			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
			}	
	}

	
	//******************************************************
	
	@Given("^Navigate to created project$")
	public void navigate_to_created_project() throws Throwable {
	    
		try{
			ptcp = new PlanTestCyclePage(driver);
			
		
			String Pname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			
			ptcp.navigateToProject(Pname);
			log.info("Plan Test Cycle Page Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

			}
	

	@Given("^User Clicks on Plan Test Cycle validate plan test cycle page$")
	public void user_Clicks_on_Plan_Test_Cycle_validate_plan_test_cycle_page() throws Throwable {
		try{
			ptcp = new PlanTestCyclePage(driver);
			ptcp.validatePlanTestCycle();
			log.info("Plan Test Cycle Page Selected Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

			}
	
	@Given("^Create New Cycle$")
	public void create_New_Cycle() throws Throwable {
	    
		try{
			ptcp = new PlanTestCyclePage(driver);
			
			String Version1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "versionOne");
			String cyclename = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "cycleName");
			
			String cycledescription =  Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "cycleDescription");
			
			String buildname = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "buildName");
			
			String environment = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "environment");
			
			
			
			ptcp.createNewCycle(Version1, cyclename,cycledescription,buildname,environment);
			
			log.info("Created New Cycle Successfully");
			   			    
			}
		 
			catch (Exception e) {
				lb.getScreenShot(fileName1);
				e.printStackTrace();
				
				driver.close();
				throw e;
				}

			}
	    
	

@Given("^Verify Created Cycle$")
public void verify_Created_Cycle() throws Throwable {
	try{
		ptcp = new PlanTestCyclePage(driver);
		//ptcp.verifyCreatedCycle();
		log.info("Verified created cycle");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}

		}

@Given("^Add Test To The Cycle$")
public void add_Test_To_The_Cycle() throws Throwable {
	try{
		ptcp = new PlanTestCyclePage(driver);
		String issueId = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueId");
		
		String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");		
		ptcp.addTestToCycle(Test);
		log.info("Added Tests to the cycle Individually");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}

	
}

@Given("^Add Test To The Cycle Via Saved JIRA Search$")
public void add_Test_To_The_Cycle_Via_Saved_JIRA_Search() throws Throwable {
    
	try{
		ptcp = new PlanTestCyclePage(driver);
		String filterName1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "filterName1");
		ptcp.addTestToCycleViaJiraSearch(filterName1);
		log.info("Added Tests to the cycle via saved jira search");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
}



@Given("^Add Test To The Folder$")
public void add_Test_To_The_folder() throws Throwable {
	try{
		ptcp = new PlanTestCyclePage(driver);
		String issueId = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueId");
		
		String Test = Property_Lib.getPropertyValue(CONFIG_PATH	+ CONFIG_FILE, "TestIssueIdWithStep");		
		ptcp.addTestTofolder(Test);
		log.info("Added Tests to the cycle Individually");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
}


@Given("^Should be able to Edit the Test Cycle details$")
public void should_be_able_to_Edit_the_Test_Cycle_details() throws Throwable {
   
	try{
		ptcp = new PlanTestCyclePage(driver);
		
		ptcp.editTestCycle();
		log.info("Edited the test cycle details successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
}


@Given("^Move Cycle from one version to other$")
public void move_Cycle_from_one_version_to_other() throws Throwable {
	try{
		ptcp = new PlanTestCyclePage(driver);
		
		String version1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "versionOne");
		ptcp.moveCycle(version1);
		log.info("Moved edited cycle from unscheduled to v1 version successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
	
	
}


@Given("^Clone cycle$")
public void clone_cycle() throws Throwable {
    
	try{
		ptcp = new PlanTestCyclePage(driver);
		
		String Cname = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "cycleName");
		
		ptcp.cloneCycle(Cname);
		log.info("Cloned cycle successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
	
}
	


@Given("^Delete cycle$")
public void delete_cycle() throws Throwable {
    
	try{
		ptcp = new PlanTestCyclePage(driver);
		
		ptcp.deleteCycle();
		log.info("Deleted cycle successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
	
}


@Then("^Execute test from plan test cycle$")
public void Execute_test_from_plan_test_cycle() throws Throwable {
    
	try{
		ptcp = new PlanTestCyclePage(driver);
		
		ptcp.ExecuteTestFromPTC();
		log.info("Executed test using E successfully");
		   			    
		}
	 
		catch (Exception e) {
			lb.getScreenShot(fileName1);
			e.printStackTrace();
			
			driver.close();
			throw e;
			}
	
}

@Given("^Add folder to cycle$")
public void add_folder_to_cycle() throws Throwable {
    try {
    	
    	ptcp = new PlanTestCyclePage(driver);
    	ptcp.createFolder();
    	log.info("Folder created Successfully");
    }
    catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}

@Given("^Delete folder$")
public void Delete_folder() throws Throwable {
    try {
    	
    	ptcp = new PlanTestCyclePage(driver);
    	ptcp.deleateFolder();
    	log.info("Folder deleated Successfully");
    }
    catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}
}

/*@Given("^upload cucumber result to cycle$")
public void upload_cucumber_result_to_cycle() throws Throwable {
	try {
		ptcp = new PlanTestCyclePage(driver);
		String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE,"FilePath");
		
		ptcp.upload_cucumber_result();
		ptcp.uploadAttachement(filePath);
		driver.navigate().refresh();
		log.info("Cucumber result is uploaded successfully for cycle");
	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}

@Given("^verify cycle status with pass$")
public void verify_cycle_status_with_pass() throws Throwable {
	try {
		ptcp = new PlanTestCyclePage(driver);
		String filePath = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE,"FilePath");
		ptcp.upload_cucumber_result();
		 
		ptcp.uploadAttachement(filePath);
		log.info("Cucumber result uploaded to cycle");
		driver.navigate().refresh();
		ptcp.verify_bddfeature_passstatus_incycle();
		
	}
	
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}


@Given("^verify cycle status with fail$")
public void verify_cycle_status_with_fail() throws Throwable {
	try {
		ptcp = new PlanTestCyclePage(driver);
		String filePath1 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE,"FilePath1");
		ptcp.upload_cucumber_result();
		 
		ptcp.uploadAttachement(filePath1);
		log.info("Cucumber result uploaded to cycle");
		driver.navigate().refresh();
		ptcp.verify_bddfeature_failstatus_incycle();
	}
	
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}

@Given("^verify cycle status with undefined$")
public void verify_cycle_status_with_undefined() throws Throwable{
	try {
		ptcp = new PlanTestCyclePage(driver);
		String filePath2 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE,"FilePath2");
		ptcp.upload_cucumber_result();
		 
		ptcp.uploadAttachement(filePath2);
		log.info("Cucumber result uploaded to cycle");
		driver.navigate().refresh();
		ptcp.verify_bddfeature_undefinedstatus_incycle();
	}
	
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}
@Given("^upload cucumber result to folder$")
public void upload_cucumber_result_to_folder() throws Throwable{
	try {
		ptcp = new PlanTestCyclePage(driver);
		String filePath3 = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE,"FilePath3");
		
		ptcp.upload_cucumber_result_to_folder();
		ptcp.uploadAttachement(filePath3);
		driver.navigate().refresh();
		log.info("Cucumber result is uploaded successfully for folder");
	}
	catch (Exception e) {
		e.printStackTrace();
		throw e;
	}
}
	}
*/