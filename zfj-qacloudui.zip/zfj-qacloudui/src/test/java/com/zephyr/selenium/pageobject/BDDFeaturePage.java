package com.zephyr.selenium.pageobject;

import static org.testng.Assert.assertEquals;

import java.util.ArrayList;
import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class BDDFeaturePage {
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;
	ViewIssuePage vip;
	BDDFeaturePage cip;

	public BDDFeaturePage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	@FindBy(xpath = "//div[contains(text(),'Zephyr')]")
	protected WebElement zephyrPage;
	
	@FindBy(xpath = "//*[contains(text(),'BDD/Cucumber (New)')]")
	public WebElement launchBDDPage;
	
	@FindBy(xpath = "//*[@id='root']/div/div[2]/button/span/span")
	protected WebElement createBDDFeature;
	
	@FindBy(xpath = "(//*[@id='project-field'])")
	protected WebElement projectDropDown;
	
	@FindBy(xpath = "(//*[@id='issuetype-field'])")
	protected WebElement issueTypeFiledDropDown;
	
	@FindBy(xpath = "(//*[@id='summary'])")
	public WebElement summary;
	
	@FindBy(xpath = "//*[@id='create-issue-submit']")
	public WebElement createButton;
	

	
	/******************************* String protected *******************************/
	


	
	public boolean LaunchBDDCucumberPage() throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			zephyrPage.click();
			System.out.println("Navigated to Zephyr page");
			launchBDDPage.click();
			System.out.println("Navigated to Cycle Summary page");
			bp.waitForElement();
					
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	public boolean CreateBDDFeature(String FeatureName) throws Exception {
		try {
			bp = new CommonUtils();
			bp.waitForElement();
			
			driver.switchTo().frame(0);
			System.out.println("Found Iframe");
			
			createBDDFeature.click();
			bp.waitForElement();
			
			System.out.println("BDD Feature Create Successfully");
			
			driver.switchTo().defaultContent();
			System.out.println("Out of Iframe");
			
			summary.click();
			summary.sendKeys(FeatureName);
			
			createButton.click();
			
			bp.waitForElement();
			
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
}
