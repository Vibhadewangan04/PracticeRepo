package com.zephyr.selenium.stepdefinition;


import org.junit.runner.RunWith;

import com.zephyr.selenium.pageobject.CreateZephyrTestPage;
import com.zephyr.selenium.pageobject.CustomfieldPage;

import com.zephyr.selenium.pageobject.LoginPage;
import com.zephyr.selenium.pageobject.ViewIssuePage;
import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;
import com.zephyr.selenium.utility.Property_Lib;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.junit.Cucumber;


public class CreateZephyrTest extends LaunchBrowser {
	LaunchBrowser lb;
	LoginPage lp;
	CommonUtils bp;
	CustomfieldPage csp;
	CreateZephyrTestPage cztp;
	ViewIssuePage vip;
	CreateIssue cri;
	
	
	//
	
	
	@Given("^Navigate to General Configuration$")
	public void navigate_to_General_Configuration() throws Throwable  {
		cztp = new CreateZephyrTestPage(driver);
		cri = new CreateIssue();
		vip = new ViewIssuePage(driver);
		cztp.navigateToGeneralConfiguration();
	}
	
	
	@When("^Select All and save the preference and saved to All successfully$")
	public void select_All_and_save_the_preference_and_saved_to_All_successfully() throws Throwable  {
		cztp = new CreateZephyrTestPage(driver);
		cztp.selectStory();
        cztp.selectSubtask();
		cztp.selectStory();
		cztp.selectTask();
		cztp.selectBug();
		cztp.selectEpic();
		
	}
	
		
	
	
	@Given("^User create the Story$")
	public void user_create_the_Story() throws Throwable {
		cztp=new CreateZephyrTestPage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeStory");
		String Story = "Story";
		cztp.createStory(projectName, issueTypeStory, Story);
		System.out.println("Story created successfully");
		Thread.sleep(2000);
		vip=new ViewIssuePage(driver);
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		cztp.verify_CreateZephyrTest_option();
		//cztp.validateCreateZephyrTestOption();
		
		
	}

	
	@And("^User create the Bug$")
	public void user_create_the_Bug() throws Throwable {
		cztp=new CreateZephyrTestPage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeBug = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeBug");
		String Bug = "Bug";
		cztp.createBug(projectName, issueTypeBug, Bug);
		System.out.println("Bug created successfully");
		
		Thread.sleep(2000);
		vip=new ViewIssuePage(driver);
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		cztp.verify_CreateZephyrTest_option();
		//cztp.validateCreateZephyrTestOption();
	    
	}
	
	
	@And("^User create the Task$")
	public void user_create_the_Task() throws Throwable {
		cztp=new CreateZephyrTestPage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeTask = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeTask");
		String Task = "Task";
		cztp.createTask(projectName, issueTypeTask, Task);
		System.out.println("Task created successfully");
		
		Thread.sleep(2000);
		vip=new ViewIssuePage(driver);
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		cztp.verify_CreateZephyrTest_option();
		//cztp.validateCreateZephyrTestOption();
	    
	}
	
	
	@And("^User create the Epic$")
	public void user_create_the_Epic() throws Throwable {
		cztp=new CreateZephyrTestPage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeEpic = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeEpic");
		String Epic= "Epic";
		cztp.createEpic(projectName, issueTypeEpic, Epic);
		System.out.println("Epic created successfully");
		
		Thread.sleep(2000);
		vip=new ViewIssuePage(driver);
		vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();
		cztp.verify_CreateZephyrTest_option();
		//cztp.validateCreateZephyrTestOption();
	    
	}

	
	
	@And("^User create the SubTask$")
	public void user_create_the_SubTask() throws Throwable {
		cztp=new CreateZephyrTestPage(driver);
		vip=new ViewIssuePage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeTest = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeTest");
		//String Testsummary= "Test for SubTask";
		cztp.createSubTask(projectName, issueTypeTest);
		System.out.println("Test for subatsk created successfully");
		/*vip=new ViewIssuePage(driver);
		vip.goToSearchTest();*/
		
		//ctp.verify_CreateZephyrTest_option();
		Thread.sleep(2000);
		/*vip.goToSearchTest();
		cztp.selectIssuetype_from_Dropdown();*/
		cztp.verify_CreateZephyrTest_option();
		//cztp.validateCreateZephyrTestOption_in_subtask();
	    
	}
	
	
	@When("^User select issuetype from dropdown$")
	public void user_select_issuetype_from_dropdown() throws Throwable {
		try {
		cztp=new CreateZephyrTestPage(driver);
		cztp.selectIssuetype_from_Dropdown();
		System.out.println("All Standard Issue Type checkbox is enabled Successfully");
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@Then("^click on context menu and verify createtest option$")
	public void click_on_context_menu_and_verify_createtest_option() throws Throwable {
		try {
			cztp=new CreateZephyrTestPage(driver);
			cztp.verify_CreateZephyrTest_option();
			
	}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}


	}
	


@Given("^User click on Create Zephyr Test option from Story and create test$")
	public void click_on_Create_Zephyr_Test_option_from_Story_and_create_test() throws Throwable{
		try {
			
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			cztp=new CreateZephyrTestPage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeStory");
			String Story = "Story";
			cztp.createStory(projectName, issueTypeStory, Story);
			//ctp.selectIssuetype_from_Dropdown();
			//ctp.createStory(project, issue, Story)
			Thread.sleep(2000);
			vip.goToSearchTest();
			cztp.selectIssuetype_from_Dropdown();
			
			
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			//cip.createTest(projectName, issueType, Test);
			System.out.println("Test created successfully from Story");
			
			cztp.create_test_from_story(projectName, issueType, Test);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

}
	
	
	@Given("^User click on Create Zephyr Test option from Bug and create Test$")
	public void user_click_on_Create_Zephyr_Test_option_from_Bug_and_create_Test() throws Throwable{
		try {
			
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			cztp=new CreateZephyrTestPage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeBug = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeBug");
			String Bug = "Bug";
			cztp.createBug(projectName, issueTypeBug, Bug);
			//ctp.selectIssuetype_from_Dropdown();
			//ctp.createStory(project, issue, Story)
			Thread.sleep(2000);
			vip.goToSearchTest();
			cztp.selectIssuetype_from_Dropdown();
			
			
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			//cip.createTest(projectName, issueType, Test);
			System.out.println("Test created successfully from Bug");
			
			cztp.create_test_from_bug(projectName, issueType, Test);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

}
	
	
	@Given("^User click on Create Zephyr Test option from Task and create Test$")
	public void user_click_on_Create_Zephyr_Test_option_from_Task_and_create_Test() throws Throwable{
		try {
			
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			cztp=new CreateZephyrTestPage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeTask = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTask");
			String Task = "Task";
			cztp.createTask(projectName, issueTypeTask, Task);
			//ctp.selectIssuetype_from_Dropdown();
			//ctp.createStory(project, issue, Story)
			Thread.sleep(2000);
			vip.goToSearchTest();
			cztp.selectIssuetype_from_Dropdown();
			
			
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			//cip.createTest(projectName, issueType, Test);
			System.out.println("Test created successfully from Task");
			
			cztp.create_test_from_task(projectName, issueType, Test);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

}
	
	
	@Given("^User click on Create Zephyr Test option from Epic and create Test$")
	public void user_click_on_Create_Zephyr_Test_option_from_Epic_and_create_Test() throws Throwable{
		try {
			
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			cztp=new CreateZephyrTestPage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeEpic = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeEpic");
			String Epic = "Epic";
			cztp.createEpic(projectName, issueTypeEpic, Epic);
			//ctp.selectIssuetype_from_Dropdown();
			//ctp.createStory(project, issue, Story)
			Thread.sleep(2000);
			vip.goToSearchTest();
			cztp.selectIssuetype_from_Dropdown();
			
			
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			//cip.createTest(projectName, issueType, Test);
			System.out.println("Test created successfully from Epic");
			
			cztp.create_test_from_epic(projectName, issueType, Test);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

}
	
	
	@Given("^User click on Create Zephyr Test option from SubTask and create Test$")
	public void user_click_on_Create_Zephyr_Test_option_from_SubTask_and_create_Test() throws Throwable{
		try {
			
			vip=new ViewIssuePage(driver);
			vip.goToSearchTest();
			cztp=new CreateZephyrTestPage(driver);
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueType1 = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			
			cztp.createSubTask(projectName, issueType1);
			//ctp.selectIssuetype_from_Dropdown();
			//ctp.createStory(project, issue, Story)
			Thread.sleep(2000);
			//vip.goToSearchTest();
			//cztp.selectIssuetype_from_Dropdown();
			
			
			String issueType = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			String Test = "Test";
			//cip.createTest(projectName, issueType, Test);
			System.out.println("Test created successfully from subtask");
			
			cztp.create_test_from_subtask(projectName, issueType);
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

}
	
	
//
	//to deselect
	
	@Given("^Navigate to General Configurations$")
	public void navigate_to_General_Configurations() throws Throwable{
			cztp = new CreateZephyrTestPage(driver);
			cri = new CreateIssue();
			vip = new ViewIssuePage(driver);
			cztp.navigateToGeneralConfiguration();
		}
		
		
	@When("^Deselect All and save the preference and Preference should not be saved to All$")
	public void deselect_All_and_save_the_preference_and_Preference_should_not_be_saved_to_All() throws Throwable{
			
		cztp = new CreateZephyrTestPage(driver);
		cztp.deselectStory();
		}
	


	@Given("^Verify CreateZephyrTest option is not available in Story$")
	public void verify_CreateZephyrTest_option_is_not_available_in_Story() throws Throwable{
		vip=new ViewIssuePage(driver);
	//cri.user_Selects_Project_Issue_Type_Story_Enter_Summary_and_Clicks_on_Create_button();
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeStory = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeStory");
			String Story = "Story";
			cztp = new CreateZephyrTestPage(driver);
			 vip.goToSearchTest();
			cztp.createStory(projectName, issueTypeStory, Story);
			System.out.println("Story created Successfully");
	        vip.goToSearchTest();
	        cztp.selectIssuetype_from_Dropdown();
	        
	        cztp.validateCreateZephyrTestOption();
}
		
		
	
	@Given("^Verify CreateZephyrTest option is not available in Bug$")
	public void verify_CreateZephyrTest_option_is_not_available_in_Bug() throws Throwable {
		vip=new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		cztp.navigateToGeneralConfiguration();
		cztp.deselectBug();
		vip.goToSearchTest();
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeBug = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeBug");
		String Bug = "Bug";
		cztp.createBug(projectName, issueTypeBug, Bug);
		System.out.println("Bug created Successfully");
	    vip.goToSearchTest();
	    cztp.selectIssuetype_from_Dropdown();
	    cztp.validateCreateZephyrTestOption();
		}
		
		
	@Given("^Verify CreateZephyrTest option is not available in Task$")
	public void verify_CreateZephyrTest_option_is_not_available_in_Task() throws Throwable{
		vip=new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		cztp.navigateToGeneralConfiguration();
		cztp.deselectTask();
		vip.goToSearchTest();
	    // cri.user_Selects_Project_Issue_Type_Task_Enter_Summary_and_Clicks_on_Create_button();
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeTask = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeTask");
		String Task = "Task";
		
		cztp.createTask(projectName, issueTypeTask, Task);
		System.out.println("Task created Successfully");
	     vip.goToSearchTest();
	     cztp.selectIssuetype_from_Dropdown();
	    cztp.validateCreateZephyrTestOption();
		}
	
	@Given("^Verify CreateZephyrTest option is not available in Epic$")
	public void verify_CreateZephyrTest_option_is_not_available_in_Epic() throws Throwable{
		vip=new ViewIssuePage(driver);
		cztp = new CreateZephyrTestPage(driver);
		cztp.navigateToGeneralConfiguration();
		cztp.deselectEpic();
		vip.goToSearchTest();
	     //cri.user_Selects_Project_Issue_Type_Epic_Enter_Summary_and_Clicks_on_Create_button();
		cztp=new CreateZephyrTestPage(driver);
		String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "projectName");
		String issueTypeEpic = Property_Lib.getPropertyValue(CONFIG_PATH
				+ CONFIG_FILE, "issueTypeEpic");
		String Epic= "Epic";
		
		cztp.createEpic(projectName, issueTypeEpic, Epic);
		System.out.println("epic created Successfully");
	     vip.goToSearchTest();
	     cztp.selectIssuetype_from_Dropdown();
	     cztp.validateCreateZephyrTestOption();
	
		}
	
	
	@Given("^Verify CreateZephyrTest option is not available in SubTask$")
	public void verify_CreateZephyrTest_option_is_not_available_in_SubTask() throws Throwable{
		vip=new ViewIssuePage(driver);
	    cztp=new CreateZephyrTestPage(driver);
	    cztp.navigateToGeneralConfiguration();
		cztp.selectBug();
		//cztp.selectSubtask();
		cztp.deselectSubtask();
		vip.goToSearchTest();
			String projectName = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "projectName");
			String issueTypeTest = Property_Lib.getPropertyValue(CONFIG_PATH
					+ CONFIG_FILE, "issueTypeTest");
			
	     cztp.createSubTask_for_deselect(projectName, issueTypeTest);
	  //   vip.goToSearchTest();
	    // cztp.selectIssuetype_from_Dropdown();
	     cztp.validateCreateZephyrTestOption_in_subtask();
	
		}
	
	
	
	
	@When("^Select All and save the preferenec$")
	public void select_All_and_save_the_preferenec() throws Throwable {
	    
	}

	@Then("^Preference should be saved to All successfully$")
	public void preference_should_be_saved_to_All_successfully() throws Throwable {
	    
	}

	@Given("^Navigate to View Issue Page$")
	public void navigate_to_View_Issue_Page() throws Throwable {
	   
	}

	@When("^User click on Menu Option$")
	public void user_click_on_Menu_Option() throws Throwable {
	  
	}

	@Then("^Verify CreateZephyrTest option is available in menu option$")
	public void verify_CreateZephyrTest_option_is_available_in_menu_option() throws Throwable {
	   
	}

	@Then("^Verify CreateZephyrTest option is available in menu option is visible in Story$")
	public void verify_CreateZephyrTest_option_is_available_in_menu_option_is_visible_in_Story() throws Throwable {
	   
	}

	@Then("^Verify CreateZephyrTest option is available in menu option is visible in Bug$")
	public void verify_CreateZephyrTest_option_is_available_in_menu_option_is_visible_in_Bug() throws Throwable {
	    
	}

	@Then("^Verify CreateZephyrTest option is available in menu option is visible in Task$")
	public void verify_CreateZephyrTest_option_is_available_in_menu_option_is_visible_in_Task() throws Throwable {
	    
	}

	@Then("^Verify CreateZephyrTest option is available in menu option is visible in SubTask$")
	public void verify_CreateZephyrTest_option_is_available_in_menu_option_is_visible_in_SubTask() throws Throwable {
	   
	}

	@Given("^Save the preference to Story/Bug/Task under Show Create Zephyr Test on Issue Type\\(s\\)$")
	public void save_the_preference_to_Story_Bug_Task_under_Show_Create_Zephyr_Test_on_Issue_Type_s() throws Throwable {
	    
	}

	@When("^Navigate to Search Test and Select Any Issue$")
	public void navigate_to_Search_Test_and_Select_Any_Issue() throws Throwable {
	    
	}

	@When("^User click on Menu icon$")
	public void user_click_on_Menu_icon() throws Throwable {
	    
	}

	@Then("^Verify CreateZephyrTest option in menu is visible for Any Issue Type$")
	public void verify_CreateZephyrTest_option_in_menu_is_visible_for_Any_Issue_Type() throws Throwable {
	    
	}

	@Given("^Navigate to General Config$")
	public void navigate_to_General_Config() throws Throwable {
	  }

	@Given("^Unsave the saved preference to Story/Bug/Task under Show Create Zephyr Test on Issue Type\\(s\\)$")
	public void unsave_the_saved_preference_to_Story_Bug_Task_under_Show_Create_Zephyr_Test_on_Issue_Type_s() throws Throwable {
	   
	}

	@When("^Go to Search Test and Select any Issue$")
	public void go_to_Search_Test_and_Select_any_Issue() throws Throwable {
	    
	}

	@When("^User click on Menu option$")
	public void user_click_on_Menu_option() throws Throwable {
	    
	}

	@Then("^Verify CreateZephyrTest option in menu is not visible for Any Issue Type$")
	public void verify_CreateZephyrTest_option_in_menu_is_not_visible_for_Any_Issue_Type() throws Throwable {
	    
	}

	@Given("^Create Issue$")
	public void create_Issue() throws Throwable {
	    
	}

	@Given("^Navigate to Search Test$")
	public void navigate_to_Search_Test() throws Throwable {
	   
	}

	@Given("^Select Any Issue$")
	public void select_Any_Issue() throws Throwable {
	   
	}

	@When("^User click on Menu icon and add Test from CreateZephyrTest option$")
	public void user_click_on_Menu_icon_and_add_Test_from_CreateZephyrTest_option() throws Throwable {
	
	}

	@Then("^Test Created successfully from CreateZephyrTest option for Issue Type$")
	public void test_Created_successfully_from_CreateZephyrTest_option_for_Issue_Type() throws Throwable {
	   
	}
}

	


