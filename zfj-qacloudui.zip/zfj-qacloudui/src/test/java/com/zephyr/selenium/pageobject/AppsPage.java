package com.zephyr.selenium.pageobject;

import static org.testng.Assert.assertEquals;

import java.util.List;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;


public class AppsPage {
	
	private static final String Test = null;
	WebDriver driver;
	CommonUtils bp;
	public Logger log;
	Actions act;
	ViewIssuePage vip;
	AppsPage appp;
	
	public AppsPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);

	}


	/******************************* protected WebElement *******************************/
	@FindBy(xpath = "//*[@id='productLogoGlobalItem']")
	protected WebElement jirahomepage;
	
	@FindBy(xpath = "//span[@aria-label='Settings']")
	protected WebElement jirasettings;
	
	@FindBy(xpath = "//span[text()='Add and manage Jira Marketplace apps.']")
	protected WebElement apps;
	
	@FindBy(xpath = "//div[text()='Customize Test Status']")
	protected WebElement customizeteststatus;
	
	@FindBy(xpath = "//div[text()='Customize Step Status']")
	protected WebElement customizestepstatus;
	
	
	@FindBy(xpath = "//div[text()='General Configuration']")
	protected WebElement generalconfig;
	
	@FindBy(xpath = "//div[contains(text(),'Projects')]")
	protected WebElement projects;
	
	@FindBy(xpath = "//input[@name='search']")
	protected WebElement searchproject;
	
	
	

	
	public boolean navigateToJiraAppsPage() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			jirasettings.click();
			
			System.out.println("Navigate to Jira settings page");	
			bp.waitForElement();
			
			apps.click();
			
			System.out.println("Clicked on Apps");
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	

	public boolean navigateToCustomizeTestStatusPage() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			customizeteststatus.click();
			
			System.out.println("Clicked on customize test status page");	
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	public boolean navigateToCustomizeStepStatusPage() throws Exception{

		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			customizestepstatus.click();
			
			System.out.println("Clicked on customize test status page");	
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}


	public boolean navigateToGeneralConfigPage() throws Exception{
			
		try{
			bp = new CommonUtils();
			bp.waitForElement();
			Thread.sleep(2000);
			generalconfig.click();
			
			System.out.println("Clicked on General configuration page");	
			return true;
		}
		
		catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		
		
		
	}
	
	
	

}
