package com.zephyr.selenium.pageobject;

import static org.junit.Assert.assertArrayEquals;
import static org.testng.Assert.assertEquals;

import java.awt.List;
import java.util.ArrayList;

import org.apache.bcel.generic.Select;
import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zephyr.selenium.utility.CommonUtils;
import com.zephyr.selenium.utility.LaunchBrowser;



public class CustomfieldPage {
	static WebDriver driver;
	CommonUtils bp;
	public Logger log;
	
	public CustomfieldPage(WebDriver driver) {

		this.driver = driver;
		PageFactory.initElements(LaunchBrowser.driver, this);
		log = Logger.getLogger(this.getClass());
		Logger.getRootLogger().setLevel(org.apache.log4j.Level.INFO);
		int stepnumber=5;

	}

	/******************************* protected WebElement *******************************/
	//click on jira setting
	@FindBy(xpath="//*[text()='Jira settings']")
	protected WebElement settings;
	//click on Apps
	@FindBy (xpath= "//*[text()='Apps']")
	protected WebElement app;
	
	//click on zephyr customfield
    @FindBy (xpath="//*[text()='Zephyr Custom Fields']")
	protected WebElement zephyrcustomfield;
	
	//click on Execution
	//@FindBy (xpath= "//*[@id=\"root\"]/div/div/div[1]/div[1]/ul/li[1]")
	@FindBy(xpath="//*[@class=\"_2zEM34RCz4E5ANnRakv7bM _2GU7xr5FxFUzKXsPYruCbs\"]")
	protected WebElement Executions;
	
	//Add customfield button execution level
	//@FindBy (xpath="//*[contains(text(),'Add Custom Field']")
	@FindBy (xpath="(//*[@class='_26Rfe1lar9WC5NDEeARvBy'])[1]")
	protected WebElement addbutton;
	
	//Add text single line
	//@FindBy (xpath="//*[@id=\"root\"]/div/div/div[4]/div/div[2]/div/div[2]/div/div[2]/div[2]/div[1]")
	@FindBy (xpath="(//*[@class='custom-field-preview'])[1]")
	protected WebElement textsingleline;
	
	//click next button
	//@FindBy(xpath="//*[text()='Next']")
	@FindBy(xpath="(//*[@class='_26Rfe1lar9WC5NDEeARvBy'])[2]")
	protected WebElement nextbutton;
	
	//enter name
	@FindBy (xpath="//*[@name='name']")
	protected WebElement textname;
	//enter description
	@FindBy (xpath="//*[@name='description']")
	protected WebElement textdescription;
	
	//click on create button
	@FindBy(xpath="//*[@id=\"root\"]//div[4]//button[2]/span")
	//@FindBy (xpath="//*[text()='Create']")
	protected WebElement createtext;
	
	//click on backbutton
	@FindBy (xpath ="//*[@id=\"root\"]//div[4]//div/div[3]/div/div/button[1]/span")
	//@FindBy(xpath="//*[conatins(text(),'Back')]")
	protected WebElement backbutton;
	
	//Add multiline customfield
	@FindBy (xpath="(//*[@class='custom-field-preview'])[2]")
	protected WebElement textmultiline;
	
	//Add number customfield
	@FindBy (xpath="(//*[@class='custom-field-preview'])[3]")
	protected WebElement numbercustomfield;
	
	//Add radio button customfield
	@FindBy (xpath="(//*[@class='custom-field-preview'])[4]")
	protected WebElement radiobuttoncustomfield;
	
	//click on radiobutton/checkbox options
	@FindBy (xpath="//*[@name='newOptionName']")
	protected WebElement optionsfield;
	
	//click on options Add button
   //  @FindBy(xpath="//*[text()='Add']")
    @FindBy(xpath="//*[@id=\"root\"]//div[4]//form//button/span")
    protected WebElement optionaddbutton;
    
    //Add checkbox customfield
    @FindBy (xpath="(//*[@class='custom-field-preview'])[5]")
    protected WebElement checkboxcustomfield;
    
    //Add singlelist customfield
    @FindBy (xpath="(//*[@class='custom-field-preview'])[6]")
    protected WebElement singlelistcustomfield;
    
    //Add multiselect customfield
    @FindBy (xpath="(//*[@class='custom-field-preview'])[7]")
    protected WebElement multiselectcustomfield;
    
    //Add datepick customfield
    @FindBy (xpath="(//*[@class='custom-field-preview'])[8]")
    protected WebElement datecustomfield;
    
    //Add datetime customfield
    @FindBy (xpath="(//*[@class='custom-field-preview'])[9]")
    protected WebElement timecustomfield;
    
    //cancel button
   // @FindBy(xpath ="//*[text()='Cancel']")
    @FindBy(xpath="//*[@id=\"root\"]//div[4]//div[3]/div/button[1]/span")
    protected WebElement cancelbutton;
    
    //steps level
    //clcik on step execution link
    @FindBy(xpath ="//*[text()='Test Steps']")
    protected WebElement testSteplink;
    
    //click on error popup
    @FindBy(xpath="//*[text()='Error']")
    protected WebElement errormsg;
    
    //click on actions of first customfield
   
   @FindBy(xpath ="(//*[@class='aui-icon aui-icon-small aui-iconfont-configure cursor-pointer'])[1]") 
   protected WebElement actionbutton;
    
    //click on edit
  // @FindBy (xpath="//*[@id=\"root\"]//div[5]//ul/li[1]")
   @FindBy (xpath="//*[text()='Edit']")
    protected WebElement editoption;
    
    //save button
    @FindBy (xpath="//*[@id=\"root\"]//div[5]//div/button[1]/span")
    protected WebElement savebutton;    
    
    //click on deleteoption
    @FindBy(xpath="//*[text()='Delete']")
    protected WebElement deleteoption;
    
    //click on success popup
    @FindBy(xpath=("//*[text()='Success']"))
    protected WebElement sucessmsg;
    
    //click on back to main menu
    @FindBy(xpath="//*[text()='Back to main menu']")
    protected WebElement backtomainmenu;
    
    //click on projectmenu 
    @FindBy(xpath="(//*[text()='Projects'])[1]")
    protected WebElement projectmenu;
    
    //to searchproject field
    @FindBy(xpath="//*[@name='search']")
    protected WebElement searchproject;
    
    //click on projectname after searching
    @FindBy(xpath="(//*[text()='Automation Project'])[2]")
     protected  WebElement projectclick;
    
    //click on close of enable popup
    @FindBy(xpath="//*[@id=\"root\"]//div[3]//button/span")
    protected WebElement closebtn;
    
    //click on zephyr customield to enable
    @FindBy(xpath="//*[text()='Zephyr Custom Fields']")
    protected WebElement zfjcustomfield;
    
    //enable the single line txt field
   // @FindBy(xpath="//*[@id=\"root\"]/div/div/div/div[2]/div[1]/div/div/div/div/div[2]/div/div/table/tbody/tr[1]/td[5]/label/div/div/span")
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[1]")
    protected WebElement enablefirstcustomfield;
    
    //enable multiline txt customfield
   
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[2]")
    protected WebElement enablesecondcustomfield;
    
    //enable number
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[3]")
    protected WebElement enablethirdcustomfield;
    
    //enable radiobutton
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[4]")
    protected WebElement enablefourthcustomfield;
    
    //enable checkbox
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[5]")
    protected WebElement enablefifthcustomfield;
    
    //enable singlechoice list
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[6]")
    protected WebElement enablesixthcustomfield;
    
    //enable multiselect
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[7]")
    protected WebElement enableseventhcustomfield;
    
    //enable datepicker
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[8]")
    protected WebElement enable_eightcustomfield;
    
    //enable datetime
    @FindBy(xpath="(//*[@class=\"hdvkUO\"])[9]")
    protected WebElement enable_ninthcustomfield;
    
	/******************************* String protected *******************************/
	protected String role;

	
	public boolean executioncustomfield(String singleline,String multiline,String number, String radiobutton,String checkbox,String singlechoice,String multichoice,String datepicker,String datetime,String des) throws Exception {
		try {
			bp = new CommonUtils();
			bp.explicitWait(settings);
			settings.click();
			app.click();
			zephyrcustomfield.click();
			//switch to frame
			//driver.switchTo().frame(driver.findElement(By.className("ap-container")));
			WebElement id1=driver.findElement(By.tagName("iframe"));
			
			
			java.util.List<WebElement> Test123 = driver.findElements(By.tagName("iframe"));
			
			int totalsize = Test123.size();
			
			for(int i=0;i<Test123.size();i++) {
				
				Test123.get(i).getText();
					
				
				//System.out.println(totaliframe);
			}
			
			
			//driver.switchTo().frame(driver.findElement(By.id("com.thed.zephyr.je__zconfig-customfields__fd0ab4c")));
			driver.switchTo().frame(id1);
			System.out.println("Found Iframe");
			
			Thread.sleep(5000);
			//Executions.click();
			addbutton.click();
			Thread.sleep(1000);
			
			
			textsingleline.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(singleline);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			createtext.click();
			//bp.explicitWait(backbutton);
			Thread.sleep(8000);
			backbutton.click();
			//bp.explicitWait(backbutton);
			
			
			
			//create Multiline Customfield
			
			textmultiline.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(multiline);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(1000);
			//bp.explicitWait(backbutton);
			
			//verify sucess msg
			
			String	expected ="Success";
			//	System.out.println(errormsg1);
		String actual=	sucessmsg.getText();
			if(actual.contains(expected)) {
			
				System.out.println("Custom fields created sucessfully");
			}
			
			else
			{
				System.out.println("Custom Field not Created.");
			}
			
			
			Thread.sleep(7000);
			
			backbutton.click();
			
			//create number customfield
			numbercustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(number);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(8000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//
				
			
			//create radio button customfield1
			
			radiobuttoncustomfield.click();	
			nextbutton.click();
			textname.click();
			textname.sendKeys(radiobutton);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			optionsfield.click();
			optionsfield.sendKeys("option1");
			optionaddbutton.click();
			optionsfield.click();
			optionsfield.sendKeys("option2");
			optionaddbutton.click();
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(7000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//create checkbox
			checkboxcustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(checkbox);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			optionsfield.click();
			optionsfield.sendKeys("checkbox1");
			optionaddbutton.click();
			optionsfield.click();
			optionsfield.sendKeys("checkbox2");
			optionaddbutton.click();
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(7000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//create single list customfield
			singlelistcustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(singlechoice);
			textdescription.click();
			textdescription.sendKeys(des);
			optionsfield.click();
			optionsfield.sendKeys("singlelist1");
			optionaddbutton.click();
			optionsfield.click();
			optionsfield.sendKeys("singlelist2");
			optionaddbutton.click();
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(7000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//create multiselect customfield
			
			multiselectcustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(multichoice);
			textdescription.click();
			textdescription.sendKeys(des);
			optionsfield.click();
			optionsfield.sendKeys("multiselect list1");
			optionaddbutton.click();
			optionsfield.click();
			optionsfield.sendKeys("multi select list2");
			optionaddbutton.click();
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(7000);
			//bp.explicitWait(backbutton);
			
			backbutton.click();
			
			//create date customfield
			
			datecustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(datepicker);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(7000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//create date-time customfield
			timecustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(datetime);
			textdescription.click();
			textdescription.sendKeys(des);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(8000);
			
			//backbutton.click();
			//bp.explicitWait(cancelbutton);
			
			//edit the customfield

			cancelbutton.click();
          Thread.sleep(3000);
         // Actions action =new Actions(driver);
         // action.moveToElement(actionbutton).click();
			actionbutton.click();
			Thread.sleep(1000);
          //action.moveToElement(editoption).click();
			editoption.click();
			textname.click();
			textname.sendKeys("Executioncustomfield Edited");
			savebutton.click();
			System.out.println("Execution customfield edited sucessfully");
			Thread.sleep(5000);
			//cancelbutton.click();
			
			
		
			return true;
		} catch (Exception e) {
			e.printStackTrace();
			
			throw e;
		}

	}
	
	

	
	
	public boolean create_stepcCustomfield(String stepDes,String stepmultiline,String stepnumber,String stepradiobutton,String stepsinglechoice,String stepdatetime,String stepsinglinetxt) throws Exception {
		try {
			bp = new CommonUtils();
			bp.explicitWait(settings);
			settings.click();
			app.click();
			zephyrcustomfield.click();
			//switch to frame
			//driver.switchTo().frame(driver.findElement(By.className("ap-container")));
			WebElement id1=driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(id1);
			System.out.println("Found Iframe");
			Thread.sleep(1000);
			
			testSteplink.click();
			Thread.sleep(1000);
			addbutton.click();
			Thread.sleep(1000);
			
			//multiline step customfield
			
            textmultiline.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(stepmultiline);
			textdescription.click();
			textdescription.sendKeys(stepDes);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(8000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//number step customfield
			numbercustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(stepnumber);
			textdescription.click();
			textdescription.sendKeys(stepDes);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(8000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//create radiobutton at steplevel
			
			radiobuttoncustomfield.click();	
			nextbutton.click();
			textname.click();
			textname.sendKeys(stepradiobutton);
			textdescription.click();
			textdescription.sendKeys(stepDes);
			Thread.sleep(1000);
			optionsfield.click();
			optionsfield.sendKeys("option1");
			optionaddbutton.click();
			optionsfield.click();
			optionsfield.sendKeys("option2");
			optionaddbutton.click();
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(1000);
			//bp.explicitWait(backbutton);
			
			//to verify the sucess msg
			String	expected ="Success";
			//	System.out.println(errormsg1);
		String actual=	sucessmsg.getText();
			if(actual.contains(expected)) {
			
				System.out.println("Custom fields created sucessfully");
			}
			
			else
			{
				System.out.println("Custom Field not Created.");
			}
			
			Thread.sleep(7000);
			backbutton.click();
			
			//create single list customfield at step level
			singlelistcustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(stepsinglechoice);
			textdescription.click();
			textdescription.sendKeys(stepDes);
			optionsfield.click();
			optionsfield.sendKeys("singlelist1");
			optionaddbutton.click();
			optionsfield.click();
			optionsfield.sendKeys("singlelist2");
			optionaddbutton.click();
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(7000);
			//bp.explicitWait(backbutton);
			backbutton.click();
			
			//create date-time customfield
			timecustomfield.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(stepdatetime);
			textdescription.click();
			textdescription.sendKeys(stepDes);
			Thread.sleep(1000);
			createtext.click();
			Thread.sleep(8000);
			backbutton.click();
			//bp.explicitWait(cancelbutton);
			//cancelbutton.click();
			
			//trying to creating>5 stepcustomfield
			textsingleline.click();
			nextbutton.click();
			textname.click();
			textname.sendKeys(stepsinglinetxt);
			textdescription.click();
			textdescription.sendKeys(stepDes);
			Thread.sleep(3000);
			createtext.click();
			
			//to handle the error popup
		String	expected1="Error";
		//	System.out.println(errormsg1);
	     String actual1=	errormsg.getText();
		if(actual1.contains(expected1)) {
		
			System.out.println("Custom fields limit is exceeded 5");
		}
		
		else
		{
			System.out.println("Custom Field Created Successfully.");
		}
		Thread.sleep(1000);
		cancelbutton.click();
		
		//Edit 1st stepcustomfield
		Thread.sleep(1000);
		actionbutton.click();
		editoption.click();
		textname.click();
		textname.sendKeys("stepcustomfield Edited");
		savebutton.click();
		Thread.sleep(1000);	
			
			driver.switchTo().defaultContent();
			
			Thread.sleep(2000);	
			settings.click();
			Thread.sleep(2000);	
			backtomainmenu.click();
			Thread.sleep(2000);
			
			return true;
		}
			
			
			
		catch (Exception e) {
			e.printStackTrace();
			
			throw e;
		}
	}
			
	
	public boolean enablecustomfield(String projectName) throws Exception {
		try {
			bp = new CommonUtils();
			projectmenu.click();
			bp.explicitWait(searchproject);
			searchproject.click();
			searchproject.sendKeys(projectName);
			bp.explicitWait(projectclick);
		//	Thread.sleep(1000);
			projectclick.click();
			bp.explicitWait(zfjcustomfield);
			zfjcustomfield.click();
			Thread.sleep(5000);
			//switch to frame
			WebElement id1=driver.findElement(By.tagName("iframe"));
			driver.switchTo().frame(id1);
			System.out.println("Found Iframe");
			Thread.sleep(5000);
			//bp.explicitWait(closebtn);
			//enable single txt
			enablefirstcustomfield.click();
			Thread.sleep(5000);
			/*Alert alert =driver.switchTo().alert();
			System.out.println(alert.getText());
			alert.dismiss();*/
			closebtn.click();
			
			//enable multiline
			bp.explicitWait(enablesecondcustomfield);
			enablesecondcustomfield.click();
			//Thread.sleep(5000);
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable number customfield
			bp.explicitWait(enablethirdcustomfield);
			enablethirdcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable radiobutton customfield
			bp.explicitWait(enablefourthcustomfield);
			enablefourthcustomfield.click();
			//bp.explicitWait(closebtn);
			Thread.sleep(5000);
			closebtn.click();
			
			//enable checkbox customfield
			bp.explicitWait(enablefifthcustomfield);
			enablefifthcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable enablesignlelist customfield
			bp.explicitWait(enablesixthcustomfield);
			enablesixthcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable enablemultiselect customfield
			bp.explicitWait(enableseventhcustomfield);
			enableseventhcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable enabledatepicker customfield
			bp.explicitWait(enable_eightcustomfield);
			enable_eightcustomfield.click();
			//bp.explicitWait(closebtn);
			Thread.sleep(5000);
			closebtn.click();
			
			//enable enabledatetime customfield
			bp.explicitWait(enable_ninthcustomfield);
			enable_ninthcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//click on teststplink
			testSteplink.click();
			bp.explicitWait(enablefirstcustomfield);
			enablefirstcustomfield.click();
			Thread.sleep(5000);
			//bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable second
			bp.explicitWait(enablesecondcustomfield);
			enablesecondcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable third customfield
			bp.explicitWait(enablethirdcustomfield);
			enablethirdcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable fourth customfield
			bp.explicitWait(enablefourthcustomfield);
			enablefourthcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			
			//enable fifth customfield
			bp.explicitWait(enablefifthcustomfield);
			enablefifthcustomfield.click();
			bp.explicitWait(closebtn);
			closebtn.click();
			driver.switchTo().defaultContent();
			
			return true;
		}
		catch (Exception e) {
			e.printStackTrace();
			
			throw e;
	}
	}
	
		
		

	public void deletecustomfield() throws Exception {
		try {
			actionbutton.click();
			deleteoption.click();
			Alert alert =driver.switchTo().alert();
			System.out.println(alert.getText());
			alert.accept();
			/*Alert alert1=driver.switchTo().alert();
			System.out.println(alert1.getText());
			alert1.dismiss();*/
			
		}
		catch (Exception e) {
			e.printStackTrace();
			
			throw e;
	}
	}



}
