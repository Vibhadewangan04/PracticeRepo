# After installing docker run the following commands to pull the latest docker containers


# final commands to start and stop the images
docker pull selenium/hub
docker pull selenium/node-chrome
docker pull selenium/node-firefox


# The below command is useful to run the docker in 2 chrome and 2 firefox browser, add other browser if required in sameway
docker-compose up -d --scale chrome=2 --scale firefox=2

#After completing the automation run the below commands to kill the container and remove the container
docker-compose kill
docker-compose rm

# press y to confirm removing
y
#updated