package com.fsw.test;

import java.util.ArrayList;
import java.util.concurrent.TimeUnit;

import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import com.fsw.pageUtils.LoginpageUtils;
import com.fsw.pageUtils.TestListeners;
import com.fsw.pages.CustomKeywords;
import com.fsw.pages.EnvironmentalPage;
import com.fsw.pages.LanguagePage;
import com.fsw.pages.RegionalPage;
import com.fsw.pages.ServerPage;
import com.fsw.pages.TestPlan;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Issue;
import ru.yandex.qatools.allure.annotations.Parameter;
import ru.yandex.qatools.allure.annotations.Severity;
import ru.yandex.qatools.allure.annotations.Stories;
import ru.yandex.qatools.allure.annotations.TestCaseId;
import ru.yandex.qatools.allure.annotations.Title;
import ru.yandex.qatools.allure.model.SeverityLevel;

@Listeners({ TestListeners.class })
@Features(value = { "Feature : Fiery Setup Wizard BAM Test cases" })
@Title("Sanity checks of FSW")
public class FSWProductWindows_TestPlan extends TestPlan {

	String FSWURL;
	String Browser;
	String Password;
	String Server_Date;
	String Server_Name;
	String cookies;
	String WebToolsURL;
	String WTUserName;
	String BonjourServiceName;
	String COLOR;

	/*
	 * public static HttpsURLConnection conn; DefaultHttpClient httpClient = new
	 * DefaultHttpClient();
	 */

	@BeforeMethod
	public void settingParametes(ITestContext testContext) {
		// FSWURL = testContext.getSuite().getParameter("FSWURL");
		BonjourServiceName = System.getProperty("BonjourServiceName");
		FSWURL = System.getProperty("FSWURL");
		Browser = System.getProperty("Browser");
		Password = System.getProperty("Password");
		Server_Date = System.getProperty("Server_Date");
		Server_Name = System.getProperty("Server_Name");
		WebToolsURL = System.getProperty("WebToolsURL");
		WTUserName = System.getProperty("WTUserName");
		COLOR = System.getProperty("COLOR");
	}

	/*
	 * FSWURL="10.210.116.30"; WebToolsURL="10.210.116.30"; //alpine IP
	 * Browser="Chrome"; Server_Date="24/10/2018"; Password="Fiery.1";
	 * WTUserName="Admin"; Server_Name="SERVER-5F134F6C";
	 * BonjourServiceName="Pro 8300series EB-35 v1.0 PS (4)";
	 */

	@Parameter("FSWURL")
	String FSW_URL;
	@Parameter("WebToolsURL")
	String WebTools_URL;
	@Parameter("Browser")
	String BrowserName;
	@Parameter("Server_Date")
	String ServerDate;
	@Parameter("Password")
	String PassWord;
	@Parameter("Server_Name")
	String ServerName;
	@Parameter("WTUserName")
	String WT_UserName;
	@Parameter("BonjourServiceName")
	String Bonjour_Service_Name;
	@Parameter("COLOR")
	String Colour;

	/*
	 * @BeforeMethod public void loginFiery() throws Exception { FSW_URL = FSWURL;
	 * CustomKeywords customKeywords = new CustomKeywords();
	 * customKeywords.Post2(FSW_URL); customKeywords.Put(); }
	 */
	/*
	 * customKeywords.doTrustToCertificates();
	 * HttpsURLConnection.setFollowRedirects(false); URL url = new
	 * URL("https://10.210.108.91/live/api/v4/login"); conn = (HttpsURLConnection)
	 * url.openConnection(); conn.setRequestMethod("POST");
	 * conn.setRequestProperty("Content Type", "application/json");
	 * conn.setRequestProperty("username", "admin");
	 * conn.setRequestProperty("username", "admin");
	 * conn.setRequestProperty("username", "admin"); HttpPost postRequest = new
	 * 
	 * 
	 * HttpPost( "https://10.210.108.91/live/api/v4/login"); StringEntity input =
	 * new StringEntity(
	 * "{\"username\": \"admin\",\"password\": \"9e811f6d6ac9e88b1b70dcf867d501aed4ac1dde10133b20538a53df9fc44e42\",\"accessrights\": \"hscPvGULGj8dNgLUVGdObw2+TuFt6gEmDYNQ92mGPASxlInlXXVHiyDrnNCJg239+W5K6ow++Yr9tn3p+sJdCKEtDO8/rrT26QWrUXmzbswH1DmwrADnpMdXCSw0ZNBrrmHAtfUN0ARDd8trWCmk+9QvrLSfeqTPqGmyrdCk2idtZEl1C/o6B5mRQzeUNqUVdI0vBOVaPULW0QW1tT+MQN6JMDgXZRJm8lC4+HqXAr13vo8pQy/TbY9XaNCyZOMyUqxGftSWGHRzsZa3RL5lFMGtUufkqPpaP7w22dFYmiYkXI0vtYn7VsUr+5r/y7M0MVnw5GiqDwAJ0ce9QIbjHQ==\",\"platform\": \"yes\"}"
	 * ); //input.setContentType("application/json"); postRequest.setEntity(input);
	 * HttpResponse response = httpClient.execute(postRequest);
	 * 
	 * if (response.getStatusLine().getStatusCode() != 200) { throw new
	 * RuntimeException("Failed : HTTP error code : " +
	 * response.getStatusLine().getStatusCode()); } else { System.out.println(
	 * "Status code is" + response.getStatusLine().getStatusCode() ); }
	 * 
	 * }
	 */

	// String color= "Black";
	// SoftAssert softAssert = new SoftAssert();

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0002")
	@Severity(value = SeverityLevel.BLOCKER)
	@Description("Verify Launching Fiery out Of Box Wizard from a remote client before the Fiery set up")
	@Stories(value = { "Story : User should be able to launch FSW and able to login successfully" })
	@Test(priority = 1)
	public void FSW_0002() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.launchURL("https://" + FSW_URL + "/fsw");
		Assert.assertTrue(this.driver.getTitle().equalsIgnoreCase("Fiery Setup Wizard"),
				"After launching fsw url, Fiery Setup Wizard title is not displaying");
		Assert.assertTrue(loginpageUtils.verifyPSWD(), "Login page of FSW is not asking for Password");
		loginpageUtils.enterPSWD(Password);

		System.out.println("test script FSW_0002 completed");
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0004")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify Next on Language Settings screen")
	@Stories(value = {
			"Story : FSW should have next button in lauguage page, so that User should be able to click and redirect to regional page" })
	@Test(priority = 2)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0004() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		Assert.assertFalse(languagePage.verifyNextBtnLangEnable(),
				"Next button in language tab is enabled before clicking agree button");
		languagePage.clickCheckboxOfAgree();
		Thread.sleep(2000);
		Assert.assertTrue(languagePage.verifyNextBtnLangEnable(),
				"Next button in language tab is not enabled after clicking agree button");
		Thread.sleep(2000);
		languagePage.clickTerms_Cond();
		Thread.sleep(2000);
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));
		Thread.sleep(2000);
		Assert.assertTrue(driver.getTitle().trim().equalsIgnoreCase("EFI software End User license agreement"));
		driver.close();
		Thread.sleep(2000);
		driver.switchTo().window(tabs2.get(0));
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		serverPage.clickNextBtnSer();
		Thread.sleep(5000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clickSkipBtnEnv();
		System.out.println("test script FSW_0004 completed");
	}
	

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0007")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Regional settings defaults per language.")
	@Stories(value = { "Story : Checking the default settings in regional page as per changing the language" })
	@Test(priority = 3)
	// @Parameters({ "FSWURL", "Browser", })
	public void FSW_0007() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		// languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("mm/dd/yyyy"),
				"Default date format for English US is not correct: mm/dd/yyyy is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for English US is not correct: 1,000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit(),
				"Default Measurement Unit for English US is not correct: Inches is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch(),
				"Default Paper size for English US is not correct: Inches is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionNA(),
					"Default Colour region for English US is not correct: North America is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("en_GB");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/yyyy"),
				"Default date format for English International is not correct: dd/mm/yyyy is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for English International is not correct: displays 1,000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for English International is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for English International is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for English International is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("fr_FR");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("jj/mm/aaaa"),
				"Default date format for French is not correct: jj/mm/aaaa is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for French is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for French is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for French is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for French is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("it_IT");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("gg/mm/aaaa"),
				"Default date format for Italian is not correct: gg/mm/aaaa is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Italian is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Italian is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Italian is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Italian is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("de_DE");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("TT/MM/JJJJ"),
				"Default date format for German is not correct: TT/MM/JJJJ is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for German is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for German is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for German is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for German is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("es_ES");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/aaaa"),
				"Default date format for Spanish is not correct: dd/mm/aaaa is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Spanish is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Spanish is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Spanish is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Spanish is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("nl_NL");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/jjjj"),
				"Default date format for Dutch is not correct: dd/mm/jjjj is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Dutch is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Dutch is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Dutch is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Dutch is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("pt_BR");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/aaaa"),
				"Default date format for Portugese is not correct: dd/mm/aaaa is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Portugese is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Portugese is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Portugese is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Portugese is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		/*
		 * if(Colour=="color"){ languagePage.selectOneLang("ja_JP");
		 * languagePage.clickNextBtnLang(); Thread.sleep(5000);
		 * Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase(
		 * "yyyy/mm/dd(年/月/日)"),
		 * "Default date format for Japaniese is not correct: yyyy/mm/dd(年/月/日) is not displaying by default"
		 * ); Assert.assertTrue(regionalPage.verifyNumberformat(),
		 * "Default Number format for Japaniese is not correct: displays 1,000 is not checked by default"
		 * ); Assert.assertTrue(regionalPage.verifyMeasurementInchUnit(),
		 * "Default Measurement Unit for Japaniese is not correct: Inches is not checked by default"
		 * ); Assert.assertTrue(regionalPage.verifyPaperSizeInch(),
		 * "Default Paper size for Japaniese is not correct: Inches is not checked by default"
		 * ); Assert.assertTrue(regionalPage.verifycolorRegionJapan(),
		 * "Default Colour region for Japaniese is not correct: Japan is not checked by default"
		 * ); regionalPage.clickBackBtnReg(); Thread.sleep(3000); }
		 */
		languagePage.selectOneLang("zh_CN");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("yyyy/mm/dd(年/月/日)"),
				"Default date format for Simplified chinese is not correct: yyyy/mm/dd(年/月/日) is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for Simplified chinese is not correct: displays 1,000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Simplified chinese is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Simplified chinese is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Simplified chinese is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("pl_PL");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/rrrr"),
				"Default date format for Polish is not correct: dd/mm/rrrr is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Polish is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Polish is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Polish is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Polish is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("ru_RU");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("дд/мм/гггг"),
				"Default date format for Russian is not correct: дд/мм/гггг is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Russian is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Russian is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Russian is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Russian is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("tr_TR");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("gg/aa/yyyy"),
				"Default date format for Turkice is not correct: gg/aa/yyyy is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Turkice is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Turkice is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Turkice is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Turkice is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("cs_CZ");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/rrrr"),
				"Default date format for czech is not correct: dd/mm/rrrr is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for czech is not correct: displays 1.000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for czech is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for czech is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for czech is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("zh_TW");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("yyyy/mm/dd"),
				"Default date format for Chinese is not correct: yyyy/mm/dd is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for Chinese is not correct: displays 1,000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Chinese is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Chinese is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Chinese is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("ko_KR");
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("yyyy/mm/dd"),
				"Default date format for Korean is not correct: yyyy/mm/dd is not displaying by default");
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for Korean is not correct: displays 1,000 is not checked by default");
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default Measurement Unit for Korean is not correct: Metric is not checked by default");
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Korean is not correct: Metric is not checked by default");
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Korean is not correct: Europe is not checked by default");
		}
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		System.out.println("test script FSW_0007 completed");

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0012")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Next on Regional Settings screen")
	@Stories(value = {
			"Story : FSW should have next button in Regional page, so that User should be able to click and redirect to Server page" })
	@Test(priority = 4)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0012() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		regionalPage.clickNumber_Format1();
		regionalPage.clickPaper_Size1();
		Assert.assertTrue(regionalPage.verifyNextBtnReg(), "Next button is not enabled in Regional Page");
		regionalPage.clickNextBtnReg();
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		Assert.assertTrue(serverpage.getServerElementText().equalsIgnoreCase("Server"),
				"Server page does not displays after clicking next button in Regional Page");

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0017")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Next on Server Settings screen")
	@Stories(value = {
			"Story : FSW should have next button in Server page, so that User should be able to click and redirect to Environment page" })
	@Test(priority = 5)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0017() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		regionalPage.clickNumber_Format1();
		regionalPage.clickPaper_Size1();
		regionalPage.clickNextBtnReg();
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		Assert.assertTrue(serverpage.verifyNextBtnSer(), "Next button is not enabled in Server Page");
		serverpage.clickNextBtnSer();
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		Assert.assertTrue(environmentalPage.getEnvElementText().equalsIgnoreCase("Select your printing environment"),
				"Environment page does not displays after clicking next button in Server Page");
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0133")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify skip customizing printing environment")
	@Stories(value = {
			"Story : User should be able to skip the environmental page with defulat values of all the pages" })
	@Test(priority = 6)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0133() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		ServerName = Server_Name;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		Assert.assertFalse(languagePage.verifyNextBtnLangEnable(),
				"Next button in language tab is enabled before clicking agree button");
		languagePage.clickCheckboxOfAgree();
		Thread.sleep(2000);
		Assert.assertTrue(languagePage.verifyNextBtnLangEnable(),
				"Next button in language tab is not enabled after clicking agree button");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		serverPage.clickNextBtnSer();
		Thread.sleep(5000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		Assert.assertTrue(environmentalPage.checkSkipBtnEnv(), "Skip button is not displayed in environmental page");
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(5000);
		Assert.assertTrue(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close"),
				"Close button is not displayed after cliking skip button in environmental page");
		environmentalPage.clickRestartBtn();
		Thread.sleep(5000);
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		Assert.assertTrue(languagePage.getDefaultLang().equalsIgnoreCase("English US"),
				"Default language is not English");
		languagePage.clickCheckboxOfAgree();
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("mm/dd/yyyy"),
				"Default Date format is not mm/dd/yyyy");
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		System.out.println("Server_Name" + ServerName);
		System.out.println("getserver" + serverPage.getServerName());
		Assert.assertTrue(serverPage.getServerName().equalsIgnoreCase(ServerName),
				"Provided serverName is different than the displaying serverName in FSW server page");
		serverPage.clickNextBtnSer();
		Thread.sleep(5000);
		Assert.assertTrue(environmentalPage.checkSkipBtnEnv(), "Skip button is not displayed in environmental page");
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(5000);
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0013")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify the Server name")
	@Stories(value = { "Story : User should be able to view the serverName in server page as same as machine name" })
	@Test(priority = 7)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0013() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		ServerName = Server_Name;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		Assert.assertFalse(languagePage.verifyNextBtnLangEnable(),
				"Next button in language tab is enabled before clicking agree button");
		languagePage.clickCheckboxOfAgree();
		Thread.sleep(2000);
		Assert.assertTrue(languagePage.verifyNextBtnLangEnable(),
				"Next button in language tab is not enabled after clicking agree button");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		System.out.println("server name from getProductServerName" + serverPage.getServerName());
		Assert.assertTrue(serverPage.getServerName().equalsIgnoreCase(ServerName),
				"Provided serverName is different than the displaying serverName in FSW server page");
		serverPage.clickNextBtnSer();
		Thread.sleep(5000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		Assert.assertTrue(environmentalPage.checkSkipBtnEnv(), "Skip button is not displayed in environmental page");
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(5000);
		// environmentalPage.clickRestartBtn();
		/*
		 * Thread.sleep(5000); loginpageUtils.loginwithunPswd("https://" + FSW_URL +
		 * "/fsw", Password); languagePage.clickCheckboxOfAgree(); Thread.sleep(2000);
		 * languagePage.clickNextBtnLang(); Thread.sleep(5000);
		 * regionalPage.clickNextBtnReg(); Thread.sleep(5000);
		 * Assert.assertTrue(serverPage.getServerName().equalsIgnoreCase (ServerName),
		 * "Provided serverName is different than the displaying serverName in FSW server page"
		 * ); serverPage.clickNextBtnSer(); Thread.sleep(5000);
		 * Assert.assertTrue(environmentalPage.checkSkipBtnEnv(),
		 * "Skip button is not displayed in environmental page");
		 * environmentalPage.clickSkipBtnEnv(); Thread.sleep(5000);
		 */
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0018")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify  Server Personality screen")
	@Stories(value = { "Story : User should be able to view the default tabs displays in environemnt page" })
	@Test(priority = 8)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0018() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			Assert.assertTrue(environmentalPage.verifyGraphics_Arts(),
					"The Graphics Arts & Proofing tab is not displayed in Environment page");
		}
		Assert.assertTrue(environmentalPage.verifyOffice_WorkGroup(),
				"The Office and WorkGroup tab is not displayed in Environment page");
		Assert.assertTrue(environmentalPage.verifyProduction(),
				"The Production tab is not displayed in Environment page");
		Assert.assertTrue(environmentalPage.verifyTransactional(),
				"The Transactional tab is not displayed in Environment page");
		Assert.assertTrue(environmentalPage.checkSkipBtnEnv(), "Skip button is not displayed in Environmental page");
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0105")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Graphic Arts personality  -> attributes displayed to the user.")
	@Stories(value = {
			"Story : Default attributes displays to the user in Graphic Arts & Proofing of Environemnt page" })
	@Test(priority = 9)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0105() throws Exception {

		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			running();
			FSW_URL = FSWURL;
			BrowserName = Browser;
			PassWord = Password;
			LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
			initializeDriver(loginpageUtils.driver);
			loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
			LanguagePage languagePage = new LanguagePage(this.driver, Browser);
			RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
			languagePage.clickCheckboxOfAgree();
			languagePage.selectOneLang("en_US");
			Thread.sleep(2000);
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			regionalPage.clickNextBtnReg();
			Thread.sleep(3000);
			ServerPage serverpage = new ServerPage(this.driver, Browser);
			serverpage.clickNextBtnSer();
			Thread.sleep(3000);
			EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
			Assert.assertTrue(environmentalPage.verifyGraphics_Arts(),
					"The Graphics Arts & Proofing tab is not displayed in Environment page");
			environmentalPage.clickGraphics_Arts();
			environmentalPage.clickNextBtnEnv();
			Thread.sleep(2000);
			Assert.assertTrue(environmentalPage.verifyEnable_Remote_Desktop(),
					"The Enable_Remote_Desktop is not checked by default in the Graphics Arts & Proofing tab of Environment tab");
			Assert.assertTrue(environmentalPage.VerifyEnable_System_Updates(),
					"The Enable_System_Updates is not checked by default in the Graphics Arts & Proofing tab of Environment tab");
			environmentalPage.clickEnable_System_Updates_Manage();
			Thread.sleep(2000);
			/*
			 * Assert.assertTrue(environmentalPage.getEveryday_Enable_Remote_Desktop().
			 * equalsIgnoreCase("Day"),
			 * "Default text of Every day dropdown for the Enable_System_Updates is not 'Day' in the Graphics Arts & Proofing tab of Environment tab"
			 * );
			 * Assert.assertTrue(environmentalPage.getEverydaytime_Enable_Remote_Desktop().
			 * equalsIgnoreCase("3"),
			 * "Default text of Every day time dropdown for the Enable_System_Updates is not '3.00AM' in the Graphics Arts & Proofing tab of Environment tab"
			 * ); Assert.assertTrue(environmentalPage.verifyFSU_Notification(),
			 * "The Fiery System Updates Notification is not checked by default for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab"
			 * ); Assert.assertTrue(environmentalPage.verifyFAU_Notification(),
			 * "The Fiery Application Updates Notification is not checked by default for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab"
			 * );
			 */ Assert.assertFalse(environmentalPage.verifyProxy_Settings(),
					"The Proxy Settings is checked by default for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab");
			environmentalPage.clickCancelEnable_System_Updates();
			Thread.sleep(2000);
			Assert.assertTrue(environmentalPage.verifyEnableAPPE(),
					"The Enable Adobe PDF Print Engine is not checked in the Graphics Arts & Proofing tab of Environment tab");
			Assert.assertFalse(environmentalPage.verifyPdfToAPPE(),
					"Always route PDF jobs to APPE is not checked by default in the Graphics Arts & Proofing tab of Environment tab");
		} else {

			System.out.println("this feature is not supported in Black/White server");

		}

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0075")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Production personality  -> attributes  Which the implicitly set.")
	@Stories(value = { "Story : Implicitly set default attributes in Production of Environemnt page" })
	@Test(priority = 12)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0075() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		WebTools_URL = WebToolsURL;
		WT_UserName = WTUserName;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clickprodunbtn();
		environmentalPage.clickNextBtnEnv();
		Thread.sleep(2000);
		environmentalPage.clickFinishBtn();
		Thread.sleep(3000);
		loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickCharacter_Set(); Thread.sleep(2000);
		 * 
		 * Assert.assertTrue(loginpageUtils.getTextUse_Character_Set().equalsIgnoreCase(
		 * "Macintosh"),
		 * "Default User Character set is not Macintosh in configure of webtools");
		 * 
		 * Thread.sleep(2000); loginpageUtils.clickCancelCharacter_Set();
		 * Thread.sleep(2000); if(Colour==0){
		 * Assert.assertFalse(loginpageUtils.verifyPrint_Start_Page(),
		 * "Print Start Page is enabled by default in Fiery Server tab of webtools configure"
		 * ); }
		 * 
		 * else{ Assert.assertTrue(loginpageUtils.verifyPrint_Start_Page(),
		 * "Print Start Page is not enabled by default in Fiery Server tab of webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickScanTab(); Thread.sleep(5000);
		 * Assert.assertTrue(loginpageUtils.getTextFileFormat().equalsIgnoreCase("PDF"),
		 * "Default File format is not PDF in Scan tab of webtools configure");
		 * Thread.sleep(2000); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
		 * equalsIgnoreCase("After 1 day"),
		 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools"); }
		 * else{ Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
		 * equalsIgnoreCase("After 1 week"),
		 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools");
		 * 
		 * }
		 */
		Thread.sleep(2000);
		loginpageUtils.clickSecurityTab();
		Thread.sleep(3000);
		loginpageUtils.clickSecureErase();
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifySecureErase(),
				"Secure Erase is enabled by default in Security tab of webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelSecureErase();
		Thread.sleep(2000);
		loginpageUtils.clickIPFiltering();
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifyIPV4(),
				"IPV4 Address Filtering is enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifyIPV6(),
				"IPV6 Address Filtering is enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelIPFiltering();
		Thread.sleep(2000);
		loginpageUtils.clickPortFiltering();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyPort_Filtering(),
				"TCP/IP Port Filtering is not enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelPortFiltering();
		Thread.sleep(2000);
		loginpageUtils.clickJobManagement();
		Thread.sleep(3000);
		Assert.assertTrue(loginpageUtils.verifyRIPWhileReceive(),
				"Enable Rip While Receive is not enabled by default in Jobmanagement tab of Webtools configure");
		Thread.sleep(2000);

		loginpageUtils.clickJobSubmission();
		Thread.sleep(3000);
		loginpageUtils.clickWSD();
		Thread.sleep(10000);
		Assert.assertTrue(loginpageUtils.verifyWSD(), "WSD is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getWSDQueue().equalsIgnoreCase("print"),
				"WSD is not Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelWSD();
		Thread.sleep(2000);
		loginpageUtils.clickFTPPrinting();
		Thread.sleep(2000);
		/*
		 * Assert.assertFalse(loginpageUtils.verifyFTPPrinting(),
		 * "FTP Printing is enabled in JobSubmission tab of Webtools configure");
		 * Thread.sleep(2000);
		 */
		Assert.assertTrue(loginpageUtils.getFTPQueue().equalsIgnoreCase("print"),
				"FTP Printing Queue is not Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCanceFTP();
		Thread.sleep(2000);
		loginpageUtils.clickPort9100();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyPort9100(),
				"Port 9100 is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getPort9100Queue().equalsIgnoreCase("print"),
				"Port 9100 Queue is Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelPort9100();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyIPP(), "IPP is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickUSB(); Thread.sleep(2000); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.verifyEnableUSBPort(),
		 * "Enable USB Port is not enabled by default in JobSubmission tab of Webtools configure"
		 * ); } else{ Assert.assertFalse(loginpageUtils.verifyEnableUSBPort(),
		 * "Enable USB Port is  enabled by default in JobSubmission tab of Webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickCancelUSB();
		 */
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyHotFolder(),
				"Fiery Hot Folders is not enabled by default in JobSubmission tab of webtools configure");
		/*
		 * loginpageUtils.clickJDFSettings(); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.verifyJDFSettings(),
		 * "JDF Settings is not enabled by default in JobSubmission tab of webtools configure"
		 * ); } else{ Assert.assertFalse(loginpageUtils.verifyJDFSettings(),
		 * "JDF Settings is enabled by default in JobSubmission tab of webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickCancelJDFSettings();
		 */
		Thread.sleep(2000);
		loginpageUtils.clickLPD();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyLPD(), "LPD is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getQueueLPD().equalsIgnoreCase("print"),
				"Queue is not Print Queue in LPD of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelLPD();
		Thread.sleep(2000);
		loginpageUtils.clickWindowsPrinting();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyWindowsSMB(),
				"Windows SMB Printing is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelWindowsPrinting();
		Thread.sleep(2000);
		loginpageUtils.clickNetwork();
		Thread.sleep(3000);
		loginpageUtils.clickEthernetSpeed();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyEthernetSpeed().equalsIgnoreCase("auto"),
				"Ethernet Speed is not Auto (10/100/1000) in Network tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelEthernetSpeed();
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickAppleTalk(); Thread.sleep(2000);
		 * Assert.assertFalse(loginpageUtils.verifyAppleTalk(),
		 * "Enable AppleTalk is enabled by deafult in Network tab of Webtools configure"
		 * ); Thread.sleep(2000); loginpageUtils.clickCancelAppleTalk();
		 * Thread.sleep(2000);
		 */
		loginpageUtils.clickSLP();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifySLP(), "SLP is not enabled in Network tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelSLP();
		Thread.sleep(2000);
		loginpageUtils.clickBonjour();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyBonjour(),
				"Bonjour is not enabled in Network tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getTextBonjour().equalsIgnoreCase("LPD"),
				"The Preferred printing protocol is not LPD by default of Network tab in Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelBonjour();

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0047")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify transactional personality  -> attributes  Which the implicitly set.")
	@Stories(value = { "Story : Implicitly set default attributes in transactional of Environemnt page" })
	@Test(priority = 13)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0047() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		WebTools_URL = WebToolsURL;
		WT_UserName = WTUserName;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clicktransactnbutton();
		environmentalPage.clickNextBtnEnv();
		Thread.sleep(2000);
		environmentalPage.clickFinishBtn();
		Thread.sleep(3000);
		loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickCharacter_Set(); Thread.sleep(2000);
		 * 
		 * 
		 * Assert.assertTrue(loginpageUtils.getTextUse_Character_Set().equalsIgnoreCase(
		 * "Macintosh"),
		 * "Default User Character set is not Windows in configure of webtools");
		 * 
		 * Thread.sleep(2000); loginpageUtils.clickCancelCharacter_Set();
		 * Thread.sleep(2000);
		 * 
		 * Assert.assertFalse(loginpageUtils.verifyPrint_Start_Page(),
		 * "Print Start Page is enabled by default in Fiery Server tab of webtools configure"
		 * );
		 * 
		 * Thread.sleep(2000); loginpageUtils.clickScanTab(); Thread.sleep(5000);
		 * Assert.assertTrue(loginpageUtils.getTextFileFormat().equalsIgnoreCase("PDF"),
		 * "Default File format is not PDF in Scan tab of webtools configure");
		 * Thread.sleep(2000); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
		 * equalsIgnoreCase("After 1 day"),
		 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools"); }
		 * else{ Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
		 * equalsIgnoreCase("After 1 week"),
		 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools");
		 * 
		 * }
		 */ Thread.sleep(2000);
		loginpageUtils.clickSecurityTab();
		Thread.sleep(3000);
		loginpageUtils.clickSecureErase();
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifySecureErase(),
				"Secure Erase is enabled by default in Security tab of webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelSecureErase();
		Thread.sleep(2000);
		loginpageUtils.clickIPFiltering();
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifyIPV4(),
				"IPV4 Address Filtering is enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifyIPV6(),
				"IPV6 Address Filtering is enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelIPFiltering();
		Thread.sleep(2000);
		loginpageUtils.clickPortFiltering();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyPort_Filtering(),
				"TCP/IP Port Filtering is not enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelPortFiltering();
		Thread.sleep(2000);
		loginpageUtils.clickJobManagement();
		Thread.sleep(3000);
		Assert.assertTrue(loginpageUtils.verifyRIPWhileReceive(),
				"Enable Rip While Receive is not enabled by default in Jobmanagement tab of Webtools configure");
		Thread.sleep(2000);

		loginpageUtils.clickJobSubmission();
		Thread.sleep(3000);
		loginpageUtils.clickWSD();
		Thread.sleep(10000);
		Assert.assertTrue(loginpageUtils.verifyWSD(), "WSD is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getWSDQueue().equalsIgnoreCase("print"),
				"WSD is not Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelWSD();
		Thread.sleep(2000);
		loginpageUtils.clickFTPPrinting();
		Thread.sleep(2000);
		/*
		 * Assert.assertFalse(loginpageUtils.verifyFTPPrinting(),
		 * "FTP Printing is enabled in JobSubmission tab of Webtools configure");
		 */
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getFTPQueue().equalsIgnoreCase("print"),
				"FTP Printing Queue is not Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCanceFTP();
		Thread.sleep(2000);
		loginpageUtils.clickPort9100();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyPort9100(),
				"Port 9100 is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getPort9100Queue().equalsIgnoreCase("print"),
				"Port 9100 Queue is Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelPort9100();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyIPP(), "IPP is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickUSB(); Thread.sleep(2000); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.verifyEnableUSBPort(),
		 * "Enable USB Port is not enabled by default in JobSubmission tab of Webtools configure"
		 * ); } else{ Assert.assertFalse(loginpageUtils.verifyEnableUSBPort(),
		 * "Enable USB Port is  enabled by default in JobSubmission tab of Webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickCancelUSB();
		 */
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyHotFolder(),
				"Fiery Hot Folders is not enabled by default in JobSubmission tab of webtools configure");
		/*
		 * loginpageUtils.clickJDFSettings(); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.verifyJDFSettings(),
		 * "JDF Settings is not enabled by default in JobSubmission tab of webtools configure"
		 * ); } else{ Assert.assertFalse(loginpageUtils.verifyJDFSettings(),
		 * "JDF Settings is enabled by default in JobSubmission tab of webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickCancelJDFSettings();
		 */
		Thread.sleep(2000);
		loginpageUtils.clickLPD();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyLPD(), "LPD is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getQueueLPD().equalsIgnoreCase("print"),
				"Queue is not Print Queue in LPD of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelLPD();
		Thread.sleep(2000);
		loginpageUtils.clickWindowsPrinting();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyWindowsSMB(),
				"Windows SMB Printing is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelWindowsPrinting();
		Thread.sleep(2000);
		loginpageUtils.clickNetwork();
		Thread.sleep(3000);
		loginpageUtils.clickEthernetSpeed();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyEthernetSpeed().equalsIgnoreCase("auto"),
				"Ethernet Speed is not Auto (10/100/1000) in Network tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelEthernetSpeed();
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickAppleTalk(); Thread.sleep(2000);
		 * Assert.assertFalse(loginpageUtils.verifyAppleTalk(),
		 * "Enable AppleTalk is enabled by deafult in Network tab of Webtools configure"
		 * ); Thread.sleep(2000); loginpageUtils.clickCancelAppleTalk();
		 * Thread.sleep(2000);
		 */
		loginpageUtils.clickSLP();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifySLP(), "SLP is not enabled in Network tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelSLP();
		Thread.sleep(2000);
		loginpageUtils.clickBonjour();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyBonjour(),
				"Bonjour is not enabled in Network tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getTextBonjour().equalsIgnoreCase("LPD"),
				"The Preferred printing protocol is not LPD by default of Network tab in Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelBonjour();

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0022")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Office Personality -> attributes  Which the implicitly set.")
	@Stories(value = {
			"Story : Implicitly set default attributes in Office and Work group Personality of Environemnt page" })
	@Test(priority = 10)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0022() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		WebTools_URL = WebToolsURL;
		WT_UserName = WTUserName;
		Bonjour_Service_Name = BonjourServiceName;

		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.checkofficebtn();
		environmentalPage.clickNextBtnEnv();
		Thread.sleep(2000);
		loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickCharacter_Set(); Thread.sleep(2000);
		 * 
		 * 
		 * 
		 * Assert.assertTrue(loginpageUtils.getTextUse_Character_Set().equalsIgnoreCase(
		 * "Macintosh"),
		 * "Default User Character set is not Windows in configure of webtools");
		 * 
		 * Thread.sleep(2000); loginpageUtils.clickCancelCharacter_Set();
		 * Thread.sleep(2000); if(Colour==0){
		 * Assert.assertFalse(loginpageUtils.verifyPrint_Start_Page(),
		 * "Print Start Page is enabled by default in Fiery Server tab of webtools configure"
		 * ); }
		 * 
		 * else{ Assert.assertTrue(loginpageUtils.verifyPrint_Start_Page(),
		 * "Print Start Page is not enabled by default in Fiery Server tab of webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickScanTab(); Thread.sleep(5000);
		 * Assert.assertTrue(loginpageUtils.getTextFileFormat().equalsIgnoreCase("PDF"),
		 * "Default File format is not PDF in Scan tab of webtools configure");
		 * Thread.sleep(2000); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
		 * equalsIgnoreCase("After 1 day"),
		 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools"); }
		 * else{ Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
		 * equalsIgnoreCase("After 1 week"),
		 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools");
		 * 
		 * }
		 */
		Thread.sleep(2000);
		loginpageUtils.clickSecurityTab();
		Thread.sleep(3000);
		loginpageUtils.clickSecureErase();
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifySecureErase(),
				"Secure Erase is enabled by default in Security tab of webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelSecureErase();
		Thread.sleep(2000);
		loginpageUtils.clickIPFiltering();
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifyIPV4(),
				"IPV4 Address Filtering is enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertFalse(loginpageUtils.verifyIPV6(),
				"IPV6 Address Filtering is enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelIPFiltering();
		Thread.sleep(2000);
		loginpageUtils.clickPortFiltering();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyPort_Filtering(),
				"TCP/IP Port Filtering is not enabled by default in Security tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelPortFiltering();
		Thread.sleep(2000);
		loginpageUtils.clickJobManagement();
		Thread.sleep(3000);
		Assert.assertTrue(loginpageUtils.verifyRIPWhileReceive(),
				"Enable Rip While Receive is not enabled by default in Jobmanagement tab of Webtools configure");
		Thread.sleep(2000);

		loginpageUtils.clickJobSubmission();
		Thread.sleep(3000);
		loginpageUtils.clickWSD();
		Thread.sleep(10000);
		Assert.assertTrue(loginpageUtils.verifyWSD(), "WSD is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getWSDQueue().equalsIgnoreCase("print"),
				"WSD is not Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelWSD();
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickFTPPrinting(); Thread.sleep(2000);
		 * Assert.assertFalse(loginpageUtils.verifyFTPPrinting(),
		 * "FTP Printing is enabled in JobSubmission tab of Webtools configure");
		 * Thread.sleep(2000);
		 * Assert.assertTrue(loginpageUtils.getFTPQueue().equalsIgnoreCase("print"),
		 * "FTP Printing Queue is not Print Queue of JobSubmission tab of Webtools configure"
		 * ); Thread.sleep(2000); loginpageUtils.clickCanceFTP(); Thread.sleep(2000);
		 */
		loginpageUtils.clickPort9100();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyPort9100(),
				"Port 9100 is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getPort9100Queue().equalsIgnoreCase("print"),
				"Port 9100 Queue is Print Queue of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelPort9100();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyIPP(), "IPP is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickUSB(); Thread.sleep(2000); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.verifyEnableUSBPort(),
		 * "Enable USB Port is not enabled by default in JobSubmission tab of Webtools configure"
		 * ); } else{ Assert.assertFalse(loginpageUtils.verifyEnableUSBPort(),
		 * "Enable USB Port is  enabled by default in JobSubmission tab of Webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickCancelUSB();
		 */
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyHotFolder(),
				"Fiery Hot Folders is not enabled by default in JobSubmission tab of webtools configure");
		/*
		 * loginpageUtils.clickJDFSettings(); if(Colour==0){
		 * Assert.assertTrue(loginpageUtils.verifyJDFSettings(),
		 * "JDF Settings is not enabled by default in JobSubmission tab of webtools configure"
		 * ); } else{ Assert.assertFalse(loginpageUtils.verifyJDFSettings(),
		 * "JDF Settings is enabled by default in JobSubmission tab of webtools configure"
		 * ); } Thread.sleep(2000); loginpageUtils.clickCancelJDFSettings();
		 */
		Thread.sleep(2000);
		loginpageUtils.clickLPD();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyLPD(), "LPD is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getQueueLPD().equalsIgnoreCase("print"),
				"Queue is not Print Queue in LPD of JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelLPD();
		Thread.sleep(2000);
		loginpageUtils.clickWindowsPrinting();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyWindowsSMB(),
				"Windows SMB Printing is not enabled in JobSubmission tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelWindowsPrinting();
		Thread.sleep(2000);
		loginpageUtils.clickNetwork();
		Thread.sleep(3000);
		loginpageUtils.clickEthernetSpeed();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyEthernetSpeed().equalsIgnoreCase("auto"),
				"Ethernet Speed is not Auto (10/100/1000) in Network tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelEthernetSpeed();
		Thread.sleep(2000);
		/*
		 * loginpageUtils.clickAppleTalk(); Thread.sleep(2000);
		 * Assert.assertFalse(loginpageUtils.verifyAppleTalk(),
		 * "Enable AppleTalk is enabled by deafult in Network tab of Webtools configure"
		 * ); Thread.sleep(2000); loginpageUtils.clickCancelAppleTalk();
		 * Thread.sleep(2000);
		 */
		loginpageUtils.clickSLP();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifySLP(), "SLP is not enabled in Network tab of Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelSLP();
		Thread.sleep(2000);
		loginpageUtils.clickBonjour();
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.verifyBonjour(),
				"Bonjour is not enabled in Network tab of Webtools configure");
		Thread.sleep(2000);
		Assert.assertTrue(loginpageUtils.getTextBonjour().equalsIgnoreCase("LPD"),
				"The Preferred printing protocol is not LPD by default of Network tab in Webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelBonjour();

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0106")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Graphic Arts  personality  -> attributes  Which the implicitly set.")
	@Stories(value = { "Story : Implicitly set default attributes in Graphic Arts & Proofing of Environemnt page" })
	@Test(priority = 11)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0106() throws Exception {

		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			running();
			FSW_URL = FSWURL;
			BrowserName = Browser;
			PassWord = Password;
			WebTools_URL = WebToolsURL;
			WT_UserName = WTUserName;
			Bonjour_Service_Name = BonjourServiceName;
			LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
			initializeDriver(loginpageUtils.driver);
			loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
			LanguagePage languagePage = new LanguagePage(this.driver, Browser);
			RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
			languagePage.clickCheckboxOfAgree();
			languagePage.selectOneLang("en_US");
			Thread.sleep(2000);
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			regionalPage.clickNextBtnReg();
			Thread.sleep(3000);
			ServerPage serverpage = new ServerPage(this.driver, Browser);
			serverpage.clickNextBtnSer();
			Thread.sleep(3000);
			EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
			environmentalPage.clickGraphics_Arts();
			environmentalPage.clickNextBtnEnv();
			Thread.sleep(2000);
			loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
			Thread.sleep(2000);
			/*
			 * loginpageUtils.clickCharacter_Set(); Thread.sleep(2000);
			 * 
			 * 
			 * Assert.assertTrue(loginpageUtils.getTextUse_Character_Set().equalsIgnoreCase(
			 * "Macintosh"),
			 * "Default User Character set is not Windows in configure of webtools");
			 * 
			 * Thread.sleep(2000); loginpageUtils.clickCancelCharacter_Set();
			 * Thread.sleep(2000); if(Colour==0){
			 * Assert.assertFalse(loginpageUtils.verifyPrint_Start_Page(),
			 * "Print Start Page is enabled by default in Fiery Server tab of webtools configure"
			 * ); }
			 * 
			 * else{ Assert.assertTrue(loginpageUtils.verifyPrint_Start_Page(),
			 * "Print Start Page is not enabled by default in Fiery Server tab of webtools configure"
			 * ); }
			 */
			Thread.sleep(2000);
			/*
			 * loginpageUtils.clickScanTab(); Thread.sleep(5000);
			 * Assert.assertTrue(loginpageUtils.getTextFileFormat().equalsIgnoreCase("PDF"),
			 * "Default File format is not PDF in Scan tab of webtools configure");
			 * Thread.sleep(2000); if(Colour==0){
			 * Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
			 * equalsIgnoreCase("After 1 day"),
			 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools"); }
			 * else{ Assert.assertTrue(loginpageUtils.getValueCleanUpFrequency().
			 * equalsIgnoreCase("After 1 week"),
			 * "Default CleanUpFrequency is not 'After 1 week' in configure of webtools");
			 * 
			 * }
			 */
			Thread.sleep(2000);
			loginpageUtils.clickSecurityTab();
			Thread.sleep(3000);
			loginpageUtils.clickSecureErase();
			Thread.sleep(2000);
			Assert.assertFalse(loginpageUtils.verifySecureErase(),
					"Secure Erase is enabled by default in Security tab of webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelSecureErase();
			Thread.sleep(2000);
			loginpageUtils.clickIPFiltering();
			Thread.sleep(2000);
			Assert.assertFalse(loginpageUtils.verifyIPV4(),
					"IPV4 Address Filtering is enabled by default in Security tab of Webtools configure");
			Thread.sleep(2000);
			Assert.assertFalse(loginpageUtils.verifyIPV6(),
					"IPV6 Address Filtering is enabled by default in Security tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelIPFiltering();
			Thread.sleep(2000);
			loginpageUtils.clickPortFiltering();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyPort_Filtering(),
					"TCP/IP Port Filtering is not enabled by default in Security tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelPortFiltering();
			Thread.sleep(2000);
			loginpageUtils.clickJobManagement();
			Thread.sleep(3000);
			Assert.assertTrue(loginpageUtils.verifyRIPWhileReceive(),
					"Enable Rip While Receive is not enabled by default in Jobmanagement tab of Webtools configure");
			Thread.sleep(2000);

			loginpageUtils.clickJobSubmission();
			Thread.sleep(3000);
			loginpageUtils.clickWSD();
			Thread.sleep(10000);
			Assert.assertTrue(loginpageUtils.verifyWSD(),
					"WSD is not enabled in JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.getWSDQueue().equalsIgnoreCase("print"),
					"WSD is not Print Queue of JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelWSD();
			Thread.sleep(2000);
			loginpageUtils.clickFTPPrinting();
			Thread.sleep(2000);
			Assert.assertFalse(loginpageUtils.verifyFTPPrinting(),
					"FTP Printing is enabled in JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.getFTPQueue().equalsIgnoreCase("print"),
					"FTP Printing Queue is not Print Queue of JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCanceFTP();
			Thread.sleep(2000);
			loginpageUtils.clickPort9100();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyPort9100(),
					"Port 9100 is not enabled in JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.getPort9100Queue().equalsIgnoreCase("print"),
					"Port 9100 Queue is Print Queue of JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelPort9100();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyIPP(),
					"IPP is not enabled in JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			/*
			 * loginpageUtils.clickUSB(); Thread.sleep(2000); if(Colour==0){
			 * Assert.assertTrue(loginpageUtils.verifyEnableUSBPort(),
			 * "Enable USB Port is not enabled by default in JobSubmission tab of Webtools configure"
			 * ); } else{ Assert.assertFalse(loginpageUtils.verifyEnableUSBPort(),
			 * "Enable USB Port is  enabled by default in JobSubmission tab of Webtools configure"
			 * ); } Thread.sleep(2000); loginpageUtils.clickCancelUSB();
			 */
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyHotFolder(),
					"Fiery Hot Folders is not enabled by default in JobSubmission tab of webtools configure");
			/*
			 * loginpageUtils.clickJDFSettings(); if(Colour==0){
			 * Assert.assertTrue(loginpageUtils.verifyJDFSettings(),
			 * "JDF Settings is not enabled by default in JobSubmission tab of webtools configure"
			 * ); } else{ Assert.assertFalse(loginpageUtils.verifyJDFSettings(),
			 * "JDF Settings is enabled by default in JobSubmission tab of webtools configure"
			 * ); } Thread.sleep(2000); loginpageUtils.clickCancelJDFSettings();
			 */
			Thread.sleep(2000);
			loginpageUtils.clickLPD();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyLPD(),
					"LPD is not enabled in JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.getQueueLPD().equalsIgnoreCase("print"),
					"Queue is not Print Queue in LPD of JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelLPD();
			Thread.sleep(2000);
			loginpageUtils.clickWindowsPrinting();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyWindowsSMB(),
					"Windows SMB Printing is not enabled in JobSubmission tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelWindowsPrinting();
			Thread.sleep(2000);
			loginpageUtils.clickNetwork();
			Thread.sleep(3000);
			loginpageUtils.clickEthernetSpeed();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyEthernetSpeed().equalsIgnoreCase("auto"),
					"Ethernet Speed is not Auto (10/100/1000) in Network tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelEthernetSpeed();
			Thread.sleep(2000);
			/*
			 * loginpageUtils.clickAppleTalk(); Thread.sleep(2000);
			 * Assert.assertFalse(loginpageUtils.verifyAppleTalk(),
			 * "Enable AppleTalk is enabled by deafult in Network tab of Webtools configure"
			 * ); Thread.sleep(2000); loginpageUtils.clickCancelAppleTalk();
			 * Thread.sleep(2000);
			 */
			loginpageUtils.clickSLP();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifySLP(), "SLP is not enabled in Network tab of Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelSLP();
			Thread.sleep(2000);
			loginpageUtils.clickBonjour();
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.verifyBonjour(),
					"Bonjour is not enabled in Network tab of Webtools configure");
			Thread.sleep(2000);
			Assert.assertTrue(loginpageUtils.getTextBonjour().equalsIgnoreCase("LPD"),
					"The Preferred printing protocol is not LPD by default of Network tab in Webtools configure");
			Thread.sleep(2000);
			loginpageUtils.clickCancelBonjour();
		} else {

			System.out.println("this feature is not supported in Black/White server");

		}

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0074")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify Production personality  -> attributes displayed to the user.")
	@Stories(value = {
			"Story : Default attributes displays to the user in Production personality of Environemnt page" })
	@Test(priority = 14)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0074() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		regionalPage.clickNextBtnReg();
		serverPage.clickNextBtnSer();
		environmentalPage.clickprodunbtn();
		environmentalPage.clickNextBtnEnv();
		Assert.assertTrue(environmentalPage.check_Prod_PrintQueue(),
				"  print queue is enabled in production   tab of Environment tab ");
		/*
		 * environmentalPage.click_prod_sampleprint(); Thread.sleep(10000);
		 */
		/*
		 * Assert.assertTrue(environmentalPage.check_Prod_ondemand(),
		 * "   ondemand is enabled in production   tab of Environment  tab of Environment tab "
		 * ); Assert.assertTrue(environmentalPage.check_Prod_sheet(),
		 * "  Sheet (for any kind of job) is enabled in production   tab of Environment  tab of Environment tab "
		 * );
		 * Assert.assertTrue(environmentalPage.output_try().equalsIgnoreCase("Disabled")
		 * ,
		 * "Default text of Output Try dropdown for the Sample print is not Disabled  in production   tab  of Environment tab"
		 * ); environmentalPage.click_prod_sampleprintcancel();
		 */
		environmentalPage.click_prod_jobmismatch();
		environmentalPage.click_prod_jobmismatch_manage();
		/*
		 * Assert.assertTrue(environmentalPage.click_prod_jobmismatch_missmatch().
		 * equalsIgnoreCase("Cancel"),
		 * "Default text of Output Try dropdown for the Sample print is not Disabled  in production   tab  of Environment tab"
		 * );
		 */
		Assert.assertTrue(environmentalPage.click_prod_jobmismatch_time().equalsIgnoreCase("5"),
				"Default text of Output Try dropdown for the Sample print is Disabled  in production   tab  of Environment tab");
		environmentalPage.click_prod_systemupdatemanagecancel();
		Thread.sleep(2000);

		Assert.assertTrue(environmentalPage.check_prod_systemupdate(),
				" System update is enabled in production   tab  of Environment tab ");
		Thread.sleep(2000);
		environmentalPage.click_prod_systemupdatemanage();
		/*
		 * Assert.assertTrue(environmentalPage.verify_prod_system_Day().equalsIgnoreCase
		 * ("Day"),
		 * "Default text of Every day dropdown for the Enable_System_Updates is not 'Day'  the in production   tab  of Environment tab"
		 * ); Assert.assertTrue(environmentalPage.verify_prod_system_Time().
		 * equalsIgnoreCase("3"),
		 * "Default text of Every day time dropdown for the Enable_System_Updates is not '3.00AM' in production   tab  of Environment tab"
		 * ); Thread.sleep(2000);
		 * Assert.assertTrue(environmentalPage.verify_prod_Fiery_systeupdate(),
		 * "  Send notification when updates are available  button  is enabled in the in production   tab  of Environment tab "
		 * ); Assert.assertTrue(environmentalPage.verify_prod_Fiery_app_update(),
		 * "  Send notification when updates are available. button is enabled in production   tab  of Environment tab"
		 * );
		 */
		Assert.assertFalse(environmentalPage.enable_prod_proxy(),
				"  Proxy   button  should be disabled in production   tab  of Environment tab");
		environmentalPage.getsystemupdatecancel();

		/*
		 * Assert.assertFalse(environmentalPage.enable_prod_sequentialprint(),
		 * "  Sequential print button  is enabled in production   tab  of Environment tab"
		 * );
		 */

		Assert.assertFalse(environmentalPage.enable_prod_setpagedevice(),
				"  Set page device is enabled in production   tab  of Environment tab ");
		/*
		 * if(Colour==0){ Assert.assertTrue(environmentalPage.enable_prod_jdf(),
		 * "  Enable jdf button is not enabled in production   tab  of Environment tab"
		 * ); } else{ Assert.assertFalse(environmentalPage.enable_prod_jdf(),
		 * "  Enable jdf button is not enabled in production   tab  of Environment tab"
		 * ); }
		 */

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0046")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify transactional personality  -> attributes displayed to the user")
	@Stories(value = {
			"Story : Default attributes displays to the user in transactional personality of Environemnt page" })
	@Test(priority = 15)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0046() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		regionalPage.clickNextBtnReg();
		serverPage.clickNextBtnSer();
		environmentalPage.clicktransactnbutton();
		environmentalPage.clickNextBtnEnv();
		Assert.assertTrue(environmentalPage.checkRipButton(),
				"Enable Rip While Receive button is selected in the transaction and personality  tab of Environment tab");
		Assert.assertTrue(environmentalPage.checkPrintQueue(),
				"printqueue is  button selected in the transaction and personality   tab of Environment tab ");
		Assert.assertFalse(environmentalPage.checkJobMismatch(),
				"job mismatch is  button should not  selected in the transaction and personality  tab of Environment tab");
		Assert.assertTrue(environmentalPage.checkEnableRemote(),
				"enable remote desktop  is  button should not selected in the transaction and personality  tab of Environment tab ");
		environmentalPage.clickAutomanage();
		Thread.sleep(2000);
		Assert.assertFalse(environmentalPage.clickEnableAutomanage(),
				" auto manage  is  button should not selected in the transaction and personality   tab of Environment tab ");
		environmentalPage.clickok();
		Thread.sleep(2000);
		/*
		 * if(Colour==0){ Assert.assertFalse(environmentalPage.check_Set_page(),
		 * " set page is  button should not selected  in the transaction and personality  tab of Environment tab"
		 * ); } else{ Assert.assertTrue(environmentalPage.check_Set_page(),
		 * " set page is  button should not selected  in the transaction and personality  tab of Environment tab"
		 * );
		 * 
		 * }
		 */
		Assert.assertFalse(environmentalPage.check_Sequential(),
				" sequential   button should not selected in the transaction and personality  tab of Environment tab ");
		Assert.assertTrue(environmentalPage.checksystemupdate(),
				"system update   is  button  selected in the transaction and personality  tab of Environment tab ");
		environmentalPage.checksystemupdate();
		environmentalPage.clicksystemupdatemanage();
		/*
		 * Assert.assertTrue(environmentalPage.verifysystem_Day1().equalsIgnoreCase(
		 * "Day"),
		 * "Default text of Every day dropdown for the Enable_System_Updates is not 'Day' in the office and workgroup tab of Environment tab"
		 * );
		 * Assert.assertTrue(environmentalPage.verifysystem_Time2().equalsIgnoreCase("3"
		 * ),
		 * "Default text of Every day time dropdown for the Enable_System_Updates is not '3.00AM' in the transaction and personality  tab of Environment tab"
		 * ); Thread.sleep(2000);
		 * Assert.assertTrue(environmentalPage.verifyFiery_systeupdate11(),
		 * "  Send notification when updates are available  button  is enabled in the in the transaction and personality  tab of Environment tab "
		 * ); Assert.assertTrue(environmentalPage.verifyFiery_app_update11(),
		 * "  Send notification when updates are available. button is enabled in the transaction and personality  tab of Environment tab"
		 * ); Thread.sleep(2000); Assert.assertFalse(environmentalPage.enable_proxy(),
		 * " verify enable proxy  button is enabled in the transaction and personality   tab of Environment tab"
		 * ); environmentalPage.getsystemupdatecancel();
		 */

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0021")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify Office Personality -> attributes displayed to the user.")
	@Stories(value = {
			"Story : Default attributes displays to the user in Office&Workgroup personality of Environemnt page" })
	@Test(priority = 16)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0021() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		regionalPage.clickNextBtnReg();
		serverPage.clickNextBtnSer();
		environmentalPage.checkofficebtn();
		environmentalPage.clickNextBtnEnv();
		Assert.assertTrue(environmentalPage.checkFhotfolder(),
				" Hot Folders checkbox is enabled in the office and workgroup tab of Environment tab");

		Assert.assertTrue(environmentalPage.checkremotedesk(),
				" remote desktop checkbox is enabled in the office and workgroup tab of Environment tab");
		Assert.assertTrue(environmentalPage.checkenableprintq(),
				" printed queue checkbox is enabled in the office and workgroup tab of Environment tab");
		Assert.assertFalse(environmentalPage.checksecureerase(),
				" Secure Erase checkbox is enabled in the office and workgroup tab of Environment tab");
		Assert.assertTrue(environmentalPage.checkprintwithoutauth(),
				" Allow users to print without authentication checkbox is enabled in the office and workgroup tab of Environment tab");
		/*
		 * if(Colour==0){ Assert.assertTrue(environmentalPage.checkusbport(),
		 * " USB port  checkbox is not enabled in the office and workgroup tab of Environment tab"
		 * ); } else{ Assert.assertFalse(environmentalPage.checkusbport(),
		 * " USB port  checkbox is enabled in the office and workgroup tab of Environment tab"
		 * );
		 * 
		 * }
		 */
		environmentalPage.checkldap();
		environmentalPage.checkldapmange();
		/*
		 * Assert.assertTrue(environmentalPage.checkscanning(),
		 * " Scanning   checkbox is enabled in the office and workgroup tab of Environment tab"
		 * );
		 */
		Assert.assertTrue(environmentalPage.checksnmp(),
				" Snmp checkbox is enabled in the office and workgroup tab of Environment tab");
		environmentalPage.checksnmpmange();
		Assert.assertTrue(environmentalPage.getSNMPmangeSecurity().equalsIgnoreCase("Medium"),
				"Security level of SNMP is not medium in the office and workgroup tab of Environment tab");
		Thread.sleep(2000);
		environmentalPage.snmpmangeCancel();
		environmentalPage.checksystemupdate();
		environmentalPage.clicksystemupdatemanage();

		Assert.assertTrue(environmentalPage.getsystemupdate(),
				" system update checkbox is enabled in the office and workgroup tab of Environment tab");

		/*
		 * Assert.assertTrue(environmentalPage.verifysystem_Day().equalsIgnoreCase("Day"
		 * ),
		 * "Default text of Every day dropdown for the Enable_System_Updates is not 'Day' in the office and workgroup tab of Environment tab in the office and workgroup tab of Environment tab"
		 * );
		 * Assert.assertTrue(environmentalPage.verifysystem_Time().equalsIgnoreCase("3")
		 * ,
		 * "Default text of Every day time dropdown for the Enable_System_Updates is not '3.00AM' in the office and workgroup  tab of Environment tab in the office and workgroup tab of Environment tab"
		 * ); Thread.sleep(2000);
		 * Assert.assertTrue(environmentalPage.verifyFiery_systeupdate(),
		 * "  Send notification when updates are available  button  is enabled in the office and workgroup tab of Environment tab"
		 * ); Assert.assertTrue(environmentalPage.verifyFiery_app_update(),
		 * "  Send notification when updates are available. button is enabled in the office and workgroup tab of Environment tab"
		 * ); Thread.sleep(2000);
		 */
		Assert.assertFalse(environmentalPage.enable_proxy(),
				" verify enable proxy  button is enabled in the office and workgroup tab of Environment tab");
		environmentalPage.getsystemupdatecancel();

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0008")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify Number Format")
	@Stories(value = { "Story : Checking the default Number Format in regional page as per changing the language" })
	@Test(priority = 17)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0008() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		String getlang0 = languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		Assert.assertEquals("English US", getlang0,
				"Language English US" + getlang0 + " is not match with given English US language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for English US is not correct: 1,000 is not checked by default");
		regionalPage.clickBackBtnReg();
		String getlang = languagePage.selectOneLang("en_GB");
		Assert.assertEquals("English International", getlang,
				"Language EI" + getlang + " is not match with given English International language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for English International is not correct: displays 1,000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang1 = languagePage.selectOneLang("fr_FR");
		Assert.assertEquals("Français", getlang1,
				"Language EI" + getlang1 + " is not match with given French language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for French is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang2 = languagePage.selectOneLang("it_IT");
		Assert.assertEquals("Italiano", getlang2,
				"Language EI" + getlang2 + " is not match with given Italian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Italian is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang3 = languagePage.selectOneLang("de_DE");
		Assert.assertEquals("Deutsch", getlang3, "Language EI" + getlang3 + " is not match with given German language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for German is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang4 = languagePage.selectOneLang("es_ES");
		Assert.assertEquals("Español", getlang4,
				"Language EI" + getlang4 + " is not match with given Spanish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Spanish is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang5 = languagePage.selectOneLang("nl_NL");
		Assert.assertEquals("Nederlands", getlang5,
				"Language EI" + getlang5 + " is not match with given Dutch language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Dutch is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang6 = languagePage.selectOneLang("pt_BR");
		Assert.assertEquals("Português brasileiro", getlang6,
				"Language EI" + getlang6 + " is not match with given Portugese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Portugese is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		/*
		 * String getlang7 = languagePage.selectOneLang("ja_JP");
		 * Assert.assertEquals("日本語", getlang7, "Language EI" + getlang7 +
		 * " is not match with given Japaniese language");
		 * languagePage.clickNextBtnLang(); Thread.sleep(3000);
		 * Assert.assertTrue(regionalPage.verifyNumberformat(),
		 * "Default Number format for Japaniese is not correct: displays 1,000 is not checked by default"
		 * ); regionalPage.clickBackBtnReg();
		 */

		String getlang8 = languagePage.selectOneLang("zh_CN");
		Assert.assertEquals("简体中文", getlang8,
				"Language EI" + getlang8 + " is not match with given Simplified chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for Simplified chinese is not correct: displays 1,000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang9 = languagePage.selectOneLang("pl_PL");
		Assert.assertEquals("Polski", getlang9, "Language EI" + getlang9 + " is not match with given polish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Polish is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang10 = languagePage.selectOneLang("ru_RU");
		Assert.assertEquals("Русский", getlang10,
				"Language EI" + getlang10 + " is not match with given Ruissian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Russian is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang11 = languagePage.selectOneLang("tr_TR");
		Assert.assertEquals("Türkçe", getlang11,
				"Language EI" + getlang11 + " is not match with given turkice language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for Turkice is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang12 = languagePage.selectOneLang("cs_CZ");
		Assert.assertEquals("Čeština", getlang12,
				"Language EI" + getlang12 + " is not match with given czech language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNoformat(),
				"Default Number format for czech is not correct: displays 1.000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang13 = languagePage.selectOneLang("zh_TW");
		Assert.assertEquals("繁體中文", getlang13, "Language EI" + getlang13 + " is not match with given Chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for Chinese is not correct: displays 1,000 is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang14 = languagePage.selectOneLang("ko_KR");
		Assert.assertEquals("한국어", getlang14, "Language EI" + getlang14 + " is not match with given korean language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyNumberformat(),
				"Default Number format for Korean is not correct: displays 1,000 is not checked by default");
		regionalPage.clickBackBtnReg();
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickNumber_Format0();
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(3000);
		environmentalPage.clickRestartBtn();
		Thread.sleep(5000);
		CustomKeywords customKeywords = new CustomKeywords();
		customKeywords.Post2(FSW_URL);
		customKeywords.SendFiledata(FSW_URL, "./src/test/resources/ansh.pdf", "669954648", "6.5X13.5");
		customKeywords.Post2(FSW_URL);
		String response = customKeywords.GetPageSize(FSW_URL, "6.5X13.5");
		Assert.assertTrue(response.contains("6.5X13.5"),
				"Response of page size doesnot contains 6.5X13.5 when job is printed with page size 6.5X13.5");
		/*
		 * Assert.assertFalse( response.contains("6,5X13,5"),
		 * "Response of page size contains 6,5X13,5 when job is printed with page size 6.5X13.5"
		 * );
		 */
		// Check CWS should accept the value - Set the Custom paper size as
		// ""6.5X13.5"" not 6,5X13,5.
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		Thread.sleep(3000);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickNumber_Format1();
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(3000);
		// if
		// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
		// {
		environmentalPage.clickRestartBtn();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// } else {
		// environmentalPage.clickRestartBtn();
		// Thread.sleep(5000);
		// }
		// Check CWS should accept the value - Set the Custom paper size as
		// ""6.5X13.5"" not 6,5X13,5.
		customKeywords.Post2(FSW_URL);
		customKeywords.SendFiledata(FSW_URL, "./src/test/resources/AllinFourRGB.pdf", "669954648", "6,5X13,5");
		customKeywords.Post2(FSW_URL);
		String response1 = customKeywords.GetPageSize(FSW_URL, "6,5X13,5");
		Assert.assertTrue(response1.contains("6,5X13,5"),
				"Response of page size doesnot contains 6,5X13,5 when job is printed with page size 6,5X13,5");
		/*
		 * Assert.assertFalse( response1.contains("6.5X13.5"),
		 * "Response of page size contains 6.5X13.5 when job is printed with page size 6,5X13,5"
		 * );
		 */

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0009")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify Measurement units")
	@Stories(value = { "Story : Checking the default Measurement units in regional page as per changing the language" })
	@Test(priority = 18)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0009() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		String getlang0 = languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		Assert.assertEquals("English US", getlang0,
				"Language English US" + getlang0 + " is not match with given English US language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit(),
				"Default measuremnet unit for English US is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang = languagePage.selectOneLang("en_GB");
		Assert.assertEquals("English International", getlang,
				"Language EI" + getlang + " is not match with given English International language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for English International is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang1 = languagePage.selectOneLang("fr_FR");
		Assert.assertEquals("Français", getlang1,
				"Language EI" + getlang1 + " is not match with given French language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for French is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang2 = languagePage.selectOneLang("it_IT");
		Assert.assertEquals("Italiano", getlang2,
				"Language EI" + getlang2 + " is not match with given Italian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Italian is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang3 = languagePage.selectOneLang("de_DE");
		Assert.assertEquals("Deutsch", getlang3, "Language EI" + getlang3 + " is not match with given German language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for German is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang4 = languagePage.selectOneLang("es_ES");
		Assert.assertEquals("Español", getlang4,
				"Language EI" + getlang4 + " is not match with given Spanish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Spanish is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang5 = languagePage.selectOneLang("nl_NL");
		Assert.assertEquals("Nederlands", getlang5,
				"Language EI" + getlang5 + " is not match with given Dutch language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Dutch is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang6 = languagePage.selectOneLang("pt_BR");
		Assert.assertEquals("Português brasileiro", getlang6,
				"Language EI" + getlang6 + " is not match with given Portugese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Portugese is not selcted inches");
		regionalPage.clickBackBtnReg();

		/*
		 * if(Colour=="color"){ String getlang7 = languagePage.selectOneLang("ja_JP");
		 * Assert.assertEquals("日本語", getlang7, "Language EI" + getlang7 +
		 * " is not match with given Japaniese language");
		 * languagePage.clickNextBtnLang(); Thread.sleep(3000);
		 * Assert.assertTrue(regionalPage.verifyMeasurementInchUnit(),
		 * "Default measuremnet unit for Japaniese is not selcted inches");
		 * regionalPage.clickBackBtnReg(); }
		 */
		String getlang8 = languagePage.selectOneLang("zh_CN");
		Assert.assertEquals("简体中文", getlang8,
				"Language EI" + getlang8 + " is not match with given Simplified chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Simplified chinese is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang9 = languagePage.selectOneLang("pl_PL");
		Assert.assertEquals("Polski", getlang9, "Language EI" + getlang9 + " is not match with given polish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for polish is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang10 = languagePage.selectOneLang("ru_RU");
		Assert.assertEquals("Русский", getlang10,
				"Language EI" + getlang10 + " is not match with given Ruissian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Russian is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang11 = languagePage.selectOneLang("tr_TR");
		Assert.assertEquals("Türkçe", getlang11,
				"Language EI" + getlang11 + " is not match with given turkice language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for turkice is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang12 = languagePage.selectOneLang("cs_CZ");
		Assert.assertEquals("Čeština", getlang12,
				"Language EI" + getlang12 + " is not match with given czech language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for czech is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang13 = languagePage.selectOneLang("zh_TW");
		Assert.assertEquals("繁體中文", getlang13, "Language EI" + getlang13 + " is not match with given Chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for Chinese is not selcted inches");
		regionalPage.clickBackBtnReg();

		String getlang14 = languagePage.selectOneLang("ko_KR");
		Assert.assertEquals("한국어", getlang14, "Language EI" + getlang14 + " is not match with given korean language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"Default measuremnet unit for korean is not selcted inches");
		regionalPage.clickBackBtnReg();

		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickMeasurement_unit1();
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(3000);
		// if
		// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
		// {
		environmentalPage.clickRestartBtn();
		CustomKeywords customKeywords = new CustomKeywords();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// } else {
		// environmentalPage.clickRestartBtn();
		// Thread.sleep(5000);
		// }
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		Thread.sleep(5000);
		// languagePage.selectOneLang("en_US");
		// Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		Assert.assertTrue(regionalPage.verifyMeasurementInchUnit1(),
				"After Metric is selected and rebooted the server, Measurement Unit is not Metric in regional page of FSW");
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0010")
	@Severity(value = SeverityLevel.CRITICAL)
	@Description("Verify Default paper size")
	@Stories(value = { "Story : Checking the default Paper Size in regional page as per changing the language" })
	@Test(priority = 19)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0010() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		String getlang0 = languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		Assert.assertEquals("English US", getlang0,
				"Language English US" + getlang0 + " is not match with given English US language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifyPaperSizeInch(),
				"Default Paper size for English US is not correct: Inches is not checked by default");
		regionalPage.clickBackBtnReg();
		String getlang = languagePage.selectOneLang("en_GB");
		Assert.assertEquals("English International", getlang,
				"Language EI" + getlang + " is not match with given English International language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for English International is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang1 = languagePage.selectOneLang("fr_FR");
		Assert.assertEquals("Français", getlang1,
				"Language EI" + getlang1 + " is not match with given French language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for French is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang2 = languagePage.selectOneLang("it_IT");
		Assert.assertEquals("Italiano", getlang2,
				"Language EI" + getlang2 + " is not match with given Italian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Italian is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang3 = languagePage.selectOneLang("de_DE");
		Assert.assertEquals("Deutsch", getlang3, "Language EI" + getlang3 + " is not match with given German language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for German is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang4 = languagePage.selectOneLang("es_ES");
		Assert.assertEquals("Español", getlang4,
				"Language EI" + getlang4 + " is not match with given Spanish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Spanish is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang5 = languagePage.selectOneLang("nl_NL");
		Assert.assertEquals("Nederlands", getlang5,
				"Language EI" + getlang5 + " is not match with given Dutch language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Dutch is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang6 = languagePage.selectOneLang("pt_BR");
		Assert.assertEquals("Português brasileiro", getlang6,
				"Language EI" + getlang6 + " is not match with given Portugese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Portugese is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		/*
		 * if(Colour=="color"){ String getlang7 = languagePage.selectOneLang("ja_JP");
		 * Assert.assertEquals("日本語", getlang7, "Language EI" + getlang7 +
		 * " is not match with given Japaniese language");
		 * languagePage.clickNextBtnLang(); Thread.sleep(3000);
		 * Assert.assertTrue(regionalPage.verifyPaperSizeInch(),
		 * "Default Paper size for Japaniese is not correct: Inches is not checked by default"
		 * ); regionalPage.clickBackBtnReg(); }
		 */
		String getlang8 = languagePage.selectOneLang("zh_CN");
		Assert.assertEquals("简体中文", getlang8,
				"Language EI" + getlang8 + " is not match with given Simplified chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Simplified chinese is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang9 = languagePage.selectOneLang("pl_PL");
		Assert.assertEquals("Polski", getlang9, "Language EI" + getlang9 + " is not match with given polish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Polish is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang10 = languagePage.selectOneLang("ru_RU");
		Assert.assertEquals("Русский", getlang10,
				"Language EI" + getlang10 + " is not match with given Ruissian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Russian is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang11 = languagePage.selectOneLang("tr_TR");
		Assert.assertEquals("Türkçe", getlang11,
				"Language EI" + getlang11 + " is not match with given turkice language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Turkice is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang12 = languagePage.selectOneLang("cs_CZ");
		Assert.assertEquals("Čeština", getlang12,
				"Language EI" + getlang12 + " is not match with given czech language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for czech is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang13 = languagePage.selectOneLang("zh_TW");
		Assert.assertEquals("繁體中文", getlang13, "Language EI" + getlang13 + " is not match with given Chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Chinese is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();

		String getlang14 = languagePage.selectOneLang("ko_KR");
		Assert.assertEquals("한국어", getlang14, "Language EI" + getlang14 + " is not match with given korean language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.verifySconePaperSizeInch1(),
				"Default Paper size for Korean is not correct: Metric is not checked by default");
		regionalPage.clickBackBtnReg();
		Thread.sleep(2000);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickPaper_Size0();
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		ServerPage serverpage = new ServerPage(this.driver, Browser);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(3000);
		environmentalPage.clickRestartBtn();
		TimeUnit.MINUTES.sleep(2);
		CustomKeywords customKeywords = new CustomKeywords();
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// Launch CWS and print a PS test page.In Command work station, in Logs
		// tab check the document size of the printed PS test page. It should be
		// 8.5X11

		customKeywords.Post2(FSW_URL);
		customKeywords.SendFiledata(FSW_URL, "./src/test/resources/ansh.pdf", "669954648", "8.5X11");
		customKeywords.Post2(FSW_URL);
		String response = customKeywords.GetPageSize(FSW_URL, "8.5X11");
		Assert.assertTrue(response.contains("8.5X11"),
				"Response of page size doesnot contains 8.5X11 when job is printed with page size 8.5X11");
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		Thread.sleep(3000);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		regionalPage.clickPaper_Size1();
		regionalPage.clickNextBtnReg();
		Thread.sleep(3000);
		serverpage.clickNextBtnSer();
		Thread.sleep(3000);
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(3000);
		// if
		// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
		// {
		environmentalPage.clickRestartBtn();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// } else {
		// environmentalPage.clickRestartBtn();
		// Thread.sleep(5000);
		// }
		// Launch CWS and print a PS test page.In Command work station, in Logs
		// tab check the document size of the printed PS test page. It should be
		// A4.
		customKeywords.Post2(FSW_URL);
		customKeywords.SendFiledata(FSW_URL, "./src/test/resources/AllinFourRGB.pdf", "669954648", "A4");
		customKeywords.Post2(FSW_URL);
		String response1 = customKeywords.GetPageSize(FSW_URL, "A4");
		Assert.assertTrue(response1.contains("A4"),
				"Response of page size doesnot contains A4 when job is printed with page size A4");
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0011")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Colour Region")
	@Stories(value = { "Story : Checking the Colour Region in regional page as per changing the language" })
	@Test(priority = 20)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0011() throws Exception {

		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			running();
			FSW_URL = FSWURL;
			BrowserName = Browser;
			PassWord = Password;
			LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
			initializeDriver(loginpageUtils.driver);
			loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
			LanguagePage languagePage = new LanguagePage(this.driver, Browser);
			RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
			languagePage.clickCheckboxOfAgree();
			String getlang0 = languagePage.selectOneLang("en_US");
			Thread.sleep(2000);
			Assert.assertEquals("English US", getlang0,
					"Language English US" + getlang0 + " is not match with given English US language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionNA(),
					"Default Colour region for English US is not correct: North America is not checked by default");
			regionalPage.clickBackBtnReg();
			String getlang = languagePage.selectOneLang("en_GB");
			Assert.assertEquals("English International", getlang,
					"Language EI" + getlang + " is not match with given English International language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for English International is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang1 = languagePage.selectOneLang("fr_FR");
			Assert.assertEquals("Français", getlang1,
					"Language EI" + getlang1 + " is not match with given French language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for French is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang2 = languagePage.selectOneLang("it_IT");
			Assert.assertEquals("Italiano", getlang2,
					"Language EI" + getlang2 + " is not match with given Italian language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Italian is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang3 = languagePage.selectOneLang("de_DE");
			Assert.assertEquals("Deutsch", getlang3,
					"Language EI" + getlang3 + " is not match with given German language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for German is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang4 = languagePage.selectOneLang("es_ES");
			Assert.assertEquals("Español", getlang4,
					"Language EI" + getlang4 + " is not match with given Spanish language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Spanish is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang5 = languagePage.selectOneLang("nl_NL");
			Assert.assertEquals("Nederlands", getlang5,
					"Language EI" + getlang5 + " is not match with given Dutch language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Dutch is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang6 = languagePage.selectOneLang("pt_BR");
			Assert.assertEquals("Português brasileiro", getlang6,
					"Language EI" + getlang6 + " is not match with given Portugese language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Portugese is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			/*
			 * String getlang7 = languagePage.selectOneLang("ja_JP");
			 * Assert.assertEquals("日本語", getlang7, "Language EI" + getlang7 +
			 * " is not match with given Japaniese language");
			 * languagePage.clickNextBtnLang(); Thread.sleep(3000);
			 * Assert.assertTrue(regionalPage.verifycolorRegionJapan(),
			 * "Default Colour region for Japaniese is not correct: Japan is not checked by default"
			 * ); regionalPage.clickBackBtnReg();
			 */

			String getlang8 = languagePage.selectOneLang("zh_CN");
			Assert.assertEquals("简体中文", getlang8,
					"Language EI" + getlang8 + " is not match with given Simplified chinese language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Simplified chinese is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang9 = languagePage.selectOneLang("pl_PL");
			Assert.assertEquals("Polski", getlang9,
					"Language EI" + getlang9 + " is not match with given polish language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Polish is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang10 = languagePage.selectOneLang("ru_RU");
			Assert.assertEquals("Русский", getlang10,
					"Language EI" + getlang10 + " is not match with given Ruissian language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Russian is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang11 = languagePage.selectOneLang("tr_TR");
			Assert.assertEquals("Türkçe", getlang11,
					"Language EI" + getlang11 + " is not match with given turkice language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Turkice is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang12 = languagePage.selectOneLang("cs_CZ");
			Assert.assertEquals("Čeština", getlang12,
					"Language EI" + getlang12 + " is not match with given czech language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for czech is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang13 = languagePage.selectOneLang("zh_TW");
			Assert.assertEquals("繁體中文", getlang13,
					"Language EI" + getlang13 + " is not match with given Chinese language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Chinese is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();

			String getlang14 = languagePage.selectOneLang("ko_KR");
			Assert.assertEquals("한국어", getlang14,
					"Language EI" + getlang14 + " is not match with given korean language");
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Assert.assertTrue(regionalPage.verifycolorRegionEurope(),
					"Default Colour region for Korean is not correct: Europe is not checked by default");
			regionalPage.clickBackBtnReg();
			Thread.sleep(2000);
			languagePage.selectOneLang("en_US");
			Thread.sleep(2000);
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			regionalPage.clickNorthAmerica();
			regionalPage.clickNextBtnReg();
			Thread.sleep(3000);
			ServerPage serverpage = new ServerPage(this.driver, Browser);
			serverpage.clickNextBtnSer();
			Thread.sleep(3000);
			EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
			environmentalPage.clickSkipBtnEnv();
			Thread.sleep(3000);
			environmentalPage.clickRestartBtn();
			Thread.sleep(5000);
			CustomKeywords customKeywords = new CustomKeywords();
			customKeywords.runningStatus(FSW_URL);
			Thread.sleep(60000);
			customKeywords.Post2(FSW_URL);
			String response = customKeywords.GetColorProfiles(FSW_URL);
			Assert.assertTrue(
					response.contains("GRACoL2006 Coated1 (EFI)") || response.contains("GRACoL2013 CRPC6 (EFI)"),
					"In Device Center ->color set up -> color management and check CMYK Source profile.The default value is not 'GRACoL2006 Coated1 (EFI) or GRACoL2013 CRPC6 (EFI)'");
			loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
			Thread.sleep(3000);
			languagePage.selectOneLang("en_US");
			Thread.sleep(2000);
			languagePage.clickCheckboxOfAgree();
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			regionalPage.clickEurope();
			regionalPage.clickNextBtnReg();
			Thread.sleep(3000);
			serverpage.clickNextBtnSer();
			Thread.sleep(3000);
			environmentalPage.clickSkipBtnEnv();
			Thread.sleep(3000);
			environmentalPage.clickRestartBtn();
			TimeUnit.MINUTES.sleep(2);
			customKeywords.runningStatus(FSW_URL);
			Thread.sleep(60000);
			customKeywords.Post2(FSW_URL);
			String response1 = customKeywords.GetColorProfiles(FSW_URL);
			Assert.assertTrue(
					response1.contains("PSO Coated FOGRA39L (EFI)") || response1.contains("PSO Coated FOGRA51 (EFI)"),
					"In Device Center ->color set up -> color management and check CMYK Source profile.The default value is not 'PSO Coated FOGRA39L(EFI) or PSO Coated FOGRA51 (EFI)'");
			loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
			Thread.sleep(3000);
			languagePage.selectOneLang("en_US");
			Thread.sleep(2000);
			languagePage.clickCheckboxOfAgree();
			languagePage.clickNextBtnLang();
			Thread.sleep(3000);
			Colour = COLOR;if (Colour.equalsIgnoreCase("Black")) {
				regionalPage.clickJapan();

				regionalPage.clickNextBtnReg();
				Thread.sleep(3000);
				serverpage.clickNextBtnSer();
				Thread.sleep(3000);
				environmentalPage.clickSkipBtnEnv();
				Thread.sleep(3000);
				environmentalPage.clickRestartBtn();
				TimeUnit.MINUTES.sleep(2);
				customKeywords.runningStatus(FSW_URL);
				customKeywords.Post2(FSW_URL);
				String response2 = customKeywords.GetColorProfiles(FSW_URL);
				Assert.assertTrue(
						response2.contains("Japan Colour 2001 type 3(EFI)")
								|| response2.contains("Japan Colour 2011 Coated"),
						"In Device Center ->color set up -> color management and check CMYK Source profile.The default value is not 'Japan Colour 2001 type 3(EFI) or Japan Colour 2011 Coated'");
			}
		} else {

			System.out.println("this feature is not supported in Black/White server");

		}

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0006")
	@Severity(value = SeverityLevel.MINOR)
	@Description("Verify Date Format and Time Zone")
	@Stories(value = {
			"Story : User should be able to change the date format and date&time should change accordingly" })
	@Test(priority = 21)
	// @Parameters({ "FSWURL", "Browser", "Server_Date" })
	public void FSW_0006() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		CustomKeywords customKeywords = new CustomKeywords();
		customKeywords.runningStatus(FSW_URL);
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		String getlang0 = languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		Assert.assertEquals("English US", getlang0,
				"Language English US" + getlang0 + " is not match with given English US language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("mm/dd/yyyy"),
				"Default date format for English US is not correct: mm/dd/yyyy is not displaying by default");
		regionalPage.clickBackBtnReg();
		String getlang = languagePage.selectOneLang("en_GB");
		Assert.assertEquals("English International", getlang,
				"Language EI" + getlang + " is not match with given English International language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/yyyy"),
				"Default date format for English International is not correct: dd/mm/yyyy is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang1 = languagePage.selectOneLang("fr_FR");
		Assert.assertEquals("Français", getlang1,
				"Language EI" + getlang1 + " is not match with given French language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("jj/mm/aaaa"),
				"Default date format for French is not correct: jj/mm/aaaa is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang2 = languagePage.selectOneLang("it_IT");
		Assert.assertEquals("Italiano", getlang2,
				"Language EI" + getlang2 + " is not match with given Italian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("gg/mm/aaaa"),
				"Default date format for Italian is not correct: gg/mm/aaaa is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang3 = languagePage.selectOneLang("de_DE");
		Assert.assertEquals("Deutsch", getlang3, "Language EI" + getlang3 + " is not match with given German language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("TT/MM/JJJJ"),
				"Default date format for German is not correct: TT/MM/JJJJ is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang4 = languagePage.selectOneLang("es_ES");
		Assert.assertEquals("Español", getlang4,
				"Language EI" + getlang4 + " is not match with given Spanish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/aaaa"),
				"Default date format for Spanish is not correct: dd/mm/aaaa is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang5 = languagePage.selectOneLang("nl_NL");
		Assert.assertEquals("Nederlands", getlang5,
				"Language EI" + getlang5 + " is not match with given Dutch language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/jjjj"),
				"Default date format for Dutch is not correct: dd/mm/jjjj is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang6 = languagePage.selectOneLang("pt_BR");
		Assert.assertEquals("Português brasileiro", getlang6,
				"Language EI" + getlang6 + " is not match with given Portugese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/aaaa"),
				"Default date format for Portugese is not correct: dd/mm/aaaa is not displaying by default");
		regionalPage.clickBackBtnReg();

		/*
		 * String getlang7 = languagePage.selectOneLang("ja_JP");
		 * Assert.assertEquals("日本語", getlang7, "Language EI" + getlang7 +
		 * " is not match with given Japaniese language");
		 * languagePage.clickNextBtnLang(); Thread.sleep(3000);
		 * Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase(
		 * "yyyy/mm/dd(年/月/日)"),
		 * "Default date format for Japaniese is not correct: yyyy/mm/dd(年/月/日) is not displaying by default"
		 * ); regionalPage.clickBackBtnReg();
		 */
		String getlang8 = languagePage.selectOneLang("zh_CN");
		Assert.assertEquals("简体中文", getlang8,
				"Language EI" + getlang8 + " is not match with given Simplified chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("yyyy/mm/dd(年/月/日)"),
				"Default date format for Simplified chinese is not correct: yyyy/mm/dd(年/月/日) is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang9 = languagePage.selectOneLang("pl_PL");
		Assert.assertEquals("Polski", getlang9, "Language EI" + getlang9 + " is not match with given polish language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/rrrr"),
				"Default date format for Polish is not correct: dd/mm/rrrr is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang10 = languagePage.selectOneLang("ru_RU");
		Assert.assertEquals("Русский", getlang10,
				"Language EI" + getlang10 + " is not match with given Ruissian language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("дд/мм/гггг"),
				"Default date format for Russian is not correct: дд/мм/гггг is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang11 = languagePage.selectOneLang("tr_TR");
		Assert.assertEquals("Türkçe", getlang11,
				"Language EI" + getlang11 + " is not match with given turkice language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("gg/aa/yyyy"),
				"Default date format for Turkice is not correct: gg/aa/yyyy is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang12 = languagePage.selectOneLang("cs_CZ");
		Assert.assertEquals("Čeština", getlang12,
				"Language EI" + getlang12 + " is not match with given czech language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("dd/mm/rrrr"),
				"Default date format for czech is not correct: dd/mm/rrrr is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang13 = languagePage.selectOneLang("zh_TW");
		Assert.assertEquals("繁體中文", getlang13, "Language EI" + getlang13 + " is not match with given Chinese language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("yyyy/mm/dd"),
				"Default date format for Chinese is not correct: yyyy/mm/dd is not displaying by default");
		regionalPage.clickBackBtnReg();

		String getlang14 = languagePage.selectOneLang("ko_KR");
		Assert.assertEquals("한국어", getlang14, "Language EI" + getlang14 + " is not match with given korean language");
		languagePage.clickNextBtnLang();
		Thread.sleep(3000);
		Assert.assertTrue(regionalPage.getDateformat().equalsIgnoreCase("yyyy/mm/dd"),
				"Default date format for Korean is not correct: yyyy/mm/dd is not displaying by default");
		regionalPage.clickBackBtnReg();
		Thread.sleep(3000);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		String dateformat = regionalPage.selectDateformat("dd/mm/yyyy");
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		serverPage.clickbackBtnSer();
		Thread.sleep(2000);
		String date_time = regionalPage.getDate_Time();
		Assert.assertEquals(date_time, Server_Date, "Date is not displaying in thye format of" + dateformat);
		String dateformat1 = regionalPage.selectDateformat("mm/dd/yyyy");
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		serverPage.clickbackBtnSer();
		Thread.sleep(2000);
		String date_time1 = regionalPage.getDate_Time();
		String[] split = Server_Date.split("/");
		String server_date = split[1] + "/" + split[0] + "/" + split[2];
		Assert.assertEquals(date_time1, server_date, "Date is not displaying in thye format of" + dateformat1);
		String dateformat2 = regionalPage.selectDateformat("yyyy/mm/dd");
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		serverPage.clickbackBtnSer();
		Thread.sleep(2000);
		String date_time2 = regionalPage.getDate_Time();
		String Server_date = split[2] + "/" + split[1] + "/" + split[0];
		Assert.assertEquals(date_time2, Server_date, "Date is not displaying in thye format of" + dateformat2);
		regionalPage.clickNextBtnReg();
		Thread.sleep(5000);
		serverPage.clickNextBtnSer();
		Thread.sleep(5000);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		environmentalPage.clickSkipBtnEnv();
		Thread.sleep(5000);
		// if
		// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
		// {
		environmentalPage.clickRestartBtn();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// } else {
		// environmentalPage.clickRestartBtn();
		// Thread.sleep(5000);
		// }
		loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
		Thread.sleep(5000);
		languagePage.selectOneLang("en_US");
		Thread.sleep(2000);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(5000);
		String actualDateFormat = regionalPage.getDateformat();
		String actualDate = regionalPage.getDate_Time();
		Assert.assertEquals(actualDateFormat, dateformat2,
				"Date Format is saved as by selected date format" + Server_date);
		Assert.assertEquals(actualDate, date_time2,
				"Date " + date_time2 + "is not displaying as date format" + Server_date);
		// CWS check of jobs date format and date.
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0136")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Complete production printing personality.")
	@Stories(value = {
			"Story : User Should be able to see the changed setings in production & should be reflected in the Configure" })
	@Test(priority = 22)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0136() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(2000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(2000);
		serverPage.clickNextBtnSer();
		Thread.sleep(2000);
		environmentalPage.clickprodunbtn();
		environmentalPage.clickNextBtnEnv();
		Thread.sleep(2000);
		/*
		 * environmentalPage.clickSystemupdate(); Thread.sleep(1000);
		 */
		boolean sysUpdates = environmentalPage.getsystemupdate();
		Thread.sleep(1000);
		/*
		 * environmentalPage.clickPrintq(); Thread.sleep(1000); boolean printqueue =
		 * environmentalPage.checkPrintQueue();
		 */
		Thread.sleep(1000);
		environmentalPage.clickJobMismatch();
		Thread.sleep(1000);
		boolean jobMismatch = environmentalPage.checkJobMismatch();
		Thread.sleep(1000);
		/*
		 * environmentalPage.clickJDF(); Thread.sleep(1000);
		 */
		boolean jdf = environmentalPage.checkJDF();
		Thread.sleep(1000);
		environmentalPage.clickSequentialprint();
		Thread.sleep(1000);
		boolean sequentialPrint = environmentalPage.checkSequentialprint();
		Thread.sleep(1000);
		environmentalPage.clickFinishBtn();
		Thread.sleep(2000);
		environmentalPage.clickRestartBtn();
		CustomKeywords customKeywords = new CustomKeywords();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
		Thread.sleep(2000);
		loginpageUtils.clickSystemUpdates();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.verifySystemUpdates(), sysUpdates,
				"SystemUpdates is not matched by default in Fiery Server tab of webtools configure");
		loginpageUtils.clickCancelSysUpdates();
		Thread.sleep(1000);
		loginpageUtils.clickJobSubmission();
		Thread.sleep(3000);
		loginpageUtils.clickSequentialPrint();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.checkSequentialPrint(), sequentialPrint,
				"SequentialPrint is not matched by default in Jobsubmission tab of webtools configure");
		loginpageUtils.clickCancelSequentialPrint();
		Thread.sleep(1000);
		loginpageUtils.clickJDFSettings();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.verifyJDFSettings(), jdf,
				"JDF is not matched by default in Jobsubmission tab of webtools configure");
		loginpageUtils.clickCancelJDFSettings();
		Thread.sleep(1000);
		loginpageUtils.clickJobManagement();
		Thread.sleep(3000);
		loginpageUtils.clickJobmismatch();
		Thread.sleep(5000);
		Assert.assertEquals(loginpageUtils.checkJobmismatch(), jobMismatch,
				"Jobmismatch is not matched by default in Jobsubmission tab of webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelJobmismatch();
		Thread.sleep(6000);
		loginpageUtils.clickPrintQueue();
		Thread.sleep(6000);
		/*
		 * Assert.assertEquals(loginpageUtils.checkPrintQueue(), printqueue,
		 * "PrintQueue is not matched by default in Jobsubmission tab of webtools configure"
		 * );
		 */
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0134")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Complete Office & workgroup printing personality")
	@Stories(value = {
			"Story : User Should be able to see the changed setings in office personality should be reflected in the Configure" })
	@Test(priority = 23)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0134() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(2000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(2000);
		serverPage.clickNextBtnSer();
		Thread.sleep(2000);
		environmentalPage.checkofficebtn();
		environmentalPage.clickNextBtnEnv();
		Thread.sleep(2000);
		/* environmentalPage.clickFhotfolder(); */
		Thread.sleep(1000);
		boolean fh = environmentalPage.checkFhotfolder();
		/* environmentalPage.clickRemotedesk(); */
		Thread.sleep(1000);
		boolean rd = environmentalPage.checkremotedesk();
		/* environmentalPage.clickUSBport(); */
		Thread.sleep(1000);
		/* boolean usb = environmentalPage.checkusbport(); */
		/*
		 * environmentalPage.clickscanning(); Thread.sleep(1000); boolean scan =
		 * environmentalPage.checkscanning(); environmentalPage.clicksnmp();
		 * Thread.sleep(1000); boolean snmp = environmentalPage.checksnmp();
		 * environmentalPage.clickSystemupdate(); Thread.sleep(1000);
		 */
		boolean sysUpdates = environmentalPage.getsystemupdate();
		Thread.sleep(1000);
		environmentalPage.clickFinishBtn();
		Thread.sleep(2000);
		// if
		// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
		// {
		environmentalPage.clickRestartBtn();
		CustomKeywords customKeywords = new CustomKeywords();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// } else {
		// environmentalPage.clickRestartBtn();
		// Thread.sleep(5000);
		// }
		loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
		Thread.sleep(2000);
		Assert.assertEquals(environmentalPage.verifyEnable_Remote_Desktop(), rd,
				"The Enable_Remote_Desktop is not checked by default in Fiery Server tab of webtools configure");
		loginpageUtils.clickSystemUpdates();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.verifySystemUpdates(), sysUpdates,
				"SystemUpdates is not matched by default in Fiery Server tab of webtools configure");
		loginpageUtils.clickCancelSysUpdates();
		Thread.sleep(2000);
		loginpageUtils.clickJobSubmission();
		Thread.sleep(3000);
		Assert.assertEquals(loginpageUtils.verifyHotFolder(), fh,
				"Fiery Hot Folders is not matched by default in JobSubmission tab of webtools configure");
		/*
		 * loginpageUtils.clickUSB(); Thread.sleep(2000);
		 * Assert.assertEquals(loginpageUtils.verifyEnableUSBPort(), usb,
		 * "Enable USB Port is matched by default in JobSubmission tab of Webtools configure"
		 * ); loginpageUtils.clickCancelUSB(); Thread.sleep(2000);
		 * loginpageUtils.clickScanTab();
		 */
		/* Thread.sleep(5000); */
		/*
		 * Assert.assertEquals(loginpageUtils.checkScanEnable(), scan,
		 * "Scan is not matched by default in JobSubmission tab of Webtools configure");
		 * Thread.sleep(2000); loginpageUtils.clickNetwork(); Thread.sleep(3000);
		 * loginpageUtils.clickSNMP(); Thread.sleep(2000);
		 * Assert.assertEquals(loginpageUtils.verifySNMP(), snmp,
		 * "SNMP is not matched by default in Network tab of Webtools configure");
		 */
	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0137")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Complete Graphic Arts and proofing personality")
	@Stories(value = {
			"Story : User Should be able to see the changed setings in Graphic Arts and proofing personality & should be reflected in the Configure" })
	@Test(priority = 24)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0137() throws Exception {

		Colour = COLOR;if (Colour.equalsIgnoreCase("color")) {
			running();
			FSW_URL = FSWURL;
			BrowserName = Browser;
			PassWord = Password;
			LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
			initializeDriver(loginpageUtils.driver);
			loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
			LanguagePage languagePage = new LanguagePage(this.driver, Browser);
			RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
			EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
			ServerPage serverPage = new ServerPage(this.driver, Browser);
			languagePage.clickCheckboxOfAgree();
			languagePage.clickNextBtnLang();
			Thread.sleep(2000);
			regionalPage.clickNextBtnReg();
			Thread.sleep(2000);
			serverPage.clickNextBtnSer();
			Thread.sleep(2000);
			/* environmentalPage.clickGraphics_Arts(); */
			environmentalPage.clickNextBtnEnv();
			Thread.sleep(2000);
			/*
			 * environmentalPage.clickRemotedesk(); Thread.sleep(1000); boolean rd =
			 * environmentalPage.checkremotedesk(); Thread.sleep(1000);
			 */
			environmentalPage.clickSystemupdate();
			Thread.sleep(1000);
			boolean sysUpdates = environmentalPage.getsystemupdate();
			Thread.sleep(1000);
			environmentalPage.clickFinishBtn();
			Thread.sleep(2000);
			// if
			// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
			// {
			environmentalPage.clickRestartBtn();
			CustomKeywords customKeywords = new CustomKeywords();
			TimeUnit.MINUTES.sleep(2);
			customKeywords.runningStatus(FSW_URL);
			Thread.sleep(60000);
			// } else {
			// environmentalPage.clickRestartBtn();
			// Thread.sleep(5000);
			// }
			loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
			Thread.sleep(2000);
			/*
			 * Assert.assertEquals(environmentalPage.verifyEnable_Remote_Desktop(), rd,
			 * "The Enable_Remote_Desktop is not matched by default in Fiery Server tab of webtools configure"
			 * );
			 */
			loginpageUtils.clickSystemUpdates();
			Thread.sleep(6000);
			Assert.assertEquals(loginpageUtils.verifySystemUpdates(), sysUpdates,
					"SystemUpdates is not matched by default in Fiery Server tab of webtools configure");
		} else {

			System.out.println("this feature is not supported in Black/White server");

		}

	}

	@Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	@TestCaseId("FSW_0135")
	@Severity(value = SeverityLevel.NORMAL)
	@Description("Verify Complete transactional printing personality.")
	@Stories(value = {
			"Story : User Should be able to see the changed setings in transactional & should be reflected in the Configure" })
	@Test(priority = 25)
	// @Parameters({ "FSWURL", "Browser" })
	public void FSW_0135() throws Exception {
		running();
		FSW_URL = FSWURL;
		BrowserName = Browser;
		PassWord = Password;
		LoginpageUtils loginpageUtils = new LoginpageUtils(null, Browser);
		initializeDriver(loginpageUtils.driver);
		loginpageUtils.loginwithunPswd("https://" + FSWURL + "/fsw", Password);
		LanguagePage languagePage = new LanguagePage(this.driver, Browser);
		RegionalPage regionalPage = new RegionalPage(this.driver, Browser);
		EnvironmentalPage environmentalPage = new EnvironmentalPage(this.driver, Browser);
		ServerPage serverPage = new ServerPage(this.driver, Browser);
		languagePage.clickCheckboxOfAgree();
		languagePage.clickNextBtnLang();
		Thread.sleep(2000);
		regionalPage.clickNextBtnReg();
		Thread.sleep(2000);
		serverPage.clickNextBtnSer();
		Thread.sleep(2000);
		environmentalPage.clicktransactnbutton();
		environmentalPage.clickNextBtnEnv();
		Thread.sleep(2000);
		/* environmentalPage.clickRemotedesk(); */
		boolean rd = environmentalPage.checkremotedesk();
		/*
		 * Thread.sleep(1000); environmentalPage.clickSystemupdate();
		 */
		boolean sysUpdates = environmentalPage.getsystemupdate();
		/*
		 * Thread.sleep(1000); environmentalPage.clickRIPTab();
		 */
		boolean rip = environmentalPage.checkRipButton();
		/*
		 * Thread.sleep(1000); environmentalPage.clickPrintq();
		 */
		boolean printqueue = environmentalPage.checkPrintQueue();
		Thread.sleep(1000);
		environmentalPage.clickJobMismatch();
		boolean jobMismatch = environmentalPage.checkJobMismatch();
		/*
		 * Thread.sleep(1000); environmentalPage.clickJDF();
		 */
		boolean jdf = environmentalPage.checkJDF();
		Thread.sleep(1000);
		environmentalPage.clickSequentialprint();
		boolean sequentialPrint = environmentalPage.checkSequentialprint();
		Thread.sleep(1000);
		environmentalPage.clickFinishBtn();
		Thread.sleep(2000);
		// if
		// (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close")))
		// {
		environmentalPage.clickRestartBtn();
		CustomKeywords customKeywords = new CustomKeywords();
		TimeUnit.MINUTES.sleep(2);
		customKeywords.runningStatus(FSW_URL);
		Thread.sleep(60000);
		// } else {
		// environmentalPage.clickRestartBtn();
		// Thread.sleep(5000);
		// }
		loginpageUtils.loginWebtoolsConfigure("https://" + WebToolsURL, WTUserName, PassWord);
		Thread.sleep(2000);
		Assert.assertEquals(environmentalPage.verifyEnable_Remote_Desktop(), rd,
				"The Enable_Remote_Desktop is not matched by default in Fiery Server tab of webtools configure");
		loginpageUtils.clickSystemUpdates();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.verifySystemUpdates(), sysUpdates,
				"SystemUpdates is not matched by default in Fiery Server tab of webtools configure");
		loginpageUtils.clickCancelSysUpdates();
		Thread.sleep(1000);
		loginpageUtils.clickJobSubmission();
		Thread.sleep(3000);
		loginpageUtils.clickSequentialPrint();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.checkSequentialPrint(), sequentialPrint,
				"SequentialPrint is not matched by default in Jobsubmission tab of webtools configure");
		loginpageUtils.clickCancelSequentialPrint();
		Thread.sleep(2000);
		loginpageUtils.clickJDFSettings();
		Thread.sleep(2000);
		Assert.assertEquals(loginpageUtils.verifyJDFSettings(), jdf,
				"JDF is not matched by default in Jobsubmission tab of webtools configure");
		loginpageUtils.clickCancelJDFSettings();
		Thread.sleep(3000);
		loginpageUtils.clickJobManagement();
		Thread.sleep(3000);
		Assert.assertEquals(loginpageUtils.verifyRIPWhileReceive(), rip,
				"RIPWhileReceive is not matched by default in Jobsubmission tab of webtools configure");
		Thread.sleep(1000);
		loginpageUtils.clickJobmismatch();
		Thread.sleep(6000);
		Assert.assertEquals(loginpageUtils.checkJobmismatch(), jobMismatch,
				"Jobmismatch is not matched by default in Jobsubmission tab of webtools configure");
		Thread.sleep(2000);
		loginpageUtils.clickCancelJobmismatch();
		Thread.sleep(2000);
		loginpageUtils.clickPrintQueue();
		Thread.sleep(6000);
		Assert.assertEquals(loginpageUtils.checkPrintQueue(), printqueue,
				"PrintQueue is not matched by default in Jobsubmission tab of webtools configure");
	}

	/*
	 * @Issue("https://jira.efi.com/browse/EFIERYJOBF-180")
	 * 
	 * @TestCaseId("FSW_0005")
	 * 
	 * @Severity(value = SeverityLevel.CRITICAL)
	 * 
	 * @Description("Verify Selecting a language from Drop Down")
	 * 
	 * @Stories(value = {
	 * "Story : User should be able to change langauge in language page of FSW" })
	 * 
	 * @Test(priority = 26) // @Parameters({ "FSWURL", "Browser" }) public void
	 * FSW_0005() throws Exception { running();FSW_URL = FSWURL; BrowserName =
	 * Browser; PassWord = Password; LoginpageUtils loginpageUtils = new
	 * LoginpageUtils(null, Browser); initializeDriver(loginpageUtils.driver);
	 * loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
	 * LanguagePage languagePage = new LanguagePage(this.driver, Browser); String
	 * defaultlang = languagePage.getDefaultLang();
	 * Assert.assertTrue(defaultlang.equalsIgnoreCase("English US"),
	 * "Default language is not English International"); List<String> getAllLanguage
	 * = languagePage.getAllLanguages(); Thread.sleep(2000);
	 * Assert.assertTrue(getAllLanguage.contains("Čeština"),
	 * "In dropdown of the languages, Čeština are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Deutsch"),
	 * "In dropdown of the languages, Deutsch are missing");
	 * Assert.assertTrue(getAllLanguage.contains("English International"),
	 * "In dropdown of the languages, English International are missing");
	 * Assert.assertTrue(getAllLanguage.contains("English US"),
	 * "In dropdown of the languages, English US are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Español"),
	 * "In dropdown of the languages, Español are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Français"),
	 * "In dropdown of the languages, Français are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Italiano"),
	 * "In dropdown of the languages, Italiano are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Nederlands"),
	 * "In dropdown of the languages, Nederlands are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Polski"),
	 * "In dropdown of the languages, Polski are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Português brasileiro"),
	 * "In dropdown of the languages, Português brasileiro are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Türkçe"),
	 * "In dropdown of the languages, Türkçe are missing");
	 * Assert.assertTrue(getAllLanguage.contains("Русский"),
	 * "In dropdown of the languages, Русский are missing");
	 * Assert.assertTrue(getAllLanguage.contains("한국어"),
	 * "In dropdown of the languages, 한국어 are missing");
	 * //Assert.assertTrue(getAllLanguage.contains("日本語"),
	 * "In dropdown of the languages, 日本語  are missing");
	 * Assert.assertTrue(getAllLanguage.contains("简体中文"),
	 * "In dropdown of the languages, 简体中文 are missing");
	 * Assert.assertTrue(getAllLanguage.contains("繁體中文"),
	 * "In dropdown of the languages, 繁體中文 are missing");
	 * System.out.println("getAllLanguage" + getAllLanguage);
	 * languagePage.selectOneLang("fr_FR"); Thread.sleep(2000);
	 * Assert.assertTrue(languagePage.getDefaultLang().equalsIgnoreCase("Français"),
	 * "Selected Français is not displaying in dropdown of launguage page");
	 * Assert.assertTrue(languagePage.textOfSelectLanguage().
	 * contains("Sélectionnez la langue du contrôleur Fiery"),
	 * "Language is not changed to Français");
	 * Assert.assertTrue(languagePage.textOfAgreeTo().contains("J'accepte les"),
	 * "Language is not changed to Français");
	 * Assert.assertTrue(languagePage.textOfTerms_Cond().
	 * contains("conditions générales"), "Language is not changed to Français");
	 * languagePage.selectOneLang("zh_CN"); Thread.sleep(2000);
	 * Assert.assertTrue(languagePage.getDefaultLang().equalsIgnoreCase("简体中文"),
	 * "Selected 简体中文 is not displaying in dropdown of launguage page");
	 * Assert.assertTrue(languagePage.textOfSelectLanguage().contains("选择Fiery控制器语言"
	 * ), "Language is not changed to Français");
	 * Assert.assertTrue(languagePage.textOfAgreeTo().contains("我同意"),
	 * "Language is not changed to Français");
	 * Assert.assertTrue(languagePage.textOfTerms_Cond().contains("条款和条件。"),
	 * "Language is not changed to Français"); Thread.sleep(2000);
	 * languagePage.clickCheckboxOfAgree(); Thread.sleep(2000);
	 * Assert.assertTrue(languagePage.verifyNextBtnLangEnable(),
	 * "Next button in language tab is not enabled");
	 * languagePage.clickNextBtnLang(); Thread.sleep(5000); RegionalPage
	 * regionalPage = new RegionalPage(this.driver, Browser);
	 * regionalPage.clickNextBtnReg(); Thread.sleep(5000); ServerPage serverPage =
	 * new ServerPage(this.driver, Browser); serverPage.clickNextBtnSer();
	 * Thread.sleep(5000); EnvironmentalPage environmentalPage = new
	 * EnvironmentalPage(this.driver, Browser); environmentalPage.clickSkipBtnEnv();
	 * Thread.sleep(5000); // if //
	 * (!(environmentalPage.getTextRestartBtn().equalsIgnoreCase("Close"))) // {
	 * environmentalPage.clickRestartBtn(); CustomKeywords customKeywords = new
	 * CustomKeywords(); TimeUnit.MINUTES.sleep(2);
	 * customKeywords.runningStatus(FSW_URL); Thread.sleep(60000); // } else { //
	 * environmentalPage.clickRestartBtn(); // Thread.sleep(5000); // }
	 * loginpageUtils.loginwithunPswd("https://" + FSW_URL + "/fsw", Password);
	 * languagePage.selectOneLang("en_US"); Thread.sleep(2000);
	 * languagePage.clickCheckboxOfAgree(); Thread.sleep(2000);
	 * languagePage.clickNextBtnLang(); Thread.sleep(5000);
	 * regionalPage.clickNextBtnReg(); Thread.sleep(5000);
	 * serverPage.clickNextBtnSer(); Thread.sleep(5000);
	 * environmentalPage.clickSkipBtnEnv(); Thread.sleep(5000);
	 * environmentalPage.clickRestartBtn(); TimeUnit.MINUTES.sleep(2);
	 * customKeywords.runningStatus(FSW_URL); Thread.sleep(60000);
	 * 
	 * System.out.println("test script FSW_0005 completed"); }
	 * 
	 * 
	 */
	@AfterMethod
	public void quitBrowser() {
		if (!(driver == null)) {
			// driver.close();
			driver.quit();
		}
	}

	public void running() throws Exception {
		FSW_URL = FSWURL;
		CustomKeywords customKeywords = new CustomKeywords();
		customKeywords.runningStatus(FSW_URL);
		TimeUnit.SECONDS.sleep(30);
	}
}
