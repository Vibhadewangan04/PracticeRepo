package com.fsw.pageUtils;



import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.fsw.pages.Loginpage;

/**
 * Login into FSW
 *
 */
public class LoginpageUtils extends Loginpage

{

	public LoginpageUtils(WebDriver driver,String browser) {
		super(driver,browser);
		// TODO Auto-generated constructor stub
	}
	
	public void loginWebtoolsConfigure(String WebtoolsURL,String userName,String pswd) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		enterWebToolsUrl(WebtoolsURL);
		Thread.sleep(5000);
		clickConfigure();
		Thread.sleep(2000);
		enterWT_UN(userName);
		enterWTPswd(pswd);
		clickLoginWebtools();
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("link_server_name")));
		}
	
	public void loginWebtoolsConfigureFlame92(String WebtoolsURL,String userName,String pswd) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		enterWebToolsUrl(WebtoolsURL);
		Thread.sleep(5000);
		clickConfigure();
		Thread.sleep(2000);
		if(driver.findElement(By.id("inputIcon")).isDisplayed()) {
			enterWT_UN(userName);
			enterWTPswd(pswd);
			clickLoginWebtools();
		}		
		Thread.sleep(5000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("link_server_name")));
		}
	public void loginWebtoolsConfigureFlame9(String WebtoolsURL,String userName,String pswd) throws InterruptedException {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		enterWebToolsUrl(WebtoolsURL);
		Thread.sleep(5000);
		clickConfigure();
		Thread.sleep(2000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("link_server_name")));
		}
	public void loginwithunPswd(String FSR_URL,String pswd) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		enterFSWUrl(FSR_URL); 
		enterPSWD(pswd);
		clickLogin();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("server_locale")));
		}
	
	public void loginwithusernamePswd(String FSR_URL,String pswd, String usname) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		enterFSWUrl(FSR_URL); 
		enterUSN(usname);
		enterPSWD(pswd);
		clickLoginbutton();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("server_locale name=")));
		}
	
	public void launchURL(String FSWURL) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		enterFSWUrl(FSWURL); 
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("newpwd")));
		}
	
	public void selectlang(String FSR_URL,String pswd) {
		WebDriverWait wait = new WebDriverWait(driver, 10);
		
		}
}
