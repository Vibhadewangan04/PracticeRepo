package com.fsw.pageUtils;



import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import ru.yandex.qatools.allure.annotations.Attachment;

import com.fsw.pages.Basepage;


public class TestListeners implements ITestListener {

	static WebDriver driver=null;
	
	/*private static String getTestMethodName(ITestResult iTestResult){
		return iTestResult.getMethod().getConstructorOrMethod().getName();
	
	}*/
	
	public void onTestFailure(ITestResult result) {
		//try {
		//if (!(driver.equals(null))){
		System.out.println("***** Error "
				+ result.getName().toString().toString().trim()
				+ " test has Failed *****");
		String methodName = result.getName().toString().trim();
		takeScreenShot(methodName);
		//}
		//}catch (Exception e) {
			System.out.println("driver is null for API: Expected");
		//}
	}
    
    @Attachment(value = "{0}",type="image/png")
    public static byte[] takeScreenShot(String methodName) {
    	//get the driver
    	driver= Basepage.getDriver();
    	return ((TakesScreenshot)driver).getScreenshotAs(OutputType.BYTES);            
    }

	public void onTestStart(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestSuccess(ITestResult result) {
		// TODO Auto-generated method stub	
	}

	public void onTestSkipped(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
		// TODO Auto-generated method stub
		
	}

	public void onStart(ITestContext context) {
		// TODO Auto-generated method stub
		
	}

	public void onFinish(ITestContext context) {
		// TODO Auto-generated method stub
		
	}
	
}
