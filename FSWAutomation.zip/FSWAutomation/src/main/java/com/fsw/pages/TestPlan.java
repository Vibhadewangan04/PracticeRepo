package com.fsw.pages;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;

public abstract class TestPlan {
	public WebDriver driver = null;
	// private static final Logger logger = Logging.getLogger(TestPlan.class);
	// private Date start;
	String localPath;
	public ITestContext testContexInfo;

	public TestPlan() {
		this.localPath = System.getProperty("user.dir") + File.separator
				+ "test-output" + File.separator + "screenshots"
				+ File.separator;
	}

	public WebDriver initializeDriver(WebDriver driver) {
		// Logging.log("Initializing the driver");
		return this.driver = driver;
	}

	public void tearDown() {
		if (this.driver != null) {
			this.driver.close();
			this.driver.quit();
		}

	}

	//@AfterMethod()
	public void afterTestMethod() {
		this.tearDown();
		// logger.info(Thread.currentThread() + " Finish method "+
		// method.getName());
	}
	
	

}
