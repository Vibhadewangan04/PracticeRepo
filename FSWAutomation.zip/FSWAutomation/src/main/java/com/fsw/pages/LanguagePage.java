package com.fsw.pages;



import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;


/**
 * Login into FSW
 *
 */
public class LanguagePage extends Basepage

{
	public LanguagePage(WebDriver driver,String browser) {
		super(driver,browser);
		// TODO Auto-generated constructor stub
	}

	WebDriverWait wait = new WebDriverWait(driver, 10);
	By selectLang = By.id("server_locale");
	By selectLangF9 = By.id("server_locale name=");	
	By textOfSelectLang = By.xpath(".//*[@id='content']/div[2]/label[1]");
	By agreeTo = By.id("leula");
	By terms_Cond = By.xpath("//a[contains(@onclick,'return popup_EULA(this,')]"); 
	By checkboxOfAgree = By.id("eula");
	By checkboxOfAgreef9 = By.xpath("//input[@id='eula']");
	
	By nextbuttonInLan = By.xpath(".//*[@id='langNext']");
	By xeroxPrintEngine = By.id("server_use_print_engine_language");
	
	@Step("Verifying Next button is enabled in Language tab")
	public boolean verifyNextBtnLangEnable() {
		return driver.findElement(nextbuttonInLan).isEnabled();
	}
	
	@Step("Clicking next button in Language tab")
	public void clickNextBtnLang() {
		 driver.findElement(nextbuttonInLan).click();
	}
	
	@Step("Clicking Check box of accept terms in Language tab")
	public void clickCheckboxOfAgree() {
		driver.findElement(checkboxOfAgree).click();
	}
	
	@Step("Clicking Check box of accept terms in Language tab")
	public void clickCheckboxOfAgreeflame9() {
		driver.findElement(checkboxOfAgreef9).click();
	}

	@Step("Getting value of Default language")
	public String getDefaultLang() {
		Select selectlanguage = new Select(driver.findElement(selectLang));
		String defaultLaunguage = selectlanguage.getFirstSelectedOption()
				.getText();
		return defaultLaunguage;
	}
	
	@Step("Getting value of Default language")
	public String getDefaultLangFlame9() {
		Select selectlanguage = new Select(driver.findElement(selectLangF9));
		String defaultLaunguage = selectlanguage.getFirstSelectedOption()
				.getText();
		return defaultLaunguage;
	}
	
	@Step("Getting all languages")
	public List<String> getAllLanguages() {
		List<String> getAllLanguage = new ArrayList<String>();
		Select selectlanguage = new Select(driver.findElement(selectLang));
		List<WebElement> allLanguages = selectlanguage.getOptions();
		System.out.println(allLanguages.size());
		for(int i =0 ; i<allLanguages.size();i++){
			getAllLanguage.add(allLanguages.get(i).getAttribute("value"));
		}
		 
		return getAllLanguage;
	}
	
	@Step("Getting all languages")
	public List<String> getAllLanguagesFlame9() {
		List<String> getAllLanguage = new ArrayList<String>();
		Select selectlanguage = new Select(driver.findElement(selectLangF9));
		List<WebElement> allLanguages = selectlanguage.getOptions();
		System.out.println(allLanguages.size());
		for(int i =0 ; i<allLanguages.size();i++){
			getAllLanguage.add(allLanguages.get(i).getText());
		}
		 
		return getAllLanguage;
	}
	
	@Step("Checking if {0} , {1} language is available in the given server")
	public boolean languageAvalibility(String lang,String language) {
		//boolean res = true;
		if(isPresentAndDisplayed1(By.xpath("//*[@id='server_locale']/option[@value = '" +lang+ "']") ))
				{
			return true;
		}else
			return false;
		//driver.findElement(By.xpath("//*[@id='server_locale' and @value = 'en-US']")).isDisplayed(); //*[@id="server_locale" and @value = "en-US"]/option[4]
		
	}
	
	public static boolean isPresentAndDisplayed1(final By by) {
		try {
			System.out.println("try1");
			WebElement ele = driver.findElement(by);
			return ele.isDisplayed();

		} catch (NoSuchElementException e) {
			System.out.println("came to catch block");
			return false;
		}
	}
	
	
	
	@Step("Selecting the language {0}")
	public String selectOneLang(String oneLang) throws InterruptedException {
		Select selectlanguage = new Select(driver.findElement(selectLang));
		selectlanguage.selectByValue(oneLang);
		Thread.sleep(5000);
		Select selectlang = new Select(driver.findElement(selectLang));
		System.out.println(selectlang.getFirstSelectedOption().getText());
		return selectlang.getFirstSelectedOption().getText();
	}
	
	@Step("Selecting the language {0}")
	public String selectOneLangFlame9(String oneLang) throws InterruptedException {
		Select selectlanguage = new Select(driver.findElement(selectLangF9));
		selectlanguage.selectByValue(oneLang);
		Thread.sleep(5000);
		Select selectlang = new Select(driver.findElement(selectLangF9));
		System.out.println("Actual Language"+selectlang.getFirstSelectedOption().getText());
		return selectlang.getFirstSelectedOption().getText();
	}
	
	
	
	@Step("Getting the text of Select the Fiery controller language")
	public String textOfSelectLanguage() {
		return driver.findElement(textOfSelectLang).getText();
	}
	
	@Step("Getting the text of I agree to the")
	public String textOfAgreeTo() {
		return driver.findElement(agreeTo).getText();
	}
	
	@Step("Getting the text of Terms and Conditions.")
	public String textOfTerms_Cond() {
		return driver.findElement(terms_Cond).getText();
	}
	
	@Step("Clicking the text of Terms and Conditions.")
	public void clickTerms_Cond() {
		driver.findElement(terms_Cond).click();
	}
	
	@Step("Verifying Xerox print Engine button is enabled in Language tab")
	public boolean verifyPrintEngineLangEnable() {
		return driver.findElement(xeroxPrintEngine).isEnabled();
	}
	
	
	@Step("Clicking Check box of Xerox print Engine button in Language tab")
	public void clickCheckboxOfPrintEngine() {
		driver.findElement(xeroxPrintEngine).click();
	}
	
	@Step("Check if Xerox key print engine langauge is present or not")
	public void printEngineisPresentEnabled() {
		if(isPresentAndDisplayed(xeroxPrintEngine)) {
			if(verifyPrintEngineLangEnable()) {
				System.out.println("Print engine true.check enable/disable");
				clickCheckboxOfPrintEngine();
				System.out.println("It is a xerox product and checbox is now disabled.");
			}
			
		}
		
		
	}
	
	
	public boolean isPresentAndDisplayed(final By by) {
		try {
			System.out.println("try1");
			WebElement ele = driver.findElement(by);
			return ele.isDisplayed();

		} catch (NoSuchElementException e) {
			System.out.println("came to catch block");
			return false;
		}
	}
	
}
