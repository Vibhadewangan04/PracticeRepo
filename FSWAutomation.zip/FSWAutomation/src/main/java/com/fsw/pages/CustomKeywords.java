package com.fsw.pages;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.net.CookieManager;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.security.SecureRandom;
import java.security.Security;
import java.security.cert.CertificateException;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;

import org.json.JSONException;

import ru.yandex.qatools.allure.annotations.Step;

public class CustomKeywords {

	// static Map<String, String> Versioinfo = new TreeMap<String, String>();
	public static int code1;
	public static String run = null;
	public static String temp2;
	public static String Cookies = "";
	public static String connectPostString;
	public static String Urlname;
	public static HttpsURLConnection conn;
	public static String test1 = null;
	public static String responsemessage;
	public static int id;
	public static String id1;
	public static int id2;
	public static String id3;
	public static int id4;
	public static String id5;
	public static int printid;
	public static String printid1;
	public static String printid2;
	public static String printid3;
	CookieManager cookieMngr = new CookieManager();

	public static String doTrustToCertificates() throws Exception {
		Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
		TrustManager[] trustAllCerts = new TrustManager[] { new javax.net.ssl.X509TrustManager() {
			public java.security.cert.X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(
					java.security.cert.X509Certificate[] chain, String authType)
					throws CertificateException {

			}

			public void checkServerTrusted(
					java.security.cert.X509Certificate[] chain, String authType)
					throws CertificateException {

			}
		}

		};

		SSLContext sc = SSLContext.getInstance("SSL");
		sc.init(null, trustAllCerts, new SecureRandom());
		HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String urlHostName, SSLSession session) {
				if (!urlHostName.equalsIgnoreCase(session.getPeerHost())) {
					System.out.println("Warning: URL host '" + urlHostName
							+ "' is different to SSLSession host '"
							+ session.getPeerHost() + "'.");
				}
				return true;
			}
		};
		HttpsURLConnection.setDefaultHostnameVerifier(hv);
		return "Pass";
	}

	public static String OpenConnection(String Urlname) {
		try {
			doTrustToCertificates();

			HttpsURLConnection.setFollowRedirects(false);
			URL url = new URL(Urlname);

			conn = (HttpsURLConnection) url.openConnection();
			System.out.println("\nSending request to URL : " + url);
		} catch (Throwable t) {
			System.out.println("Not opened the connection:" + t.getMessage());
		}
		return "Pass";
	}

	public static String responseValue() throws Exception {

		BufferedReader in1 = new BufferedReader(new InputStreamReader(
				conn.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in1.readLine()) != null) {
			response.append(inputLine);
			inputLine = inputLine.replaceAll("\\{", "").replaceAll("\\}", "")
					.replaceAll("\"", "");

			if (inputLine.contains(",")) {
				for (String temp21 : inputLine.split(",")) {

					try {
						if (temp21.split(":")[0] == null) {
							System.out.println("No value is existed");
						} else {
							System.out.println(temp21.split(":")[0] + "--->"
									+ temp21.split(":")[1]);
						}
					} catch (Throwable t) {
						System.out.println("Array exception" + t.getMessage());
					}
				}

			}
		}

		in1.close();
		return response.toString();
	}

	public static String Get(String Urlname) {
		try {
			// Urlname = APPTEXT.getProperty(object);
			OpenConnection(Urlname);
			conn.setRequestProperty("Cookie", Cookies);
			conn.setRequestProperty("Accept_Language", "en_US");
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(15000);
			conn.setReadTimeout(15000);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			System.out.println("ResponseCode =" + conn.getResponseCode());
			System.out.println("Response message:" + conn.getResponseMessage());
			code1 = conn.getResponseCode();
			temp2 = responseValue();

		} catch (Throwable t) {
			// //log.info("get request failed: " + t.getMessage());
			return "fail";
		}
		return temp2;
	}

	@Step("Getting the PageSize via API and checking the PageSize is proper based on jobs and number format")
	public static String GetPageSize(String serverIp, String pagesize) {
		try {
			// Urlname = APPTEXT.getProperty(object);
			OpenConnection("https://" + serverIp + "/live/api/v3/jobs?key[]=pageSize");
			conn.setRequestProperty("Cookie", Cookies);
			conn.setRequestProperty("Accept_Language", "en_US");
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(15000);
			conn.setReadTimeout(15000);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			System.out.println("ResponseCode =" + conn.getResponseCode());
			System.out.println("Response message:" + conn.getResponseMessage());
			code1 = conn.getResponseCode();
			temp2 = responseValue();
			/*
			 * if(temp2.contains(pagesize))
			 * 
			 * {} //
			 */
		} catch (Throwable t) {
			// //log.info("get request failed: " + t.getMessage());
			return "fail";
		}
		return temp2;
	}

	@Step("Getting the color profiles via API and checking the color profile for CMYK")
	public static String GetColorProfiles(String serverIp) {
		try {
			// Urlname = APPTEXT.getProperty(object);
			OpenConnection("https://" + serverIp
					+ "/live/api/v3/colorprofiles?current_default=true");
			conn.setRequestProperty("Cookie", Cookies);
			conn.setRequestProperty("Accept_Language", "en_US");
			conn.setRequestMethod("GET");
			conn.setConnectTimeout(15000);
			conn.setReadTimeout(15000);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			System.out.println("ResponseCode =" + conn.getResponseCode());
			System.out.println("Response message:" + conn.getResponseMessage());
			code1 = conn.getResponseCode();
			temp2 = responseValue();
			/*
			 * if(temp2.contains(pagesize))
			 * 
			 * {} //
			 */
		} catch (Throwable t) {
			// //log.info("get request failed: " + t.getMessage());
			return "fail";
		}
		return temp2;
	}

	public static String Put() throws Exception {
		// Urlname = APPTEXT.getProperty(object);
		try {
			OpenConnection("https://10.210.86.131/live/api/v1/configuration/certificates/self_signed");
			String connectPostString2 = "{\"configuration\": {\"certificates\": {\"self_signed\": {\"KeyType\": \"RSA\",\"KeySize\": \"2048\",\"CommonName\": \"fieryapi.efi.com\",\"EmailAddr\": \"gurupran@efi.com\",\"OrgName\": \"EFI\",\"OrgUnit\": \"CQA\",\"CityName\": \"Bangalore\",\"StateName\": \"Karnataka\",\"CountryName\": \"IN\",\"ValidNumDays\": \"365\"}}}}";
			conn.setRequestMethod("PUT");
			conn.setRequestProperty("Cookie", Cookies);
			conn.setRequestProperty("Accept_Language", "en_US");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			OutputStreamWriter wr = new OutputStreamWriter(
					conn.getOutputStream());
			wr.write(connectPostString2);
			wr.flush();
			wr.close();
			int responseCode = conn.getResponseCode();
			// Object response = conn.getContent();
			String responsemessage = conn.getResponseMessage();
			System.out.println("\nSending 'POST' request to URL : " + Urlname);
			System.out.println("Response Code : " + responseCode);
			System.out.println("Response Message : " + responsemessage);
			BufferedReader in = new BufferedReader(new InputStreamReader(
					conn.getInputStream()));
			String inputLine;
			StringBuffer response1 = new StringBuffer();

			while ((inputLine = in.readLine()) != null) {
				response1.append(inputLine);
			}
			in.close();

			// print result
			System.out.println(response1.toString());
			// responseValue();
			// Cookies = conn.getHeaderField("Set-Cookie");
		} catch (Throwable t) {
			System.out
					.println("Exception is occured while accessing login API:"
							+ t.getMessage());
			return "Fail";
		}
		return responsemessage;
	}

	@Step("Verifying the server is in running status or not")
	public static boolean runningStatus(String server_ip) throws Exception

	{ // log.info("====================================");
		// log.info("Executing running status method");
		// Urlname = APPTEXT.getProperty(object);
		int code3, status = 0;
		for (int i = 0; i <= 10; i++) {
			try {

				Get("https://" + server_ip + "/live/api/v3/status");
				code3 = conn.getResponseCode();
				run = temp2.split(":")[1].replaceAll("\\}", "").replaceAll(
						"\"", "");
				System.out.println("Code3 value: " + code3);
				System.out.println("running value: " + run);

				if (code3 == 200 && temp2.contains("running")) {

					System.out.println("fiery api executed");
					// log.info("fiery api executed");
					status = 1;
					break;
				}
				TimeUnit.MINUTES.sleep(1);
			} catch (Throwable t) {
				System.out.println("exception" + t.getMessage());
				TimeUnit.MINUTES.sleep(1);

			}

		}
		if (status == 1) {
			return true;
		} else {
			return false;
		}

	}

	public static String startingStatus() throws Exception

	{
		// //log.info("====================================");
		// //log.info("Executing starting status method");
		// //Urlname=APPTEXT.getProperty(object);
		int ajaxTime = 0;

		for (;;) {
			try {
				Get(Urlname);
				run = temp2.split(":")[1].replaceAll("\\}", "").replaceAll(
						"\"", "");

				System.out.println("starting value: " + run);
				System.out.println("Code1 Value: " + code1);

				if (code1 == 200 && run.equalsIgnoreCase("starting")) {

					System.out.println("fiery api executed");
					// //log.info("fiery api executed");
					break;
				}

				if (ajaxTime > 150) {
					System.out.println("Timeout:: page is loading....");
					break;
				}
				ajaxTime++;
			} catch (Throwable t) {
				System.out.println("Expected exception" + t.getMessage());
				TimeUnit.MINUTES.sleep(1);
				// //log.info("Expected exceptions" + t.getMessage());

			}

		}
		return "Pass";
	}

	public static String login() throws Throwable {
		// //log.info("====================================");
		// //log.info("Executing login method");

		// //Urlname=APPTEXT.getProperty(object);
		try {
			Post2(Urlname);
		} catch (Throwable t) {
			System.out.println("Login is not successfull:" + t.getMessage());
			return "Fail";
		}
		return "Pass";
	}

	/*
	 * public static String ConfigValues() throws SessionNotFoundException,
	 * Throwable
	 * 
	 * { //log.info("====================================");
	 * //log.info("Executing Comparing the configuration values with expected data"
	 * );
	 * 
	 * //Urlname=APPTEXT.getProperty(object); //String data =
	 * testData.getCellData(Sheetname, data_column_name,2);
	 * //log.info("Expected data: "+data); try { Get(Urlname);
	 * if(conn.getResponseCode()==501) { Get(Urlname); Get(Urlname); } String
	 * temp22[] = temp2.split(",");
	 * 
	 * if (temp2.contains(data.trim())) {
	 * System.out.println("Current selected value is:" +data);
	 * //log.info("Current selected value is:" +data+" matched"); return "Pass";
	 * } return "Fail"; } catch (Throwable t) { System.out.println("Exception" +
	 * t.getMessage()); return "Fail"; } }
	 */
	/*
	 * public static String ConfigValues2() throws SessionNotFoundException,
	 * Throwable
	 * 
	 * { //log.info("====================================");
	 * //log.info("Executing Comparing the configuration values with expected data"
	 * );
	 * 
	 * Urlname = APPTEXT.getProperty(object); String data =
	 * testData.getCellData(Sheetname, data_column_name, 2); float u2 =
	 * Float.parseFloat(data); int data2 = (int) (u2);
	 * //log.info("Expected data: " + data2); try { Get(Urlname);
	 * if(conn.getResponseCode()==501) { for(int i=0;i<=5;i++) { Get(Urlname); }
	 * } String temp22[] = temp2.split(","); for (String temp21 : temp22) {
	 * 
	 * try { if (temp21.split(":")[0] == null) {
	 * System.out.println("No value is existed"); } else {
	 * System.out.println(temp21.split(":")[0] + "--->" + temp21.split(":")[1]);
	 * test1 = temp21.split(":")[1].replaceAll("}}}}", "") .replaceAll("\\[",
	 * "").replaceAll("\"", "") .replaceAll("\\]", "").replaceAll("\"", "");
	 * System.out.println("Value of int selected:" + Integer.parseInt(test1));
	 * if (Integer.parseInt(test1) == data2) {
	 * System.out.println("Current selected value is:" + test1);
	 * //log.info("Current selected value is:" + Integer.parseInt(test1) +
	 * "matched"); return "Pass"; } } }
	 * 
	 * catch (Throwable t1) { System.out.println("Array exception" +
	 * t1.getMessage()); } } return "Fail"; } catch (Throwable t) {
	 * System.out.println("Exception" + t.getMessage()); return "Fail"; }
	 * 
	 * }
	 */
	/*
	 * public static String Reconnect() throws Exception, Throwable { String
	 * data=testData.getCellData(Sheetname, data_column_name, 2); Get(Urlname);
	 * 
	 * run = temp2.split(":")[1].replaceAll("\\}", "") .replaceAll("\"", "");
	 * 
	 * System.out.println("running value: " + run);
	 * 
	 * if (run.equalsIgnoreCase("starting")) {
	 * 
	 * System.out.println("fiery api executed");
	 * //log.info("fiery api executed"); }else { login();
	 * Serveractions_Post(""); } return "Pass";
	 * 
	 * 
	 * }
	 */
	public static String Serveractions_Post(String Urlname) {
		// Urlname = APPTEXT.getProperty(object);
		try {
			OpenConnection(Urlname);
			conn.setRequestProperty("Cookie", Cookies);
			conn.setRequestProperty("Accept_Language", "en_US");
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			int responseCode = conn.getResponseCode();
			responsemessage = conn.getResponseMessage();
			System.out.println("\nSending 'POST' request to URL : " + Urlname);
			System.out.println("Response Code : " + responseCode);
			System.out.println("Response Message : " + responsemessage);
			responseValue();
			Cookies = conn.getHeaderField("Set-Cookie");
		} catch (Throwable t) {
			System.out
					.println("Exception is occured while accessing login API:"
							+ t.getMessage());
			return "Fail";
		}
		return responsemessage;

	}

	@Step("Login API")
	public static String Post2(String ServerIp) throws Exception {
		// Urlname = APPTEXT.getProperty(object);
		try {
			OpenConnection("https://" + ServerIp + "/live/api/v3/login");
			String connectPostString2 = "username="
					+ URLEncoder.encode("admin", "UTF-8")
					+ "&password="
					+ URLEncoder
							.encode("9e811f6d6ac9e88b1b70dcf867d501aed4ac1dde10133b20538a53df9fc44e42",
									"UTF-8")
					+ "&accessrights[a1]="
					+ URLEncoder
							.encode("hscPvGULGj8dNgLUVGdObw2+TuFt6gEmDYNQ92mGPASxlInlXXVHiyDrnNCJg239+W5K6ow++Yr9tn3p+sJdCKEtDO8/rrT26QWrUXmzbswH1DmwrADnpMdXCSw0ZNBrrmHAtfUN0ARDd8trWCmk+9QvrLSfeqTPqGmyrdCk2idtZEl1C/o6B5mRQzeUNqUVdI0vBOVaPULW0QW1tT+MQN6JMDgXZRJm8lC4+HqXAr13vo8pQy/TbY9XaNCyZOMyUqxGftSWGHRzsZa3RL5lFMGtUufkqPpaP7w22dFYmiYkXI0vtYn7VsUr+5r/y7M0MVnw5GiqDwAJ0ce9QIbjHQ==",
									"UTF-8");
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			OutputStreamWriter wr = new OutputStreamWriter(
					conn.getOutputStream());
			wr.write(connectPostString2);
			wr.flush();
			wr.close();
			int responseCode = conn.getResponseCode();
			String responsemessage = conn.getResponseMessage();
			System.out.println("\nSending 'POST' request to URL : " + "https://" + ServerIp + "/live/api/v4/login");
			System.out.println("Response Code : " + responseCode);
			System.out.println("Response Message : " + responsemessage);
			responseValue();
			Cookies = conn.getHeaderField("Set-Cookie");
		} catch (Throwable t) {
			System.out
					.println("Exception is occured while accessing login API:"
							+ t.getMessage());
			return "Fail";
		}
		return Cookies;
	}
	
	public static org.json.JSONArray readJsonFromUrl(InputStream is)
			throws IOException, JSONException {
		// InputStream is = new URL(url).openStream();
		try {
			BufferedReader rd = new BufferedReader(new InputStreamReader(is,
					Charset.forName("UTF-8")));
			String jsonText = readAll(rd);
			System.out.println(jsonText);
			org.json.JSONArray json = null;
			try {
				json = new org.json.JSONArray(jsonText);

			} catch (org.json.JSONException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return json;
		} finally {
			is.close();
		}
	}
	
	public static String readAll(Reader rd) throws IOException {
		StringBuilder sb = new StringBuilder();
		int cp;
		while ((cp = rd.read()) != -1) {
			sb.append((char) cp);
		}
		return sb.toString();
	}
	
	public static String getqueuedetails(String Urlname) {
		// Urlname="https://"+APPTEXT.getProperty(object)+"/live/api/v1/queues?key[]=name&key[]=id";
		System.out.println("Get queuedetails URlname" + Urlname);
		// log.info("Get queue details:"+Urlname);
		try {
			OpenConnection(Urlname);
			conn.addRequestProperty("Cookie", Cookies);
			conn.setRequestProperty("Accept_Language", "en_US");
			conn.setRequestMethod("GET");
			conn.setDoOutput(true);
			conn.connect();
			System.out.println("ResponseCode =" + conn.getResponseCode());
			System.out.println("Response message:" + conn.getResponseMessage());
			code1 = conn.getResponseCode();
			org.json.JSONArray json1 = readJsonFromUrl(conn.getInputStream());
			for (int i = 0; i < json1.length(); i++) {
				org.json.JSONObject jsonobject = json1.getJSONObject(i);
				String name = jsonobject.getString("name");
				if (name.endsWith("hold")) {
					id = jsonobject.getInt("id");
					System.out.println("id value:" + id);
					id1 = Integer.toString(id);
				}
			}
		} catch (Throwable t) {
			// //log.info("exception is occured while executing queuedetails API:"+t.getMessage());
		}
		return id1;
	}

	public static void SendFiledata(String serverIp, String file, String queueId,
			String pageSize) throws IOException {
		String charset = "UTF-8";
		File uploadFile1 = new File(file);
		// File uploadFile2 = new File("e:/Test/PIC2.JPG");
		// String requestURL = "https://10.210.86.137/live/api/v1/jobs";
		getqueuedetails("https://" + serverIp
				+ "/live/api/v3/queues?key[]=name&key[]=id");
		MultipartUtility multipart = new MultipartUtility("https://" + serverIp
				+ "/live/api/v3/jobs?key[]=pageSize", charset);

		// multipart.addHeaderField("User-Agent", "CodeJava");
		// multipart.addHeaderField("Test-Header", "Header-Value");
		multipart.addHeaderField("Cookie", Cookies);

		System.out.println("queue" +id1);
		 multipart.addFormField("queue", id1);
		 multipart.addFormField("attributes",
		 "{\"pageSize\": \""+pageSize+"\"}");
		 

		multipart.addFilePart("files", uploadFile1);
		// multipart.addFilePart("fileUpload", uploadFile2);

		java.util.List<String> response = multipart.finish();
		// return charset;

		// System.out.println("SERVER REPLIED:");

		for (String line : response) {
			System.out.println(line);
			String print1[] = line.split(":");
			printid1 = print1[1].replaceAll("\"", "").replaceAll("\\}", "");
			System.out.println("Job id:" + printid1);

		}
	}
}
