package com.fsw.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class Basepage {
	public static WebDriver driver = null;

	public Basepage(WebDriver driver, String browser) {
		this.driver = getDriver(driver, browser);
		System.out.println("driver object is " + this.driver);
	}

	public WebDriver getDriver(WebDriver driver, String browser) {

		try {
			if (driver == null) {
				// String browserName =
				// context.getCurrentXmlTest().getParameter("browser");
				if (browser.equalsIgnoreCase("Firefox")) {
					System.setProperty("webdriver.gecko.driver",
							"geckodriver.exe");
					FirefoxOptions options = new FirefoxOptions();
					//options.addPreference("log", "{level: trace}");
					DesiredCapabilities handlSSLErr = DesiredCapabilities
							.firefox();
					handlSSLErr.setCapability("marionette", true);
					handlSSLErr.setCapability("moz:firefoxOptions", options);
					handlSSLErr.setCapability(CapabilityType.ACCEPT_SSL_CERTS,
							true);
					driver = new FirefoxDriver(handlSSLErr);
				} else if (browser.equalsIgnoreCase("Chrome")) {
					System.setProperty("webdriver.chrome.driver",
							"chromedriver.exe");
					ChromeOptions options = new ChromeOptions();
					
					options.addArguments("enable-automation");
					options.addArguments("--no-sandbox");
					options.addArguments("--disable-extensions");
					options.addArguments("--dns-prefetch-disable");
					options.addArguments("--disable-gpu");
					options.addArguments("ignore-certificate-errors");
					options.addArguments("allow-insecure-localhost");
					DesiredCapabilities handlSSLErr = DesiredCapabilities
							.chrome();
					handlSSLErr.setCapability(CapabilityType.ACCEPT_SSL_CERTS,
							true);
					handlSSLErr.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS,
							true);
					handlSSLErr.setCapability(ChromeOptions.CAPABILITY, options);
					driver = new ChromeDriver(handlSSLErr);
				} else if (browser.equalsIgnoreCase("IE")) {
					System.setProperty("webdriver.ie.driver",
							"IEDriverServer.exe");
					DesiredCapabilities handlSSLErr = DesiredCapabilities
							.internetExplorer();
					handlSSLErr.setCapability(CapabilityType.ACCEPT_SSL_CERTS,
							true);
					driver = new InternetExplorerDriver(handlSSLErr);
				} else if (browser.equalsIgnoreCase("Edge")) {
					System.setProperty("webdriver.edge.driver",
							"MicrosoftWebDriver.exe");
					DesiredCapabilities handlSSLErr = DesiredCapabilities
							.edge();
					handlSSLErr.setCapability(CapabilityType.ACCEPT_SSL_CERTS,
							true);
					driver = new InternetExplorerDriver(handlSSLErr);
				}

				// driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS)
				// ;
				// driver.manage().window().maximize();
			}
		} catch (Exception e) {
			e.printStackTrace();
			// Logging.log("Exception thrown while intializing the driver "+
			// e.getMessage());
		}
		return driver;
	}

	public Basepage() {

	}

	public static WebDriver getDriver() {
		return driver;
	}
}
