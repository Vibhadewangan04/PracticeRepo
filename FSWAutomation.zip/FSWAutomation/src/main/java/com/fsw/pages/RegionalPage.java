package com.fsw.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

/**
 * Login into FSW
 *
 */
public class RegionalPage extends Basepage

{
	public RegionalPage(WebDriver driver, String browser) {
		super(driver, browser);
		// TODO Auto-generated constructor stub
	}

	WebDriverWait wait = new WebDriverWait(driver, 10);
	By nextbtnReg = By.xpath(".//*[@id='next']");
	By dateformate = By.id("date");
	By dateformatef9 = By.id("date_format");
	By seldate = By.id("seldate");
	By seldatef9 = By.id("server_date");	
	By number_format0 = By.xpath("//input[@id='number_format0']");
	By number_format1 = By.xpath("//input[@id='number_format1']");
	By paper_size0 = By.id("paper_size0");
	By paper_size1 = By.id("paper_size1");
	By color_region0 = By.id("color_region0");
	By color_region1 = By.id("color_region1");
	By color_region2 = By.id("color_region2");
	By measurement_unit0 = By.id("measurement_unit0");
	By measurement_unit1 = By.id("measurement_unit1");
	By backbtnReg = By.id("back");

	

	@Step("Clicking North America checkbox in Regional tab")
	public void clickNorthAmerica() {
		 
		driver.findElement(color_region0).click();
	}
	
	@Step("Clicking North America checkbox in Regional tab")
	public boolean clickNorthAmerica11() {
		 boolean text = false;
         try
         {
         //text=driver.findElement(color_region0).isDisplayed();
         text = isPresentAndDisplayed(color_region0);
         
         }catch(Exception e)
         {
                //System.out.println(e.getMessage());
         }
         if(text==true)
         {
         return true;
         }else
         {
                return false;
                }
		
	}
	
	
	public static boolean isPresentAndDisplayed(final By by) {
		try {
			System.out.println("try1");
			WebElement ele = driver.findElement(by);
			return ele.isDisplayed();

		} catch (NoSuchElementException e) {
			System.out.println("came to catch block");
			return false;
		}
	}

	@Step("Clicking Europe checkbox in Regional tab")
	public void clickEurope() {
		
		driver.findElement(color_region1).click();
	}

	@Step("Clicking Japan checkbox in Regional tab")
	public void clickJapan() {
		driver.findElement(color_region2).click();
	}

	@Step("Clicking Number format checkbox in Regional tab")
	public void clickNumber_Format0() {
		driver.findElement(number_format0).click();
	}

	@Step("Clicking Measurement Unit checkbox in Regional tab")
	public void clickMeasurement_unit0() {
		driver.findElement(measurement_unit0).click();
	}

	@Step("Clicking Paper Size checkbox in Regional tab")
	public void clickPaper_Size0() {
		driver.findElement(paper_size0).click();
	}

	@Step("Clicking Measurement Unit checkbox in Regional tab")
	public void clickMeasurement_unit1() {
		driver.findElement(measurement_unit1).click();
	}
	//added new snippet for product
	
	@Step("Checking default paper size in Regional tab")
	public boolean verifySconePaperSizeInch() {
		return driver.findElement(paper_size0).isSelected();
	}
	
	
	//added snippet by Ram
	
	@Step("Checking default paper size in Regional tab")
	public boolean verifySconePaperSizeInch1() {
		return driver.findElement(paper_size1).isSelected();
	}
	
	@Step("Clicking Number format checkbox in Regional tab")
	public void clickNumber_Format1() {
		driver.findElement(number_format1).click();
	}

	@Step("Clicking Paper Size checkbox in Regional tab")
	public void clickPaper_Size1() {
		driver.findElement(paper_size1).click();
	}

	@Step("Checking default nuberformat in Regional tab")
	public boolean verifyNumberformat() {
		return driver.findElement(number_format0).isSelected();
	}

	@Step("Checking default measurement unit in Regional tab")
	public boolean verifyMeasurementInchUnit() {
		return driver.findElement(measurement_unit0).isSelected();
	}

	
	//added snippet by Ram
	
	@Step("Checking default measurement unit in Regional tab")
	public boolean verifyMeasurementInchUnit1() {
		return driver.findElement(measurement_unit1).isSelected();
	}
	
	@Step("Checking default measuremnents units for the launguage in Regional tab")
	public boolean verifyMeasurementMetricUnit() {
		return driver.findElement(measurement_unit1).isSelected();
	}

	@Step("Checking default measuremnents units for the launguage in Regional tab")
	public boolean verifyNoformat() {
		return driver.findElement(number_format1).isSelected();
	}

	@Step("Checking default paper size in Regional tab")
	public boolean verifyPaperSizeInch() {
		return driver.findElement(paper_size0).isSelected();
	}
	
	
	//new snippet added by Ram

	@Step("Checking default paper size in Regional tab")
	public boolean verifyPaperSizeInch1() {
		return driver.findElement(paper_size1).isSelected();
	}
	
	@Step("Checking default paper size in Regional tab")
	public boolean verifyPaperSizeMetric() {
		return driver.findElement(paper_size1).isSelected();
	}

	@Step("Checking default color region in Regional tab")
	public boolean verifycolorRegionNA() {
		return driver.findElement(color_region0).isSelected();
	}

	@Step("Checking default color region in Regional tab")
	public boolean verifycolorRegionEurope() {
		return driver.findElement(color_region1).isSelected();
	}

	@Step("Checking default color region in Regional tab")
	public boolean verifycolorRegionJapan() {
		return driver.findElement(color_region2).isSelected();
	}

	@Step("Clicking back button in Regional tab")
	public void clickBackBtnReg() {
		driver.findElement(backbtnReg).click();
	}

	@Step("Clicking next button in Regional tab")
	public void clickNextBtnReg() {
		driver.findElement(nextbtnReg).click();
	}

	@Step("Verifying the next button is enabled in Regional tab")
	public boolean verifyNextBtnReg() {
		
		return driver.findElement(nextbtnReg).isEnabled();
	}

	@Step("Selct the date format in Regional tab")
	public String selectDateformat(String datformat) {
		Select select = new Select(driver.findElement(dateformate));
		select.selectByVisibleText(datformat);
		return select.getFirstSelectedOption().getText();
	}
	
	@Step("Selct the date format in Regional tab")
	public String selectDateformatFlame9(String datformat)  {
		Select select = new Select(driver.findElement(dateformatef9));
		select.selectByVisibleText(datformat);
		return select.getFirstSelectedOption().getText();
	}

	@Step("Get the date format in Regional tab")
	public String getDateformat() {
		Select select = new Select(driver.findElement(dateformate));
		return select.getFirstSelectedOption().getText();
	}
	
	@Step("Get the date format in Regional tab")
	public String getDateformatFlame9() {
		Select select = new Select(driver.findElement(dateformatef9));
		return select.getFirstSelectedOption().getText();
	}

	@Step("Get the Date & Time in Regional tab")
	public String getDate_Time() {
		return driver.findElement(seldate).getAttribute("value");
	}
	@Step("Get the Date & Time in Regional tab")
	public String getDate_TimeFlame9() {
		return driver.findElement(seldatef9).getAttribute("value");
	}

}
