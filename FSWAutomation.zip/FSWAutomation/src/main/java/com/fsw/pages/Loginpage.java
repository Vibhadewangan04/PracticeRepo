package com.fsw.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Parameters;

import ru.yandex.qatools.allure.annotations.Step;

/**
 * Login into FSW
 *
 */
public class Loginpage extends Basepage

{
	public Loginpage(WebDriver driver, String browser) {
		super(driver, browser);
		// TODO Auto-generated constructor stub
	}

	WebDriverWait wait = new WebDriverWait(driver, 10);
	By newusernm = By.id("inputIcon");
	By newpsdw = By.id("newpwd");
	By loginbtn = By.id("ok");
	By Loginbutton = By.id("loginBtn");
	By serverName = By.id("id-server-name-header");
	By configure = By.id("id-configure-tab");
	By inputIcon = By.id("inputIcon");
	By pwdwebTools = By.id("newpwd");
	By loginBtn = By.id("loginBtn");
	By character_set = By.id("link_server_use_character_set");
	By use_character_set = By.id("server_use_character_set");
	By cancelCharacterSet = By
			.xpath(".//*[@id='use_character_set_popup']/div[3]/button[contains(@id,'cancel')]");
	By cancelSecureErase = By
			.xpath(".//*[@id='secure_erase_popup']/div[3]/button[contains(@id,'cancel')]");
	By scanBtn = By.id("tab_scan");
	By enableScan = By.id("server_secure_erase");
	By fileFormat = By.id("server_scan_default_file_format");
	By cleanup_Job = By.name("server_scan_job_cleanup_frequency");
	By print_start_page = By.id("server_print_start_page");
	By securityTab = By.id("tab_security");
	By secureErase = By.id("link_server_secure_erase");
	By jobManagement = By.id("tab_job_management");
	By samplePrint = By.id("link_server_sample_print_frequency");
	By sp_demand = By.id("sp_demand");
	By sp_sheet = By.id("sp_sheet");
	By output_tray = By.id("server_sample_print_output_tray");
	By cancelSamplePrint = By
			.xpath(".//*[@id='sample_print_popup']/div[3]/button[contains(@id,'cancel')]");
	By server_preview_while_processing = By
			.id("server_preview_while_processing");
	By jobSubmission = By.id("tab_job_submission");
	By enable_HF = By.id("server_enable_HF");
	By enable_jdf = By.id("link_server_enable_jdf");
	By server_enable_jdf = By.id("server_enable_jdf");
	By cancelJDF = By.xpath(".//*[@id='jdf_popup']/div[3]/button[1]");
	By network = By.id("tab_network");
	By ethernetSpeed = By.id("link_server_ethernet_speed");
	By server_ethernet_speed = By.id("server_ethernet_speed");
	By cancel_ethernet_speed = By
			.xpath(".//*[@id='ethernet_speed_popup']/div[3]/button[contains(@id,'cancel')]");
	By enable_usb_printing = By.id("link_server_enable_usb_printing");
	By server_enable_usb_printing = By.id("server_enable_usb_printing");
	By cancelUSB = By
			.xpath(".//*[@id='usb_popup']/div[3]/button[contains(@id,'cancel')]");
	By link_server_enable_appletalk = By.id("link_server_enable_appletalk");
	By server_enable_appletalk = By.id("server_enable_appletalk");
	By cancel_appletalk = By
			.xpath(".//*[@id='apple_talk_popup']/div[3]/button[contains(@id,'cancel')]");
	By server_enable_rip_while_receive = By
			.id("server_enable_rip_while_receive");
	By link_server_enable_ip4_filters = By.id("link_server_enable_ip4_filters");
	By server_enable_ip4_filters = By.id("server_enable_ip4_filters");
	By server_enable_ip6_filters = By.id("server_enable_ip6_filters");
	By cancelIPFiltering = By
			.xpath(".//*[@id='ip_filter_popup']/div[3]/button[1]");
	By link_server_enable_port_filtering = By
			.id("link_server_enable_port_filtering");
	By server_enable_port_filtering = By.id("server_enable_port_filtering");
	By cancelPortFiltering = By
			.xpath(".//*[@id='tcp_ip_port_filter_popup_button']/button[1]");
	By link_enable_lpd_printing = By.id("link_enable_lpd_printing");
	By server_lpd_default_queue = By.id("server_lpd_default_queue");
	By enable_lpd_printing = By.id("enable_lpd_printing");
	By cancelLPD = By.xpath(".//*[@id='lpd_popup']/div[3]/button[1]");
	By link_server_enable_windows_printing = By
			.id("link_server_enable_windows_printing");
	By server_enable_windows_printing = By.id("server_enable_windows_printing");
	By cancelWindowsPrinting = By
			.xpath(".//*[@id='smb_windows_popup']/div[3]/button[1]");
	By enable_SLP = By.id("link_server_enable_slp");
	By server_enable_slp = By.id("server_enable_slp");
	By cancelSLP = By.xpath(".//*[@id='slp_popup']/div[3]/button[1]");
	By bonjour = By.id("link_server_enable_bonjour");
	By server_enable_bonjour = By.id("server_enable_bonjour");
	By server_bonjour_printing_protocol = By
			.id("server_bonjour_printing_protocol");
	By cancelBonjour = By.xpath(".//*[@id='bonjour_popup']/div[3]/button[1]");
	By link_server_enable_ftp_printing = By
			.id("link_server_enable_ftp_printing");
	By server_enable_ftp_printing = By.id("server_enable_ftp_printing");
	By server_default_ftp_queue = By.id("server_default_ftp_queue");
	By ftp_printing_popup = By.id("ftp_printing_popup");
	By cancelFTP = By.xpath(".//*[@id='ftp_printing_popup']/div[3]/button[1]");
	By link_server_enable_port_9100 = By.id("link_server_enable_port_9100");
	By server_enable_port_9100 = By.id("server_enable_port_9100");
	By server_port_9100_queue = By.id("server_port_9100_queue");
	By cancelPort9100 = By
			.xpath(".//*[@id='port_9100_popup']/div[3]/button[1]");
	By server_enable_ipp = By.id("server_enable_ipp");
	By link_server_wsd_enable_print = By.id("link_server_wsd_enable_print");
	By server_wsd_enable_print = By.id("server_wsd_enable_print");
	By server_wsd_print_queue = By.id("server_wsd_print_queue");
	By cancelWSD = By.xpath(".//*[@id='wsd_popup']/div[3]/button[1]");
	By snmp = By.id("link_server_enable_snmp");
	By enable_snmp = By.id("server_enable_snmp");
	By systemUpdates = By.id("link_server_enable_system_updates");
	By enable_systemUpdates = By.id("server_enable_system_updates");
	By server_enable_scan = By.id("server_enable_scan");
	By cancelSysUpdates = By
			.xpath(".//*[@id='system_updates_popup']/div[3]/button[1]");
	By sequentialPrint = By.id("link_server_enable_sequential_print");
	By server_enable_sequential_print = By.id("server_enable_sequential_print");
	By cancelSequentialPrint = By
			.xpath(".//*[@id='sequential_print_popup']/div[3]/button[1]");
	By jobmismatch = By.id("link_server_enable_job_mismatch");
	By enablejobmismatch = By.id("server_enable_job_mismatch");
	By cancelJobmismatcht = By
			.xpath(".//*[@id='job_mismatch_popup']/div[3]/button[@id='cancel']");
	By printqueue = By.id("link_server_enable_printed_queue");
	By enableprintqueue = By.id("server_enable_printed_queue");
	By cancelprintqueue = By
			.xpath(".//*[@id='printed_queue_popup']/div[3]/button[1]");
	
	@Step("Clicking the PrintQueue in Job_management tab of webtools configure")
	public void clickPrintQueue() {
		driver.findElement(printqueue).click();
	}

	@Step("Verify the PrintQueue in Jobmanagement tab of webtools configure")
	public boolean checkPrintQueue() {
		return driver.findElement(enableprintqueue).isSelected();
	}

	@Step("Clicking the cancel button of PrintQueue in Job_management tab of webtools configure")
	public void clickCancelPrintQueue() {
		driver.findElement(cancelJobmismatcht).click();
	}
	
	@Step("Clicking the Jobmismatch in Job_management tab of webtools configure")
	public void clickJobmismatch() {
		driver.findElement(jobmismatch).click();
	}

	@Step("Verify the Jobmismatch in Jobsubmission tab of webtools configure")
	public boolean checkJobmismatch() {
		return driver.findElement(enablejobmismatch).isSelected();
	}

	@Step("Clicking the cancel button of Jobmismatch in Job_management tab of webtools configure")
	public void clickCancelJobmismatch() {
		driver.findElement(cancelJobmismatcht).click();
	}

	@Step("Clicking the sequentialPrint in Jobsubmission tab of webtools configure")
	public void clickSequentialPrint() {
		driver.findElement(sequentialPrint).click();
	}
	@Step("Clicking the sequentialPrint in Jobsubmission tab of webtools configure")
	public void clickSequentialPrintFlame9() {
		driver.findElement(server_enable_sequential_print).click();
	}
	@Step("Clicking the cancel button of sequentialPrint in Jobsubmission tab of webtools configure")
	public void clickCancelSequentialPrint() {
		driver.findElement(cancelSequentialPrint).click();
	}

	@Step("Verify the sequentialPrint in Jobsubmission tab of webtools configure")
	public boolean checkSequentialPrint() {
		return driver.findElement(server_enable_sequential_print).isSelected();
	}

	@Step("Verify Document scanning in Scan tab of webtools configure.")
	public boolean checkScanEnable() {
		return driver.findElement(server_enable_scan).isSelected();
	}

	@Step("Clicking the cancel button of systemUpdates in Network tab of webtools configure")
	public void clickCancelSysUpdates() {
		driver.findElement(cancelSysUpdates).click();
	}

	@Step("Verify the systemUpdates tab of Network tab of webtools configure")
	public boolean verifySystemUpdates() {
		return driver.findElement(enable_systemUpdates).isSelected();
	}

	@Step("Clicking the SNMP button in Network tab of webtools configure")
	public void clickSNMP() {
		driver.findElement(snmp).click();
	}

	@Step("Clicking the systemUpdates button in Network tab of webtools configure")
	public void clickSystemUpdates() {
		driver.findElement(systemUpdates).click();
	}

	@Step("Verify the SNMP button of Network tab of webtools configure")
	public boolean verifySNMP() {
		return driver.findElement(enable_snmp).isSelected();
	}

	@Step("Clicking Cancel button in WSD of JobSubmission tab in Webtools configure")
	public void clickCancelWSD() {
		driver.findElement(cancelWSD).click();
	}

	@Step("Clicking WSD of JobSubmission tab in Webtools configure")
	public void clickWSD() {
		driver.findElement(link_server_wsd_enable_print).click();
	}

	@Step("Verifying WSD is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyWSD() {
		return driver.findElement(server_wsd_enable_print).isSelected();
	}

	@Step("Verifying WSD is Print Queue of JobSubmission tab of Webtools configure")
	public String getWSDQueue() {
		Select select = new Select(driver.findElement(server_wsd_print_queue));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Clicking Cancel button in Port 9100 of JobSubmission tab in Webtools configure")
	public void clickCancelPort9100() {
		driver.findElement(cancelPort9100).click();
	}

	@Step("Clicking Port 9100 of JobSubmission tab in Webtools configure")
	public void clickPort9100() {
		driver.findElement(link_server_enable_port_9100).click();
	}

	@Step("Verifying IPP is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyIPP() {
		return driver.findElement(server_enable_ipp).isSelected();
	}

	@Step("Verifying Port 9100 is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyPort9100() {
		return driver.findElement(server_enable_port_9100).isSelected();
	}

	@Step("Verifying Port 9100 Queue is Print Queue of JobSubmission tab of Webtools configure")
	public String getPort9100Queue() {
		Select select = new Select(driver.findElement(server_port_9100_queue));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Clicking Cancel button in FTP Printing of JobSubmission tab in Webtools configure")
	public void clickCanceFTP() {
		driver.findElement(cancelFTP).click();
	}

	@Step("Clicking FTP Printing of JobSubmission tab in Webtools configure")
	public void clickFTPPrinting() {
		driver.findElement(link_server_enable_ftp_printing).click();
	}

	@Step("Verifying FTP Printing is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyFTPPrinting() {
		return driver.findElement(server_enable_ftp_printing).isSelected();
	}

	@Step("Verifying FTP Printing Queue is Print Queue of JobSubmission tab of Webtools configure")
	public String getFTPQueue() {
		Select select = new Select(driver.findElement(server_default_ftp_queue));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Clicking Service Location Protocol (SLP) of Network tab in Webtools configure")
	public void clickSLP() {
		driver.findElement(enable_SLP).click();
	}

	@Step("Verifying the Preferred printing protocol is LPD of Network tab in Webtools configure")
	public String getTextBonjour() {
		Select select = new Select(
				driver.findElement(server_bonjour_printing_protocol));
		return select.getFirstSelectedOption().getText();
	}
	
	@Step("Verifying the Bonjour Service Name of Network tab in Webtools configure")
	public String getBonjourName() {
		return driver.findElement(By.id("server_bonjour_service_name")).getAttribute("value");
	}

	@Step("Verifying Bonjour is enabled in Network tab of Webtools configure")
	public boolean verifyBonjour() {
		return driver.findElement(server_enable_bonjour).isSelected();
	}

	@Step("Clicking Bonjour of Network tab in Webtools configure")
	public void clickBonjour() {
		driver.findElement(bonjour).click();
	}

	@Step("Clicking Cancel button in Bonjour of Network tab in Webtools configure")
	public void clickCancelBonjour() {
		driver.findElement(cancelBonjour).click();
	}

	@Step("Clicking Cancel button in SLP of Network tab in Webtools configure")
	public void clickCancelSLP() {
		driver.findElement(cancelSLP).click();
	}

	@Step("Clicking Windows Printing of JobSubmission tab in Webtools configure")
	public void clickWindowsPrinting() {
		driver.findElement(link_server_enable_windows_printing).click();
	}

	@Step("Verifying Enable SLP is enabled in Network tab of Webtools configure")
	public boolean verifySLP() {
		return driver.findElement(server_enable_slp).isSelected();
	}

	@Step("Verifying Enable Windows SMB Printing is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyWindowsSMB() {
		return driver.findElement(server_enable_windows_printing).isSelected();
	}

	@Step("Clicking Cancel button in Windows Printing of JobSubmission tab in Webtools configure")
	public void clickCancelWindowsPrinting() {
		driver.findElement(cancelWindowsPrinting).click();
	}

	@Step("Clicking Cancel button in IP Address Filtering of Security tab in Webtools configure")
	public void clickCancelIPFiltering() {
		driver.findElement(cancelIPFiltering).click();
	}

	@Step("Clicking Cancel button in LPD of JobSubmission tab in Webtools configure")
	public void clickCancelLPD() {
		driver.findElement(cancelLPD).click();
	}

	@Step("Verifying LPD Queue in JobSubmission tab of Webtools configure")
	public String getQueueLPD() {
		Select select = new Select(driver.findElement(server_lpd_default_queue));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Verifying LPD is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyLPD() {
		return driver.findElement(enable_lpd_printing).isSelected();
	}

	@Step("Clicking LPD in JobSubmission tab in Webtools configure")
	public void clickLPD() {
		driver.findElement(link_enable_lpd_printing).click();
	}

	@Step("Clicking Cancel button in Port Address Filtering of Security tab in Webtools configure")
	public void clickCancelPortFiltering() {
		driver.findElement(cancelPortFiltering).click();
	}

	@Step("Clicking Cancel button in Ethernet Speed of Network tab in Webtools configure")
	public void clickCancelEthernetSpeed() {
		driver.findElement(cancel_ethernet_speed).click();
	}

	@Step("Clicking Cancel button in AppleTalk of Network tab in Webtools configure")
	public void clickCancelAppleTalk() {
		driver.findElement(cancel_appletalk).click();
	}

	@Step("Verifying Enable AppleTalk is not enabled in Network tab of Webtools configure")
	public boolean verifyAppleTalk() {
		return driver.findElement(server_enable_appletalk).isSelected();
	}

	@Step("Verifying Enable Rip While Receive is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyRIPWhileReceive() {
		return driver.findElement(server_enable_rip_while_receive).isSelected();
	}

	@Step("Verifying IPV4 Address Filtering is not enabled in Security tab of Webtools configure")
	public boolean verifyIPV4() {
		return driver.findElement(server_enable_ip4_filters).isSelected();
	}

	@Step("Verifying IPV6 Address Filtering is not enabled in Security tab of Webtools configure")
	public boolean verifyIPV6() {
		return driver.findElement(server_enable_ip6_filters).isSelected();
	}

	@Step("Verifying TCP/IP Port Filtering is enabled in Security tab of Webtools configure")
	public boolean verifyPort_Filtering() {
		return driver.findElement(server_enable_port_filtering).isSelected();
	}

	@Step("Clicking TCP/IP Port Filtering in Security tab in Webtools configure")
	public void clickPortFiltering() {
		driver.findElement(link_server_enable_port_filtering).click();
	}

	@Step("Clicking IP Address Filtering in Security tab in Webtools configure")
	public void clickIPFiltering() {
		driver.findElement(link_server_enable_ip4_filters).click();
	}

	@Step("Clicking AppleTalk in Network tab in Webtools configure")
	public void clickAppleTalk() {
		driver.findElement(link_server_enable_appletalk).click();
	}

	@Step("Clicking Cancel button in USB of JobSubmission tab in Webtools configure")
	public void clickCancelUSB() {
		driver.findElement(cancelUSB).click();
	}

	@Step("Verifying Enable USB Port is not enabled in JobSubmission tab of Webtools configure")
	public boolean verifyEnableUSBPort() {
		return driver.findElement(server_enable_usb_printing).isSelected();
	}

	@Step("Clicking USB of JobSubmission tab in Webtools configure")
	public void clickUSB() {
		driver.findElement(enable_usb_printing).click();
	}

	@Step("Verifying Ethernet Speed is Auto (10/100/1000) in Network tab of Webtools configure")
	public String verifyEthernetSpeed() {
		Select select = new Select(driver.findElement(server_ethernet_speed));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Clicking JDF Settings in JobSubmission tab of Webtools configure")
	public void clickJDFSettings() {
		driver.findElement(enable_jdf).click();
	}

	@Step("Clicking Ethernet Speed in Network tab of Webtools configure")
	public void clickEthernetSpeed() {
		driver.findElement(ethernetSpeed).click();
	}

	@Step("Clicking Network tab of Webtools configure")
	public void clickNetwork() {
		driver.findElement(network).click();
	}

	@Step("Clicking Cancel button in JDF Settings of JobSubmission tab of Webtools configure")
	public void clickCancelJDFSettings() {
		driver.findElement(cancelJDF).click();
	}

	@Step("Verifying JDFSettings is not enabled in JobSubmission tab of Webtools configure")
	public boolean verifyJDFSettings() {
		return driver.findElement(server_enable_jdf).isSelected();
	}

	@Step("Verifying Fiery Hot Folders is enabled in JobSubmission tab of Webtools configure")
	public boolean verifyHotFolder() {
		return driver.findElement(enable_HF).isSelected();
	}

	@Step("Clicking JobSubmission tab of Webtools configure")
	public void clickJobSubmission() {
		driver.findElement(jobSubmission).click();
	}

	@Step("Checking default Sample print Output Tray in JobManagement tab of configure in Webtools")
	public String getOutPutTray() {
		Select select = new Select(driver.findElement(output_tray));
		return select.getFirstSelectedOption().getText();
	}

	@Step("Verifying Server Preview While Processing is not enabled in JobManagement tab of Webtools configure")
	public boolean verifyPreview_While_Processing() {
		return driver.findElement(server_preview_while_processing).isSelected();
	}

	@Step("Verifying Sample Print Frequency is On-demand in JobManagement tab of Webtools configure")
	public boolean verifySample_PrintFrequency() {
		return driver.findElement(sp_demand).isSelected();
	}

	@Step("Verifying Content is Sheet (for any kind of job) in JobManagement tab of Webtools configure")
	public boolean verifySPContent() {
		return driver.findElement(sp_sheet).isSelected();
	}

	@Step("Clicking Cancel button in Sample print of JobManagement tab of Webtools configure")
	public void clickCancelSamplePrint() {
		driver.findElement(cancelSamplePrint).click();
	}

	@Step("Clicking JobManagement tab of Webtools configure")
	public void clickJobManagement() {
		driver.findElement(jobManagement).click();
	}

	@Step("Clicking Sample Print in JobManagement tab of Webtools configure")
	public void clickSamplePrint() {
		driver.findElement(samplePrint).click();
	}

	@Step("Clicking Secure Erase in Security tab of Webtools configure")
	public void clickSecureErase() {
		driver.findElement(secureErase).click();
	}

	@Step("Clicking Cancel button of Secure Erase in Security tab of Webtools configure")
	public void clickCancelSecureErase() {
		driver.findElement(cancelSecureErase).click();
	}

	@Step("Clicking Security tab of configure in Webtools")
	public void clickSecurityTab() {
		driver.findElement(securityTab).click();
	}

	@Step("Verifying Secure Erase in Security tab of Webtools configure")
	public boolean verifySecureErase() {
		return driver.findElement(enableScan).isSelected();
	}

	@Step("Verifying Print Start Page is not enabled in Fiery Server tab of configure in Webtools")
	public boolean verifyPrint_Start_Page() {
		return driver.findElement(print_start_page).isSelected();
	}

	@Step("Checking Clear each scan job in Scan tab of configure in Webtools")
	public String getValueCleanUpFrequency() {
		Select select1 = new Select(driver.findElement(cleanup_Job));
		return select1.getFirstSelectedOption().getText();
	}

	@Step("Checking default file format in Scan tab of configure in Webtools")
	public String getTextFileFormat() {
		Select select = new Select(driver.findElement(fileFormat));
		return select.getFirstSelectedOption().getText();
	}

	@Step("Entering the FSW URL")
	public void enterFSWUrl(String FSWURL) {
		driver.get(FSWURL);
		if (driver.toString().contains("InternetExplorerDriver")) {
			driver.get("javascript:document.getElementById('overridelink').click();");
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(newpsdw));
	}

	@Step("Entering the WebTools URL")
	public void enterWebToolsUrl(String WebToolsURL) {
		driver.get(WebToolsURL);
		if (driver.toString().contains("InternetExplorerDriver")) {
			driver.get("javascript:document.getElementById('overridelink').click();");
		}
		wait.until(ExpectedConditions.visibilityOfElementLocated(serverName));
	}

	@Step("Clicking Scan tab of configure in Webtools")
	public void clickScanTab() {
		driver.findElement(scanBtn).click();
	}

	@Step("Checking scanning for document is enabled in scan tab of configure in Webtools")
	public boolean verifyEnableScan() {
		return driver.findElement(enableScan).isSelected();
	}

	@Step("Clicking User Character set of configure in Webtools")
	public void clickCharacter_Set() {
		driver.findElement(character_set).click();
	}

	@Step("Getting the value of Server Use Character set of configure in Webtools")
	public String getTextUse_Character_Set() {
		Select select = new Select(driver.findElement(use_character_set));
		return select.getFirstSelectedOption().getText();
		//return driver.findElement(use_character_set).getText();
	}

	@Step("Clicking Cancel button of User Character Set in configure of webtools")
	public void clickCancelCharacter_Set() {
		driver.findElement(cancelCharacterSet).click();
	}

	@Step("Clicking Configure Tab in Webtools")
	public void clickConfigure() {
		driver.findElement(configure).click();
	}

	@Step("Enter UserName in Webtools")
	public void enterWT_UN(String userName) {
		driver.findElement(inputIcon).sendKeys(userName);
	}

	@Step("Enter Password in Webtools")
	public void enterWTPswd(String pwdWebTools) {
		driver.findElement(pwdwebTools).sendKeys(pwdWebTools);
	}

	@Step("Click Login button in Webtools")
	public void clickLogin() {
		driver.findElement(loginbtn).click();
	}
	
	@Step("Click Login button in Webtools")
	public void clickLoginbutton() {
		driver.findElement(Loginbutton).click();
	}
	
	@Step("Enter User Name")
	public void enterUSN(String UserName) {
		driver.findElement(newusernm).sendKeys(UserName);
	}

	@Step("Enter Password")
	public void enterPSWD(String password) {
		driver.findElement(newpsdw).sendKeys(password);
	}
	
	@Step("Check for asking User Name in login page")
	public boolean verifyuserName() {
		return driver.findElement(newusernm).isDisplayed();
	}

	@Step("Check for asking Password in login page")
	public boolean verifyPSWD() {
		return driver.findElement(newpsdw).isDisplayed();
	}

	@Step("Clicking Login Button in Webtools")
	public void clickLoginWebtools() {
		driver.findElement(loginBtn).click();
	}
}
