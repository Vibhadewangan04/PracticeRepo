package com.fsw.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

/**
 * Login into FSW
 *
 */
public class EnvironmentalPage extends Basepage

{
	public EnvironmentalPage(WebDriver driver, String browser) {
		super(driver, browser);
		// TODO Auto-generated constructor stub
	}

	WebDriverWait wait = new WebDriverWait(driver, 10);
	By nextbtnEnv = By.xpath(".//*[@id='next']");
	By skipbtnEnv = By.xpath(".//*[@id='skipButtonContainer']/div");
	By restartbtn = By.id("restartbtn");
	By restartbtn2=By.xpath(".//button[@id='restartbtn']");
	By envElement = By.xpath(".//*[@id='content']/h2");
	By grp_arts = By.xpath(".//*[@id='graphic_arts']/span");
	By production = By.xpath(".//*[@id='production']/span");
	By transactional = By.xpath(".//*[@id='performance']/span");
	By office_WorkGroup = By.xpath(".//*[@id='office']/span");
	By enable_Remote_Desktop = By.id("server_enable_remote_desktop");
	By enable_System_Updates = By.id("update");
	By enable_System_Updatesf9 = By.id("server_enable_system_updates");
	By enable_System_Updates_Manage = By.id("updatebtn");
	By check_day = By.id("server_system_update_day");
	By check_time = By.id("server_system_update_time");
	By fsu_Notification = By.id("fiery_sys_2");
	By fau_Notification = By.id("fiery_app_2");
	By ss_update_enable_proxy = By.id("server_system_update_enable_proxy");
	By cancelESU = By
			.xpath(".//*[@id='systemUpdates']/div[9]/button[contains(@id,'cancel')]");
	By enableAPPE = By.id("adobe");
	By pdfToAPPE = By.id("routePDF");
	By officebtn = By.xpath(".//*[@id='office']/span");
	By Fhotflder = By.id("server_enable_HF");
	By remotedesktop = By.id("server_enable_remote_desktop");
	By printedqueue = By.id("pq");
	By secureErase = By.id("se");
	By printwithoutAutcn = By.id("auth");
	By USBport = By.id("usb");
	By Ldap = By.id("ldap");
	By Ldapmange = By.xpath("(//button[@id='cancel'])[7]");
	By Ldapmangef9 = By.xpath("//button[@id='cancel_fsw_ldap']");
	
	By enablescanning = By.id("scan");
	By enableSNMP = By.id("snmp");
	By enableSNMPf9 = By.id("server_enable_snmp");	
	By SMNPmange = By.id("snmpbtn");
	By SMNPmanagesec = By.xpath(".//*[@id='SNMPSecLevel']/option[2]");
	By SMNPmanagesecf9 = By.xpath(".//*[@id='server_snmp_security_level']/option[2]");	
	By SMNPcancel = By
			.xpath(".//*[@id='snmpDialog']/div[2]/button[contains(@id,'cancel')]");
	By Systemupdate = By.id("update");
	By Systemupdatef9 = By.id("server_enable_system_updates");
	
	By Systemupdatemanage = By.id("updatebtn");
	By Systemupdatecancel = By
			.xpath(".//*[@id='systemUpdates']/div[9]/button[contains(@id,'cancel')]");
	By systemUpdateCancel = By
			.xpath(".//*[@id='systemUpdates']/div[5]/button[contains(@id,'cancel')]");
	By Systemupdateday = By.id("server_system_update_day");
	By FierySystemupdate = By.id("fiery_sys_2");
	By Systemupdatetime = By.id("server_system_update_time");
	By Fieryappupdate = By.id("fiery_app_2");
	By Enableproxy = By
			.xpath(".//*[@id='server_system_update_enable_proxy']");
	By transabtn = By.xpath(".//*[@id='performance']/span");
	By Ripbuttn = By.id("rip");
	By printqueue = By.id("pq");
	By jobmismatch = By.id("jobMis");
	By jobmismatchf9 = By.id("server_enable_job_mismatch");
	By enableremot = By.id("server_enable_remote_desktop");
	By enableautomanage = By.id("jlbtn");
	By enableauto = By.id("jl");
	By enableautof9 = By.id("server_enable_joblog_auto_export");
	By clickok = By.id("ok");
	By clickokf9 = By.id("fsw_auto_joblog_ok");	
	By enablesystem = By.id("update");
	By enablesystemf9 = By.id("server_enable_system_updates");	
	By Systemupdate1 = By.id("updatebtn");
	By Systemupdateday1 = By.id("server_system_update_day");
	By FierySystemupdate1 = By.id("fiery_sys_2");
	By Systemupdatetime1 = By.id("server_system_update_time");
	By Fieryappupdate1 = By.id("fiery_app_2");
	By Enableproxy1 = By.id("server_system_update_enable_proxy");
	By enablesetpage = By.id("spd");	
	By enablesequential = By.id("sequentialPrint");
	By poducnbtn = By.id("production");
	By prodprintqueue = By.id("pq");
	By prodsampleprint = By.id("samplepr");
	By prodondemand = By.id("sp_demand");
	By prodsheet = By.id("sp_sheet");
	By prodAutoselect = By.id("server_sample_print_output_tray");
	By prodsampleprintcancel = By
			.xpath(".//*[@id='samplePrintDialog']/div[5]/button[1]");
	By prodenablejobmismatch = By.id("jobMis");
	By prodenablejobmismatchf9 = By.id("server_enable_job_mismatch");
	By prodjobMissmatchManage = By.id("jobMisLink");
	By prodsequentialprintManage = By.id("sequentialpr");
	By prodjobmissmatchTime = By.id("server_job_mismatch_timeout");
	By prodjobmissmatchAction = By.id("jobMismatachAction");
	By prodjobmissmatchActionf9 = By.id("server_job_mismatch_action");
	By prodjobmissmatchcancel = By.xpath(".//*[@id='manageJobMismatch']/div[2]/button[1]");
	By prodsequentialprintcancel = By.id("cancel_fsw_squential_print");
	By preodenablesystem = By.id("update");
	By prodSystemupdate = By.id("updatebtn");
	By prodSystemupdateday = By.id("server_system_update_day");
	By prodSystemupdatetime = By.id("server_system_update_time");
	By prodFierySystemupdate = By.id("fiery_sys_2");
	By prodFieryappupdate = By.id("fiery_app_2");
	By prodEnableproxy = By.id("server_system_update_enable_proxy");
	By prodsequentialPrintFlame9 = By.xpath("//input[@id='server_enable_sequential_print']");
	By prodsequentialPrint = By.id("sequentialPrint");	
	By server_enable_sequential_print = By.id("server_enable_sequential_print");
	By prodenablesetpagedevice = By.id("spd");
	By prodjdf = By.id("jdf");
	By prodjdff9 = By.id("server_enable_jdf");
	By finish = By.id("finish");
	By environmtTab= By.xpath("//li[contains(text(),'Environment')]");

	@Step("Clicking the Enable JDF in the Transactional tab of Environment tab  ")
	public void clickJDF() {
		driver.findElement(prodjdf).click();
	}
	@Step("Clicking the Enable JDF in the Transactional tab of Environment tab  ")
	public void clickJDFFlame9() {
		driver.findElement(prodjdff9).click();
	}
	@Step("Verify the Enable JDF in the Transactional tab of Environment tab  ")
	public boolean checkJDF() {
		return driver.findElement(prodjdf).isSelected();
	}
	@Step("Verify the Enable JDF in the Transactional tab of Environment tab  ")
	public boolean checkJDFFlame9() {
		return driver.findElement(prodjdff9).isSelected();
	}
	@Step("Clicking the Enable Job Mismatch in the Transactional tab of Environment tab  ")
	public void clickJobMismatch() {
		driver.findElement(jobmismatch).click();
	}
	@Step("Clicking the Enable Job Mismatch in the Transactional tab of Environment tab  ")
	public void clickJobMismatchFlame9() {
		driver.findElement(jobmismatchf9).click();
	}
	@Step("Clicking the Enable RIP While Receive in the Transactional tab of Environment tab  ")
	public void clickRIPTab() {
		driver.findElement(Ripbuttn).click();
	}

	@Step("Clicking the offic and workgroup button in the office and workgroup tab of Environment tab")
	public void checkofficebtn() {
		driver.findElement(office_WorkGroup).click();
	}

	@Step("Clicking the finish button of Environment tab")
	public void clickFinishBtn() {
		driver.findElement(finish).click();
	}

	@Step("Click fiery hot folder button in the office and workgroup tab of Environment tab")
	public void clickFhotfolder() {
		driver.findElement(Fhotflder).click();
	}

	@Step("Verify enable fiery hot folder button in  the office and workgroup tab of Environment tab")
	public boolean checkFhotfolder() {
		return driver.findElement(Fhotflder).isSelected();
	}

	@Step("Verify enable remote desktop  button in the office and workgroup tab of  Environment tab")
	public boolean checkremotedesk() {
		return driver.findElement(remotedesktop).isSelected();
	}

	@Step("Click remote desktop  button in the office and workgroup tab of  Environment tab")
	public void clickRemotedesk() {
		driver.findElement(remotedesktop).click();
	}

	@Step("Verify Enable printed queue  button in the office and workgroup tab of  Environment tab")
	public boolean checkenableprintq() {
		return driver.findElement(printedqueue).isSelected();
	}
	
	@Step("Clicking printed queue button in the office and workgroup tab of  Environment tab")
	public void clickPrintq() {
		 driver.findElement(printedqueue).click();
	}

	@Step("Verify Enable Secure Erase  button in the office and workgroup tab of  Environment tab")
	public boolean checksecureerase() {
		return driver.findElement(secureErase).isSelected();
	}
	
	//adding new method
	@Step("Verify Enable Secure Erase  button in the office and workgroup tab of  Environment tab")
	public boolean checkenvtTab() {
		return driver.findElement(environmtTab).isDisplayed();
	}

	@Step("Verify Allow users to print without authentication  button in  the office and workgroup tab of Environment tab")
	public boolean checkprintwithoutauth() {
		return driver.findElement(printwithoutAutcn).isSelected();
	}

	@Step("Verify  Enable USB port  button in  the office and workgroup tab of Environment tab")
	public boolean checkusbport() {
		return driver.findElement(USBport).isSelected();
	}

	@Step("Click USB port  button in  the office and workgroup tab of Environment tab")
	public void clickUSBport() {
		driver.findElement(USBport).click();
	}

	@Step("Verify LDAP  button in the office and workgroup tab of Environment tab")
	public void checkldap() {
		driver.findElement(Ldap).click();
	}

	@Step("Verify LADP manage  button in the office and workgroup tab of Environment tab")
	public void checkldapmange() {
		driver.findElement(Ldapmange).click();

	}
	
	@Step("Verify LADP manage  button in the office and workgroup tab of Environment tab")
	public void checkldapmangeFlame9() {
		driver.findElement(Ldapmangef9).click();

	}

	@Step("Verify Enable Scanning  button in the office and workgroup tab of Environment tab")
	public boolean checkscanning() {
		return driver.findElement(enablescanning).isSelected();
	}

	@Step("Click Scanning button in the office and workgroup tab of Environment tab")
	public void clickscanning() {
		driver.findElement(enablescanning).click();
	}

	@Step("Verify Enable SNMP  button in the office and workgroup tab of Environment tab")
	public boolean checksnmp() {
		return driver.findElement(enableSNMP).isSelected();

	}

	@Step("Verify Enable SNMP  button in the office and workgroup tab of Environment tab")
	public boolean checksnmpFlame9() {
		return driver.findElement(enableSNMPf9).isSelected();

	}
	@Step("Click SNMP  button in the office and workgroup tab of Environment tab")
	public void clicksnmp() {
		driver.findElement(enableSNMP).click();

	}
	@Step("Click SNMP  button in the office and workgroup tab of Environment tab")
	public void clicksnmpFlame9() {
		driver.findElement(enableSNMPf9).click();

	}
	@Step("Verify Enable SNMP  Manage button in the office and workgroup tab of Environment tab")
	public void checksnmpmange() {
		WebElement element = driver.findElement(SMNPmange);
		element.click();

	}

	@Step("Verify Enable SNMP  button in the office and workgroup tab of Environment tab")
	public String getSNMPmangeSecurity() {
		WebElement element = driver.findElement(SMNPmanagesec);
		String s = element.getText();
		return s;
	}
	
	@Step("Verify Enable SNMP Manage Security button in the office and workgroup tab of Environment tab")
	public String getSNMPmangeSecurityFlame9() {
		WebElement element = driver.findElement(SMNPmanagesecf9);
		String s = element.getText();
		System.out.println(s);
		return s;
	}

	@Step("Click Cancel SNMP  button in  the office and workgroup tab of Environment tab")
	public void snmpmangeCancel() {
		driver.findElement(SMNPcancel).click();

	}

	@Step("Verify Enable system update  button in the office and workgroup tab of  Environment tab")
	public boolean getsystemupdate() {
		return driver.findElement(Systemupdate).isSelected();

	}
	
	@Step("Verify Enable system update  button in the Transaction tab of  Environment tab")
	public boolean getsystemupdateFlame9() {
		return driver.findElement(Systemupdatef9).isSelected();

	}

	@Step("Click system update button in the Transaction tab of Environment tab")
	public void clickSystemupdate() {
		driver.findElement(Systemupdate).click();

	}
	
	@Step("Click system update button in the Transaction tab of Environment tab")
	public void clickSystemupdateFlame9() {
		driver.findElement(Systemupdatef9).click();

	}

	@Step("Verify system update manage in the office and workgroup tab of Environment tab")
	public void systemupdatemanage() {
		driver.findElement(Systemupdatemanage).click();

	}

	@Step("Verify syssem update cance in the office and workgroup tab of  Environment tab")
	public void getsystemupdatecancel() {
		driver.findElement(Systemupdatecancel).click();

	}
	
	@Step("Verify system update cancel in the office and workgroup tab of  Environment tab")
	public void clickCancelSysUpdate() {
		driver.findElement(systemUpdateCancel).click();

	}

	@Step("Verify Checking Every day time dropdown for the Enable_System_Updates in the office and work tab of Environment tab")
	public String verifysystem_Day() {
		Select select = new Select(driver.findElement(Systemupdateday));
		return select.getFirstSelectedOption().getText();

	}

	@Step("Checking Every day time dropdown for the Enable_System_Updates in the office and work of Environment tab")
	public String verifysystem_Time() {
		Select select = new Select(driver.findElement(Systemupdatetime));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Verifying the Fiery System Updates Notification is checked for the Enable_System_Updates in the office and work tab of Environment tab")
	public boolean verifyFiery_systeupdate() {
		return driver.findElement(FierySystemupdate).isSelected();

	}

	@Step("Verifying the Fiery System Updates Notification is checked for the Enable_System_Updates in the office and work tab of Environment tab")
	public boolean verifyFiery_app_update() {
		return driver.findElement(Fieryappupdate).isSelected();

	}

	@Step("Verify Enable proxy  button in  the office and workgroup tab of Environment tab")
	public boolean enable_proxy() {
		return driver.findElement(Enableproxy).isSelected();

	}

	@Step("Clicking the Transaction button in  the  transaction and personality tab of Environment tab")
	public void clicktransactnbutton() {
		driver.findElement(transabtn).click();
	}
	
/*	@Step("verify the Transaction button in  the  transaction and personality tab of Environment tab")
	public boolean checktransactnbutton() {
		return driver.findElement(transabtn).isDisplayed();
	}*/
	
	
	@Step("verifying the Transaction button in  the  transaction and personality tab of Environment tab")
	public boolean check_transactnbutton() {

		if((driver.findElements(transabtn)).size()!= 0)
		{
			return true;
		}
		return false;
	}

	@Step("Clicking the Rip while recieve button in the   transaction and personality tab of  Environment tab")
	public boolean checkRipButton() {
		return driver.findElement(Ripbuttn).isSelected();
	}

	@Step("Clicking the printed queue  button in  the transaction and personality  tab of Environment tab")
	public boolean checkPrintQueue() {
		return driver.findElement(printqueue).isSelected();
	}

	@Step("Clicking the printed queue  button  the transaction and personality  tab of in Environment tab")
	public boolean checkJobMismatch() {
		return driver.findElement(jobmismatch).isSelected();
	}
	
	@Step("Verify Job Mismatch button is enabled in the transaction and personality  tab of in Environment tab")
	public boolean checkJobMismatchFlame9() {
		return driver.findElement(jobmismatchf9).isSelected();
	}

	@Step("Verify enable remore desktop  button is enabled in  the transaction and personality  tab of Environment tab")
	public boolean checkEnableRemote() {
		return driver.findElement(enableremot).isSelected();
	}

	@Step("Clicking the manage  button in  the transaction and personality  tab of Environment tab")
	public void clickAutomanage() {
		driver.findElement(enableautomanage).click();
	}

	@Step("Verify Auto manage is enabled in  the transaction and personality tab of Environment tab")
	public boolean clickEnableAutomanage() {
		return driver.findElement(enableauto).isSelected();
	}
	
	@Step("Verify Auto manage is enabled in  the transaction and personality tab of Environment tab")
	public boolean clickEnableAutomanageFlame9() {
		return driver.findElement(enableautof9).isSelected();
	}

	@Step("Clicking the OK button in  the transaction and personality  tab of Environment tab")
	public void clickok() {
		driver.findElement(clickok).click();
	}
	@Step("Clicking the OK button in  the transaction and personality  tab of Environment tab")
	public void clickokFlame9() {
		driver.findElement(clickokf9).click();
	}

	@Step("Verifying system updates button in  the transaction and personality  tab of Environment tab")
	public boolean checksystemupdate() {
		return driver.findElement(enablesystem).isSelected();
	}
	@Step("Verifying system updates button in  the Office and WorkGroup tab in Environment tab")
	public boolean checksystemupdateFlame9() {
		return driver.findElement(enablesystemf9).isSelected();
	}
	@Step("Clicking system updates button in  the transaction and personality  tab of Environment tab")
	public void clicksystemupdate() {
		 driver.findElement(enablesystem).click();
	}
	@Step("Clicking system updates button in  the Office and WorkGroup tab in Environment tab")
	public void clicksystemupdateFlame9() {
		 driver.findElement(enablesystemf9).click();
	}

	@Step("Verify syssem update cance in  the transaction and personality  tab of Environment tab")
	public void clicksystemupdatemanage() {
		driver.findElement(Systemupdate1).click();

	}

	@Step("Verify Checking Every day time dropdown for the Enable_System_Updates in the transaction and personality  tab of Environment tab")
	public String verifysystem_Day1() {
		Select select = new Select(driver.findElement(Systemupdateday1));
		return select.getFirstSelectedOption().getText();

	}

	@Step("Checking Every day time dropdown for the Enable_System_Updates in the transaction and personality  of Environment tab")
	public String verifysystem_Time2() {
		Select select = new Select(driver.findElement(Systemupdatetime1));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Verifying the Fiery System Updates Notification is checked for the Enable_System_Updates in the transaction and personality  tab of Environment tab")
	public boolean verifyFiery_systeupdate11() {
		return driver.findElement(FierySystemupdate1).isSelected();

	}

	@Step("Verifying the Fiery System Updates Notification is checked for the Enable_System_Updates in the transaction and personality tab of Environment tab")
	public boolean verifyFiery_app_update11() {
		return driver.findElement(Fieryappupdate1).isSelected();

	}

	@Step("Verify Enable system update  button in the transaction and personality tab of Environment tab")
	public boolean verifyFiery_systeupdate1() {
		return driver.findElement(Systemupdatetime1).isSelected();

	}

	@Step("Verify Enable system update  button in the transaction and personality tab of  Environment tab")
	public boolean verifyFiery_app_update1() {
		return driver.findElement(Fieryappupdate1).isSelected();

	}

	@Step("Verify Enable proxy  button in  the transaction and personality tab of Environment tab")
	public boolean enable_proxy1() {
		return driver.findElement(Enableproxy1).isSelected();

	}

	@Step("Verify Enable set page button in the transaction and personality tab of Environment tab")
	public boolean check_Set_page() {
		return driver.findElement(enablesetpage).isSelected();

	}
	
	@Step("Verify Enable sequential  button in the transaction and personality of  Environment tab")
	public boolean check_Sequential() {
		return driver.findElement(enablesequential).isSelected();

	}
	@Step("Verify Enable sequential  button in the transaction and personality of  Environment tab")
	public boolean check_SequentialFlame9() {
		return driver.findElement(prodsequentialPrintFlame9).isSelected();

	}
	@Step("Verifying the Always route PDF jobs to APPE is not checked in the Graphics Arts & Proofing tab of Environment tab")
	public boolean verifyPdfToAPPE() {
		return driver.findElement(pdfToAPPE).isSelected();
	}

	@Step("Verifying the Enable Adobe PDF Print Engine is checked in the Graphics Arts & Proofing tab of Environment tab")
	public boolean verifyEnableAPPE() {
		return driver.findElement(enableAPPE).isSelected();
	}

	@Step("Clicking the cancel button of Enable_System_Update in the Graphics Arts & Proofing tab of Environment tab")
	public void clickCancelEnable_System_Updates() {
		driver.findElement(cancelESU).click();
	}

	@Step("Verifying the Proxy Settings is not checked for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab")
	public boolean verifyProxy_Settings() {
		return driver.findElement(ss_update_enable_proxy).isSelected();
	}

	@Step("Verifying the Fiery System Updates Notification is checked for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab")
	public boolean verifyFSU_Notification() {
		return driver.findElement(fsu_Notification).isSelected();
	}

	@Step("Verifying the Fiery Application Updates Notification is checked for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab")
	public boolean verifyFAU_Notification() {
		return driver.findElement(fau_Notification).isSelected();
	}

	@Step("Checking Every day time dropdown for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab")
	public String getEverydaytime_Enable_Remote_Desktop() {
		Select select = new Select(driver.findElement(check_time));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Checking Every day dropdown for the Enable_System_Updates in the Graphics Arts & Proofing tab of Environment tab")
	public String getEveryday_Enable_Remote_Desktop() {
		Select select = new Select(driver.findElement(check_day));
		return select.getFirstSelectedOption().getText();
	}

	@Step("Verifying the Enable_Remote_Desktop is checked in the Graphics Arts & Proofing tab of Environment tab")
	public boolean verifyEnable_Remote_Desktop() {
		return driver.findElement(enable_Remote_Desktop).isSelected();
	}

	@Step("Verifying the Enable_System_Updates is checked in the Graphics Arts & Proofing tab of Environment tab")
	public boolean VerifyEnable_System_Updates() {
		return driver.findElement(enable_System_Updates).isSelected();
	}
	@Step("Verifying the Enable_System_Updates is checked in the Graphics Arts & Proofing tab of Environment tab")
	public boolean VerifyEnable_System_UpdatesFlame9() {
		return driver.findElement(enable_System_Updatesf9).isSelected();
	}
	@Step("Clicking the Enable_System_Updates manage link in the Graphics Arts & Proofing tab of Environment tab")
	public void clickEnable_System_Updates_Manage() {
		driver.findElement(enable_System_Updates_Manage).click();
	}
	@Step("Clicking the Enable_System_Updates link in the Graphics Arts & Proofing tab of Environment tab")
	public void clickEnable_System_UpdatesFlame9() {
		driver.findElement(enable_System_Updatesf9).click();
	}	
	@Step("Clicking the Graphics Arts & Proofing tab in Environment tab")
	public void clickGraphics_Arts() {
		driver.findElement(grp_arts).click();
	}

	@Step("Clicking the Office and WorkGroup tab in Environment tab")
	public void getofficebtn() {
		driver.findElement(office_WorkGroup).click();
	}

	@Step("Verifying the Office and WorkGroup tab is displayed in Environment page")
	public boolean verifyOffice_WorkGroup() {
		return driver.findElement(office_WorkGroup).isDisplayed();
	}

	@Step("Verifying the Graphics Arts & Proofing tab is displayed in Environment page")
	public boolean verifyGraphics_Arts() {
		return driver.findElement(grp_arts).isDisplayed();
	}

	@Step("Verifying the Production tab is displayed in Environment page")
	public boolean verifyProduction() {
		return driver.findElement(production).isDisplayed();
	}

	@Step("Verifying the Transactional tab is displayed in Environment page")
	public boolean verifyTransactional() {
		return driver.findElement(transactional).isDisplayed();
	}

	@Step("Getting the text of Environment Element in Environment page")
	public String getEnvElementText() {
		return driver.findElement(envElement).getText();
	}

	@Step("Clicking Next button in Environment tab")
	public void clickNextBtnEnv() {
		driver.findElement(nextbtnEnv).click();
	}

	@Step("Clicking Skip button in Environment tab for Production")
	public void clickSkipBtnEnv() {
		driver.findElement(skipbtnEnv).click();
	}
	
	@Step("Clicking Skip button in Environment tab for displayed")
    public boolean clickSkipBtnEnv1() {
           boolean text = false;
           try
           {
           text=driver.findElement(skipbtnEnv).isDisplayed();
           
           }catch(Exception e)
           {
                  //System.out.println(e.getMessage());
           }
           if(text==true)
           {
           return true;
           }else
           {
                  return false;
                  }
    
    }


	@Step("Verifying skip button is displayed or not in environmental page")
	public boolean checkSkipBtnEnv() {
		return driver.findElement(skipbtnEnv).isDisplayed();
	}

	@Step("Clicking Close or Restart button in Environment tab")
	public void clickRestartBtn() {
		driver.findElement(restartbtn).click();
	}
	@Step("Clicking Close or Restart button in Environment tab")
	public void clickRestartBtn2() {
		driver.findElement(restartbtn2).click();
	}

	@Step("Getting the text of Close or Restart button in Environment tab")
	public String getTextRestartBtn() {
		return driver.findElement(restartbtn).getText();
	}

	@Step("Clicking the production  tab of Environment tab")
	public void clickprodunbtn() {
		driver.findElement(poducnbtn).click();
	}
	
	
	@Step("Checking production  tab is present in Environment tab")
	public boolean check_produnbtn() {
		
		if((driver.findElements(poducnbtn)).size()!= 0){
			
			return true;
		}
		return false;
	}

	@Step("Verify the printqueue button in  the  production tab of Environment tab")
	public boolean check_Prod_PrintQueue() {
		return driver.findElement(prodprintqueue).isSelected();
	}

	@Step("Clicking the manage button in  the  production tab of Environment tab")
	public void click_prod_sampleprint() {
		driver.findElement(prodsampleprint).click();
	}

	@Step("checking the Frequency is On Demand  in  the  production tab of Environment tab")
	public boolean check_Prod_ondemand() {
		return driver.findElement(prodondemand).isSelected();
	}

	@Step("Clicking the manage button in  the  production tab of Environment tab")
	public void click_prod_sampleprintcancel() {
		driver.findElement(prodsampleprintcancel).click();
	}

	@Step("checking the Content is Sheet (for any kind of job)  in  the  production tab of Environment tab")
	public boolean check_Prod_sheet() {
		return driver.findElement(prodsheet).isSelected();
	}

	@Step("Verify output try is disabled in  the production tab of Environment tab")
	public String output_try() {
		Select select = new Select(driver.findElement(prodAutoselect));
		return select.getFirstSelectedOption().getAttribute("value");

	}

	@Step("Clicking the manage button in  the  production tab of Environment tab")
	public void click_prod_jobmismatch() {
		driver.findElement(prodenablejobmismatch).click();
	}
	
	@Step("Clicking the Enable job Mismatch button in  the  production tab of Environment tab")
	public void click_prod_jobmismatchFlame9() {
		driver.findElement(prodenablejobmismatchf9).click();
	}

	@Step("Clicking the manage button in  the  production tab of Environment tab")
	public void click_prod_jobmismatch_manage() {
		driver.findElement(prodjobMissmatchManage).click();
	}
	@Step("Clicking the manage button in  the  production tab of Environment tab")
	public void click_prod_sequentialprint_manage() {
		driver.findElement(prodsequentialprintManage).click();
	}
	@Step("verifying time  in  the  production tab of Environment tab")
	public String click_prod_jobmismatch_time() {
		WebElement getTextjobMismatch = driver
				.findElement(prodjobmissmatchTime);
		return getTextjobMismatch.getAttribute("Value");

	}

	@Step("Verify jobmissmatch Action in the production tab of Environment tab")
	public String click_prod_jobmismatch_missmatch() {
		Select select = new Select(driver.findElement(prodjobmissmatchAction));
		return select.getFirstSelectedOption().getText();

	}
	
	@Step("Verify jobmissmatch Action in the production tab of Environment tab")
	public String click_prod_jobmismatch_missmatchFlame9() {
		Select select = new Select(driver.findElement(prodjobmissmatchActionf9));
		return select.getFirstSelectedOption().getText();

	}

	@Step("Clicking system update cancel button in the production tab of Environment tab")
	public void click_prod_systemupdatemanagecancel() {
		driver.findElement(prodjobmissmatchcancel).click();

	}
	@Step("Clicking sequentialprint cancel button in the production tab of Environment tab")
	public void click_prod_sequentialprintmanagecancel() {
		driver.findElement(prodsequentialprintcancel).click();

	}
	
	@Step("Verify  Enable_System_Updates is enabled in the production tab of Environment tab")
	public boolean check_prod_systemupdate() {
		return driver.findElement(preodenablesystem).isSelected();
	}

	@Step("Clicking system update manage  link in the production tab of Environment tab")
	public void click_prod_systemupdatemanage() {
		driver.findElement(prodSystemupdate).click();

	}

	@Step("Verify Checking Every day time dropdown for the Enable_System_Updates is enabled in the production tab of Environment tab")
	public String verify_prod_system_Day() {
		Select select = new Select(driver.findElement(prodSystemupdateday));
		return select.getFirstSelectedOption().getText();

	}

	@Step("Checking Every day time dropdown for the Enable_System_Updates is enabled in the production tab of Environment tab")
	public String verify_prod_system_Time() {
		Select select = new Select(driver.findElement(prodSystemupdatetime));
		return select.getFirstSelectedOption().getAttribute("value");
	}

	@Step("Verifying the Fiery System Updates Notification is checked for the Enable_System_Updates is enabled in the production tab of Environment tab")
	public boolean verify_prod_Fiery_systeupdate() {
		return driver.findElement(prodFierySystemupdate).isSelected();

	}

	@Step("Verifying the Fiery App Updates Notification is checked for the Enable_System_Updates is enabled in the production tab of Environment tab ")
	public boolean verify_prod_Fiery_app_update() {
		return driver.findElement(prodFieryappupdate).isSelected();

	}

	@Step("Verify proxy is disabled in the production tab of Environment tab")
	public boolean enable_prod_proxy() {
		return driver.findElement(prodEnableproxy).isSelected();

	}

	@Step("Verify Sequential print is enabled in the production tab of Environment tab")
	public boolean enable_prod_sequentialprintFlame9() {
		return driver.findElement(prodsequentialPrintFlame9).isSelected();

	}
	@Step("Verify Sequential print is enabled in the production tab of Environment tab")
	public boolean enable_prod_sequentialprint() {
		return driver.findElement(prodsequentialPrint).isSelected();

	}

	@Step("Verify Sequential print is enabled in the Transactional tab of Environment tab")
	public boolean checkSequentialprint() {
		return driver.findElement(prodsequentialPrint).isSelected();

	}
	@Step("Verify Sequential print is enabled in the Transactional tab of Environment tab")
	public boolean checkSequentialprintFlame9() {
		return driver.findElement(server_enable_sequential_print).isSelected();

	}

	@Step("Clicking Sequential print in the Transactional tab of Environment tab")
	public void clickSequentialprint() {
		driver.findElement(prodsequentialPrint).click();

	}

	@Step("Verify Set page device in the production tab of Environment tab")
	public boolean enable_prod_setpagedevice() {
		return driver.findElement(prodenablesetpagedevice).isSelected();

	}

	@Step("Verify Enable proxy  button in  the  production  tab of Environment tab")
	public boolean enable_prod_jdf() {
		return driver.findElement(prodjdf).isSelected();

	}
	@Step("Verify Enable proxy  button in  the  production  tab of Environment tab")
	public boolean enable_prod_jdfFlame9() {
		return driver.findElement(prodjdff9).isSelected();

	}

}
