package com.fsw.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

/**
 * Login into FSW
 *
 */
public class ServerPage extends Basepage

{
	public ServerPage(WebDriver driver, String browser) {
		super(driver, browser);
		// TODO Auto-generated constructor stub
	}

	WebDriverWait wait = new WebDriverWait(driver, 10);
  By finishBtn=By.xpath("//button[contains(text(),'Finish')]");
       By closeBtn=By.xpath("//button[@class='restartActiveButton']");

	By nextbtnSer = By.xpath(".//*[@id='next']");
	By backbtn = By.xpath(".//*[@id='back']");
	By serverElement = By.xpath(".//*[@id='content']/h2");
	By serverName= By.id("server");
	By serverNamef9= By.id("server_name");
	
	//newley added snippet
	By serverProductName= By.id("id-server-name-header");

	@Step("Verifying the next button is enabled in Server tab")
	public boolean verifyNextBtnSer() {
		return driver.findElement(nextbtnSer).isEnabled();
	}
	
	@Step("Getting the ServerName in Server Page")
	public String getServerName() {
		return driver.findElement(serverName).getAttribute("value");
	}
	
	@Step("Getting the ServerName in Server Page")
	public String getServerNameFlame9() {
		return driver.findElement(serverNamef9).getAttribute("value");
	}
	//newley added snippet
	@Step("Getting the ServerName in Server Page")
	public String getProductServerName() {
		return driver.findElement(serverName).getText();
	}

	@Step("Getting the text of Server Element in Server page")
	public String getServerElementText() {
		return driver.findElement(serverElement).getText();
	}

	@Step("Clicking next button in Server tab")
	public void clickNextBtnSer() {
		driver.findElement(nextbtnSer).click();
	}

	@Step("Clicking back button in Server tab")
	public void clickbackBtnSer() {
		driver.findElement(backbtn).click();
	}
@Step("Clicking on Finish button in server tab")
       public void clicFinBtnSer() {
              driver.findElement(finishBtn).click();
       }
       
       @Step("Clicking close button in Server tab")
       public void clickCloseBtnSer() {
              driver.findElement(closeBtn).click();
       }


}
