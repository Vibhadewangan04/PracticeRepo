package grp.art;

public class Demo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

				
			       int i, m=0, flag=0;
			       
			       int n=7;
			       
			       m= n/2;
			       
			     
			            System.out.println( m + " this is m"); 
			            
	

	}

}
