package grp.art;

import java.util.*;  
public class HashMapExample  
{  
	public static void main(String args[])  
	{  
		//creating object of HashMap  
		HashMap<String, Integer> hm= new HashMap<String, Integer>();  
		//adding key-value pair  
		hm.put("John", 23);  
		hm.put("Richard", 21); 
		hm.put("Monty", 27 );  
		hm.put("Devid", 19);  
		System.out.println("Before adding duplicate keys: ");  
		System.out.println(hm);  
		
		//adding duplicate keys  
		hm.put("Monty", 25);    //replace the Monty's previous age  
		hm.put("Devid", 26);  //duplicate keys- but at last again duplicate key is there that latest will get print
		hm.put("Devid", 19);  // duplicate keys - value both are duplicate
		hm.put("Devid", 18);  //duplicate keys. latest key-value get print
		System.out.println("After adding duplicate keys: ");  
		System.out.println(hm);  
		
		
		//adding null keys  
				hm.put("Monty", 25);    //replace the Monty's previous age  
				hm.put(null, 31);  //duplicate null keys- but at next again duplicate null key is there that latest will get print
				hm.put(null, 32);  //duplicate null keys - this is latest this will get print
				hm.put("key1has nullValue", null); 
				hm.put("key2has nullValue", null); // duplicate value, both null duplicate get print
				
				System.out.println("After adding null keys and value: ");  
				System.out.println(hm);  
	}  
}  



/*
 * output 
 * Before adding duplicate keys: 
{Monty=27, John=23, Richard=21, Devid=19}
After adding duplicate keys: 
{Monty=25, John=23, Richard=21, Devid=18}
After adding null keys and value: 
{Monty=25, null=32, key1has nullValue=null, John=23, Richard=21, Devid=18, key2has nullValue=null}

 */