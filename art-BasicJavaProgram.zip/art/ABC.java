package grp.art;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.Color;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ABC {

	public static void main(String[] args) {

		
	//	int[] array = new int[] {1,2,3, 3, 4, 5, 7, 7};
		String s = "this is java";
		char[] array = s.toCharArray();
		
		int count;
	
		
		System.out.print("duplicate value : ");
	     
	      for(int i = 0; i<array.length; i++ ) {
	    	  count = 1;
	    	  
	         for(int j = i+1 ; j<array.length; j++) {
	        	 
	        	 
	            if(array[i]==array[j] && array [i] != ' ') {
	            	count++;
	            	array[j] = '0';
	            	
	            }
	               

	         if (count > 1 && array[i] != '0') 
	        	 System.out.print(array[j] + ", ");

	         
	         
	      }
	}
}
}