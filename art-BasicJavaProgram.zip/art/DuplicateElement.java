package grp.art;

public class DuplicateElement {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int[] array = new int[] {1,2,3, 3, 4, 5, 7, 7};
		
		System.out.print("duplicate value : ");
	     
	      for(int i = 0; i<array.length; i++ ) {
	    	
	         for(int j = i+1 ; j<array.length; j++) {	        	 
	            if(array[i]==array[j] ) {

	        	 System.out.print(array[j] + ", ");


	}

}
}
	}
}