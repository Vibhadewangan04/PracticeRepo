package grp.art;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class Class {

		@Test
		public void test(){
		
//		public static void main(String[] args) {
			
		 System.setProperty("webdriver.chrome.driver", "src/test/ExeFiles/chromedriver.exe");
	     WebDriver driver = new ChromeDriver();
	   
	//     driver.navigate().to("https://teams.microsoft.com/_?culture=en-in&country=IN&lm=deeplink&lmsrc=homePageWeb&cmpid=WebSignIn#");  
	     
	     driver.navigate().to("https://teams.microsoft.com/_?culture=en-in&country=IN&lm=deeplink&lmsrc=homePageWeb&cmpid=WebSignIn#/conversations/19:acd7ae9e3a4f4c519b1e882c1ee21a2b@thread.v2?ctx=chat");
	     driver.manage().window().maximize();
	     Actions actions = new Actions(driver);
	     
	     
	   /*driver.findElement(By.xpath("//*[@href='/registration/signin?ref=nv_generic_lgin']")).click();
	     System.out.println("Clicked on sign in to create new account");
	  
	     driver.findElement(By.xpath("//*[text()='Create a New Account']")).click();
	     
	     actions.sendKeys("xyz").sendKeys(Keys.TAB).sendKeys("vibhadewangan@gmail.com").sendKeys(Keys.TAB).sendKeys("password").sendKeys(Keys.TAB).sendKeys("password").sendKeys(Keys.TAB).click().perform();
	     System.out.println("successfully created new account");*/
	     
	    driver.navigate().refresh();
	    driver.navigate().to("https://teams.microsoft.com/_?culture=en-in&country=IN&lm=deeplink&lmsrc=homePageWeb&cmpid=WebSignIn#");
		
		
	    driver.findElement(By.xpath("//img[@class='user-picture']")).click();
	    
	    driver.findElement(By.xpath("//span[@id='personal-skype-status-text']")).click();
	    
	    driver.findElement(By.xpath("//*[text()='Busy']")).click();

	   //   (//*[text()='Available'])[2]
	 
	    
	    
	}

}
