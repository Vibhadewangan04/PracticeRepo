package grp.art;

import java.util.Scanner;

public class ScannerClassExample {
		
		public static void main(String args[]){                       
	          String s = "Hello, This is JavaTpoint.";  
	          //Create scanner Object and pass string in it  
	          Scanner scan = new Scanner(s);  
	          //Check if the scanner has a token  
	          System.out.println("Boolean Result: " + scan.hasNext());  
	          //Print the string  
	          System.out.println("String: " +scan.nextLine());  
	          scan.close();           
	          
	          System.out.println("--------Enter Your Details-------- ");  
	          Scanner sc = new Scanner(System.in);  
	          System.out.print("Enter your name: ");    
	          String name = sc.next();   
	          System.out.println("Name: " + name);   
	          
	          System.out.print("Enter your favourite number: ");  
	          int i = sc.nextInt();  
	          System.out.println("number: " + i);  
	          
	          System.out.print("Enter your salary: ");  
	          double d = sc.nextDouble();  
	          System.out.println("Salary: " + d);         
	          sc.close();           
	
	
	
	
	}

}
