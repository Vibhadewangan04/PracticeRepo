package grp.art;

public class HoursToSeconds {

		// Function to convert hours
		// into minutes and seconds
		static void ConvertHours_ToMinutesSeconds(int n)
		{
		int minutes, seconds;

			minutes = n * 60;
			seconds = n * 3600;

			System.out.println( "Minutes = " + minutes + ", Seconds = " + seconds);
		}
		
		
		static void ConvertHours_MinutesToSeconds(int h, int m, int s)
		{
		int minutesToS, HoursToS, SecondsTos;

			minutesToS = m * 60;
			HoursToS = h * 3600;
			SecondsTos = s*1;
			
		int total = 	minutesToS + HoursToS + SecondsTos ;

			System.out.println("Total seconds is : "+ total);
			
			
			// divide by 2 total seconds result 
			
			int FinalResult = total / 2 ;
			System.out.println( "final result " + FinalResult);
		}

			public static void main (String[] args) {
			int n = 5;
			ConvertHours_ToMinutesSeconds(n);


			String ss = "1h 1m 2s";
			
			int h = 1;
			int m = 1;
			int s = 2;
			ConvertHours_MinutesToSeconds(h,  m ,  s);
			}


		//	private static void ConvertHours_MinutesToSeconds(int h, int m, int s) {
				// TODO Auto-generated method stub
				
			}
			
				
	

