package grp.art;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

// read intersection also
/*Input : arr1[] = {1, 3, 4, 5, 7}
arr2[] = {2, 3, 5, 6} 
Output : Union : {1, 2, 3, 4, 5, 6, 7} 
 Intersection : {3, 5}  // intersect means common in both means duplicate values
*/

public class UnionIntersectionTwoarrays {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// Integer array 1
		Integer[] array1 = { 1, 2, 3, 4, 5, 6, 7, 8 };
		System.out.println("Array 1 : " + Arrays.toString(array1));

		// Integer array 2
		Integer[] array2 = { 2, 4, 6, 8, 10, 12, 14 };
		System.out.println("Array 2 : " + Arrays.toString(array2));

		// creating a new Set
		Set<Integer> unionOfArrays = new HashSet<Integer>();

		// adding the first array to set
		unionOfArrays.addAll(Arrays.asList(array1));

		// adding the second array to set
		unionOfArrays.addAll(Arrays.asList(array2));

		// converting set to array.
		Integer[] unionArray = {};
		unionArray = unionOfArrays.toArray(unionArray);

		// printing the union of two arrays.
		System.out.println("Union of two arrays: " + Arrays.toString(unionArray));
		
		
		
		System.out.print("Intersection of the two arrays : ");
	     
	      for(int i = 0; i<array1.length; i++ ) {
	         for(int j = 0; j<array2.length; j++) {
	            if(array1[i]==array2[j]) {
	               System.out.print(array2[j] + ", ");

	            }
	         }

	      
	      }
	      
	}
}