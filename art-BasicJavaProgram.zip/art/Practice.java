package grp.art;

/*public class Practice {

		public static void main(String args[]) 
		{ 
		     int num =1, row =4;
		     
		      for(int i=1; i<=row; i++) // for row
		          {           
		          
		          for(int j=1; j<=i; j++) //  inner loop for columns
		          {     
		          	
		              System.out.print(num+ " "); 
		              num++;
		          }   
		          
		          System.out.println(); // ending line after each row
		      } 
		}
		
}*/


/*public class Practice {

public static void main(String args[]) 
{ 
	
       int i, j, k, row= 4, num=10;
       
        for( i=1; i<=row; i++) // for row
            { 
        	
        	for (k=row; k>=i; k--)         
			{  
				System.out.print(" ");   
			}   
            
            for( j=1; j<=i; j++) //  inner loop for columns
            { 
               System.out.print(num+ "" );  
               num--;
            }   
            	            
         System.out.println(); // ending line after each row
        } 
    }
}
	
	*/






// prime number program

public class Practice {

	public static void main(String args[]) 
	{ 

		int i, m=0, flag=0;

		int n=61;

		m= n/2;

		if (n==0|n==1) {  
			flag = 1;
			System.out.println(n + " is not prime"); 

		} 



		else {
			for (i=2; i<=m; i++)
				if (n%i==0) 
				{
					System.out.println(n+ " is not prime");

					flag=1;
					break;	   
				}

		}	  

		if (flag==0) {
			System.out.println(n+ " is prime");
		}	              

	}  
}
	

/*package grp.art;

public class Practice {
	
	
	static int i;   //run fine,  if remove static gets compile time error
	static String s = "qwe";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("i:" +i);
		System.out.println("string:" +s);
		
	}
}
*/

/*output
i:0
string:qwe
*/

/*
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.JavascriptExecutor;


//how to check/validate web page is loaded completely in selenium

public class ABC{
   public static void main(String[] args) {
	   
	   System.setProperty("webdriver.chrome.driver", "../art/driversExe/chrome97/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
	   

      String url = "https://www.tutorialspoint.com/index.htm";
      driver.get(url);
      
      driver.manage().window().maximize();
      
      // Javascript executor to return value
      JavascriptExecutor j = (JavascriptExecutor) driver;
      j.executeScript("return document.readyState").toString().equals("complete");
      // get the current URL
      String s = driver.getCurrentUrl();
      // checking condition if the URL is loaded
      if (s.equals(url)) {
         System.out.println("Page Loaded");
         System.out.println("Current Url: " + s);
      }
      else {
         System.out.println("Page did not load");
      }
    //  driver.quit();
   }

}*/

/*output
Page Loaded
Current Url: https://www.tutorialspoint.com/index.htm

*/




/*package grp.art;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class ABC {
	
	static int i =10;  // global variable
	
	
	public static void fun() {
		
	//	int i =20; // local method variable
		System.out.println("fun i is " + i);
		
		
	}

	public static void main(String[] args) {
		
		System.out.println("i is " + i);
		
		fun();
		
		
	}*/
/*	
//	output  if  ini i=20 commented
	i is 10
	fun i is 10
	
	
//	output  if  ini i=20 not commented
	i is 10
	fun i is 20*/



/*
//copy array to another array
public class ABC {


	public static void main(String[] args) {
		
	     //copy array to another array
            //Initialize array     
             
       int [] arr1 = new int [] {1, 2, 3, 4, 5};     
        //Create another array arr2 with size of arr1    
       int arr2[] = new int[arr1.length];    
       //Copying all elements of one array into another    
       for (int i = 0; i < arr1.length; i++) {     
           arr2[i] = arr1[i];     
       }      
        //Displaying elements of array arr1     
       System.out.println("Elements of original array: ");    
       for (int i = 0; i < arr1.length; i++) {     
          System.out.print(arr1[i] + " ");    
       }     
           
       System.out.println();    
       
       
       
     //Displaying elements of array arr2     
       System.out.println("Elements of new array: ");    
       for (int i = 0; i < arr2.length; i++) {     
          System.out.print(arr2[i] + " ");    
       }     
	      
	}
}

*/



/*
 * Elements of original array: 1 2 3 4 5 Elements of new array: 1 2 3 4 5
 */
