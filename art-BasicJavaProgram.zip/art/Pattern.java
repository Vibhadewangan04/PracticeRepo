package grp.art;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.Color;

import io.github.bonigarcia.wdm.WebDriverManager;

//read this way row increasing then i++,if column increasing then j++, space incre then k++
//if column decreasing then after each row the j--, space dec after each row then k-- 

/*public class Pattern {
 
	
	public static void main(String args[]) 
    { 
       
   //    Scanner sc = new Scanner(System.in);
  //   System.out.println("Enter the number of rows: ");
	 
	//    int rows = sc.nextInt(); 
       
        for(int i=0; i<5; i++) // for row
            {           
            
            for(int j=0; j<=i; j++) //  inner loop for columns
            {     
            	
                System.out.print("* "); // print star
            }   
            
            System.out.println(); // ending line after each row
        } 
        
    //    sc.close();
    } */

/*// output
*
* *
* * *
* * * **/


//2nd
/*public class Pattern {

public static void main(String args[]) 
{ 
       int num =10, row =4;
       
        for(int i=1; i<=row; i++) // for row
            {           
            
            for(int j=1; j<=i; j++) //  inner loop for columns
            {     
            	
                System.out.print(num+ " "); 
                num--;
            }   
            
            System.out.println(); // ending line after each row
        } 
}	
}*/

/*output
10 
9 8 
7 6 5 
4 3 2 1 
*/


// read this way if row increasing then i++, if column increasing then j++
// if space use k
//3rd read this way
/*public class Pattern {

	public static void main(String args[]) 
    { 
		
	       int i, j, row= 5;
	       
	        for( i=1; i<=row; i++) // for row
	            {           
	            
	            for( j=row; j>=i; j--) //  inner loop for columns
	            {     
	            	
	                System.out.print("*"); 
	              
	            }   
	            
	            System.out.println(); // ending line after each row
	        } 
	    }  
}*/
/*output
*****
****
***
**
*/


//4th read this way
/*public class Pattern {

	public static void main(String args[]) 
    { 
		
	       int i, j, row= 4, num=10;
	       
	        for( i=1; i<=row; i++) // for row
	            {           
	            
	            for( j=row; j>=i; j--) //  inner loop for columns
	            {     
	            	
	                System.out.print(num+ " "); 
	                num--;
	            }   
	            
	            System.out.println(); // ending line after each row
	        } 
	    }  
}
*/
/*//output
10 9 8 7 
6 5 4 
3 2 
1 */



//read this way row increasing then i++,if column increasing then j++, space incre then k++
//if column decreasing then after each row the j--, space dec after each row then k-- 

//5th - read this way
/*public class Pattern {

	public static void main(String args[]) 
    { 
		
	       int i, j, k, row= 5, num=10;
	       
	        for( i=1; i<=row; i++) // for row
	            { 
	        	
	        	for (k=row; k>=i; k--)         
				{  
					System.out.print(" ");   
				}   
	            
	            for( j=1; j<=i; j++) //  inner loop for columns
	            { 
	               System.out.print("*");  
	            }   
	            	            
	         System.out.println(); // ending line after each row
	        } 
	    }  
}*/
/*	
output
     *
    **
   ***
  ****
 *****
 */


//6th
/*public class Pattern {

	public static void main(String args[]) 
    { 
		//will work for 4 row and num-10 for more row and num need to chnage k,j loop also
		int i, j, k, row = 4, num=10;     
		
		for (i=0; i<row; i++)   //Outer loop work for rows  
		{  
			for (k=row; k>=i; k--)         
			{  
				System.out.print(" ");   
			}   
	
			for (j=0; j<=i; j++ )   
			{        
				System.out.print(num);   
				num--;
			}  
			
		//throws the cursor in a new line after printing each line  
		System.out.println();   
		}   

    }	
}*/

/*output
    10
   98
  765
 4321
*/






//dont read this way below is another way
/*public class Pattern {

	public static void main(String args[]) 
    { 
		   
		
		int i, j, k, rows = 10;
	    for ( i= rows; i>=1; i--)
	    {
	        for ( k=rows; k>=i; k--)
	        {
	            System.out.print(" ");
	        }
	        for (j=1; j<=i; j++)
	        {
	            System.out.print("*");
	        }
	        System.out.println();
	    }
	
	}
}*/


/*output
*****
 ****
  ***
   **
    *
*/

//dont read this 2nd way. in below 7th number have some diff way 
/*	
		int i, j, k, rows = 5;
	    for ( i= 1; i<= rows ; i++)
	    {
	        for ( k=1; k<=i; k++)
	        {
	            System.out.print(" ");
	        }
	        for (j=1; j<=rows-i; j++)
	        {
	            System.out.print("*");
	        }
	        System.out.println();

}*/
  


/*output

 ****
  ***
   **
    *

*/


//7th -  3rd way- read this
/*public class Pattern {

	public static void main(String args[]) 
    { 
		
		int i, j, k, rows = 10;
	    for ( i= 1; i<= rows ; i++)
	    {
	        for ( k=1; k<=i; k++)
	        {
	            System.out.print(" ");
	        }
	        for (j=rows; j>=i; j--)
	        {
	            System.out.print("*");
	        }
	        System.out.println();
	    }
	 
	}
}*/
/*
output
****
 ***
  **
   *
*/




// 8th
/*public class Pattern {

	public static void main(String args[]) 
    { 
		
	
	       int i, j, k, row= 4, num=10 ;
	       
	        for( i=1; i<=row; i++) // for row
	          {           
	        	for ( k=1; k<=i; k++)
		        {
		            System.out.print(" ");
		        }
		        for (j=row; j>=i; j--)
		        {
		            System.out.print(num); // num or "1" or "*"
		            num--;
		        }  
	            
	            System.out.println(); // ending line after each row
	        } 
	    }  
}*/


/*output
10987
  654
   32
    1
*/




//9th
/*public class Pattern {

	public static void main(String args[]) 
    { 
		
	//	give num = 2,3,4,5,6 any number to print below pattern
	       int i, j, k, row= 5, num=1 ;
	       
	        for( i=1; i<=row; i++) // for row
	          {           
	        	for ( k=row; k>=i; k--)
		        {
		            System.out.print(" ");
		        }
		        for (j=1; j<=i; j++)
		        {
		            System.out.print(num); // num or "1" or "*"
		            
		        }  
	            
	            System.out.println(); // ending line after each row
	        } 
	    }  
}*/

/*output
     1
    11
   111
  1111
 11111
*/
 


//10th half top pyramid
/*public class Pattern {

	public static void main(String args[]) 
  { 
		
	//	give num = 2,3,4,5,6 any number to print below pattern
	       int i, j, k, row= 8, num=1 ;
	       
	        for( i=1; i<=row; i++) // for row
	          {           
	        	for ( k=row; k>=i; k--)
		        {
		            System.out.print(" ");
		        }
		        for (j=1; j<=i; j++)
		        {
		        	   // one space after star to print like pyramid pattern
		            System.out.print(num +" "); // num or "1" or "*"      
		        }  
	            
	            System.out.println(); // ending line after each row
	        } 
	    }  
}
*/

/*output

    1 
   1 1 
  1 1 1 
 1 1 1 1 
1 1 1 1 1 
*/

//11th  half pyramid   // one space after star to print like pyramid pattern

/*
public class Pattern {

	public static void main(String args[]) 
    { 
		
		int i, j, k, rows = 10;
	    for ( i= 1; i<= rows ; i++)
	    {
	        for ( k=1; k<=i; k++)
	        {
	            System.out.print(" ");
	        }
	        for (j=rows; j>=i; j--)
	        {
	         // one space after star to print link pyramid pattern
	            System.out.print("* ");
	        }
	        System.out.println();
	    }
	 
	}
}*/

/*output
* * * * * 
 * * * * 
  * * * 
   * * 
    * 
*/




//full pyramid to make this join 10th,11th loops code 
//in this output of mid 2 line will same width to chnage that start 2nd loop from row 1 extra and extra space


/*public class Pattern {

	public static void main(String args[]) 
    { 
		
	//	give num = 2,3,4,5,6 any number to print below pattern
	       int i, j, k, row= 6, num=1 ;
	       
	        for( i=1; i<=row; i++) // for row
	          {           
	        	for ( k=row; k>=i; k--)
		        {
		            System.out.print(" ");
		        }
		        for (j=1; j<=i; j++)
		        {
		        	   // one space after star to print like pyramid pattern
		            System.out.print("* "); // num or "1" or "*"      
		        }  
	            
	            System.out.println(); // ending line after each row
	        } 
	        
	              		
	        //		int i, j, k, row = 5;
	 
	        	    for ( i= 1; i<= row ; i++)
	        	    {
	        	        for ( k=1; k<=i; k++)
	        	        {
	        	            System.out.print(" ");
	        	        }
	        	        for (j=row; j>=i; j--)
	        	        {
	        	         // one space after star to print link pyramid pattern
	        	            System.out.print("* ");
	        	        }
	        	        System.out.println();
	        	    }
	        	 
	        	}
	        }
	        */

/*output
	* 
   * * 
  * * * 
 * * * * 
* * * * * 
* * * * * 
 * * * * 
  * * * 
   * * 
    * 
    */



/*public class Pattern {

	public static void main(String args[]) {
   		
	//	give num = 2,3,4,5,6 any number to print below pattern
	       int i, j, k, row= 6, num=1 ;
	       
	        for( i=1; i<=row; i++) // for row
	          {           
	        	for ( k=row; k>=i; k--)
		        {
		            System.out.print(" ");
		        }
		        for (j=1; j<=i; j++)
		        {
		        	   // one space after star to print like pyramid pattern
		            System.out.print(j+" "); // num or "1" or "*"      
		        }  
	            
	            System.out.println(); // ending line after each row
	        } 
             
	        for( i=row-1; i>=1; i--) // for row
	          {           
	        	for ( k=row; k>=i; k--)
		        {
		            System.out.print(" ");
		        }
		        for (j=1; j<=i; j++)
		        {
		        	   // one space after star to print like pyramid pattern
		            System.out.print(j+" "); // num or "1" or "*"      
		        }  
	          }
		        System.out.println();
	          
	}
}

}*/
	        
	              		
	       /* //		int i, j, k, row = 5;
	 
	        	    for ( i= 1; i<= row ; i++)
	        	    {
	        	        for ( k=1; k<=i; k++)
	        	        {
	        	            System.out.print(" ");
	        	        }
	        	      //  for (j=row; j>=i; j--)
	        	          for (j=1; j<row; j++)
	        	        {
	        	         // one space after star to print link pyramid pattern
	        	            System.out.print(j+" ");
	        	        }
	        	        System.out.println();
	        	    }
	        	 
	        	}
	        }
	        
*/







//prime number program

/*public class Pattern {

	public static void main(String args[]) 
	{ 

		int i, m=0, flag=0;

		int n=61;

		m= n/2;

		if (n==0|n==1) {  
			flag = 1;
			System.out.println(n + " is not prime"); 

		} 



		else {
			for (i=2; i<=m; i++)
				if (n%i==0) 
				{
					System.out.println(n+ " is not prime");

					flag=1;
					break;	   
				}

		}	  

		if (flag==0) {
			System.out.println(n+ " is prime");
		}	              

	}  
}*/


/*
package grp.art;


//https://www.geeksforgeeks.org/java-program-to-count-the-occurrence-of-each-character-in-a-string-using-hashmap/

		import java.io.*;
		import java.util.*;
	 public	class OccurenceOfCharInString {
			static void characterCount(String inputString)
			{
				// Creating a HashMap containing char
				// as a key and occurrences as a value
	HashMap<Character, Integer> charCountMap= new HashMap<Character, Integer>();

				// Converting given string to char array

				char[] strArray = inputString.toCharArray();

				// checking each char of strArray
				for (char c : strArray) {
					if (charCountMap.containsKey(c)) {

						// If char is present in charCountMap,
						// incrementing it's count by 1
						charCountMap.put(c, charCountMap.get(c) + 1);
					}
					else {

						// If char is not present in charCountMap,
						// putting this char to charCountMap with 1 as it's value
						charCountMap.put(c, 1);
					}
				}

				// Printing the charCountMap
				for (Map.Entry entry : charCountMap.entrySet()) {
					System.out.println(entry.getKey() + " " + entry.getValue());
				}
			}

			// Driver Code
			public static void main(String[] args)
			{
				String str = "This is vibha";
				characterCount(str);
			}
	}
	 
	 */
	 
/*	  2
	  a 1
	  b 1
	  s 2
	  T 1
	  v 1
	  h 2
	  i 3
*/
	

/*
//reverse string - output is : Java is This 
public static void main(String[] args){
	
	String input = "This is Java";
	String output = "";

 String[]  array = input.split(" ");

for(int i= array.length-1;  i>=0 ; i--)
 {
output = output+ array[i] + " ";
 }

System.out.println("output is : "+output);

*/










// to print color and validate color of web page element	 
	 
/*	 
    WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();		
     driver.get("https://www.tutorialspoint.com/about/about_careers.htm");
     // identify text
     WebElement t = driver.findElement(By.tagName("h1"));
     //obtain color in rgba
     String s = t.getCssValue("color");
     // convert rgba to hex
     String c = Color.fromString(s).asHex();
     System.out.println("Color is :" + s);
     System.out.println("Hex code for color:" + c);
     driver.quit();
		
   */  
	
//	Map<Integer,String> map=new HashMap<Integer,String>();//Creating HashMap    
//	   map.put(1,"Mango");  //Put elements in Map  
//	   map.put(1,"Apple");    
//	   map.put(3,"Banana");   
//	   map.put(4,"Grapes");   
//	
//	 
//	   System.out.println(map.get(1));   //   Apple , new initialize value will get print

 
//String name = "qwe";  // below 2 line is fine
//Object x = name;

//error will get for below 		
//	 Object x = "david";
//	 String name = x;



//diff between size(), getSize() methods

//driver.get("https://www.amazon.com/");
//List <WebElement> link = driver.findElements(By.tagName("a"));
//int size = link.size();  	    
//WebElement logo = driver.findElement(By.id("nav-logo-sprites"));
//Dimension getSize=  logo.getSize();
//System.out.println(size); // returns list of elements (count)
//System.out.println(getSize); // return Dimension- width and height of the target WebElement


//RemoveSpecialCharacter from given string - https://www.javatpoint.com/how-to-remove-special-characters-from-string-in-java
 
/*String str= "This#string%contains^special123*characters&."; 
			System.out.println("string with special chars : " + str);  
			
			str = str.replaceAll("[^a-zA-Z0-9]", " ");  
			System.out.println("string w/o special chars : " + str);  
			
			str = str.replaceAll("[^a-zA-Z]", " ");  
			System.out.println("string w/o special chars and number: " + str);  
			
			str = str.replaceAll("[^a-z]", " ");  
			System.out.println("string w/o special chars and caps, number : " + str);			
			}  
}
/*
 * output 
 * string with special chars : This#string%contains^special123*characters&. 
 * string w/o special chars : This string contains special123 characters
 * string w/o special chars and number: This string contains special characters
 * string w/o special chars and caps,number : his string contains special characters
 */


