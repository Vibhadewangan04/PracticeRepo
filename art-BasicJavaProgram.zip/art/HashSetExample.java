package grp.art;

import java.util.*;  
public class HashSetExample  
{  
	public static void main(String args[])  
	{  
		//creating object of HashSet   
		HashSet<String> hs= new HashSet<String>();  
		
		//adding values to HashSet  
		hs.add("Java");  
		hs.add("Python");  
		hs.add("C++");  
		hs.add("C");  
		System.out.println("Before adding duplicate and null values: ");  
		System.out.println(hs);  
		
		//adding duplicate values 
		hs.add("Java");  
		hs.add("Java");  
		hs.add("Python"); // duplicate values not allow
		hs.add("Python");  
		hs.add("C");  
		System.out.println("After adding duplicate values: ");  
		System.out.println(hs); 
		
		//adding null values  
		hs.add(null);   // it allows only single null value
		hs.add(null);  //duplicate null value
		System.out.println("After adding null values: ");  
		System.out.println(hs);  
	}  
}  

/*
 * output
 * Before adding duplicate and null values: 
 * [Java, C++, C, Python] 
 * After adding duplicate values:
 * [Java, C++, C, Python]
 * After adding null values: 
 * [null, Java, C++, C, Python]
 */		
		