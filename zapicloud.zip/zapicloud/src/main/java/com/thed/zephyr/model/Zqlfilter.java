/**
 * Created by manoj.behera on 22-Nov-2016.
 */
package com.thed.zephyr.model;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONObject;

/**
 * @author manoj.behera 22-Nov-2016
 *
 */
public class Zqlfilter {
	private String apiType;
	private String zql ;
	private String name;
	private String description;
	private boolean favorite;
	private String sharePerm ;
	private String id;
	private String owner;
	private boolean byUser;
	private boolean fav;
	private int offset;
	private int size;
	/**
	 * @return the size
	 */
	public int getSize() {
		return size;
	}
	/**
	 * @param size the size to set
	 */
	public void setSize(int size) {
		this.size = size;
	}
	/**
	 *
	 * @author Created by manoj.behera on 26-Nov-2016.
	 */
	public Zqlfilter(String apiType) {
		this.apiType = apiType;
	}
	public Zqlfilter() {
		super();
	}
	
	
	
	
	/**
	 * @return the byUser
	 * Created by manoj.behera on 26-Nov-2016.
	 */
	public boolean isByUser() {
		return byUser;
	}
	/**
	 * @param byUser the byUser to set
	 * @author Created by manoj.behera on 26-Nov-2016.
	 */
	public void setByUser(boolean byUser) {
		this.byUser = byUser;
	}
	/**
	 * @return the fav
	 * Created by manoj.behera on 26-Nov-2016.
	 */
	public boolean isFav() {
		return fav;
	}
	/**
	 * @param fav the fav to set
	 * @author Created by manoj.behera on 26-Nov-2016.
	 */
	public void setFav(boolean fav) {
		this.fav = fav;
	}
	/**
	 * @return the offset
	 * Created by manoj.behera on 26-Nov-2016.
	 */
	public int getOffset() {
		return offset;
	}
	/**
	 * @param offset the offset to set
	 * @author Created by manoj.behera on 26-Nov-2016.
	 */
	public void setOffset(int offset) {
		this.offset = offset;
	}
	/**
	 * @param owner the owner to set
	 * @author Created by manoj.behera on 26-Nov-2016.
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * @return the zql
	 * Created by manoj.behera on 22-Nov-2016.
	 */
	public String getZql() {
		return zql;
	}
	/**
	 * @param zql the zql to set
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	public void setZql(String zql) {
		this.zql = zql;
	}
	/**
	 * @return the name
	 * Created by manoj.behera on 22-Nov-2016.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the description
	 * Created by manoj.behera on 22-Nov-2016.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @param description the description to set
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the favorite
	 * Created by manoj.behera on 22-Nov-2016.
	 */
	public boolean isFavorite() {
		return favorite;
	}
	/**
	 * @param favorite the favorite to set
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	public void setFavorite(boolean favorite) {
		this.favorite = favorite;
	}
	/**
	 * @return the sharePerm
	 * Created by manoj.behera on 22-Nov-2016.
	 */
	public String getSharePerm() {
		return sharePerm;
	}
	/**
	 * @param sharePerm the sharePerm to set
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	public void setSharePerm(String sharePerm) {
		this.sharePerm = sharePerm;
	}
	/**
	 * @return the id
	 * Created by manoj.behera on 22-Nov-2016.
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param id the id to set
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	public void setId(String id) {
		this.id = id;
	}
	
	/**
	 * @return the owner
	 * Created by manoj.behera on 26-Nov-2016.
	 */
	public String getOwner() {
		return owner;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	@Override
	public String toString() {
		JSONObject zqlfilterJson = new JSONObject();
		
		if("getZqlFilters".equals(this.apiType)){
			zqlfilterJson.put("byUser", this.byUser);
			zqlfilterJson.put("fav", this.fav);
			if(this.owner != null){
				zqlfilterJson.put("owner", this.owner);
			}
		}else if ("searchZQLFilters".equals(this.apiType)) {
			if(! StringUtils.isBlank(this.name)){
				zqlfilterJson.put("name", this.name);
			}
			if(! StringUtils.isBlank(this.sharePerm) ){
				zqlfilterJson.put("sharePerm", this.sharePerm);
			}
			if(! StringUtils.isBlank(this.owner)){
				zqlfilterJson.put("owner", this.owner);
			}
			//zqlfilterJson.put("offset", this.offset);
			if(this.size != 0){
				zqlfilterJson.put("size", this.size);
			}
			
		}else{
			if(this.zql != null){
				zqlfilterJson.put("zql", this.zql);
			}
			if(this.name != null){
				zqlfilterJson.put("name", this.name);
			}
			if(this.description != null){
				zqlfilterJson.put("description", this.description);
			}
			
			zqlfilterJson.put("favorite", this.favorite);
			
			if(this.sharePerm != null){
				zqlfilterJson.put("sharePerm", this.sharePerm);
			}
			if(this.id != null){
				zqlfilterJson.put("id", this.id);
			}
			if(this.owner != null){
				zqlfilterJson.put("owner", this.owner);
			}
		}
		
		return zqlfilterJson.toString();
	}
	
}
