/**
 *
 */
package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

/**
 * @author poornachandra
 *
 */
public class CopyFilter extends BaseTest {

	JwtGenerator jwtGenerator = null;
	String zql = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
/**
 * Test case - 1
 * Copy ZQL filter "Zql":"project = projectName"
 */

// copy ZQL filter when filter has: "Zql":"project = IE"
@Test(priority = 1)
	public void test1_copyZqlFilter_when_filter_is_created_by_project_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = "+Config.getValue("projectKey"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 2
 * Copy ZQL filter "Zql":"project != projectName"
 */
// copy ZQL filter when filter has: "Zql":"project != IE"
@Test(priority = 2)
	public void test2_copyZqlFilter_when_filter_is_created_by_project_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project != "+Config.getValue("projectKey"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 3
 * Copy ZQL filter "Zql":"project is not Empty"
 */
	// copy ZQL filter when filter has: "Zql":"project is not Empty"
	@Test(priority = 3)
	public void test3_copyZqlFilter_when_filter_is_created_by_project_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is not EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 4
 * Copy ZQL filter: "Zql":"project is EMPTY"
 */

// copy ZQL filter when filter has: "Zql":"project is Empty"
@Test(priority = 4)
	public void test4_copyZqlFilter_when_filter_is_created_by_project_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 5
 * Copy ZQL filter: "Zql":"project not in (projectkey,projectkey1)"
 */
// copy ZQL filter when filter has: "Zql":"project not in (IE,Rock)"
@Test(priority = 5)
	public void test5_copyZqlFilter_when_filter_is_created_by_project_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project not in"+ "("+Config.getValue("projectKey")+","+Config.getValue("projectKey1")+")");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 6
 * Copy ZQL filter: "Zql":"project in (projectkey,projectkey1)"
 */

// copy ZQL filter when filter has: "Zql":"project in (IE,Rock,RUBY)"
@Test(priority = 6)
	public void test6_copyZqlFilter_when_filter_is_created_by_project_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project in"+ "("+Config.getValue("projectKey")+","+Config.getValue("projectKey1")+")");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 7
 * Copy ZQL filter: "Zql":"priority = Highest"
 */
// copy ZQL filter when filter has: "Zql":"priority = Highest"
@Test(priority = 7)
	public void test7_copyZqlFilter_when_filter_is_created_by_priority_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority = Highest");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 8
 * Copy ZQL filter: "Zql":"priority != Medium"
 */
// copy ZQL filter when filter has: "Zql":"priority != Medium"
@Test(priority = 8)
	public void test8_copyZqlFilter_when_filter_is_created_by_priority_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority != Medium");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 9
 * Copy ZQL filter: "Zql":"priority is not EMPTY"
 */
// copy ZQL filter when filter has: "Zql":"priority is not Empty"
@Test(priority = 9)
	public void test9_copyZqlFilter_when_filter_is_created_by_priority_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority is not EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 10
 * Copy ZQL filter: "Zql":"priority is EMPTY"
 */
// copy ZQL filter when filter has: "Zql":"priority is Empty"
@Test(priority = 10)
	public void test10_copyZqlFilter_when_filter_is_created_by_priority_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 11
 * Copy ZQL filter: "Zql":"priority not in (Low,Lowest,Medium)"
 */
// copy ZQL filter when filter has: "Zql":"priority not in
// (Low,Lowest,Medium)"
@Test(priority = 11)
	public void test11_copyZqlFilter_when_filter_is_created_by_priority_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority not in (Low,Lowest,Medium)");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 12
 * Copy ZQL filter: "Zql":"priority in (Low,Lowest,Medium)"
 */
// copy ZQL filter when filter has: "Zql":"priority in (Highest,High)"
@Test(priority = 12)
	public void test12_copyZqlFilter_when_filter_is_created_by_priority_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority in (Low,Lowest,Medium)");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 13
 * Copy ZQL filter: "Zql":"component = component name"
 */
// copy ZQL filter when filter has: "Zql":"component = RC10"
@Test(priority = 13)
	public void test13_copyZqlFilter_when_filter_is_created_by_component_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component ="+Config.getValue("component"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 14
 * Copy ZQL filter: "Zql":"component != component name"
 */
// copy ZQL filter when filter has: "Zql":"component != RC10"
@Test(priority = 14)
	public void test14_copyZqlFilter_when_filter_is_created_by_component_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component !="+Config.getValue("component"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 15
 * Copy ZQL filter: "Zql":"component is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"component is not Empty"
@Test(priority = 15)
	public void test15_copyZqlFilter_when_filter_is_created_by_component_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component is not EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 16
 * Copy ZQL filter: "Zql":"component is Empty"
 */
// copy ZQL filter when filter has: "Zql":"component is Empty"
@Test(priority = 16)
	public void test16_copyZqlFilter_when_filter_is_created_by_component_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 17
 * Copy ZQL filter: "Zql":"component not in (component,component1)"
 */
// copy ZQL filter when filter has: "Zql":"component not in (RC10,RC20)"
@Test(priority = 17)
	public void test17_copyZqlFilter_when_filter_is_created_by_component_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component not in ("+Config.getValue("component")+","+Config.getValue("component1")+")");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 18
 * Copy ZQL filter: "Zql":"component not in (component,component1)"
 */

// copy ZQL filter when filter has: "Zql":"component in (RC10,RC20,c1)"
@Test(priority = 18)
	public void test18_copyZqlFilter_when_filter_is_created_by_component_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component in ("+Config.getValue("component")+","+Config.getValue("component1")+")");			
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 19
 * Copy ZQL filter: "Zql":cycleName="cyclename"
 */
// copy ZQL filter when filter has: "Zql":"cycleName = 123"
@Test(priority = 19)
	public void test19_copyZqlFilter_when_filter_is_created_by_cycleName_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName=\""+Config.getValue("cyclename")+"\"");			
		zqlfilterJson.setName("cyclename1 " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 20
 * Copy ZQL filter: "Zql":cycleName!="cyclename"
 */
// copy ZQL filter when filter has: "Zql":"cycleName != 123"
@Test(priority = 20)
	public void test20_copyZqlFilter_when_filter_is_created_by_cycleName_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName!=\""+Config.getValue("cyclename")+"\"");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 21
 * Copy ZQL filter: "Zql":cycleName is not EMPTY"
 */
// copy ZQL filter when filter has: "Zql":"cycleName is not Empty"
@Test(priority = 21)
	public void test21_copyZqlFilter_when_filter_is_created_by_cycleName_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName is not EMPTY");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 22
 * Copy ZQL filter: "Zql":cycleName is EMPTY"
 */
// copy ZQL filter when filter has: "Zql":"cycleName is Empty"
@Test(priority = 22)
	public void test22_copyZqlFilter_when_filter_is_created_by_cycleName_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName is EMPTY");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 23
 * Copy ZQL filter: "Zql":cycleName not in (cyclename,cyclename1)"
 */
// copy ZQL filter when filter has: "Zql":"cycleName not in (123,50 exe)"
@Test(priority = 23)
	public void test23_copyZqlFilter_when_filter_is_created_by_cycleName_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName not in ("+Config.getValue("cyclename")+","+Config.getValue("cyclename1")+")");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 24
 * Copy ZQL filter: "Zql":cycleName in (cyclename,cyclename1)"
 */
// copy ZQL filter when filter has: "Zql":"cycleName in (123,50 exe,Ad hoc)"
@Test(priority = 24)
	public void test24_copyZqlFilter_when_filter_is_created_by_cycleName_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName in ("+Config.getValue("cyclename")+","+Config.getValue("cyclename1")+")");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 25
 * Copy ZQL filter: "Zql":cycleName ~ad"
 */
// copy ZQL filter when filter has: "Zql":"cycleName ~ 123"
@Test(priority = 25)
	public void test25_copyZqlFilter_when_filter_is_created_by_cycleName_tilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName ~ad");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 26
 * Copy ZQL filter: "Zql":cycleName !~ad"
 */
// copy ZQL filter when filter has: "Zql":"cycleName !~ 123"
@Test(priority = 26)
	public void test26_copyZqlFilter_when_filter_is_created_by_cycleName_NotTilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName !~ad");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 27
 * Copy ZQL filter: "Zql":fixVersion = fixversioname"
 */
// copy ZQL filter when filter has: "Zql": fixVersion = "RUBY#2.0"
@Test(priority = 27)
	public void test27_copyZqlFilter_when_filter_is_created_by_fixVersion_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion = "+Config.getValue("fixVersion"));			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 28
 * Copy ZQL filter: "Zql":fixVersion != fixversioname"
 */
// copy ZQL filter when filter has: "Zql":"fixVersion != RUBY#2.0"
@Test(priority = 28)
	public void test28_copyZqlFilter_when_filter_is_created_by_fixVersion_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion != "+Config.getValue("fixVersion"));			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}

/**
* Test case - 29
* Copy ZQL filter: "Zql":fixVersion != fixversioname"
*/
	// copy ZQL filter when filter has: "Zql":"fixVersion is not Empty"
	@Test(priority = 29)
	public void test29_copyZqlFilter_when_filter_is_created_by_fixVersion_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion is not EMPTY");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 30
 * Copy ZQL filter: "Zql":fixVersion is EMPTY"
 */
// copy ZQL filter when filter has: "Zql":"fixVersion is Empty"
@Test(priority = 30)
	public void test30_copyZqlFilter_when_filter_is_created_by_fixVersion_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion is EMPTY");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 31
 * Copy ZQL filter: "Zql":fixVersion not in(fixVersion,fixVersion1)"
 */

// copy ZQL filter when filter has: "Zql":"fixVersion not in (RUBY#2.0,50)"
@Test(priority = 31)
	public void test31_copyZqlFilter_when_filter_is_created_by_fixVersion_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion not in ("+Config.getValue("fixVersion")+","+Config.getValue("fixVersion1")+")");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 32
 * Copy ZQL filter: "Zql":fixVersion in (fixVersion,fixVersion1)"
 */
// copy ZQL filter when filter has: "Zql":"fixVersion in
// (RUBY#2.0,50,Unscheduled)"
@Test(priority = 32)
	public void test32_copyZqlFilter_when_filter_is_created_by_fixVersion_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion in ("+Config.getValue("fixVersion")+","+Config.getValue("fixVersion1")+")");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 33
 * Copy ZQL filter: "Zql":executionStatus = WIP"
 */
// copy ZQL filter when filter has: "Zql": "executionStatus = WIP"
@Test(priority = 33)
	public void test33_copyZqlFilter_when_filter_is_created_by_executionStatus_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus ="+Config.getValue("executionStatus"));			
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 34
 * Copy ZQL filter: "Zql":executionStatus != FAIL"
 */
// copy ZQL filter when filter has: "Zql":"executionStatus != FAIL"
@Test(priority = 34)
	public void test34_copyZqlFilter_when_filter_is_created_by_executionStatus_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus !="+Config.getValue("executionStatus1"));		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 35
 * Copy ZQL filter: "Zql":executionStatus is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"executionStatus is not Empty"
@Test(priority = 35)
	public void test35_copyZqlFilter_when_filter_is_created_by_executionStatus_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus is not Empty");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 36
 * Copy ZQL filter: "Zql":executionStatus is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"executionStatus is Empty"
@Test(priority = 36)
	public void test36_copyZqlFilter_when_filter_is_created_by_executionStatus_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus is Empty");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 37
 * Copy ZQL filter: "Zql":executionStatus not in (executionStatus,executionStatus1)"
 */

// copy ZQL filter when filter has: "Zql":"executionStatus not in
// (PASSED,WIP)"
@Test(priority = 37)
	public void test37_copyZqlFilter_when_filter_is_created_by_executionStatus_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus not in ("+Config.getValue("executionStatus")+","+Config.getValue("executionStatus1")+")");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 38
 * Copy ZQL filter: "Zql":executionStatus in (BLOCKED,UNEXECUTED,new!)"
 */
// copy ZQL filter when filter has: "Zql":"executionStatus in
// (BLOCKED,UNEXECUTED,new!)"
@Test(priority = 38)
	public void test38_copyZqlFilter_when_filter_is_created_by_executionStatus_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus in ("+Config.getValue("executionStatus")+","+Config.getValue("executionStatus1")+","+Config.getValue("customStatus")+")");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 39
 * Copy ZQL filter: "Zql":executedBy = admin"
 */
// copy ZQL filter when filter has: "Zql": "executedBy = admin"
@Test(priority = 39)
	public void test39_copyZqlFilter_when_filter_is_created_by_executedBy_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy = admin");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 40
 * Copy ZQL filter: "Zql":executedBy != admin"
 */
// copy ZQL filter when filter has: "Zql":"executedBy != admin"
@Test(priority = 40)
	public void test40_copyZqlFilter_when_filter_is_created_by_executedBy_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy != admin");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 41
 * Copy ZQL filter: "Zql":executedBy is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"executedBy is not Empty"
@Test(priority = 41)
	public void test41_copyZqlFilter_when_filter_is_created_by_executedBy_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy is not Empty");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 42
 * Copy ZQL filter: "Zql":executedBy is Empty"
 */
// copy ZQL filter when filter has: "Zql":"executedBy is Empty"
@Test(priority = 42)
	public void test42_copyZqlFilter_when_filter_is_created_by_executedBy_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy is Empty");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 43
 * Copy ZQL filter: "Zql":executedBy not in (admin,user1)"
 */
// copy ZQL filter when filter has: "Zql":"executedBy not in (admin,user1)"
@Test(priority = 43)
	public void test43_copyZqlFilter_when_filter_is_created_by_executedBy_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy not in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 44
 * Copy ZQL filter: "Zql":executedBy in (admin,user1)"
 */
// copy ZQL filter when filter has: "Zql":"executedBy in
// (admin,user2,user3)"
@Test(priority = 44)
	public void test44_copyZqlFilter_when_filter_is_created_by_executedBy_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 45
 * Copy ZQL filter: "Zql":assignee = admin"
 */
// copy ZQL filter when filter has: "Zql": "assignee = admin"
@Test(priority = 45)
	public void test45_copyZqlFilter_when_filter_is_created_by_assignee_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee = admin");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 46
 * Copy ZQL filter: "Zql":assignee != admin"
 */
// copy ZQL filter when filter has: "Zql":"assignee != admin"
@Test(priority = 46)
	public void test46_copyZqlFilter_when_filter_is_created_by_assignee_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee != admin");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 47
 * Copy ZQL filter: "Zql":assignee is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"assignee is not Empty"
@Test(priority = 47)
	public void test47_copyZqlFilter_when_filter_is_created_by_assignee_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee is not Empty");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 48
 * Copy ZQL filter: "Zql":assignee is Empty"
 */
// copy ZQL filter when filter has: "Zql":"assignee is Empty"
@Test(priority = 48)
	public void test48_copyZqlFilter_when_filter_is_created_by_assignee_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee is Empty");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 49
 * Copy ZQL filter: "Zql":assignee not in (admin,user1)"
 */
// copy ZQL filter when filter has: "Zql":"assignee not in (admin,user1)"
@Test(priority = 49)
	public void test49_copyZqlFilter_when_filter_is_created_by_assignee_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee not in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 50
 * Copy ZQL filter: "Zql":assignee not in (admin,user1)"
 */
// copy ZQL filter when filter has: "Zql":"assignee in (admin,user2,user3)"
@Test(priority = 50)
	public void test50_copyZqlFilter_when_filter_is_created_by_assignee_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 51
 * Copy ZQL filter: "Zql":issue = IE-1"
 */
// copy ZQL filter when filter has: "Zql": "issue = IE-1"
@Test(priority = 51)
	public void test51_copyZqlFilter_when_filter_is_created_by_issue_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue ="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 52
 * Copy ZQL filter: "Zql":issue = IE-1"
 */
// copy ZQL filter when filter has: "Zql":"issue != IE-1"
@Test(priority = 52)
	public void test52_copyZqlFilter_when_filter_is_created_by_issue_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue !="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 53
 * Copy ZQL filter: "Zql":issue <= IE-1"
 */

// copy ZQL filter when filter has: "Zql":"issue <= IE-1"
@Test(priority = 53)
	public void test53_copyZqlFilter_when_filter_is_created_by_issue_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue <="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 54
 * Copy ZQL filter: "Zql":issue >= IE-1"
 */
// copy ZQL filter when filter has: "Zql":"issue >= IE-1"
@Test(priority = 54)
	public void test54_copyZqlFilter_when_filter_is_created_by_isuue_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue >="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 55
 * Copy ZQL filter: "Zql":issue < IE-1"
 */
// copy ZQL filter when filter has: "Zql":"issue < IE-1"
@Test(priority = 55)
	public void test55_copyZqlFilter_when_filter_is_created_by_issue_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue <"+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 56
 * Copy ZQL filter: "Zql":issue > IE-1"
 */
// copy ZQL filter when filter has: "Zql":"issue > IE-1"
@Test(priority = 56)
	public void test56_copyZqlFilter_when_filter_is_created_by_issue_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue >"+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 57
 * Copy ZQL filter: "Zql":issue not in (IE-1,IE-2)"
 */
// copy ZQL filter when filter has: "Zql":"issue not in (IE-1,IE-2)"
@Test(priority = 57)
	public void test57_copyZqlFilter_when_filter_is_created_by_issue_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue not in ("+Config.getValue("issueid")+","+Config.getValue("issueid1")+")");		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 58
 * Copy ZQL filter: "Zql":issue not in (IE-1,IE-2)"
 */
// copy ZQL filter when filter has: "Zql":"assignee in
// (issue1,issue2,issue3)"
@Test(priority = 58)
	public void test58_copyZqlFilter_when_filter_is_created_by_issue_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue not in ("+Config.getValue("issueid")+","+Config.getValue("issueid1")+","+Config.getValue("issueid2")+")");		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 59
 * Copy ZQL filter: "Zql":creationDate = yyyy-MM-dd"
 */
// copy ZQL filter when filter has: "Zql": "creationDate = 2016-11-23"
@Test(priority = 59)
	public void test59_copyZqlFilter_when_filter_is_created_by_creationDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate ="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 60
 * Copy ZQL filter: "Zql":creationDate != yyyy-MM-dd"
 */
// copy ZQL filter when filter has: "Zql":"creationDate != 2016-11-23"
@Test(priority = 60)
	public void test60_copyZqlFilter_when_filter_is_created_by_creationDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate !="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 61
 * Copy ZQL filter: "Zql":creationDate <= yyyy-MM-dd"
 */
// copy ZQL filter when filter has: "Zql":"creationDate <= 2016-11-23"
@Test(priority = 61)
	public void test61_copyZqlFilter_when_filter_is_created_by_creationDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate <="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 62
 * Copy ZQL filter: "Zql":creationDate >= yyyy-MM-dd"
 */
// copy ZQL filter when filter has: "Zql":"creationDate >= 2016-11-23"
@Test(priority = 62)
	public void test62_copyZqlFilter_when_filter_is_created_by_creationDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate >="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 63
 * Copy ZQL filter: "Zql":creationDate < yyyy-MM-dd"
 */
// copy ZQL filter when filter has: "Zql":"creationDate < 2016-11-23"
@Test(priority = 63)
	public void test63_copyZqlFilter_when_filter_is_created_by_creationDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate <"+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 64
 * Copy ZQL filter: "Zql":creationDate > yyyy-MM-dd"
 */
// copy ZQL filter when filter has: "Zql":"creationDate > 2016-11-23"
@Test(priority = 64)
	public void test64_copyZqlFilter_when_filter_is_created_by_creationDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate >"+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 65
 * Copy ZQL filter: "Zql":creationDate not in (yyyy-MM-dd,yyyy-MM-dd)"
 */
// copy ZQL filter when filter has: "Zql":"creationDate not in
// (2016-11-23,2016-11-22)"
@Test(priority = 65)
	public void test65_copyZqlFilter_when_filter_is_created_by_creationDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate not in ("+Config.getValue("creationdate")+","+Config.getValue("creationdate")+")");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 66
 * Copy ZQL filter: "Zql":creationDate  in (yyyy-MM-dd,yyyy-MM-dd)"
 */
// copy ZQL filter when filter has: "Zql":"creationDate in
// (2016-11-23,2016-11-22,2016-11-21)"
@Test(priority = 66)
	public void test66_copyZqlFilter_when_filter_is_created_by_creationDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate in ("+Config.getValue("creationdate")+Config.getValue("creationdate")+")");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 67
 * Copy ZQL filter: "Zql":creationDate is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"creationDate is not Empty"
@Test(priority = 67)
	public void test67_copyZqlFilter_when_filter_is_created_by_creationDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate is not Empty");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 68
 * Copy ZQL filter: "Zql":creationDate is Empty"
 */

// copy ZQL filter when filter has: "Zql":"creationDate is Empty"
@Test(priority = 68)
	public void test68_copyZqlFilter_when_filter_is_created_by_creationDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate is Empty");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 69
 * Copy ZQL filter: "Zql":executionDate = yyyy-mm-dd"
 */

// copy ZQL filter when filter has: "Zql": "executionDate = 2016-11-23"
@Test(priority = 69)
	public void test69_copyZqlFilter_when_filter_is_created_by_executionDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate ="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 70
 * Copy ZQL filter: "Zql":executionDate != yyyy-mm-dd"
 */
// copy ZQL filter when filter has: "Zql":"executionDate != 2016-11-23"
@Test(priority = 70)
	public void test70_copyZqlFilter_when_filter_is_created_by_executionDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate !="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 71
 * Copy ZQL filter: "Zql":executionDate <= yyyy-mm-dd"
 */
// copy ZQL filter when filter has: "Zql":"executionDate <= 2016-11-23"
@Test(priority = 71)
	public void test71_copyZqlFilter_when_filter_is_created_by_executionDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate <="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 72
 * Copy ZQL filter: "Zql":executionDate >= yyyy-mm-dd"
 */
// copy ZQL filter when filter has: "Zql":"executionDate >= 2016-11-23"
@Test(priority = 72)
	public void test72_copyZqlFilter_when_filter_is_created_by_executionDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate >="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 73
 * Copy ZQL filter: "Zql":executionDate < yyyy-mm-dd"
 */
// copy ZQL filter when filter has: "Zql":"executionDate < 2016-11-23"
@Test(priority = 73)
	public void test73_copyZqlFilter_when_filter_is_created_by_executionDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate <"+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 74
 * Copy ZQL filter: "Zql":executionDate > yyyy-mm-dd"
 */
// copy ZQL filter when filter has: "Zql":"executionDate > 2016-11-23"
@Test(priority = 74)
	public void test74_copyZqlFilter_when_filter_is_created_by_executionDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate >"+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 75
 * Copy ZQL filter: "Zql":executionDate not in (yyy-mm-dd,yyyy-mm-dd)"
 */
// copy ZQL filter when filter has: "Zql":"executionDate not in
// (2016-11-23,2016-11-22)"
@Test(priority = 75)
	public void test75_copyZqlFilter_when_filter_is_created_by_executionDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate not in ("+Config.getValue("executionDate")+","+Config.getValue("executionDate1")+")");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 76
 * Copy ZQL filter: "Zql":executionDate in (yyy-mm-dd,yyyy-mm-dd)"
 */
// copy ZQL filter when filter has: "Zql":"executionDate in
// (2016-11-23,2016-11-22,2016-11-21)"
@Test(priority = 76)
	public void test76_copyZqlFilter_when_filter_is_created_by_executionDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate in ("+Config.getValue("executionDate")+Config.getValue("executionDate1")+")");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 77
 * Copy ZQL filter: "Zql":executionDate is not Empty"
 */
// copy ZQL filter when filter has: "Zql":"executionDate is not Empty"
@Test(priority = 77)
	public void test77_copyZqlFilter_when_filter_is_created_by_executionDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is not Empty");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 78
 * Copy ZQL filter: "Zql":executionDate is Empty"
 */
// copy ZQL filter when filter has: "Zql":"executionDate is Empty"
@Test(priority = 78)
	public void test78_copyZqlFilter_when_filter_is_created_by_executionDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is Empty");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 79
 * Copy ZQL filter: "Attempt to copy Zql filter by passing invalid filterId"
 */
// Attempt to copy Zql filter by passing invalid filterId
@Test(priority = 79)
	public void test79_attemptToCopyZqlFilterByPassingInvalidFilterId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("executionDate is Empty");
		zqlfilterJson.setName("Api filter" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = "64464646464646";
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Copied Api filter " + System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		
		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		boolean copyFilterStatus = zapiService.validateInvalidZQLFilterId(filterId, copyFilterResponse);				
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 80
 * Copy ZQL filter: "Attempt to copy Zql filter by passing null filterId"
 */
// Attempt to copy ZQL filter by passing name as null
@Test(priority = 80)
	public void test80_attemptToCopyZQLFilterByPassingNameAsNULL() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is Empty");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName(null);
		System.out.println(zqlfilterJson.toString());
		
		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
/**
 * Test case - 80
 * Copy ZQL filter: "Attempt to copy ZQL filter by passing name which already exists"
 */

// Attempt to copy ZQL filter by passing name which already exists
@Test(priority = 81)
	public void test81_attemptToCopyZqlFilterByPassingNameWhichAlreadyExists() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is Empty");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter");
		System.out.println(zqlfilterJson.toString());

		Response copyFilterResponse = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		boolean copyFilterStatus = zapiService.validateAlreadyExistsZQLFilter(copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
}