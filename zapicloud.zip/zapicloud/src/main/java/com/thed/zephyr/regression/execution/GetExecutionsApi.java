/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetExecutionsApi extends BaseTest {
	JwtGenerator jwtGenerator = null;
	Long issueId = null;
	Long projectId = null;
	int offset = 0;
	int size = 0;
	private long issueId1;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//TODO
	//Get executions by passing valid projectId and IssueId with executions in Adhoc Cycle of scheduled version
	@Test(priority = 1,  enabled = testEnabled)
	public void test1_getExecutionsWithExecutionsInAdhoCycleOfScheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		offset = 0;
		size = 10;
		projectId = Long.parseLong(Config.getValue("projectId"));
		//issueId = 10000l;
		//create issues
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");		
		System.out.println("*****issueId"+issueId);
		
		
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by passing valid projectId and IssueId with executions in Non-Adhoc Cycle of scheduled version
	@Test(priority = 2,enabled = testEnabled)
	public void test2_getExecutionsWithExecutionsInNonAdhoCycleOfScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		//create issues
		 Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad1.setSummary("test");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad1.toString());
			Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
			Assert.assertNotNull(response1, "Create Issue Api Response is null.");
					
			boolean status1 = jiraService.validateCreateIssueApi(response1);
			Assert.assertTrue(status1, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
			String issueKey1 = new JSONObject(response1.body().asString()).getString("key");		
			System.out.println("*****issueId"+issueId);
		//creating cycle
				
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by passing valid projectId and IssueId with executions in Adhoc Cycle of unscheduled version
	@Test(priority = 3,enabled = testEnabled)
	public void test3_getExecutionsWithExecutionsInAdhoCycleOfUnscheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(-1l);
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(1);
				
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
			    // String executionId= executionJson.getJSONObject("execution").getString("id");
			      
				/*List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
				}
				System.out.println("exeIDs are ------>"+exeIds);*/

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by passing valid projectId and IssueId with executions in Non-Adhoc Cycle of unscheduled version
	@Test(priority = 4, enabled = testEnabled)
	public void test4_getExecutionsWithExecutionsInNonAdhoCycleOfUnscheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(-1l);
				cycleJson.setName("Cycle");
				cycleJson.setDescription("Cycle for get executions");

				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status2 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status2, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(-1l);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(1);
				
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
			    // String executionId= executionJson.getJSONObject("execution").getString("id");
			      
				/*List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
				}
				System.out.println("exeIDs are ------>"+exeIds);*/

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//TODO
	//Get executions with executions fully executed
	@Test(priority = 5,enabled = testEnabled)
	public void test5_getExecutionsWithExecutionsFullyExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 2;
		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(2);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
			    // String executionId= executionJson.getJSONObject("execution").getString("id");
	//update executions
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			//Long issueId1 = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(1l);
			executionJson.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions with executions partially executed
	@Test(priority = 6,enabled = testEnabled)
	public void test6_getExecutionsWithExecutionsPartiallyExecuted(){
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 2;
		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(2);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
			    // String executionId= executionJson.getJSONObject("execution").getString("id");
	//update executions
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length()-1;j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId1 = issueIds.get(j);
			executionJson.setIssueId(issueId1);
			System.out.println(issueId1);
			executionJson.setStatusId(1l);
			executionJson.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions when there are 50 executions
	@Test(priority = 7,enabled = false)
	public void test7_getExecutionsWhenThereAre50Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(50);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions when there are 500 executions
	@Test(priority = 8, enabled = false)
	public void test8_getExecutionsWhenThereAre500Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 50;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(500);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
			    // String executionId= executionJson.getJSONObject("execution").getString("id");
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions when there are 1000 executions
	@Test(priority = 9, enabled = false)
	public void test9_getExecutionsWhenThereAre1000Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 50;
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions having different execution status (I.e pass, fail, wip, blocked)
	@Test(priority = 10, enabled = testEnabled)
	public void test10_getExecutionsWithDifferentExecutionStatus(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(4);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    
	//update execution status=PASS	
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		//	Long issueId1 = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(1l);
			executionJson.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
			//update execution with FAIL
		List<String> exeIds1 = new ArrayList<>() ;
		JSONArray jsarray21 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length()-2;j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(exeid);
			//Long issueId1 = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Attempt to get executions by by passing invalid issueId and valid projectId
	@Test(priority = 11, enabled = testEnabled)
	public void test11_attemptTogetExecutionsByPassingInvalidIssueId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		issueId = 99l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		
		//create issue
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId1);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	   
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsWithInvalidIssueId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//FIXME
	//Attempt to get execution by passing invalid projectId and valid issueId
	@Test(priority = 12, enabled = testEnabled)
	public void test12_attemptTogetExecutionsByPassingInvalidprojectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = 99l;
		offset = 0;
		size = 10;
		
		//create issue
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean status1 = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(status1, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
				
				//create execution
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsWithInvalidProjectId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Attempt to get executions without passing issueId
	@Test(priority = 13, enabled = testEnabled)
	public void test13_attemptTogetExecutionWithoutPassingIssueId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		issueId = null;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;

		//create issue
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean status1 = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(status1, "Response Validation Failed.");
				issueId1 = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
				
				//create execution
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(issueId1);
				executionJson.setCycleId("-1");
			    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			   
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Attempt to get executions by passing issueId and projectId if there are no executions scheduled
	@Test(priority = 14, enabled = testEnabled)
	public void test14_attemptTogetExecutionByPassingIssueIdAndProjectIdIfThereAreNoExecutionsScheduled(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10518l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		//create issue
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get exectuions when defects and comments linked to the Executions
	@Test(priority = 15 ,enabled = testEnabled)
	public void test15_getExecutionsWhenDefectsAndCommentsAreLinkedToExecutions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 10;
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(4);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
				
				//create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					//Long issueId = issueIds.get(j);
					executionJson.setIssueId(issueId);
					executionJson.setDefects(defectsList);
					executionJson.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson.setStatusId(2l);
					executionJson.setExecutionId(exeid);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	//TODO
	//Attempt to get executions without passing projectId
	//FIXME
	@Test(priority = 16, enabled = testEnabled)
	public void test16_attemptTogetExecutionsWithoutPassingProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = null;
		offset = 0;
		size = 10;
		
		//create issue
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to get executions, if the size is set to 51
	@Test(priority = 17, enabled = testEnabled)
	public void test17_attemptToGetExecutionsWhenSizeIsSetTo51(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 0;
		size = 51;
		
		//create issue
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean status1 = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(status1, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
				
				//create execution
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//FIXME
	//TODO
	// Attempt to get executions by issue id, if the offset is set to an invalid value
	//executions will not get but response status will get 200 ok
	
	@Test(priority = 18, enabled = testEnabled)
	public void test18_attemptToGetExecutionsIfOffsetIsSetToInvalidValue(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 551234567;
		size = 10;

		//create issue
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		
	    Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to get executions, if the offset value is greater size
	//Executions will not get but response will get 200 ok
	@Test(priority = 19, enabled = testEnabled)
	public void test19_attemptToGetExecutionsIfOffsetIsGreaterThenSize(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 20;
		size = 10;
		
		//create issue
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean status1 = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(status1, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
				
				//create execution
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				

		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutions(response, projectId, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//FIXME
	//TODO
	//Attempt to get Executions if the offset is greater than the number of excutions for the issue
	@Test(priority = 20,enabled = testEnabled)
	public void test20_attemptToGetExecutionsIfOffsetIsGreaterThanNumberOfExecutions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//issueId = 10000l;
		projectId = Long.parseLong(Config.getValue("projectId"));
		offset = 5;
		size = 10;

		//create issue
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
}
