/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface ZqlFilterApi {

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createZQLFilter(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param zqlFilterId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLFilter(JwtGenerator jwtGenerator, String zqlFilterId);
//	/**
//	 * @param jwtGenerator
//	 * @return Response of the executed API.
//	 * @author Created by manoj.behera on 14-Nov-2016.
//	 */
//	Response searchZQLFilter(JwtGenerator jwtGenerator);
	/**
	 * @param jwtGenerator
	 * @param filterId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response toggleFavorite(JwtGenerator jwtGenerator, String filterId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	Response copyFilter(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param filterId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	Response updateFilter(JwtGenerator jwtGenerator, String filterId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param filterId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	Response deleteFilter(JwtGenerator jwtGenerator, String filterId);
	/**
	 * @param jwtGenerator
	 * @param zqlFilterName
	 * @return
	 * @author Created by manoj.behera on 26-Nov-2016.
	 */
	Response quickSearchZQLFilter(JwtGenerator jwtGenerator, String zqlFilterName);
	/**
	 * @param jwtGenerator
	 * @param byUser
	 * @param fav
	 * @param offset
	 * @param maxRecords
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */
	Response getFavouriteZQLFilters(JwtGenerator jwtGenerator, boolean byUser, boolean fav, int offset, int maxRecords);
	/**
	 * @param jwtGenerator
	 * @param byUser
	 * @param offset
	 * @param maxRecords
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */
	Response getMyZQLFilters(JwtGenerator jwtGenerator, boolean byUser, int offset, int maxRecords);
	/**
	 * @param jwtGenerator
	 * @param fav
	 * @param offset
	 * @param maxRecords
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */
	Response getPapularZQLFilters(JwtGenerator jwtGenerator, boolean fav, int offset, int maxRecords);
	/**
	 * @param jwtGenerator
	 * @param zqlFilter
	 * @return
	 * @author Created by manoj.behera on 03-Dec-2016.
	 */
	Response searchZQLFilters(JwtGenerator jwtGenerator, String zqlFilter);
	/**
	 * @param jwtGenerator
	 * @return
	 * @author Created by manoj.behera on 08-Dec-2016.
	 */
	Response pingJob(JwtGenerator jwtGenerator);
	Response createIssueZQLFilter(JwtGenerator jwtGenerator, String payLoad);
	
}
