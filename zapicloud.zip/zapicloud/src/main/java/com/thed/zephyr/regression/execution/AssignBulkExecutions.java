package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseOptions;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class AssignBulkExecutions extends BaseTest{
	
	JwtGenerator jwtGenerator = null;
	String cycleId = null;
	String issueKey = null;
	Long issueId = null;

	String cycleIdScheduledVersion = null;
	String cycleIdUnscheduledVersion = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
//	@Test(priority = 1)
	public void assignBulkExecutions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479228127201-242ac1135-0001\",\"0001478768982671-242ac1131-0001\"],\"assigneeType\":\"assignee\",\"assignee\":\"admin\"}";
		System.out.println(payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 1, enabled = testEnabled)
	public void test1_assignBulkExecutions_oneExecution_to_Assignee_Admin(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		//issuePayLoad.setReporter("admin");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("accountId"));
		executionJson2.setassignedToAccountId(Config.getValue("accountId"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _oneExecution_to_Assignee_Admin Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 2, enabled = testEnabled)
	public void test2_assignBulkExecutions_twoExecution_to_Assignee_Admin(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("accountId"));
		executionJson2.setassignedToAccountId(Config.getValue("accountId"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _twoExecution_to_Assignee_Admin Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 3, enabled = testEnabled)
	public void test3_assignBulkExecutions_tenExecution_to_Assignee_Admin(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 10);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("accountId"));
		executionJson2.setassignedToAccountId(Config.getValue("accountId"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tenExecution_to_Assignee_Admin Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//large data 
	@Test(priority = 4, enabled = false)
	public void test4_assignBulkExecutions_100Execution_to_Assignee_Admin() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(100);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("accountId"));
		executionJson2.setassignedToAccountId(Config.getValue("accountId"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _hundredExecution_to_Assignee_Admin Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 5, enabled = testEnabled)
	public void test5_assignBulkExecutions_oneExecution_to_Assignee_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _oneExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 6, enabled = testEnabled)
	public void test6_assignBulkExecutions_twoExecution_to_Assignee_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _twoExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 7, enabled = testEnabled)
	public void test7_assignBulkExecutions_tenExecution_to_Assignee_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tenExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//large data
	@Test(priority = 8, enabled = false)
	public void test8_assignBulkExecutions_100Execution_to_Assignee_otherUser() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(100);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _hundredExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 9, enabled = testEnabled)
	public void test9_assignBulkExecutions_oneExecution_to_Assignee_currentUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _onedExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 10, enabled = false)
	public void test10_assignBulkExecutions_tenExecution_to_Assignee_currentUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tendExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 11, enabled = false)
	public void test11_assignBulkExecutions_100Execution_to_Assignee_currentUser() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(100);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _hundreddExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 12, enabled = testEnabled)
	public void test12_assignBulkExecutions_oneExecution_from_current_to_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		
		//now assigned to current user, from here will assign to other user
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("assignee");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee(Config.getValue("userID"));
		executionJson3.setassignedToAccountId(Config.getValue("userID"));
		//String payLoad = executionJson2.toString();
		String payLoad2 = executionJson3.toString();
		
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
		System.out.println("Bulkassignee _1Execution_from_current_to_otherUser Sucessfully");
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 13, enabled = testEnabled)
	public void test13_assignBulkExecutions_5Execution_from_current_to_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		
		//now assigned to current user, from here will assign to other user
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("assignee");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee(Config.getValue("userID"));
		executionJson3.setassignedToAccountId(Config.getValue("userID"));
		//String payLoad = executionJson2.toString();
		String payLoad2 = executionJson3.toString();
		
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
		System.out.println("Bulkassignee _5Execution_from_current_to_otherUser Sucessfully");
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 14, enabled = testEnabled)
	public void test14_assignBulkExecutions_5Execution_from_otherUser_to_currentUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		
		//now assigned to current user, from here will assign to other user
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssigneeType("currentUser");
	//	executionJson3.setAssignee("user1");
		String payLoad2 = executionJson3.toString();
		
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
		
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 15, enabled = false)
	public void test15_assignBulkExecutions_10Execution_from_otherUser_to_currentUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		
		//now assigned to current user, from here will assign to other user
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssigneeType("currentUser");
	//	executionJson3.setAssignee("user1");
		String payLoad2 = executionJson3.toString();
		
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
		
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	@Test(priority = 16, enabled = false)
	public void test16_assignBulkExecutions_5Execution_to_user_name_capital(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	@Test(priority = 17, enabled = false)
	public void test17_assignBulkExecutions_5Execution_to_user_name_small(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 18, enabled = testEnabled)
	public void test18_assignBulkExecutions_5Execution_to_user_name_number(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 19, enabled = testEnabled)
	public void test19_assignBulkExecutions_5Execution_to_user_name_capitalAndSmall(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 20, enabled = testEnabled)
	public void test20_assignBulkExecutions_5Execution_to_user_name_alphaNumeric(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 21, enabled = testEnabled)
	public void test21_assignBulkExecutions_5Execution_to_user_name_specialChar(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 22, enabled = testEnabled)
	public void test22_assignBulkExecutions_5Execution_to_user_name_having_spaces(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 23, enabled = testEnabled)
	public void test23_assignBulkExecutions_5Execution_to_user_name_internationalChar(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 24, enabled = testEnabled)
	public void test24_assignBulkExecutions_5Execution_to_user_name_longChar(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Making it false or comment because in GDPR used only accountid not the username
	//@Test(priority = 25, enabled = testEnabled)
	public void test25_assignBulkExecutions_5Execution_to_user_name_mixChar(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("admin");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 26, enabled = testEnabled)
	public void test26_attempt_to_assign_2Execution_to_invalid_assignType(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assigne");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("accountId"));
		executionJson2.setassignedToAccountId(Config.getValue("accountId"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		//response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		//Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 27, enabled = testEnabled)
	public void test27_attempt_to_assign_2Execution_when_assignType_null(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("null");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("accountId"));
		executionJson2.setassignedToAccountId(Config.getValue("accountId"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		//response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		//Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 28, enabled = testEnabled)
	public void test28_attempt_to_assign_2Execution_when_assignee_null(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee("null");
		executionJson2.setassignedToAccountId("null");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		//response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		//Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 29, enabled = testEnabled)
	public void test29_attempt_to_assign_2Execution_when_assignee_invalidaccountId_notCreated(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee("123");
		executionJson2.setassignedToAccountId("123");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		//response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		//Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 30, enabled = testEnabled)
	public void test30_assignBulkExecutions_3Execution_from_otherUser_to_differentOtherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 3);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(3);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		
		//now assigned to other  user, from here will assign to other user
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("assignee");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee(Config.getValue("user1ID"));
		executionJson3.setassignedToAccountId(Config.getValue("user1ID"));
		//String payLoad = executionJson2.toString();
		String payLoad2 = executionJson3.toString();
		
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
		System.out.println("Bulkassignee _3Execution_from_otheruser_to_differentUser Sucessfully");
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 31, enabled = testEnabled)
	public void test31_assignBulkExecutions_3Execution_from_user_to_sameUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 3);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(3);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		
		//now assigned same user
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("assignee");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee(Config.getValue("userID"));
		executionJson3.setassignedToAccountId(Config.getValue("userID"));
		//String payLoad = executionJson2.toString();
		String payLoad2 = executionJson3.toString();
		
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
		System.out.println("Bulkassignee _3Execution_from_User_to same user Sucessfully");
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 32, enabled = testEnabled)
	public void test32_assignBulkExecutions_5Execution_to_curentUser_in_unsheduled_Adhoc(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(-1l);
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _5Execution_to_Assignee_currentuser in unscheduled adhoc cycle Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 33, enabled = testEnabled)
	public void test33_assign_5Executions_to_curentUser_in_unsheduled_plannedCycle(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(-1l);
		executionJson.setCycleId(cycleId);
		//executionJson.setCycleId(Long.parseLong(Config.getValue("cyleId")));
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _5Execution_to_Assignee_currentuser in unscheduled planned cycle Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 34, enabled = testEnabled)
	public void test34_assign_5Executions_to_curentUser_in_sheduled_adhoc(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tendExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 35, enabled = testEnabled)
	public void test35_assign_5Executions_to_curentUser_in_sheduled_plannedCycle(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId(cycleId);
		//executionJson.setCycleId(Long.parseLong(Config.getValue("cyleId")));
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _5Execution_to_Assignee_currentuser in unscheduled planned cycle Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 36, enabled = testEnabled)
	public void test36_assignBulkExecutions_5Execution_to_otherUser_in_unsheduled_Adhoc(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(-1l);
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _5Execution_to_Assignee_othertuser in unscheduled adhoc cycle Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 37, enabled = testEnabled)
	public void test37_assign_5Executions_to_otherUser_in_unsheduled_plannedCycle(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(-1l);
		executionJson.setCycleId(cycleId);
		//executionJson.setCycleId(Long.parseLong(Config.getValue("cyleId")));
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _5Execution_to_Assignee_currentuser in unscheduled planned cycle Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 38, enabled = testEnabled)
	public void test38_assign_5Executions_to_otherUser_in_sheduled_adhoc(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tendExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 39, enabled = testEnabled)
	public void test39_assign_5Executions_to_otherUser_in_sheduled_plannedCycle(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId(cycleId);
		//executionJson.setCycleId(Long.parseLong(Config.getValue("cyleId")));
		executionJson.setNoOfExecutions(5);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _5Execution_to_Assignee_currentuser in unscheduled planned cycle Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//If try to assignee deactivate user getting 200 response .ZFJCLOUD-4932
	@Test(priority = 40, enabled = testEnabled)
	public void test40_attempt_to_assign_2Execution_when_assignee_deactivated(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10201");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10201l);
		executionJson.setVersionId(10106l);
		executionJson.setCycleId("0001480507472149-242ac1124-0001");
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setAssignee("user1"); //give the deactivated userName
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//ZFJCLOUD-4920
	@Test(priority = 41, enabled = testEnabled)
	public void test41_attempt_to_assign_2Execution_when_assignee_deleted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
			//	System.out.println("*****"+issueIds);
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(2);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
			    // String executionId= executionJson.getJSONObject("execution").getString("id");
			      
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
				}
				System.out.println("exeIDs are ------>"+exeIds);
				Execution executionJson2 = new Execution();
				executionJson2.setExecutions(exeIds);
				executionJson2.setAssigneeType("assignee");
				//executionJson2.setAssignee("admin");
				executionJson2.setChangeAssignee(true);
				//manually need to delete so passing invalid accountid
				executionJson2.setAssignee("12345");
				executionJson2.setassignedToAccountId("12345");
				String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		System.out.println("Bulkassignee _tenExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 42, enabled = testEnabled)
	public void test42_attempt_to_assign_2Execution_by_user_emailAddress(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("useremail"));
		executionJson2.setassignedToAccountId(Config.getValue("useremail"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		System.out.println("Bulkassignee _tenExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 43, enabled = testEnabled)
	public void test43_attempt_to_assign_2Execution_by_user_fullName(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userUsername"));
		executionJson2.setassignedToAccountId(Config.getValue("userUsername"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		System.out.println("Bulkassignee _tenExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 44, enabled = testEnabled)
	public void test44_assign_2Execution_by_same_executionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		System.out.println("*****"+issueId);
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	   
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1= jsonResponse.getJSONObject("execution").getString("id");
	      
		/*List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}*/
		System.out.println("exeIDs are ------>"+executionId1);
		Execution executionJson2 = new Execution();
		List<String> exeIds2 = new ArrayList<>() ;
		exeIds2.add(executionId1);
		exeIds2.add(executionId1);
		executionJson2.setExecutions(exeIds2);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _Execution_to_Assignee_user by passing same executionid Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//execution field is mandatory even if executionid is null working fine=ZFJCLOUD-4931
	@Test(priority = 45, enabled = testEnabled)
	public void test45_attempt_to_assign_2Execution_by_executionId_null(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		System.out.println("*****"+issueId);
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	   
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1= jsonResponse.getJSONObject("execution").getString("id");
	      
		/*List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}*/
		System.out.println("exeIDs are ------>"+executionId1);
		Execution executionJson2 = new Execution();
		List<String> exeIds2 = new ArrayList<>() ;
		exeIds2.add("");
		exeIds2.add("");
		executionJson2.setExecutions(exeIds2);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//execution field is mandatory even if executionid is invalid working fine=ZFJCLOUD-4931
	@Test(priority = 46, enabled = testEnabled)
	public void test46_attempt_to_assign_2Execution_by_executionId_invalid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean status1 = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(status1, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
				
				System.out.println("*****"+issueId);
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(this.issueId);
				executionJson.setCycleId("-1");
			    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			   
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId1= jsonResponse.getJSONObject("execution").getString("id");
			      
				/*List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
				}*/
				System.out.println("exeIDs are ------>"+executionId1);
				Execution executionJson2 = new Execution();
				List<String> exeIds2 = new ArrayList<>() ;
				exeIds2.add("123400");
				exeIds2.add("123401");
				executionJson2.setExecutions(exeIds2);
				executionJson2.setAssigneeType("assignee");
				executionJson2.setChangeAssignee(true);
				executionJson2.setAssignee(Config.getValue("userID"));
				executionJson2.setassignedToAccountId(Config.getValue("userID"));
				String payLoad = executionJson2.toString();
				
				
				System.out.println("payload: "+payLoad);
				Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Response: "+response.getBody().asString());
				/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
				Assert.assertNotNull(response, "Job progress Api Response is null.");
				System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
				
				boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}
	
	@Test(priority = 47, enabled = testEnabled)
	public void test47_assignBulkExecutions_twoExecution_to_currentUser_when_loggedInAsOtherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tendExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 48, enabled = testEnabled)
	public void test48_assignBulkExecutions_twoExecution_to_other_when_loggedInAsOtherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("user1ID"));
		executionJson2.setassignedToAccountId(Config.getValue("user1ID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _tenExecution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 49, enabled = testEnabled)
	public void test49_unAssign_1execution_whichWas_assigned_to_currentUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _onedExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//now Unassigned those executions
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee("");
		executionJson3.setassignedToAccountId("");
		String payLoad2 = executionJson3.toString();
				
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
				
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 50, enabled = false)
	public void test50_unAssign_10execution_whichWas_assigned_to_currentUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _onedExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//now Unassigned those executions
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee("");
		executionJson3.setassignedToAccountId("");
		String payLoad2 = executionJson3.toString();
				
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
				
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 51, enabled = testEnabled)
	public void test51_unAssign_1execution_whichWas_assigned_to_otherUser(){
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _onedExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//now Unassigned those executions
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee("");
		executionJson3.setassignedToAccountId("");
		String payLoad2 = executionJson3.toString();
				
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
				
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 52, enabled = false)
	public void test52_unAssign_10execution_whichWas_assigned_to_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _onedExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//now Unassigned those executions
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee("");
		executionJson3.setassignedToAccountId("");
		String payLoad2 = executionJson3.toString();
				
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
				
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 53, enabled = false)
	public void test53_unAssign_10execution_whichWas_assigned_to_different_otherUser(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(10);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("user1ID"));
		executionJson2.setassignedToAccountId(Config.getValue("user1ID"));
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _onedExecution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//now Unassigned those executions
		Execution executionJson3 = new Execution();
		executionJson3.setExecutions(exeIds);
		executionJson3.setAssigneeType("");
		executionJson3.setChangeAssignee(true);
		executionJson3.setAssignee("");
		executionJson3.setassignedToAccountId("");
		String payLoad2 = executionJson3.toString();
				
		System.out.println("payload: "+payLoad2);
		Response response2 = zapiService.assignBulkExecutions(jwtGenerator, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Response: "+response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		Assert.assertNotNull(response2, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response2.getBody().asString());
				
		boolean status2 = zapiService.validateJobProgress(response2,payLoad2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 54, enabled = testEnabled)
	public void test54_assign_2Execution_after_activated_inactiveUSer(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		//issuePayLoad.setReporter("admin");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
	//	System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		//given activate the inactive user
		executionJson2.setAssignee(Config.getValue("user1ID"));
		executionJson2.setassignedToAccountId(Config.getValue("user1ID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _oneExecution_to_Assignee_Admin Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	//execution field is mandatory even if executionid is invalid working fine=ZFJCLOUD-4931
	@Test(priority = 55, enabled = testEnabled)
	public void test55_assignBulkExecutions_twoExecution_when_one_executionId_invalid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		System.out.println("*****"+issueId);
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	   
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1= jsonResponse.getJSONObject("execution").getString("id");
	      
		/*List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}*/
		System.out.println("exeIDs are ------>"+executionId1);
		Execution executionJson2 = new Execution();
		List<String> exeIds2 = new ArrayList<>() ;
		exeIds2.add(executionId1);
		exeIds2.add("123");
		executionJson2.setExecutions(exeIds2);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//execution field is mandatory even if executionid is null working fine=ZFJCLOUD-4931
	@Test(priority = 56, enabled = testEnabled)
	public void test56_assignBulkExecutions_twoExecution_when_one_executionId_null(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		System.out.println("*****"+issueId);
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	   
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1= jsonResponse.getJSONObject("execution").getString("id");
	      
		/*List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}*/
		System.out.println("exeIDs are ------>"+executionId1);
		Execution executionJson2 = new Execution();
		List<String> exeIds2 = new ArrayList<>() ;
		exeIds2.add(executionId1);
		exeIds2.add("");
		executionJson2.setExecutions(exeIds2);
		executionJson2.setAssigneeType("assignee");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//large data
	@Test(priority = 57, enabled = false)
	public void test57_assignBulkExecutions_500Execution_to_Assignee_currentUser() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _500 Execution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//large data
	@Test(priority = 58, enabled = false)
	public void test58_assignBulkExecutions_500Execution_to_Assignee_otherUser() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		System.out.println("Bulkassignee _500Execution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//large data
	@Test(priority = 59, enabled = false)
	public void test59_attempt_assignBulkExecutions_501Execution_to_Assignee_otherUser() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(501);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setAssigneeType("assignee");
		//executionJson2.setAssignee("admin");
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssignee(Config.getValue("userID"));
		executionJson2.setassignedToAccountId(Config.getValue("userID"));
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		System.out.println("Attempt to Bulkassignee _501Execution_to_Assignee_user Sucessfully");
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//large data
	@Test(priority = 60, enabled = false)
	public void test60_attempt_assignBulkExecutions_501Execution_to_Assignee_currentUser() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(501);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
		Execution executionJson2 = new Execution();
		executionJson2.setExecutions(exeIds);
		executionJson2.setChangeAssignee(true);
		executionJson2.setAssigneeType("currentUser");
	//	executionJson2.setAssignee("user1");
		String payLoad = executionJson2.toString();
		
		System.out.println("payload: "+payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		/*response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());*/
		System.out.println("Attemting to Bulkassignee _501Execution_to_Assignee_currentuser Sucessfully");
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
