package com.thed.zephyr.regression.teststep;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class CloneTeststepApi extends BaseTest{
	
	String cycleId = null;
	String issueKey = null;
	String stepId = null;
	String clonedstep = null;
	String stepid = null;
	private Long projectId = Long.parseLong(Config.getValue("projectId")); 
    private Long issueId;
    Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
    Long issueTypeId2 = Long.parseLong(Config.getValue("issueTypeStoryId"));
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
			
	}
	
	//-1 - clone after , 0 - before, -2 - last step, position - position need to give
	/**
	 * Created by debadatta.kathar
	 * Clone test step using position, to the first test step
	 */
@Test(priority = 1)
	public void cloneTeststep_test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}


// Clone test step using position as 0 to the first test step

//Clone test step using position as 0 to the last test step

@Test(priority = 2)
public void cloneTeststep_test2(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "A";
	String dataValue = "B";
	String resultValue = "C"; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	System.out.println("payload-->"+ teststepJson.toString());
	Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
	test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	System.out.println(createteststepresponse.getBody().asString());
	
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);		
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("0");
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
}





//Clone test step using position as 1 to the first test step
@Test(priority = 3)
public void cloneTeststep3_test3(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "A";
	String dataValue = "B";
	String resultValue = "C"; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	System.out.println("payload-->"+ teststepJson.toString());
	Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
	test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	System.out.println(createteststepresponse.getBody().asString());
	
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);		
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("1");
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
}





  //Clone test step using position as 1 to the last test step
@Test(priority = 4)
public void cloneTeststep_test4(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "A";
	String dataValue = "B";
	String resultValue = "C"; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	System.out.println("payload-->"+ teststepJson.toString());
	Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
	test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	System.out.println(createteststepresponse.getBody().asString());
	
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);		
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("1");
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
}






// create multiple steps then clone 1 step
@Test(priority = 111)
public void cloneTeststep_test111(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "abc";
	String dataValue = "jjj";
	String resultValue = "kkk";
	
	Teststep teststepJson = new Teststep();		
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	Response createteststepresponse=null;
	for (int i = 0; i < 2; i++) {
		createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);	
	}
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"clonesteps 111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"1\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("2");
	
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
}






//	@Test(priority = 2)
	/*public void cloneTeststep_test2222(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = 10200l;
		Long issueId = 10777l;
		String stepId = "0001479897756773-242ac1121-0001";
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateClonedTeststep(projectId, issueId, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	 * Created by debadatta.kathar
	 * Clone test step using position as 1 to the first test step
	 */
//	@Test(priority = 3)
	/*public void cloneTeststep_test3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = 10200l;
		Long issueId = 10777l;
		String stepId = "0001479897216196-242ac1121-0001";
		String payLoad = "{\"step\":\"Cloning after\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"1\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateClonedTeststep(projectId, issueId, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step using position as 1 to the last test step
	 */
//	@Test(priority = 4)
	/*public void cloneTeststep_test4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = 10200l;
		Long issueId = 10777l;
		String stepId = "0001479897756773-242ac1121-0001";
		String payLoad = "{\"step\":\"Cloning at first position\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"1\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateClonedTeststep(projectId, issueId, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	 * Created by debadatta.kathar
	 * Clone test step using position as -1 to the first test step
	 */
	
	
// Clone test step using position as -1 to the last test step
@Test(priority = 5)
public void cloneTeststep_test5(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "A";
	String dataValue = "B";
	String resultValue = "C"; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	System.out.println("payload-->"+ teststepJson.toString());
	Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
	test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	System.out.println(createteststepresponse.getBody().asString());
	
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);		
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("-1");
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
}
	
//Clone test step using position as -1 to the last test step
	@Test(priority = 6)
	public void cloneTeststep_test6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-1");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
		
		//Clone test step using position as -2 to the first test step
	@Test(priority = 7)
	public void cloneTeststep_test7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-2");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step using position as -2 to the first test step
	 */
	
	//Clone test step using position as -2 to the last test step
	@Test(priority = 8)
	public void cloneTeststep_test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-2");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step using position as -2 to the middle test step
	 */
	@Test(priority = 9)
	public void cloneTeststep_test9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "abc";
		String dataValue = "jjj";
		String resultValue = "kkk";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
		for (int i = 0; i < 2; i++) {
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		}
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"clonesteps 111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"1\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-2");
		
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	
	
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step using a valid position without changing the step value
	 */
	@Test(priority = 10)
	public void cloneTeststep_test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setData("Clone"+dataValue);
		System.out.println("didn't added clone word as label for clone step");
		teststepJson.setClone_position_Id("1");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	
	
	
	
	 // Created by debadatta.kathar
	 // Clone test step using a valid position by changing the step value
	 
	
	@Test(priority = 11)
	public void cloneTeststep_test11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);

		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "updated step";
		String updateddataValue = "updated test data";
		String updatedresultValue = "updated expected result"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);

		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+updatedstepValue);
		teststepJson.setClone_position_Id("-2");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	
	// Created by debadatta.kathar
	 // Clone test step using invalid iisueId
	 
	@Test(priority = 12)
	public void cloneTeststep_test12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//Long projectId = 10299l;
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		//Long projectId2 = 10299l;
		Long issueId2 = 10299l;
		
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId2, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateCreateTestStepInvalidIsueId2(projectId, issueId2, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step using invalid position 
	 */
	@Test(priority = 13)
	public void cloneTeststep_test13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("44");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTestStepInvalidPositionId(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	/**
	 * Created by debadatta.kathar
	 * Clone test modified step 
	 */
	@Test(priority = 14)
	public void cloneTeststep_test14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		

		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "modified";
		String updateddataValue = "modified";
		String updatedresultValue = "modified"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);
	

		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+updatedstepValue);
		teststepJson.setClone_position_Id("-2");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test modified step with different wiki format
	 */
	@Test(priority = 15)
	public void cloneTeststep_test15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		

		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "different";
		String updateddataValue = "h1. different";
		String updatedresultValue = "h2. different"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);
	

		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+updatedstepValue);
		teststepJson.setClone_position_Id("-2");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone a cloned step
	 */
	@Test(priority = 16)
	public void cloneTeststep_test16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		
		//String stepValue2 =  (String) (teststepJson.setStep1("Clone"+stepValue));
		teststepJson.setClone_position_Id("-1");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
	
		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	
		String stepid2= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad2 = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad2);
      teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-1");
		Response Cloneteststepresponse2 = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid2, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse2.getBody().asString());		
	
	
	}
		

	/**
	 * Created by debadatta.kathar
	 * Attempt to clone a deleted step
	 */
	@Test(priority = 17)
	/*public void cloneTeststep_test17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = 10200l;
		Long issueId = 10788l;
		String stepId = "0001479908836926-242ac1121-0001";
		String payLoad = "{\"step\":\"new\",\"data\":\"new\",\"result\":\"new\",\"position\":\"-2\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateClonedTeststep(projectId, issueId, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	*/
	
	//
	public void cloneTeststep_test17() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Delete test step with wiki format");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);
		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("h1. Biggest heading");
		TeststepJson.setData("h1. Biggest heading");
		TeststepJson.setResult("h1. Biggest heading");
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	

	
	
// clone same step multiple times
	@Test(priority = 18)
	public void cloneTeststep_test18(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
			issuePayLoad.setSummary("Test"+System.currentTimeMillis());
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
			
			//Step values
			String stepValue = "12345";
			String dataValue = "!@#$%^&*";
			String resultValue = "русский (Россия)español "; 		
			Teststep teststepJson = new Teststep();
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			System.out.println("payload-->"+ teststepJson.toString());
			Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
			test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			
			boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
			Assert.assertTrue(Createteststepstatus);		
			
			String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
			System.out.println("Step id "+ stepid);	
			String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
			System.out.println(payLoad);
			teststepJson.setStep("Clone"+stepValue);
			teststepJson.setClone_position_Id("2");
			for (int i = 0; i < 3; i++) {
			Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
			Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
			System.out.println(Cloneteststepresponse.getBody().asString());		
			boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
			Assert.assertTrue(Clonestatus);
			}
			test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	
	
	
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step having number, special character, international character
	 */
	@Test(priority = 19)
	public void cloneTeststep_test19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "12345";
		String dataValue = "!@#$%^&*";
		String resultValue = "русский (Россия)español "; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("2");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	
	
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step if there 1000 steps in an issue
	 */
	@Test(priority = 20)
	public void cloneTeststep_test20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "abc";
		String dataValue = "jjj";
		String resultValue = "kkk";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
		//for (int i = 0; i < 1000; i++) if user wants clone after creating 1000 steps
		for (int i = 0; i < 5; i++){		
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		}
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"clonesteps 111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"1\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("2");
		
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	/**
	 * Created by debadatta.kathar
	 * Clone test step with no step value
	 */
	
	@Test(priority = 21)
	public void cloneTeststep_test21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "";
		String dataValue = "data";
		String resultValue = "result"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	/**
	 * Created by debadatta.kathar
	 * Clone test step with no data value
	 */
	@Test(priority = 22)
	public void cloneTeststep_test22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "step";
		String dataValue = "";
		String resultValue = "result"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step with no rseult value
	 */
	@Test(priority = 23)
	public void cloneTeststep_test23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "step";
		String dataValue = "data";
		String resultValue = ""; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step with step value "CLONE" as first letter
	 */
	@Test(priority = 24)
	public void cloneTeststep_test24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "CLONE";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	/**
	 * Created by debadatta.kathar
	 * Clone test step with invalid projectId
	 */
	
	@Test(priority = 25)
	public void cloneTeststep_test25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//Long projectId = 10299l;
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		//issuePayLoad.setProject("199999");
		
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		Long projectId2 = 10299l;
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId2, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateCreateTestStepInvalidProjectId(projectId2, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	
	/**
	 * Created by debadatta.kathar
	 * Clone test step with invalid projectId
	 */
	
	@Test(priority = 26)
	public void cloneTeststep_test26AttemptcloneTeststepWithInvalidProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//Long projectId = 10299l;
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		Long projectId2 = 10299l;
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId2, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		boolean Clonestatus = zapiService.validateCreateTestStepInvalidProjectId(projectId2, issueId, payLoad, Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar
	 * Clone test step with no step,data,result value
	 */
@Test(priority = 27)
public void cloneTeststep_test27(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "";
	String dataValue = "";
	String resultValue = ""; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	System.out.println("payload-->"+ teststepJson.toString());
	Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
	test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	System.out.println(createteststepresponse.getBody().asString());
	
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);		
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("0");
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
}
}

