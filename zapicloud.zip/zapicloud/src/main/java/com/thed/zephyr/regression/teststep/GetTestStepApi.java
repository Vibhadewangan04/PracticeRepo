//Get teststepAPi


package com.thed.zephyr.regression.teststep;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class GetTestStepApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	Long projectId = Long.parseLong(Config.getValue("projectId"));
	Long issueId;
	Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));

	@BeforeClass
	public void beforeClass() {

		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).get("id").toString());
	}

	// get test step which having wiki format text : biggest heading
	@Test(priority = 1, enabled = true)
	public void getTeststepHavingWikiHeading1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("h1. Biggest heading");
		teststepJson.setData("h1. Hey");
		teststepJson.setResult("h1. Hello");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		// String stepId2 = "";

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());
		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having wiki format text : bigger heading
	@Test(priority = 2, enabled = true)
	public void getTeststepHavingWikiHeading2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("h2. Bigger heading");
		teststepJson.setData("h2. Hi");
		teststepJson.setResult("h2. Dude");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having wiki format text : Big heading
	@Test(priority = 3, enabled = true)
	public void getTeststepHavingWikiHeading3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("h3. Big heading");
		teststepJson.setData("h3. Hello");
		teststepJson.setResult("h3. Buddy");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having wiki format text : Normal heading
	@Test(priority = 4, enabled = true)
	public void getTeststepHavingWikiHeading4() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("h4. Normal heading");
		teststepJson.setData("h4. Hello world");
		teststepJson.setResult("h4. Hi Everyone");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having wiki format text : Small heading
	@Test(priority = 5, enabled = true)
	public void getTeststepHavingWikiHeading5() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("h5. Small heading");
		teststepJson.setData("h5. Good morning");
		teststepJson.setResult("h5. how are u");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having wiki format text : Smallest heading
	@Test(priority = 6, enabled = true)
	public void getTeststepHavingWikiHeading6() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("h6. Smallest heading");
		teststepJson.setData("h6. bye");
		teststepJson.setResult("h6. Good Night");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having strong cases of wiki format text
	@Test(priority = 7, enabled = true)
	public void getTeststepHavingWikiStrong() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("*strong*");
		teststepJson.setData("*alphabet in strong case*");
		teststepJson.setResult("*Hehehe*");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having emphasis cases of wiki format text
	@Test(priority = 8, enabled = true)
	public void getTeststepHavingWikiEmphasis() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("_emphasis_");
		teststepJson.setData("_Java programmimg_");
		teststepJson.setResult("_c++ programmimg_");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having citation of wiki format text
	@Test(priority = 9, enabled = true)
	public void getTeststepHavingWikiCitation() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("??citation??");
		teststepJson.setData("??Zapi technology??");
		teststepJson.setResult("??zephyr,bangalore??");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having deleted wiki format text
	@Test(priority = 10, enabled = true)
	public void getTeststepHavingWikiDeleted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("-deleted-");
		teststepJson.setData("-test cases to delete-");
		teststepJson.setResult("-facebook-");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having inserted wiki format text
	@Test(priority = 11, enabled = true)
	public void getTeststepHavingWikiInserted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("+inserted+");
		teststepJson.setData("+underline the points+");
		teststepJson.setResult("+important notes+");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having superscript wiki format text
	@Test(priority = 12, enabled = true)
	public void getTeststepHavingWikiSuperscript() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("^2^ 3");
		teststepJson.setData("10 ^2^");
		teststepJson.setResult("7 ^3^ 4");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having subscript wiki format text
	@Test(priority = 13, enabled = true)
	public void getTeststepHavingWikiSubscript() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("~2~ 3");
		teststepJson.setData("10 ~2~");
		teststepJson.setResult("7 ~3~ 4");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having block quoted wiki format text
	@Test(priority = 14, enabled = true)
	public void getTeststepHavingWikiBlockQuotedText() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("bq. test step");
		teststepJson.setData("bq. test data");
		teststepJson.setResult("bq. step result");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having block quoted wiki format text
	@Test(priority = 15, enabled = true)
	public void getTeststepHavingWikiBlockQuotedText2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("{quote}here is quotable content to be quoted {quote}");
		teststepJson.setData("{quote}here is quotable content to be quoted {quote}");
		teststepJson.setResult("{quote}here is quotable content to be quoted {quote}");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having colored wiki format text
	@Test(priority = 16, enabled = true)
	public void getTeststepHavingWikiColorText() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("{color:red}look ma, red text!{color}");
		teststepJson.setData("{color:blue}look ma, blue text!{color}");
		teststepJson.setResult("{color:yellow}yellow text!{color}");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having horizontal line
	@Test(priority = 17, enabled = true)
	public void getTeststepHavingWikiHoriZontalLine() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("----creates a horizontal line");
		teststepJson.setData("----creates a horizontal line");
		teststepJson.setResult("----creates a horizontal line");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having hifen symbol
	@Test(priority = 18, enabled = true)
	public void getTeststepHavingWikiHifenSymbol() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("---produces hifen symbol");
		teststepJson.setData("---produces hifen symbol");
		teststepJson.setResult("---produces hifen symbol");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having link
	@Test(priority = 19, enabled = true)
	public void getTeststepHavingWikiLink() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		teststepJson.setData("[Atlassian|http://atlassian.com]");
		teststepJson.setResult("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having bullet points
	@Test(priority = 20, enabled = true)
	public void getTeststepHavingWikiBulletPoint() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("* some\n* bullet\n* points");
		teststepJson.setData("* Whatsup app\n* facebook\n* Twitter");
		teststepJson.setResult("* java programming language\n* c++\n* Ruby and Pythan");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Numbered List
	@Test(priority = 21, enabled = true)
	public void getTeststepHavingWikiNumberedList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("# a\n# numbered\n# list");
		teststepJson.setData("# Zapi\n# Zapi Technology,banglore\n# Vlcc building");
		teststepJson.setResult("# Zephyr\n# Zfjcloud\n# Zee and Zfj");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having line break
	@Test(priority = 22, enabled = true)
	public void getTeststepHavingWikiLineBreak() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("Hello\\\\good morning");
		teststepJson.setData("Hello\\\\world");
		teststepJson.setResult("Hi\\\\everyone");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having image
	@Test(priority = 23, enabled = true)
	public void getTeststepHavingWikiImage() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		teststepJson.setData("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		teststepJson.setResult("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having table
	@Test(priority = 24, enabled = true)
	public void getTeststepHavingWikiTable() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		teststepJson.setData("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		teststepJson.setResult("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Email Link
	@Test(priority = 25, enabled = true)
	public void getTeststepHavingWikiEmailLink() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("[mailto:legendaryservice@atlassian.com]");
		teststepJson.setData("[mailto:legendaryservice@atlassian.com]");
		teststepJson.setResult("[mailto:legendaryservice@atlassian.com]");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Empty line
	@Test(priority = 26, enabled = true)
	public void getTeststepHavingWikiEmptyLine() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("paragraph1\n\nparagraph2");
		teststepJson.setData("paragraph1\n\nparagraph2");
		teststepJson.setResult("paragraph1\n\nparagraph2");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Escape character
	@Test(priority = 27, enabled = true)
	public void getTeststepHavingWikiEscapeCharacter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("\\* a\n\\* b");
		teststepJson.setData("\\* a\n\\* b");
		teststepJson.setResult("\\* a\n\\* b");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having different types of wiki formated text
	@Test(priority = 28, enabled = true)
	public void getTeststepHavingDifferentWiki1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("-deleted-");
		teststepJson.setData("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		teststepJson.setResult("h2. Bigger heading");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having different types of wiki formated text
	@Test(priority = 29, enabled = true)
	public void getTeststepHavingDifferentWiki2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("* some\n* bullet\n* points");
		teststepJson.setData("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		teststepJson.setResult("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having different types of wiki formated text
	@Test(priority = 30, enabled = true)
	public void getTeststepHavingDifferentWiki3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("{color:green}look ma, green text!{color}");
		teststepJson.setData("# a\n# numbered\n# list");
		teststepJson.setResult("[mailto:legendaryservice@atlassian.com]");

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having only Test step value
	@Test(priority = 31, enabled = true)
	public void getTeststepHavingOnlyStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "A";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having only Test data value
	@Test(priority = 32, enabled = true)
	public void getTeststepHavingOnlyTestData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String dataValue = "only data";
		Teststep teststepJson = new Teststep();
		teststepJson.setData(dataValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having only Test step expected Result value
	@Test(priority = 33, enabled = true)
	public void getTeststepHavingOnlyTestResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String resultData = "only result";
		Teststep teststepJson = new Teststep();
		teststepJson.setResult(resultData);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test step and test data value
	@Test(priority = 34, enabled = true)
	public void getTeststepHavingTestStepAndData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "step";
		String dataValue = "data";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test step and test step result value
	@Test(priority = 35, enabled = true)
	public void getTeststepHavingTestStepAndResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "step";
		String resultValue = "result";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test data and test step result value
	@Test(priority = 36, enabled = true)
	public void getTeststepHavingTestDataAndResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String dataValue = "data";
		String resultValue = "result";
		Teststep teststepJson = new Teststep();
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test steps in capital letter
	@Test(priority = 37, enabled = true)
	public void getTeststepHavingOnlyCapitalAlpha() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "AAAA";
		String dataValue = "BBBB";
		String resultValue = "CCCC";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test steps in small letter
	@Test(priority = 38, enabled = true)
	public void getTeststepHavingOnlySmallAlpha() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "aaaa";
		String dataValue = "bbbb";
		String resultValue = "cccc";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test steps in alphanumeric characters
	@Test(priority = 39, enabled = true)
	public void getTeststepHavingAlphanumeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "sadf345";
		String dataValue = "2345fghh";
		String resultValue = "hsgytd87yhjuy89iu";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test steps only in numeric
	@Test(priority = 40, enabled = true)
	public void getTeststepHavingOnlyNumeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "2345";
		String dataValue = "9786543";
		String resultValue = "345678976543";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test steps only in special char
	@Test(priority = 41, enabled = true)
	public void getTeststepHavingOnlySpecialChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "~!@#$%";
		String dataValue = "+_)(*&^%$";
		String resultValue = "&*()(*&^%$()+_)(*&^%$#@";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Test steps in all type of character with blank
	// spaces
	@Test(priority = 42, enabled = true)
	public void getTeststepHavingAllTypeOfChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789";
		String dataValue = "tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789";
		String resultValue = "tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having international char: french
	@Test(priority = 43, enabled = true)
	public void getTeststepHavingFrenchChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Nouveau statut d'exécution pour des exécutons concordantes";
		String dataValue = "La permission d'accéder à Zephyr pour le nuage Jira de  HipChat a été autorisée.";
		String resultValue = "Supprimer cette étape de statut d'exécution";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having international char: German
	@Test(priority = 44, enabled = true)
	public void getTeststepHavingGermanChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Dieser JIRA Issue Type wird zur Stellung von Zephyr Tests verwendert.";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat bereits gewährt. Seite neu laden, um Zephyr für Jira Cloud bezüglich HipChat zu verwenden.";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having international char: Spanish
	@Test(priority = 45, enabled = true)
	public void getTeststepHavingSpanishChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Ya se ha concedido una autorización para acceder a Zephyr para Jira Cloud y para HipChat. Vuelva a cargar la página para utilizar Zephyr para Jira Cloud y para HipChat.";
		String dataValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		String resultValue = "Eliminar Step Execution Status";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having different type of international char:
	// French,German,Spanish
	@Test(priority = 46, enabled = true)
	public void getTeststepHavingInternationalChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having Long char
	@Test(priority = 47, enabled = true)
	public void getTeststepHavingLongChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...";
		String dataValue = "This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...";
		String resultValue = "This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get test step which having blank data in step
	@Test(priority = 48, enabled = true)
	public void getTeststepHavingBlankData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "";
		String dataValue = "";
		// String resultValue = "";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		// teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test stepId invalid
	@Test(priority = 50, enabled = true)
	public void attemptToGetTeststepWithInvalidStepId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		String stepIdInvalid = "0001479902137205-242ac1121-0001";
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepIdInvalid);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidStepId(stepIdInvalid, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test stepId value=null
	@Test(priority = 51, enabled = true)
	public void attemptToGetTeststepWithStepIdNull() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		String stepIdInvalid = null;
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepIdInvalid);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidStepId(stepIdInvalid, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test Blank stepId
	@Test(priority = 52, enabled = true)
	public void attemptToGetTeststepWithStepIdBlank() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);

		String stepIdInvalid = "";
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepIdInvalid);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidStepId(stepIdInvalid, getStepResponse);
		//Assert.assertTrue(status);
		Assert.assertFalse(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test Null issueid
	@Test(priority = 53, enabled = true)
	public void attemptToGetTeststepWithNullIssueid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		Long invalidIssueId = 0l;

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, invalidIssueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(invalidIssueId, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test Invalid issueid
	@Test(priority = 54, enabled = true)
	public void attemptToGetTeststepWithInvalidIssueid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		Long invalidIssueId = 10555l;

		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, invalidIssueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(invalidIssueId, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test Invalid projectId
	@Test(priority = 55, enabled = true)
	public void attemptToGetTeststepWithInvalidProjectid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		Long invalidProjectId = 46578l;
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, invalidProjectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidProjectIdForTestStep(invalidProjectId, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with test Null projectId
	@Test(priority = 56, enabled = true)
	public void attemptToGetTeststepWithNullProjectid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		Long invalidprojectId =null;
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, invalidprojectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateNullProjectId(invalidprojectId, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
		System.out.println("will not GetTeststep bcoz of NullProjectid");
	}

	// attempt to get test step with mismatch projectId and issueId
	@Test(priority = 57, enabled = true)
	public void attemptToGetTeststepWith_Mismatch_ProjectIdAndIssueId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		Long projectId2 = 100002l;
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId2, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidProjectId(projectId2, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to get test step with mismatch issueId and stepId
	@Test(priority = 58, enabled = true)
	public void attemptToGetTeststepWith_Mismatch_IssueIdAndStepId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		String stepValue = "Supprimer cette étape de statut d'exécution";
		String dataValue = "Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.";
		String resultValue = "Nuevo status de ejecución para coincidir con ejecuciones";
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createStepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createStepResponse, "create test step response is null");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createStepResponse.getBody().asString());

		boolean createStepStatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createStepResponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");

		String stepId = new JSONObject(createStepResponse.getBody().asString()).get("id").toString();
		System.out.println("stepid=" + stepId);
		Long issueId2 = 10888l;
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId2, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(issueId2, getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
