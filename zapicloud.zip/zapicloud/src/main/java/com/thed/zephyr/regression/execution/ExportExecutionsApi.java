/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.ExportExecution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class ExportExecutionsApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	String exportType = null;
	private Long projectId1;
	private int projectName1;
	private Long issueId;
	private String expand;
	private boolean maxAllowed;
	private int startIndex;
	private Execution executionJson1;
	private JSONObject teststepObj;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}


	//Export execution in XML Format when all executions are unexecuted
	@Test(priority = 1,enabled=testEnabled)
	public void test1_exportExecutionsInXMLFormatWhenAllExecutionsAreUnexecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
		
		// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
		//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId);
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId);
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
		
		
		//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {executionId,executionId1};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = UNEXECUTED ";
System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in XML Format when all executions are executed
	@Test(priority = 2, enabled=testEnabled)
	public void test2_exportExecutionsInXMLFormatWhenAllExecutionsAreExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
		
		// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						
					//String	ex1=jsarray2.getString(0).toString();
						String	ex1=exeIds.get(0).toString();
				//	String ex2=jsarray2.getString(1).toString();
						String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	
	//Export execution in XML Format when all executions have different status
	@Test(priority = 3,enabled=testEnabled)
	public void test3_exportExecutionsInXMLFormatWhenAllExecutionsHaveDifferentStatus(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//2 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length()-1;j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(2l);
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						
						/*String	ex1=exeIds.get(0).toString();
						String	ex2=exeIds.get(1).toString();*/
						String	ex1=jsarray2.getString(0).toString();
						String	ex2=jsarray2.getString(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus in(FAIL,UNEXECUTED)  ";
       System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in XML Format when all executions have comments
	@Test(priority = 4, enabled=testEnabled)
	public void test4_exportExecutionsInXMLFormatWhenExecutionsHaveComments(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//2 executionn
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						String	ex1=exeIds.get(0).toString();
						String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
      System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in XML Format when all executions have unexecuted test steps
	@Test(priority = 5,enabled=testEnabled)
	public void test5_exportExecutionsInXMLFormatWhenExecutionsHaveUnexecutedTestSteps(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create test steps
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(1);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						String	ex1=jsarray2.getString(0).toString();
				//	String ex2=jsarray2.getString(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
     System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in XML Format when all executions have executed test steps
	@Test(priority = 6, enabled= testEnabled)
	public void test6_exportExecutionsInXMLFormatWhenExecutionsHaveExecutedTestSteps(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
				
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\": \""+ stepId +"\",\"issueId\": \""  + issueId11 + "\", \"status \":  {  \"id\" : \"1\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 50 executions in XML Format
	@Test(priority = 7,enabled=false)
	public void test7_export50ExecutionsInXMLFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
        Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(50);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 500 executions in XML Format
	@Test(priority = 8,enabled=false)
	public void test8_export500ExecutionsInXMLFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		exportType = "XML";
		
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(500);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
	    String	ex1=exeIds.get(0).toString();
	    String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 1000 executions in XML Format
	@Test(priority = 9,enabled=false)
	public void test9_export1000ExecutionsInXMLFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		exportType = "XML";
		
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1000);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(1000);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
	    String	ex1=exeIds.get(0).toString();
	    String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in CSV Format when all executions are unexecuted
	@Test(priority = 10,enabled=testEnabled)
	public void test10_exportExecutionsInCSVFormatWhenAllExecutionsAreUnexecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "CSV";
	    Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
	    maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(-1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	     String	ex1=exeIds.get(0).toString();
	     String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = UNEXECUTED ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in CSV Format when all executions are executed
	@Test(priority = 11, enabled=testEnabled)
	public void test11_exportExecutionsInCSVFormatWhenAllExecutionsAreExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "CSV";
	    Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
	    maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update execution
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	     String	ex1=exeIds.get(0).toString();
	     String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in CSV Format when all executions have different status
	@Test(priority = 12,enabled=testEnabled)
	public void test12_exportExecutionsInCSVFormatWhenAllExecutionsHaveDifferentStatus(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "CSV";
	    Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
	    maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update execution
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length()-1;j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(2l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	    /* String	ex1=exeIds.get(0).toString();
	     String	ex2=exeIds.get(1).toString();*/
	String	ex1=jsarray2.getString(0).toString();
	String	ex2=jsarray2.getString(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus in (FAIL,UNEXECUTED) ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);
		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in CSV Format when all executions have comments
	@Test(priority = 13,enabled=testEnabled)
	public void test13_exportExecutionsInCSVFormatWhenExecutionsHaveComments(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "CSV";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//2 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						String	ex1=exeIds.get(0).toString();
						String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
     System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in CSV Format when all executions have unexecuted test steps
	@Test(priority = 14,enabled=testEnabled)
	public void test14_exportExecutionsInCSVFormatWhenExecutionsHaveUnexecutedTestSteps(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		 String exportType = "CSV";
	     Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		 expand = "teststeps";
		 maxAllowed=true;
		 startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create test steps
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		        System.out.println(CycleName);
		
		//1 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(1);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						String	ex1=jsarray2.getString(0).toString();
				//	String ex2=jsarray2.getString(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
    System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 50 executions in CSV Format
	@Test(priority = 16, enabled=false)
	public void test16_export50ExecutionsInCSVFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "CSV";
	    Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 50);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(50);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);
		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 500 executions in CSV Format
	@Test(priority = 17,enabled=false)
	public void test17_export500ExecutionsInCSVFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "CSV";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 500);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(500);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 1000 executions in CSV Format
	@Test(priority = 18,enabled=false)
	public void test18_export1000ExecutionsInCSVFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "CSV";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(1000);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in HTML Format when all executions are unexecuted
	@Test(priority = 19,enabled=testEnabled)
	public void test19_exportExecutionsInHTMLFormatWhenAllExecutionsAreUnexecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	String	exportType = "HTML";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
	    maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(-1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	     String	ex1=exeIds.get(0).toString();
	     String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = UNEXECUTED ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in HTML Format when all executions are executed
	@Test(priority = 20,enabled=testEnabled)
	public void test20_exportExecutionsInHTMLFormatWhenAllExecutionsAreExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "HTML";
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
	    maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
       String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update execution
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	     String	ex1=exeIds.get(0).toString();
	     String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
       System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in HTML Format when all executions have different status
	@Test(priority = 21,enabled=testEnabled)
	public void test21_exportExecutionsInHTMLFormatWhenAllExecutionsHaveDifferentStatus(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	    String	exportType = "HTML";
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//2 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length()-1;j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(2l);
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						
						/*String	ex1=exeIds.get(0).toString();
						String	ex2=exeIds.get(1).toString();*/
						String	ex1=jsarray2.getString(0).toString();
						String	ex2=jsarray2.getString(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus in(FAIL,UNEXECUTED)  ";
      System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in HTML Format when all executions have comments
	@Test(priority = 22,enabled=testEnabled)
	public void test22_exportExecutionsInHTMLFormatWhenExecutionsHaveComments(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	    String	exportType = "HTML";
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//2 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						String	ex1=exeIds.get(0).toString();
						String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
    System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);
		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in HTML Format when all executions have unexecuted test steps
	@Test(priority = 23,enabled=testEnabled)
	public void test23_exportExecutionsInHTMLFormatWhenExecutionsHaveUnexecutedTestSteps(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		 String exportType = "HTML";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		 expand = "teststeps";
		 maxAllowed=true;
		 startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create test steps
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		        System.out.println(CycleName);
		
		//1 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(1);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						String	ex1=jsarray2.getString(0).toString();
				//	String ex2=jsarray2.getString(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Export execution in HTML Format when all executions have executed test steps
	@Test(priority = 24,enabled=testEnabled)
	public void test24_exportExecutionsInHTMLFormatWhenExecutionsHaveExecutedTestSteps(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	    String exportType = "HTML";
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
		String	stepId=new JSONObject(stepresponse.body().asString()).get("id").toString();
				
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId11 = issueIds.get(j);
				executionJson11.setIssueId(issueId11);
				System.out.println(issueId11);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
				Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println(StepResultsresponse.getBody().asString());
				
				JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
				JSONArray value = js1.getJSONArray("stepResults");
				JSONObject stepResult = value.getJSONObject(0);
				String stepresultid = stepResult.get("id").toString();
				stepId= stepResult.get("stepId").toString();
				ex1 =stepResult.get("executionId").toString();
				issueId =Long.parseLong(stepResult.get("issueId").toString());
				System.err.println(stepresultid);
				
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\":" + issueId +  \" status\":\""{\"id\":\"\"1"}}";
				
			//	{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";

	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\": \""+ stepId +"\",\"issueId\": \""  + issueId + "\", \"status \":  {  \"id\" : \"1\"}}";
	
	
	
	   System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS  ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 50 executions in HTML Format
	@Test(priority = 25,enabled=false)
	public void test25_export50ExecutionsInHTMLFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	     String	exportType = "HTML";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		 expand = "teststeps";
		 maxAllowed=true;
		 startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(50);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 500 executions in HTML Format
	@Test(priority = 26,enabled=false)
	public void test26_export500ExecutionsInHTMLFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	    String exportType = "HTML";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(500);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Export 1000 executions in HTML Format
	@Test(priority = 27,enabled=false)
	public void test27_export1000ExecutionsInHTMLFormat(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "HTML";
		 Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(1000);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
						//update
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId11 = issueIds.get(j);
		executionJson11.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson11.setStatusId(1l);
		executionJson11.setExecutionId(exeid);
							
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			executionJson11.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");
}
						
						
	String	ex1=exeIds.get(0).toString();
	String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
        System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);


		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export executions Api Response is null.");
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status11 = zapiService.validateExportExecutions(fileName, exportType);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Attempt to export executions using wrong exportType
	@Test(priority = 28,enabled=testEnabled)
	public void test28_attemptToExportExecutionsUsingWrongExportType(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String exportType = "aaa";
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		 String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
		
		// Create cycle
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("export execution"+System.currentTimeMillis());
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		
			//2 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						
						//update
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId11 = issueIds.get(j);
							executionJson11.setIssueId(issueId11);
							System.out.println(issueId11);
							executionJson11.setStatusId(1l);
							executionJson11.setExecutionId(exeid);
							
							////update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}
						
						
					//String	ex1=jsarray2.getString(0).toString();
						String	ex1=exeIds.get(0).toString();
				//	String ex2=jsarray2.getString(1).toString();
						String	ex2=exeIds.get(1).toString();
					
					//String[] executions = {"0001478798882197-242ac1131-0001","0001478842855816-242ac1131-0001"};
		String[] executions = {ex1,ex2};	
		String zqlQuery = "project =  \""+projectName+"\" AND cycleName = \""+CycleName+"\" AND executionStatus = PASS ";
       System.err.println(zqlQuery);
		ExportExecution exportJson = new ExportExecution();
		exportJson.setExportType(exportType);
		exportJson.setExecutions(executions);
		exportJson.setzqlQuery(zqlQuery);

		Response response = zapiService.exportExecutions(jwtGenerator, exportJson.toString());
		Assert.assertNotNull(response, "Export Executions Api Response is null.");
		test.log(LogStatus.PASS, "Export Executions Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateExportExecutions(response.getBody().asString(), exportType);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
}
