/**
 *
 */
package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class QuickSearch extends BaseTest{

	JwtGenerator jwtGenerator = null;
	String zql = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//Search Execution Filters by Filter's name
	@Test(priority = 1)
	public void test1_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("search" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//Search Execution Filters by Filter name with 2 chars
	@Test(priority = 2)
	public void test2_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("search" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = "se";

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters by Filter name with special characters
	@Test(priority = 3)
	public void test3_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("@@@@" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = "@@@@";

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters by Filter name with alphanumeric characters
	@Test(priority = 4)
	public void test4_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("alp50" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters by Filter name with only numbers
	@Test(priority = 5)
	public void test5_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("5050" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//Search Execution Filters by Filter name with spaces
	@Test(priority = 6)
	public void test6_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Filter with Space" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters by Filter name with Capital Letters
	@Test(priority = 7)
	public void test7_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("CAPS" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters by Filter's Description
	@Test(priority = 8)
	public void test8_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Through desc" + System.currentTimeMillis());
		zqlfilterJson.setDescription("description");
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = "description";

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters with new value after renaming filter to a different name or description
	@Test(priority = 9)
	public void test9_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("search" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Updated"+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//TODO
	//	Create 10 filters with similar name and search with partial text
	//TODO
	//	Create 50 filters with similar name and search with partial text
	//TODO
	//	Create 100 filters with similar name and search with partial text
	//TODO
	//	Create 500 filters with similar name and search with partial text

	//	Search Execution Filters by Filtername, if there are no matchings for Filter Name or description
	@Test(priority = 14)
	public void test14_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String filterName = "noMatchingFilterName";

		Response response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Search Execution Filters with Old value after renaming filter to a different name or description
	@Test(priority = 15)
	public void test15_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("search" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		System.out.println(zqlfilterJson.toString());

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create ZQL Filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Updated"+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());

		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());

		response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Quick Search Api Response is null.");
		test.log(LogStatus.PASS, "Quick Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		//		Assert.assertTrue(status);
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

}
