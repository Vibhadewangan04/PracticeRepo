/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira.impl;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.api.jira.ProjectApi;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
@Service("projectApi")
public class ProjectApiImpl implements ProjectApi {
	@Override
	public Response getProjects(RequestSpecification basicAuth, String recent){
		 String api = "/rest/api/2/project";
//		 Map<String, String> headers = new HashMap<String, String>();
//		 headers.put("Content-Type", "application/json");
		 return basicAuth.queryParam("recent", recent).when().get(api);
	 }
	@Override
	public Response getProjectVersions(RequestSpecification basicAuth, String projectIdOrKey){
		 String api = "/rest/api/2/project/"+projectIdOrKey+"/versions";
//		 Map<String, String> headers = new HashMap<String, String>();
//		 headers.put("Content-Type", "application/json");
		 return basicAuth.when().get(api);
	 }
	@Override
	public Response getProjectComponents(RequestSpecification basicAuth, String projectIdOrKey){
		 String api = "/rest/api/2/project/"+projectIdOrKey+"/versions";
//		 Map<String, String> headers = new HashMap<String, String>();
//		 headers.put("Content-Type", "application/json");
		 return basicAuth.when().get(api);
	 }
	@Override
	public Response getAllProjects(RequestSpecification basicAuth){
		 String api = "/rest/api/2/project";
//		 Map<String, String> headers = new HashMap<String, String>();
//		 headers.put("Content-Type", "application/json");
		 return basicAuth.when().get(api);
	 }
	@Override
	public Response getAllProjectTypes(RequestSpecification basicAuth){
		 String api = "/rest/api/2/project";
//		 Map<String, String> headers = new HashMap<String, String>();
//		 headers.put("Content-Type", "application/json");
		 return basicAuth.when().get(api);
	 }
}
