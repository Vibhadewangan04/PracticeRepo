package com.thed.zephyr.service.jira;

import java.util.List;

import org.json.JSONArray;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface JiraApiService {
	/**
	 * @param basicAuth
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createIssue(RequestSpecification basicAuth, String payLoad);
	/**
	 * @param response
	 * @return boolean value
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	boolean validateCreateIssueApi(Response response);
	/**
	 * @param basicAuth
	 * @param issueKey
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteIssue(RequestSpecification basicAuth, String issueKey);
	/**
	 * @param basicAuth
	 * @param payLoad
	 * @param numberOfIssues
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	List<String> createIssues(RequestSpecification basicAuth, String payLoad, int numberOfIssues);
	
	Response getProjects(RequestSpecification basicAuth, String recent);
	Response getPriorities(RequestSpecification basicAuth);
	Response getUsersFromPicker(RequestSpecification basicAuth, String query, int offset, int maxResults, boolean showAvatar, String exclude);
	/**
	 * @param basicAuth
	 * @param projectIdOrKey
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getProjectVersions(RequestSpecification basicAuth, String projectIdOrKey);
	/**
	 * @param basicAuth
	 * @param projectIdOrKey
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getProjectComponents(RequestSpecification basicAuth, String projectIdOrKey);
	/**
	 * @param basicAuth
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getAllProjects(RequestSpecification basicAuth);
	/**
	 * @param basicAuth
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getAllProjectTypes(RequestSpecification basicAuth);
	
	/**
	 * @param basicAuth
	 * @param versionPayLoad
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response createVersion(RequestSpecification basicAuth, String versionPayLoad);

	/**
	 * @param basicAuth
	 * @param versionId
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getVersion(RequestSpecification basicAuth, String versionId);

	/**
	 * @param basicAuth
	 * @param versionId
	 * @param moveFixIssuesTo
	 * @param moveAffectedIssuesTo
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response deleteVersion(RequestSpecification basicAuth, String versionId, String moveFixIssuesTo,
			String moveAffectedIssuesTo);
	Response createComponent(RequestSpecification basicAuth, String componentPayLoad);
	/**
	 * @param basicAuth
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	Response searchRequest(RequestSpecification basicAuth, String payLoad);
	/**
	 * @param basicAuth
	 * @param jql
	 * @param startAt
	 * @param maxResults
	 * @return
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	Response searchRequest(RequestSpecification basicAuth, String jql, int startAt, int maxResults);
	Response createFilterInSearchTest(RequestSpecification basicAuth, String payload);
	Response createIssueLink(RequestSpecification basicAuth, String string);
	
	 Response getProjectBoard(RequestSpecification basicAuth, String projectId);
	 Response createSprint(RequestSpecification basicAuth, String payload);
	 Response addissuetosprint(RequestSpecification basicAuth, Long sprintid,String payload);
	 Response updatesprint(RequestSpecification basicAuth, Long sprintId,String payload);
	 Response deletesprint(RequestSpecification basicAuth, Long sprintId);
	 
	 Response getTransitions(RequestSpecification basicAuth, String issueKey);
	 Response editissue(RequestSpecification basicAuth, String issueKey,String payload);

}
