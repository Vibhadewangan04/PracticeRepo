/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.cycle;

import org.json.JSONArray;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class CreateCycleApi extends BaseTest{

	/*JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}*/
	/**
	 * Create a Cycle
	 */
	@Test(priority = 1, enabled = testEnabled)
	public void createCycle_lowercase_unscheduledVersion_1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("zephyr");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 2, enabled = testEnabled)
	public void createCycle_UPPERCASE_unscheduledVersion_2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("ZEPHYR");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 3, enabled = testEnabled)
	public void createCycle_numbers_unscheduledVersion_3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("1234567890");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 4, enabled = testEnabled)
	public void createCycle_alphanumeric_unscheduledVersion_4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("zephyr123");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 5, enabled = testEnabled)
	public void createCycle_specialchars_unscheduledVersion_5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("!@#$%^&*(");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 6, enabled = testEnabled)
	public void createCycle_internationalchars_unscheduledVersion_6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("zephyr123");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 7, enabled = testEnabled)
	public void createCycle_minchars_unscheduledVersion_7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("z");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 8, enabled = testEnabled)
	public void createCycle_210chars_unscheduledVersion_8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("zephyr123vbnmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 9, enabled = testEnabled)
	public void createCycle_duplicatenameinsameversion_9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("same cycle name");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 10, enabled = testEnabled)
	public void createCycle_10_duplicatenameindifferentversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("same cycle name in differenent version");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		
		response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * unscheduledVersion code copied from priority =-8
	 * Create cycle with description in lowercase
	 */
	@Test(priority = 11, enabled = testEnabled)
	public void createCycle_11_cycleDesc_lower(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Desc lower");
		cycleJson.setDescription("lower");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * Create cycle with description in UPPER CASE
	 */
	@Test(priority = 12, enabled = testEnabled)
	public void createCycle_12_cycleDesc_Uppercase(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Desc upper");
		cycleJson.setDescription("UPPERCASE");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * Create cycle with description in numbers
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void createCycle_13_cycleDesc_Numbers(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Desc number");
		cycleJson.setDescription("1234567890");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * Create cycle with description containing alphanumeric characters
	 */
	@Test(priority = 14, enabled = testEnabled)
	public void createCycle_14_cycleDesc_Aplhanumeric(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Desc Alphanumeric");
		cycleJson.setDescription("A1b2c3d4");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * Create cycle with description containing special characters and spaces
	 */
	@Test(priority = 15, enabled = testEnabled)
	public void createCycle_15_cycleDesc_Special_spaces(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Desc Specialcharacter ");
		cycleJson.setDescription("!@#$%^ &*()_+=-");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * Create cycle with description containing international characters
	 */
	@Test(priority = 16, enabled = testEnabled)
	public void createCycle_16_Desc_international_Characters(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Desc international cahracters");
		cycleJson.setDescription("Dateiname auf Deutsch");//german characters
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/*
	 * Create cycle with long description (max = 255 chars)
	 */
	@Test(priority = 17, enabled = testEnabled)
	public void createCycle_17_Desc_255_Characters(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName(" Desc 255characters");
		String char255="This issue is not exesiting in the following test bed , please try to add more informanctionof"
				+ " how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned"
				+ " this issue . Already checked in code , code checkin failed...";
		cycleJson.setDescription(char255);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
	}	
	/*
	 *Create a cycle with duplicate description to another cycle in same/different version
	 */
	@Test(priority = 18, enabled = testEnabled)
	public void createCycle_18_Desc_Duplicate_same_version(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName(" Duplicate Desc");		
		cycleJson.setDescription("My desc");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
	}
	/*
	 * coding for Various build characters started 
	 *  
	 * Create cycle with build in lowercase
	 */
	
	@Test(priority = 19, enabled = testEnabled)
	public void createCycle_19_Build_lower(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
			
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Build lower");
		cycleJson.setBuild("lower");
			
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
		/*
		 * Create cycle with Build in UPPER CASE
		 */
		@Test(priority = 20, enabled = testEnabled)
		public void createCycle_20_Build_Uppercase(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Build upper");
			cycleJson.setBuild("UPPERCASE");			
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
		/*
		 * Create cycle with Build in numbers
		 */
		@Test(priority = 21, enabled = testEnabled)
		public void createCycle_21_Build_Numbers(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Build Number");
			cycleJson.setBuild("1234567890");
			
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
		/*
		 * Create cycle with Build containing alphanumeric characters
		 */
		@Test(priority =22, enabled = testEnabled)
		public void createCycle_22_Build_Aplhanumeric(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Build number");
			cycleJson.setBuild("1234567890");
			
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
		/*
		 * Create cycle with Build containing special characters and spaces
		 */
		@Test(priority = 23, enabled = testEnabled)
		public void createCycle_23_Build_Special_spaces(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName(" Build Special character");
			cycleJson.setBuild("!@#$%^ &*()_+=-");			
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
		/*
		 * Create cycle with Build containing international characters
		 */
		@Test(priority = 24, enabled = testEnabled)
		public void createCycle_24_Build_international_Characters(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Build internatinal caharacter");
			
			cycleJson.setBuild("Dateiname auf Deutsch");//german characters
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
		/*
		 * Create cycle with long Build (max = 255 chars)
		 */
		@Test(priority = 25, enabled = testEnabled)
		public void createCycle_25_Build_255_Characters(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Build 255 character");
			String char255="This issue is not exesiting in the following test bed , please try to add more informanctionof"
					+ " how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned"
					+ " this issue . Already checked in code , code checkin failed...";
			cycleJson.setBuild(char255);
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
			
		}	
		/*
		 * no test case is there i add it for future
		 *Create a cycle with Build description to another cycle in same/different version
		 */
		@Test(priority = 26, enabled = testEnabled)
		public void createCycle_26_Build_Duplicate_same_version(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Duplicate build");		
			cycleJson.setBuild("My desc");
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
			
		}	
	
		/*
		 * coding for Various Environment characters started 
		 * Create cycle with environment in lowercase
		 */
		
		@Test(priority = 27, enabled = testEnabled)
		public void createCycle_27_environment_lower(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Environment lowercase");
			cycleJson.setBuild("lower");
				
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
			/*
			 * Create cycle with environment in UPPER CASE
			 */
		@Test(priority = 28, enabled = testEnabled)
		public void createCycle_28_environment_Uppercase(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Environment Uppercase");
			cycleJson.setBuild("UPPERCASE");			
				
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
			/*
			 * Create cycle with environment in numbers
			 */
		@Test(priority = 29, enabled = testEnabled)
		public void createCycle_29_environment_Numbers(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Environment number");
			cycleJson.setEnvironment("1234567890");
				
				
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
			/*
			 * Create cycle with environment containing alphanumeric characters
			 */
		@Test(priority =30, enabled = testEnabled)
		public void createCycle_30_environment_Aplhanumeric(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName(" Environment Alphanumeric");
			cycleJson.setEnvironment("A1b2c3d4");
				
				
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
			/*
			 * Create cycle with environment containing special characters and spaces
			 */
		@Test(priority = 31, enabled = testEnabled)
		public void createCycle_31_environment_Special_spaces(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName(" Environment Specialcharacter");
			cycleJson.setEnvironment("!@#$%^ &*()_+=-");			
				
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
			/*
			 * Create cycle with environment containing international characters
			 */
		@Test(priority = 32, enabled = testEnabled)
		public void createCycle_32_environment_international_Characters(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("Environment International character");
				
			cycleJson.setEnvironment("Dateiname auf Deutsch");//german characters
				
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
		}
			/*
			 * Create cycle with long environment (max = 255 chars)
			 */
			@Test(priority = 33, enabled = testEnabled)
			public void createCycle_33_environment_255_Characters(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("Environment 255 character");
				String char255="This issue is not exesiting in the following test bed , please try to add more informanctionof"
						+ " how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned"
						+ " this issue . Already checked in code , code checkin failed...";
				cycleJson.setEnvironment(char255);
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}	
			/*
			 * 
			 *Create a cycle with environment description to another cycle in same/different version
			 */
			@Test(priority = 34, enabled = testEnabled)
			public void createCycle_34_environment_Duplicate_same_version(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("Duplicate Environment");		
				cycleJson.setEnvironment("My Environment");
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}
			
			/*
			 * Create cycle with start date as current date
			 */
			@Test(priority = 35, enabled = testEnabled)
			public void createCycle_35_startdate_currentdate(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName(" cycle with current start date");				
				cycleJson.setStartDate("2016-11-10");
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}	
			
			/*
			 * Create cycle with start date as date in the past
			 */
			@Test(priority = 36, enabled = testEnabled)
			public void createCycle_36_startdate_pastdate(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("cycle with past start date");				
				cycleJson.setStartDate("2016-11-07");//yyyy-mm-dd
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}
			
			/*
			 * Create cycle with start date as date in the future
			 */
			@Test(priority = 37, enabled = testEnabled)
			public void createCycle_37_startdate_futuredate(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("cycle with furture start date");				
				cycleJson.setStartDate("2016-11-25");//yyyy-mm-dd
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}
			
			/*
			 * Create cycle with End date as current date
			 */
			@Test(priority = 38, enabled = testEnabled)
			public void createCycle_38_Enddate_currentdate(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("cycle with current enddate");
				cycleJson.setStartDate("2016-11-10");
				cycleJson.setEndDate("2016-11-10");
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}	
			
			/*
			 * Create cycle with End date as date in the past
			 */
			@Test(priority = 39, enabled = testEnabled)
			public void createCycle_39_startdate_pastdate(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("cycle with past end date");
				cycleJson.setStartDate("2016-11-06");
				cycleJson.setEndDate("2016-11-07");//yyyy-mm-dd
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}
			
			/*
			 * Create cycle with End date as date in the future
			 */
			@Test(priority = 40, enabled= testEnabled)
			public void createCycle_40_Enddate_futuredate(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson.setName("cycle with current furture end date");
				cycleJson.setStartDate("2016-11-20");
				cycleJson.setEndDate("2016-11-25");//yyyy-mm-dd
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				
				boolean status = zapiService.validateCycle(cycleJson.toString(), response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
				
			}
			
		/**
		 * Create Cycle with All the Fileds Filled.
		 * @author Created by manoj.behera on 14-Nov-2016.
		 */
		@Test(priority = 41, enabled = testEnabled)
		public void createCycle_41_Allfeilds_filled(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("zephyr");
			cycleJson.setDescription("description");
			cycleJson.setBuild("build");
			cycleJson.setEnvironment("environment");
			cycleJson.setStartDate("2016-11-20");
			cycleJson.setEndDate("2016-11-25");//yyyy-mm-dd
				
			System.out.println(cycleJson.toString());
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
				
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				
		}
		
		@Test(priority = 42, enabled = false)
		public void createCycle_42_50cycles(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionThreeId")));
			cycleJson.setName("Cycle example");
			cycleJson.setDescription("Cycle one desc");
			
			int numberOfCycles = 50;
			
			JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Created Cycles through Api successfully.");
			
			extentReport.endTest(test);
		}
		@Test(priority = 43, enabled = false)
		public void createCycle_43_500cycles(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionThreeId")));
			cycleJson.setName("Cycle example");
			cycleJson.setDescription("Cycle one desc");
			
			int numberOfCycles = 500;
			
			JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Created Cycles through Api successfully.");
			
			extentReport.endTest(test);
		}	
		@Test(priority = 44, enabled = false)
		public void createCycle_44_1000cycles(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionThreeId")));
			cycleJson.setName("Cycle example");
			cycleJson.setDescription("Cycle one desc");
			
			int numberOfCycles = 1000;
			
			JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Created Cycles through Api successfully.");
			
			extentReport.endTest(test);
		}		
		@Test(priority = 45, enabled = testEnabled)
		public void createCycle_45_createCycle_Attempt_endDateBeforeStartDate(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("zephyr");
			cycleJson.setDescription("description");
			cycleJson.setBuild("build");
			cycleJson.setEnvironment("environment");
			cycleJson.setStartDate("2016-11-20");
			cycleJson.setEndDate("2016-11-19");//yyyy-mm-dd
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				
		}	
		@Test(priority = 46, enabled = testEnabled)
		public void createCycle_46_createCycle_Attempt_NoProjectId(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
//			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("zephyr");
			cycleJson.setDescription("description");
			cycleJson.setBuild("build");
			cycleJson.setEnvironment("environment");
			cycleJson.setStartDate("2016-11-20");
			cycleJson.setEndDate("2016-11-25");//yyyy-mm-dd
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				
		}
		@Test(priority = 47, enabled = testEnabled)
		public void createCycle_47_createCycle_Attempt_NoVersionId(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			//cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			cycleJson.setName("zephyr");
			cycleJson.setDescription("description");
			cycleJson.setBuild("build");
			cycleJson.setEnvironment("environment");
			cycleJson.setStartDate("2016-11-20");
			cycleJson.setEndDate("2016-11-21");//yyyy-mm-dd
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				
		}
		@Test(priority = 48, enabled = testEnabled)
		public void createCycle_48_createCycle_Attempt_NoCycleName(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
				
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
//			cycleJson.setName("zephyr");
			cycleJson.setDescription("description");
			cycleJson.setBuild("build");
			cycleJson.setEnvironment("environment");
			cycleJson.setStartDate("2016-11-20");
			cycleJson.setEndDate("2016-11-19");//yyyy-mm-dd
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				
		}
			
}
