package com.thed.zephyr.regression.teststep;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class UpdateTeststepApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	private Long projectId = Long.parseLong(Config.getValue("projectId")); 
    private Long issueId;
    Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),Config.getValue("secretKey"), Config.getValue("adminUserName"));
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).get("id").toString());
	 }

	// Updating teststep for step, data and result
	@Test(priority = 1, enabled = true)
	public void updateTeststep_updating_All_value() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step			
		
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		
		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("updated step");
		teststepJson.setData("updated test data");
		teststepJson.setResult("updated expected result");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Updating step value
	 @Test(priority = 2, enabled = true)
	public void updateTeststep_Test1_UpdatingStepValue() {
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Debadatta");

			// Creating a test step			
			
			String stepValue = "step value";
			String dataValue = "data value";
			String resultValue = "result value";
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);

			String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
			System.out.println("The step id" + stepId);
			
			teststepJson.setStep("updated step");
		//	teststepJson.setData("updated test data");
		//	teststepJson.setResult("updated expected result");
			teststepJson.setId(stepId);

			response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

	// Updating data value
	 @Test(priority = 3, enabled = true)
	public void updateTeststep_Test2_UpdatingDataValue() {
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Debadatta");

			// Creating a test step in new issue
			String stepValue = "step value";
			String dataValue = "data value";
			String resultValue = "result value";
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);

			String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
			System.out.println("The step id" + stepId);
			
		//	teststepJson.setStep("updated step");
			teststepJson.setData("updated test data");
		//	teststepJson.setResult("updated expected result");
			teststepJson.setId(stepId);

			response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

	// Updating result value
	 @Test(priority = 4, enabled = true)
	public void updateTeststep_Test3_UpdatingResultValue() {
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Debadatta");

			// Creating a test step			
			
			String stepValue = "step value";
			String dataValue = "data value";
			String resultValue = "result value";
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);

			String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
			System.out.println("The step id" + stepId);
			
		//	teststepJson.setStep("updated step");
		//	teststepJson.setData("updated test data");
			teststepJson.setResult("updated expected result");
			teststepJson.setId(stepId);

			response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

	// Upadating step and data
	 @Test(priority = 5, enabled = true)
	public void updateTeststep_updating_stepAndData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("xyz");
		teststepJson.setData("nmo");
		teststepJson.setResult("lmi");

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("updated step");
		teststepJson.setData("updated test data");
	//	teststepJson.setResult("updated expected result");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Updating data and result
	 @Test(priority = 6, enabled = true)
	public void updateTeststep_updating_dataAndresult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("xyz");
		teststepJson.setData("nmo");
		teststepJson.setResult("lmi");

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
	//	teststepJson.setStep("updated step");
		teststepJson.setData("updated test data");
		teststepJson.setResult("updated expected result");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// updating step and result
	 @Test(priority = 7, enabled = true)
	public void updateTeststep_updating_stepAndResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");


		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("updated step");
	//	teststepJson.setData("updated test data");
		teststepJson.setResult("updated expected result");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Updating with number
	 @Test(priority = 8, enabled = true)
	public void updateTeststep_with_only_number() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("12345");
		teststepJson.setData("098765");
		teststepJson.setResult("345678");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// special characters
	 @Test(priority = 9, enabled = true)
	public void updateTeststep_with_only_specialChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		
		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("~!@#$%^&");
		teststepJson.setData(")$$%^&*");
		teststepJson.setResult("*&*^%$%^&*(");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// updating with international character
	 @Test(priority = 10, enabled = true)
	public void updateTeststep_with_internationalChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("русский (Россия???????????????");
		teststepJson.setData("日本語 (日本) 한국어 (대한민국)");
		teststepJson.setResult("日本語 (日本) 한국어 (대한민국 русский (Россия??? ?????");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Updating with same value
	 @Test(priority = 11, enabled = true)
	public void updateTeststep_updating_with_same_value() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
				String stepValue = "step value";
				String dataValue = "data value";
				String resultValue = "result value";
				Teststep teststepJson = new Teststep();		
				teststepJson.setStep(stepValue);
				teststepJson.setData(dataValue);
				teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("step value");
		teststepJson.setData("data value");
		teststepJson.setResult("result value");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Updating with blank values
	 @Test(priority = 12, enabled = true)
	public void updateTeststep_with_blankValue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
	
		teststepJson.setStep("");
		teststepJson.setData("");
		teststepJson.setResult("");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Re-updating the steps
	 @Test(priority = 13, enabled = true)
	public void updateTeststep_again() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("abcd");
		teststepJson.setData("abcd");
		teststepJson.setResult("abcd");

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		teststepJson.setStep("updated first time sdfgh");
		teststepJson.setData("vfghjk");
		teststepJson.setResult("tyuio");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		//updating the step again	
		teststepJson.setStep("updated 2nd time sdxyz");
		teststepJson.setData("lmn");
		teststepJson.setResult("qwerty");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Attempt to update test step of a deleted test step
	 @Test(priority = 14, enabled = true)
	public void attempt_to_update_DeletedStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id:-- " + stepId);
		//deleting that test step
		Response deleteStepResponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepId);
		boolean deleteStepStatus = zapiService.validateDeleteTeststep(deleteStepResponse, projectId, issueId, stepId);
		Assert.assertTrue(deleteStepStatus);
		//updating the step after delete
		teststepJson.setStep("wert");
		teststepJson.setData("ghjk");
		teststepJson.setResult("fdghuj");
		teststepJson.setId(stepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateInvalidStepId(stepId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	// Update clone step
	 @Test(priority = 15, enabled = true)
	public void updateTeststep_ClonedStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		//cloning the step
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		Response cloneResponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		boolean cloneStatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, cloneResponse);
		Assert.assertTrue(cloneStatus);

		String clonedStepId =new JSONObject(new JSONArray(cloneResponse.getBody().asString()).get(0).toString()).get("id").toString();
		
		teststepJson.setStep("after clone updated step");
		teststepJson.setData("after clone updated data");
		teststepJson.setResult("after clone updated result");
		teststepJson.setId(clonedStepId);

		response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, clonedStepId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
	}

	// Updating teststep 100 times
	 @Test(priority = 16, enabled = true)
	public void updateTeststep_100Times() {
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		// Creating a test step in new issue
		String stepValue = "step value";
		String dataValue = "data value";
		String resultValue = "result value";
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
	
	//	for(int i =0;i<=100;i++) u can give 100
		for(int i =0;i<=4;i++){  
			teststepJson.setStep("updated step"+i+ "times");
			teststepJson.setData("updated data"+i);
			teststepJson.setResult("updated result"+i);
			teststepJson.setId(stepId);

			response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
		}
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
		
		
	// Invalid IssueId
	 @Test(priority = 17, enabled = true)
	public void updateTeststep_InvalidIssueId() {
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Debadatta");

			// Creating a test step in new issue
			String stepValue = "step value";
			String dataValue = "data value";
			String resultValue = "result value";
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);

			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);

			String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
			System.out.println("The step id" + stepId);
		
			teststepJson.setStep("");
			teststepJson.setData("");
			teststepJson.setResult("");
			teststepJson.setId(stepId);
		//	Long invalidIssueId = 23456l;
			Long invalidIssueId = 15544l;
			response = zapiService.updateTeststep(jwtGenerator, projectId, invalidIssueId, stepId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

		//	status = zapiService.validateTeststep(projectId, invalidIssueId, teststepJson.toString(), response);
			status = zapiService.validateInvalidIssueId(invalidIssueId, response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 
	// Invalid projectId
		 @Test(priority = 18, enabled = true)
		public void updateTeststep_InvalidprojectId() {
			 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
				test.assignAuthor("Debadatta");

				// Creating a test step in new issue
				String stepValue = "step value";
				String dataValue = "data value";
				String resultValue = "result value";
				Teststep teststepJson = new Teststep();		
				teststepJson.setStep(stepValue);
				teststepJson.setData(dataValue);
				teststepJson.setResult(resultValue);

				Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());

				boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

				String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
				System.out.println("The step id" + stepId);
			
				teststepJson.setStep("");
				teststepJson.setData("");
				teststepJson.setResult("");
				teststepJson.setId(stepId);
				Long invalidprojectId = 78906l;
				response = zapiService.updateTeststep(jwtGenerator, invalidprojectId, issueId, stepId, teststepJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());
				
				status = zapiService.validateInvalidProjectId(invalidprojectId, response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
			}
		 
			// Invalid stepId
		 @Test(priority = 19, enabled = true)
		public void updateTeststep_InvalidStepId() {
			 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
				test.assignAuthor("Debadatta");

				// Creating a test step in new issue
				String stepValue = "step value";
				String dataValue = "data value";
				String resultValue = "result value";
				Teststep teststepJson = new Teststep();		
				teststepJson.setStep(stepValue);
				teststepJson.setData(dataValue);
				teststepJson.setResult(resultValue);

				Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());

				boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

				String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
				System.out.println("The step id" + stepId);
				String invalidStepId = "78906h9789";
				teststepJson.setId(invalidStepId);
				teststepJson.setStep("");
				teststepJson.setData("");
				teststepJson.setResult("");
				
				response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, invalidStepId, teststepJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());
				
				status = zapiService.validateInvalidStepId(invalidStepId, response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
			}
		 
			// Null IssueId
			 @Test(priority = 20, enabled = true)
			public void updateTeststep_NullIssueId() {
				 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Debadatta");

					// Creating a test step in new issue
					String stepValue = "step value";
					String dataValue = "data value";
					String resultValue = "result value";
					Teststep teststepJson = new Teststep();		
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);

					Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);

					String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
					System.out.println("The step id" + stepId);
				
					teststepJson.setStep("");
					teststepJson.setData("");
					teststepJson.setResult("");
					teststepJson.setId(stepId);
					Long invalidIssueId = null;
					response = zapiService.updateTeststep(jwtGenerator, projectId, invalidIssueId, stepId, teststepJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					status = zapiService.validateInvalidIssueId(invalidIssueId, response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
			 
			// Null projectId
				 @Test(priority = 21 , enabled = true)
				public void updateTeststep_NullprojectId() {
					 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
						test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
						test.assignAuthor("Debadatta");

						// Creating a test step in new issue
						String stepValue = "step value";
						String dataValue = "data value";
						String resultValue = "result value";
						Teststep teststepJson = new Teststep();		
						teststepJson.setStep(stepValue);
						teststepJson.setData(dataValue);
						teststepJson.setResult(resultValue);

						Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
						Assert.assertNotNull(response, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
						System.out.println(response.getBody().asString());

						boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
						Assert.assertTrue(status);
						test.log(LogStatus.PASS, "Response validated suuccessfully.");
						extentReport.endTest(test);

						String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
						System.out.println("The step id" + stepId);
					
						teststepJson.setStep("");
						teststepJson.setData("");
						teststepJson.setResult("");
						teststepJson.setId(stepId);
						Long invalidprojectId = null;
						response = zapiService.updateTeststep(jwtGenerator, invalidprojectId, issueId, stepId, teststepJson.toString());
						Assert.assertNotNull(response, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
						System.out.println(response.getBody().asString());
						
						//status = zapiService.validateInvalidProjectIdstep1(invalidprojectId, response);
						status = zapiService.validateInvalidProjectId(invalidprojectId, response);
						Assert.assertTrue(status);
						test.log(LogStatus.PASS, "Response validated suuccessfully.");
						extentReport.endTest(test);
					}
				 
					// Null stepId
				 @Test(priority = 22, enabled = true)
	              public void updateTeststep_NullStepId() {
					 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
						test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
						test.assignAuthor("Debadatta");

						// Creating a test step in new issue
						String stepValue = "step value";
						String dataValue = "data value";
						String resultValue = "result value";
						Teststep teststepJson = new Teststep();		
						teststepJson.setStep(stepValue);
						teststepJson.setData(dataValue);
						teststepJson.setResult(resultValue);

						Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
						Assert.assertNotNull(response, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
						System.out.println(response.getBody().asString());
						boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
   					    Assert.assertTrue(status);
						test.log(LogStatus.PASS, "Response validated suuccessfully.");
						extentReport.endTest(test);

					String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
						System.out.println("The step id" + stepId);
					//	Teststep teststepJson = new Teststep();
						String invalidStepId = null;
						
						teststepJson.setStep("");
						teststepJson.setData("");
						teststepJson.setResult("");
						teststepJson.setId(invalidStepId);
						
						Response updateTeststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, invalidStepId, teststepJson.toString());
						Assert.assertNotNull(updateTeststepresponse, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
						System.out.println(updateTeststepresponse.getBody().asString());
						
						boolean status1 = zapiService.validateInvalidStepId(invalidStepId, updateTeststepresponse);
						Assert.assertTrue(status1);
						test.log(LogStatus.PASS, "Response validated suuccessfully.");
						extentReport.endTest(test);
					}

				 
				 
					// Zero IssueId
				 @Test(priority = 23, enabled = true)
				public void updateTeststep_ZeroIssueId() {
					 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
						test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
						test.assignAuthor("Debadatta");

						// Creating a test step in new issue
						String stepValue = "step value";
						String dataValue = "data value";
						String resultValue = "result value";
						Teststep teststepJson = new Teststep();		
						teststepJson.setStep(stepValue);
						teststepJson.setData(dataValue);
						teststepJson.setResult(resultValue);

						Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
						Assert.assertNotNull(response, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
						System.out.println(response.getBody().asString());

						boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
						Assert.assertTrue(status);
						test.log(LogStatus.PASS, "Response validated suuccessfully.");
						extentReport.endTest(test);

						String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
						System.out.println("The step id" + stepId);
					
						teststepJson.setStep("");
						teststepJson.setData("");
						teststepJson.setResult("");
						teststepJson.setId(stepId);
						Long invalidIssueId = 0l;
						response = zapiService.updateTeststep(jwtGenerator, projectId, invalidIssueId, stepId, teststepJson.toString());
						Assert.assertNotNull(response, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
						System.out.println(response.getBody().asString());

						status = zapiService.validateInvalidIssueId(invalidIssueId, response);
						Assert.assertTrue(status);
						test.log(LogStatus.PASS, "Response validated suuccessfully.");
						extentReport.endTest(test);
					}
				 
				// Zero projectId
					 @Test(priority = 24, enabled = true)
					public void updateTeststep_ZeroprojectId() {
						 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
							test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
							test.assignAuthor("Debadatta");

							// Creating a test step in new issue
							String stepValue = "step value";
							String dataValue = "data value";
							String resultValue = "result value";
							Teststep teststepJson = new Teststep();		
							teststepJson.setStep(stepValue);
							teststepJson.setData(dataValue);
							teststepJson.setResult(resultValue);

							Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
							Assert.assertNotNull(response, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
							System.out.println(response.getBody().asString());

							boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
							Assert.assertTrue(status);
							test.log(LogStatus.PASS, "Response validated suuccessfully.");
							extentReport.endTest(test);

							String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
							System.out.println("The step id" + stepId);
						
							teststepJson.setStep("");
							teststepJson.setData("");
							teststepJson.setResult("");
							teststepJson.setId(stepId);
							Long invalidprojectId = 0l;
							response = zapiService.updateTeststep(jwtGenerator, invalidprojectId, issueId, stepId, teststepJson.toString());
							Assert.assertNotNull(response, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
							System.out.println(response.getBody().asString());
							
							status = zapiService.validateInvalidProjectId(invalidprojectId, response);
							Assert.assertTrue(status);
							test.log(LogStatus.PASS, "Response validated suuccessfully.");
							extentReport.endTest(test);
						}
					 
						// Zero stepId
					 @Test(priority = 25, enabled = true)
					public void updateTeststep_zeroStepId() {
						 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
							test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
							test.assignAuthor("Debadatta");

							// Creating a test step in new issue
							String stepValue = "step value";
							String dataValue = "data value";
							String resultValue = "result value";
							Teststep teststepJson = new Teststep();		
							teststepJson.setStep(stepValue);
							teststepJson.setData(dataValue);
							teststepJson.setResult(resultValue);

							Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
							Assert.assertNotNull(response, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
							System.out.println(response.getBody().asString());

							boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
							Assert.assertTrue(status);
							test.log(LogStatus.PASS, "Response validated suuccessfully.");
							extentReport.endTest(test);

							String stepId = new JSONObject(response.getBody().asString()).get("id").toString();
							System.out.println("The step id" + stepId);
							String invalidStepId = "0";
							teststepJson.setStep("");
							teststepJson.setData("");
							teststepJson.setResult("");
							teststepJson.setId(invalidStepId);
							
							response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, invalidStepId, teststepJson.toString());
							Assert.assertNotNull(response, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
							System.out.println(response.getBody().asString());
							
							status = zapiService.validateInvalidStepId(invalidStepId, response);
							Assert.assertTrue(status);
							test.log(LogStatus.PASS, "Response validated suuccessfully.");
							extentReport.endTest(test);
						}

}
