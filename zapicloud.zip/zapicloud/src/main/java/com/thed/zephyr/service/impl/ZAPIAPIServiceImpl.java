//zapi service

package com.thed.zephyr.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import java.util.Set;
import java.util.TimeZone;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.IOUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.testng.Assert;

import com.google.gson.JsonArray;
import com.jayway.restassured.response.Response;
import com.sun.jersey.core.header.ContentDisposition;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.AttachmentApi;
import com.thed.zephyr.api.ChartApi;
import com.thed.zephyr.api.ConfigApi;
import com.thed.zephyr.api.CycleApi;
import com.thed.zephyr.api.ExecutionApi;
import com.thed.zephyr.api.ExecutionworkflowApi;
import com.thed.zephyr.api.JiraReportApi;
import com.thed.zephyr.api.JobProgressApi;
import com.thed.zephyr.api.ServerInfoApi;
import com.thed.zephyr.api.StepresultsApi;
import com.thed.zephyr.api.TeststepApi;
import com.thed.zephyr.api.TraceabilityApi;
import com.thed.zephyr.api.ZqlApi;
import com.thed.zephyr.api.ZqlFilterApi;
import com.thed.zephyr.api.impl.Executionworkflowimpl;
import com.thed.zephyr.api.FolderApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.service.ZAPIApiService;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */



@Service("zapiService")
public class ZAPIAPIServiceImpl implements ZAPIApiService {

	@Autowired
	private CycleApi cycleApi;

	@Autowired
	private FolderApi folderApi;// we need @Service("folderApi") in Folder APi method

	@Autowired
	private ExecutionworkflowApi executionworkflowApi;

	@Autowired
	private ExecutionApi executionApi;

	@Autowired
	private ConfigApi configApi;

	@Autowired
	private ServerInfoApi serverInfoApi;

	@Autowired
	private TeststepApi teststepApi;

	@Autowired
	private ZqlApi zqlApi;

	@Autowired
	private ZqlFilterApi zqlFilterApi;

	@Autowired
	private AttachmentApi attachmentApi;

	@Autowired
	private StepresultsApi stepresultsApi;

	@Autowired
	private JobProgressApi jobProgressApi;

	@Autowired
	private TraceabilityApi traceabilityApi;

	@Autowired
	private ChartApi chartApi;

	@Autowired
	private JiraReportApi jiraReportApi;

	Long versionId = null;
	  private Long projectId = Long.parseLong(Config.getValue("projectId")); 
	  private Long projectId1 = Long.parseLong(Config.getValue("projectId1")); 
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#createCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createCycle(JwtGenerator jwtGenerator, String payLoad) {
		return cycleApi.createCycle(jwtGenerator, payLoad);
	}

	@Override
	public JSONArray createCycles(JwtGenerator jwtGenerator, String payLoad, int numberOfCycles) {
		JSONArray cycleObjects = new JSONArray();
		String payLoadCopy = payLoad;
		System.out.println("Started creation of " + numberOfCycles + " cycles.");
		for (int i = 1; i <= numberOfCycles; i++) {
			String cycleName = new JSONObject(payLoadCopy).get("name").toString() + " " + i;
			JSONObject json = new JSONObject(payLoad);
			json.remove("name");
			json.put("name", cycleName);
			payLoad = json.toString();
			System.out.println(payLoad);
			Response response = cycleApi.createCycle(jwtGenerator, payLoad);
			Assert.assertTrue(validateCycle(payLoad, response), "Validated response successfully.");
			cycleObjects.put(response.getBody().asString());
			System.out.println("Cycle created : " + i + " cycles.");
		}
		return cycleObjects;
	}

	@Override
	public Response getFolders(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId) {
		return folderApi.getFolders(jwtGenerator, projectId, versionId, cycleId);
	}

	// Added on 10-01-2019
	@Override
	public Response getExecutionTimeTracking(JwtGenerator jwtGenerator, Long projectId, Long versionId,
			String cycleId) {
		return executionApi.getExecutionTimeTracking(jwtGenerator, projectId, versionId, cycleId);
	}

	@Override
	public boolean ValidateGetExecutionTimeTracking(JwtGenerator jwtGenerator, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject GetExecutionTimeTrackingJsonObj = new JSONObject(responseData);
		boolean flag = false;
		try {
			RestUtils.ValidateStatusIs200(response);
			String s = GetExecutionTimeTrackingJsonObj.get("data").toString();
			JSONObject obj = new JSONObject(s);
			Assert.assertNotNull(obj);
			// System.out.println(obj.length());
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateCreateCycle(java.lang.
	 * String, com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public boolean validateCycle(String reqPayLoad, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject requestJsonObject = new JSONObject(reqPayLoad);
		JSONObject responseJsonObject = new JSONObject(responseData);

		if (!requestJsonObject.has("projectId")) {
			System.out.println("Project id is not passed.");
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
					"versionId error type is not error.");
			Assert.assertTrue(responseJsonObject.get("clientMessage").toString().equals("projectId field is required.")
					|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: projectId"),
					"projectId field is required.");
		} else if (!requestJsonObject.has("versionId")) {
			System.out.println("Version id is not passed.");
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
					"versionId error type is not error.");
			Assert.assertTrue(responseJsonObject.get("clientMessage").toString().equals("versionId field is required.")
					|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: versionId"),
					"versionId field is required.");

		} else if ((requestJsonObject.has("name") && requestJsonObject.getString("name").isEmpty())
				|| (!requestJsonObject.has("name"))) {
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
					"Cycle error type is not error.");
			Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("name field is required.")
					|| responseJsonObject.get("clientMessage").toString().contains("name field value is required"));

		} else if (requestJsonObject.has("endDate") && (!requestJsonObject.get("startDate").toString().equals("null"))
				&& (!requestJsonObject.get("endDate").toString().equals("null"))) {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			Date startDate = null;
			Date endDate = null;
			try {
				startDate = sdf.parse(requestJsonObject.get("startDate").toString());
				endDate = sdf.parse(requestJsonObject.get("endDate").toString());
			} catch (ParseException e) {
				e.printStackTrace();
			}
			if (endDate.compareTo(startDate) < 0) {
				System.out.println("endDate is before startDate");
				RestUtils.validateStatusIs400(response);
				Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
						"Cycle error type is not error.");
				Assert.assertEquals(responseJsonObject.get("clientMessage").toString(),
						"Cycle endDate should be greater then startDate.",
						"Cycle endDate should be greater then startDate client message is not getting.");

			} else {
				RestUtils.ValidateStatusIs200(response);
				if (requestJsonObject.has("id")) {
					Assert.assertEquals(responseJsonObject.getString("id"), requestJsonObject.getString("id"),
							"Cycle id is null.");
				} else {
					Assert.assertNotNull(responseJsonObject.get("id"), "Cycle id is null.");
				}

				Assert.assertEquals(responseJsonObject.get("projectId").toString(),
						requestJsonObject.get("projectId").toString(),
						"Project Id not validated in the Response of Create cycle API.");
				if (requestJsonObject.has("versionId")) {
					Assert.assertEquals(responseJsonObject.get("versionId").toString(),
							requestJsonObject.get("versionId").toString(),
							"Version Id not validated in the Response of Create cycle API.");
				} else {
					Assert.assertEquals(responseJsonObject.get("versionId").toString(), "-1",
							"Version Id not validated in the Response of Create cycle API.");
				}
				Assert.assertEquals(responseJsonObject.get("name").toString(), requestJsonObject.get("name").toString(),
						"Cycle name not validated in the Response of Create cycle API.");
				if (requestJsonObject.has("description")) {
					Assert.assertEquals(responseJsonObject.get("description").toString(),
							requestJsonObject.get("description").toString(),
							"Cycle name not validated in the Response of Create cycle API.");
				}
				if (requestJsonObject.has("build")) {
					Assert.assertEquals(responseJsonObject.get("build").toString(),
							requestJsonObject.get("build").toString(),
							"Cycle build not validated in the Response of Create cycle API.");
				}
				if (requestJsonObject.has("environment")) {
					Assert.assertEquals(responseJsonObject.get("environment").toString(),
							requestJsonObject.get("environment").toString(),
							"Cycle environment not validated in the Response of Create cycle API.");
				}
				if (requestJsonObject.has("startDate")) {
					Assert.assertNotNull(responseJsonObject.get("startDate").toString(),
							"Cycle startDate not validated in the Response of Create cycle API.");
				}
				if (requestJsonObject.has("endDate")) {
					Assert.assertNotNull(responseJsonObject.get("endDate").toString(),
							"Cycle endDate not validated in the Response of Create cycle API.");
				}
			}

		} else {
			RestUtils.ValidateStatusIs200(response);

			if (requestJsonObject.has("id")) {
				Assert.assertEquals(responseJsonObject.getString("id"), responseJsonObject.getString("id"),
						"Cycle id is null.");
			} else {
				Assert.assertNotNull(responseJsonObject.get("id"), "Cycle id is null.");
			}

			Assert.assertEquals(responseJsonObject.get("projectId").toString(),
					requestJsonObject.get("projectId").toString(),
					"Project Id not validated in the Response of Create cycle API.");
			if (requestJsonObject.has("versionId")) {
				Assert.assertEquals(responseJsonObject.get("versionId").toString(),
						requestJsonObject.get("versionId").toString(),
						"Version Id not validated in the Response of Create cycle API.");
			} else {
				Assert.assertEquals(responseJsonObject.get("versionId").toString(), "-1",
						"Version Id not validated in the Response of Create cycle API.");
			}

			Assert.assertEquals(responseJsonObject.get("name").toString(), requestJsonObject.get("name").toString(),
					"Cycle name not validated in the Response of Create cycle API.");
			if (requestJsonObject.has("description")) {
				Assert.assertEquals(responseJsonObject.get("description").toString(),
						requestJsonObject.get("description").toString(),
						"Cycle name not validated in the Response of Create cycle API.");
			}
			if (requestJsonObject.has("build")) {
				Assert.assertEquals(responseJsonObject.get("build").toString(),
						requestJsonObject.get("build").toString(),
						"Cycle build not validated in the Response of Create cycle API.");
			}
			if (requestJsonObject.has("environment")) {
				Assert.assertEquals(responseJsonObject.get("environment").toString(),
						requestJsonObject.get("environment").toString(),
						"Cycle environment not validated in the Response of Create cycle API.");
			}
			if (requestJsonObject.has("startDate")) {
				Assert.assertNotNull(responseJsonObject.get("startDate").toString(),
						"Cycle startDate not validated in the Response of Create cycle API.");
			}
			if (requestJsonObject.has("endDate")) {
				Assert.assertNotNull(responseJsonObject.get("endDate").toString(),
						"Cycle endDate not validated in the Response of Create cycle API.");
			}
		}

		System.out.println("Cycle API Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#updateCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response updateCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad) {
		return cycleApi.updateCycle(jwtGenerator, cycleId, payLoad);
	}

	// /*
	// * (non-Javadoc)
	// *
	// * @see
	// * com.thed.zephyr.service.ZAPIApiService#validateUpdateCycle(com.jayway.
	// * restassured.response.Response)
	// *
	// * @author Created by manoj.behera on 14-Nov-2016.
	// */
	// @Override
	// public boolean validateUpdateCycle(Response response) {
	//
	// String responseData = response.getBody().asString();
	// System.out.println(responseData);
	// RestUtils.ValidateStatusIs200(response);
	// Assert.assertNotNull(new JSONObject(responseData).get("id"), "Updated
	// cycle id is null.");
	// // Assert.assertTrue(new
	// //
	// JSONObject(responseData).get("responseMessage").toString().contains("updated
	// // successfully"));
	// System.out.println("Response data validated successfully.");
	// return true;
	// }

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#deleteCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId) {
		return cycleApi.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateDeletedCycle(com.jayway.
	 * restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public boolean validateDeletedCycle(Long projectId, Long versionId, String cycleId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJson = new JSONObject(responseData);
		if (projectId == null) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"));
			// Assert.assertTrue(new
			// JSONObject(responseData).get("error").toString().equals("Missing
			// parameter: projectId"));
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.equals("Missing parameter: projectId"));
		} else if (versionId == null) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"));
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.equals("Missing parameter: versionId"));
		} else if (cycleId == null) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"));
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.contains("invalid or not belong to projectId"));
		} else if (cycleId.equals("")) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(new JSONObject(responseData).get("error").toString().equals("API not found."));
		} else {
			RestUtils.ValidateStatusIs200(response);
			Assert.assertTrue(responseJson.has("message"));
			Assert.assertTrue(responseJson.has("timestamp"));
			Assert.assertTrue(
					responseJson.getString("message").toString().equals("cycle " + cycleId + " successfully deleted"));
			Assert.assertNotNull(responseJson.get("timestamp").toString());
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId) {
		return cycleApi.getCycle(jwtGenerator, projectId, versionId, cycleId);
	}

	// // TODO
	// @Override
	// public boolean validateGetCycle(Long projectId, Long versionId, String
	// cycleId, Response response) {
	// String responseData = response.getBody().asString();
	// System.out.println(responseData);
	// if (projectId == null) {
	// RestUtils.validateStatusIs400(response);
	// Assert.assertTrue(
	// new JSONObject(responseData).get("error").toString().equals("Missing
	// parameter: projectId"));
	// } else if (versionId == null) {
	// RestUtils.validateStatusIs400(response);
	// Assert.assertTrue(
	// new JSONObject(responseData).get("error").toString().equals("Missing
	// parameter: versionId"));
	// } else if (cycleId == null || cycleId.equals("") || new
	// JSONObject(responseData).has("errorType")) {
	// RestUtils.validateStatusIs400(response);
	// Assert.assertTrue(new
	// JSONObject(responseData).get("errorType").toString().equals("ERROR"));
	// Assert.assertTrue(new
	// JSONObject(responseData).get("clientMessage").toString()
	// .contains("invalid or not belong to projectId"));
	// } else {
	// System.out.println("200 response");
	// RestUtils.ValidateStatusIs200(response);
	//
	// }
	// System.out.println("Response data validated successfully.");
	// return true;
	//
	// }

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getCycles(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getCycles(JwtGenerator jwtGenerator, Long projectId, Long versionId) {
		return cycleApi.getCycles(jwtGenerator, projectId, versionId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @author Created by Praveenkumar
	 */
	@Override
	public boolean validateGetCycles(Long projectId, Long versionId, Response response) {
		if (projectId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: projectId", "should return Missing parameter: projectId");
		} else if (versionId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: versionId", "should return Missing parameter: versionId");
		}
		// TODO
		// Add validations for 50/500/5000
		else {
			RestUtils.ValidateStatusIs200(response);
			System.out.println(response.getBody().asString());
		}
		System.out.println("Get Cycles Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateGetFolders(Long projectId, Long versionId, String cycleId, Response response) {
		if (projectId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: projectId", "should return Missing parameter: projectId");
		} else if (versionId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: versionId", "should return Missing parameter: versionId");
		} else if (cycleId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: cycleId", "should return Missing parameter: versionId");
		}
		// TODO
		// Add validations for 50/500/5000
		else {
			RestUtils.ValidateStatusIs200(response);
			System.out.println(response.getBody().asString());
		}
		System.out.println("Get Cycles Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#copyExecutionsToCycle(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response copyExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad) {
		return cycleApi.copyExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// return response2;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @author Created by Praveenkumar
	 */
	@Override
	public boolean validateCopyExecutionsToCycle(Response response) {
		String responseData = response.getBody().asString();
		/*if (new JSONObject(responseData).get("clientMessage").toString().contains("field is required")) {
			RestUtils.validateStatusIs400(response);
		} else {}*/
			// TODO
			// Add validations
			
			JSONObject jsobj = new JSONObject(responseData);
			System.out.println(new JSONObject(jsobj.get("message").toString()).get("success").toString());
			RestUtils.ValidateStatusIs200(response);
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateCopyExecutionsToCycleWithInvalidCycleId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		/*Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("invalid or not belong to projectId"), "Error Code is null");*/
		Long projectId=Long.parseLong(Config.getValue("projectId"));
		String s = String.valueOf(projectId);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		
		String actual = "Cycle 987654321 is invalid or does not belong to the projectId " + s + " and versionId -1."
				;
		System.out.println(actual);

		Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.contains("is invalid or does not belong to the projectId"));
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateCopyExecutionsToCycleWithInvalidProjectId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("projectId field value is null or 987,654 is not valid.")
				||
	new JSONObject(responseData).get("clientMessage").toString().contains("projectId field is required."),
				"Error Code not complete");
		
		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}

	@Override
	public boolean validateCopyExecutionsToCycleWithInvalidVersionId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("versionId field value is null or 987,654,321 is not valid.")
			||	new JSONObject(responseData).get("clientMessage").toString().contains("versionId field is required."),
				"Error Code not complete");

		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}

	@Override
	public boolean validateZqlWithInvalidExecutionId(Response response , String executionId) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println("executionId field value is null or " +executionId+ "is not valid.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString().contains("executionId field value is null or " +executionId+ " is not valid."));
	
			
		
		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}
	
	@Override
	public boolean validateExecutionIdNull(String ExecutionId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJson = new JSONObject(responseData);
		if (ExecutionId == null) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"));
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.equals("Missing parameter: executionId"));
		} else {
			RestUtils.ValidateStatusIs200(response);
			Assert.assertTrue(responseJson.has("message"));
			Assert.assertTrue(responseJson.has("timestamp"));
			Assert.assertTrue(
					responseJson.getString("message").toString().equals( ExecutionId + " has executions"));
			Assert.assertNotNull(responseJson.get("timestamp").toString());
		}
		System.out.println("Response data validated successfully.");
		return true;
	}
	
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#moveExecutionsToCycle(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response moveExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad) {
		return cycleApi.moveExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// return response1;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @author Created by Praveenkumar
	 */
	@Override
	public boolean validateMoveExecutionsToCycle(Response response) {
		String responseData = response.getBody().asString();
		/*
		 * if (new JSONObject(responseData).get("clientMessage").toString().
		 * contains("field is required")) { RestUtils.validateStatusIs400(response); }
		 * else {
		 */
		// TODO
		// Add validations
		JSONObject jsobj = new JSONObject(responseData);
		System.out.println(new JSONObject(jsobj.get("message").toString()).get("success").toString());
		RestUtils.ValidateStatusIs200(response);

		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateMoveExecutionsToCycleWithInvalidCycleId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Long projectId=Long.parseLong(Config.getValue("projectId"));
		String s = String.valueOf(projectId);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		
		String actual = "Cycle 987654321 is invalid or does not belong to the projectId " + s + " and versionId -1."
				;
		System.out.println(actual);

		Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.contains("is invalid or does not belong to the projectId"));
		
		
		/*Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("Cycle 987654321 is invalid or does not belong to the projectId "+s+" and versionId -1."), "Error Code is null");*/
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateMoveExecutionsToCycleWithInvalidProjectId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("projectId field value is null or 987,654 is not valid.")
				||
	new JSONObject(responseData).get("clientMessage").toString().contains("projectId field is required."),
				"Error Code not complete");
		
		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}

	@Override
	public boolean validateMoveExecutionsToCycleWithInvalidVersionId(Response response) {
		String responseData = response.getBody().asString();
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("versionId field value is null or 987,654,321 is not valid.")
			||	new JSONObject(responseData).get("clientMessage").toString().contains("versionId field is required."),
				"Error Code not complete");

		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}

	@Override
	public Response jobProgressHandler(JwtGenerator jwtGenerator, String jobProgressId) {
		Response response2 = null;
		do {
			response2 = jobProgressApi.getJobProgress(jwtGenerator, jobProgressId);
			System.out.println(response2.getBody().asString());
		} while (!(new JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		return response2;
	}

	@Override
	public boolean validateJobProgress(Response response, String payload) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		JSONObject jsobj = new JSONObject(responseData);
		System.out.println(new JSONObject(jsobj.get("message").toString()).get("success").toString());
		JSONObject jsobj1 = new JSONObject(payload);
		// System.out.println(jsobj1.get("executions").toString());
		return true;
	}

	@Override
	public boolean validateinvalidJobProgress(Response response, String payload) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		/*
		 * Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString().
		 * contains("assigneeType field value is null or assigne is not valid."),
		 * "Error Code is null");
		 */
		Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.equals("assigneeType field value is null or assigne is not valid.")
				|| responseJsonObject.get("clientMessage").toString()
						.equals("assigneeType field value is null or null is not valid.")
				|| responseJsonObject.get("clientMessage").toString().equals("Please select person from list")
				|| responseJsonObject.get("clientMessage").toString().equals(
						"You have exceeded the max allowed limit of 500 executions while performing bulk operations. Please correct the input and try again.")
				||responseJsonObject.get("clientMessage").toString().equals("stepStatus field value is null or 444,441 is not valid.")
		|| responseJsonObject.get("clientMessage").toString().equals("status field value is null or 444,441 is not valid."));
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#exportCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	@Override
	public Response exportCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId,
			String exportType) {
		return cycleApi.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
	}

	@Override
	public boolean downloadCycleExportedFile(JwtGenerator jwtGenerator, String fileName) {
		try {
			Response responseOfDownloadApi = cycleApi.downloadExportedFile(jwtGenerator, fileName);
			InputStream inputStream = responseOfDownloadApi.getBody().asInputStream();
			try {
				String theString = IOUtils.toString(inputStream, "UTF-8");
				IOUtils.closeQuietly(inputStream);
				File file = new File(fileName);
				FileOutputStream fop = new FileOutputStream(file);
				file.createNewFile();
				fop.write(theString.getBytes());
				fop.flush();
				fop.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateExportCycle(Long projectId, Long versionID, String cycleId, String exportType,
			Response response) {
		String responseData = response.getBody().asString();
		System.out.println("checking response");
		System.err.println(responseData);
		if (responseData == null || responseData == "" || responseData.contains("error")) {
			if (projectId == null) {
				System.out.println(projectId);
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(
						new JSONObject(responseData).get("error").toString().equals("Missing parameter: projectId"));
			} else if (versionID == null) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(
						new JSONObject(responseData).get("error").toString().equals("Missing parameter: versionId"));
			} else if (cycleId == null || cycleId.equals("")) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"));
				Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
						.contains("invalid or not belong to projectId"));
			} else if (exportType == null || exportType == "") {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(
						new JSONObject(responseData).get("error").toString().equals("Missing parameter: projectId"));
				// Assert.assertTrue(new
				// JSONObject(responseData).get("clientMessage").toString().contains("invalid
				// or not belong to projectId"));
			} else {
				RestUtils.ValidateStatusIs200(response);
				// Assert.assertTrue(new
				// JSONObject(responseData).get("error").toString().contains("Missing
				// parameter"));
			}

		} else {
			System.out.println("200 response");
			RestUtils.ValidateStatusIs200(response);
		}

		return true;
	}
	// Test step Apis

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#createTeststep(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String payLoad) {
		return teststepApi.createTeststep(jwtGenerator, projectId, issueId, payLoad);
	}

	@Override
	public JSONArray createTeststeps(JwtGenerator jwtGenerator, Long projectId, Long issueId, String payLoad) {
		JSONArray teststepObject = new JSONArray();
		String payLoadCopy = payLoad;
		JSONObject jsonPayLoad = new JSONObject(payLoadCopy);

		if (jsonPayLoad.has("noOfTeststeps")) {
			int noOfTeststeps = (int) new JSONObject(payLoadCopy).get("noOfTeststeps");
			System.out.println("Started creation of " + noOfTeststeps + " test steps.");
			for (int i = 1; i <= noOfTeststeps; i++) {
				// Long cycleName = (Long) new
				// JSONObject(payLoadCopy).get("issueId");
				JSONObject json1 = new JSONObject(payLoad);
				json1.remove("noOfTeststeps");
				if (jsonPayLoad.has("step")) {
					json1.put("step", jsonPayLoad.get("step").toString() + i);
				} else {
					// json1.put("step", ""+i);
				}
				if (jsonPayLoad.has("data")) {
					json1.put("data", jsonPayLoad.get("data").toString() + i);
				} else {
					// json1.put("data", ""+i);
				}
				if (jsonPayLoad.has("result")) {
					json1.put("result", jsonPayLoad.get("result").toString() + i);
				} else {
					// json1.put("data", ""+i);
				}

				payLoad = json1.toString();
				// System.out.println(payLoad);
				Response response = teststepApi.createTeststep(jwtGenerator, projectId, issueId, payLoad);
				Assert.assertTrue(validateTeststep(projectId, issueId, payLoad, response),
						"Validated response successfully.");
				teststepObject.put(response.getBody().asString());
				System.out.println("Teststeps created : " + (i) + " .");
			}
		} else {
			JSONArray jsonStepList = new JSONObject(payLoadCopy).getJSONArray("stepList");
			JSONArray jsonDataList = new JSONObject(payLoadCopy).getJSONArray("dataList");
			JSONArray jsonResultList = new JSONObject(payLoadCopy).getJSONArray("resultList");
			System.out.println("Started creation of " + jsonStepList.length() + " test steps.");
			for (int i = 0; i < jsonStepList.length(); i++) {
				// Long cycleName = (Long) new
				// JSONObject(payLoadCopy).get("issueId");
				JSONObject json1 = new JSONObject(payLoad);
				json1.remove("stepList");
				json1.remove("dataList");
				json1.remove("resultList");
				if (!jsonPayLoad.has("step")) {
					json1.put("step", jsonStepList.get(i).toString());
				}
				if (!jsonPayLoad.has("data")) {
					json1.put("data", jsonDataList.get(i).toString());
				}
				if (!jsonPayLoad.has("result")) {
					json1.put("result", jsonResultList.get(i).toString());
				}

				payLoad = json1.toString();
				// System.out.println(payLoad);
				Response response = teststepApi.createTeststep(jwtGenerator, projectId, issueId, payLoad);
				Assert.assertTrue(validateTeststep(projectId, issueId, payLoad, response),
						"Validated response successfully.");
				teststepObject.put(response.getBody().asString());
				System.out.println("Teststeps created : " + (i + 1) + " .");
			}
		}
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
			System.out.println(" Failed in one second");
		}

		return teststepObject;
	}

	@Override
	public boolean validateTeststep(Long projectId, Long issueId, String reqPayLoad, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJson = new JSONObject(responseData);
		JSONObject reqJson = new JSONObject(reqPayLoad);
		Assert.assertNotNull(responseJson.get("id"), "Teststep id is null.");
		Assert.assertNotNull(responseJson.get("orderId"), "Teststep orderId id is null.");
		Assert.assertNotNull(responseJson.get("createdOn"), "Teststep created on id is null.");
		Assert.assertEquals(responseJson.get("createdBy").toString(), Config.getValue("accountId"),
				"Teststep created by is not matching.");
		Assert.assertEquals(responseJson.get("issueId").toString(), issueId.toString(), "Issue id not matching.");
		if (responseJson.has("step")) {
			Assert.assertEquals(responseJson.get("step").toString(), reqJson.get("step").toString(),
					"Test step name is not matching");
		}
		if (responseJson.has("data")) {
			Assert.assertEquals(responseJson.get("data").toString(), reqJson.get("data").toString(),
					"Test step data is not matching");
		}
		if (responseJson.has("result")) {
			Assert.assertEquals(new JSONObject(responseData).get("result").toString(), reqJson.get("result").toString(),
					"Test step result is not matching");
		}
		System.out.println("Response validated successfully.");
		return true;
	}

	public boolean validateTeststepWithProjectIdNull(Long projectId, Long issueId, String reqPayLoad,
			Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJson = new JSONObject(responseData);
		JSONObject reqJson = new JSONObject(reqPayLoad);
		Assert.assertNotNull(responseJson.get("id"), "Teststep id is null.");
		Assert.assertNotNull(responseJson.get("orderId"), "Teststep orderId id is null.");
		Assert.assertNotNull(responseJson.get("createdOn"), "Teststep created on id is null.");
		Assert.assertEquals(responseJson.get("createdBy").toString(), Config.getValue("accountId"),
				"Teststep created by is not matching.");
		Assert.assertEquals(responseJson.get("issueId").toString(), issueId.toString(), "Issue id not matching.");
		if (responseJson.has("step")) {
			Assert.assertEquals(responseJson.get("step").toString(), reqJson.get("step").toString(),
					"Test step name is not matching");
		}
		if (responseJson.has("data")) {
			Assert.assertEquals(responseJson.get("data").toString(), reqJson.get("data").toString(),
					"Test step data is not matching");
		}
		if (responseJson.has("result")) {
			Assert.assertEquals(new JSONObject(responseData).get("result").toString(), reqJson.get("result").toString(),
					"Test step result is not matching");
		}
		System.out.println("Response validated successfully.");
		return true;
	}

	@Override
	public boolean validateUpdatedTeststep(Long projectId, Long issueId, String reqPayLoad, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJson = new JSONObject(responseData);
		JSONObject reqJson = new JSONObject(reqPayLoad);
		Assert.assertNotNull(responseJson.get("id"), "Teststep id is null.");
		Assert.assertNotNull(responseJson.get("orderId"), "Teststep orderId id is null.");
		Assert.assertNotNull(responseJson.get("createdOn"), "Teststep created on id is null.");
		Assert.assertEquals(responseJson.get("createdBy").toString(), Config.getValue("accountId"),
				"Teststep created by is not matching.");
		Assert.assertEquals(responseJson.get("issueId").toString(), issueId.toString(), "Issue id not matching.");

		System.out.println("Response validated successfully.");
		return true;
	}

	@Override
	public boolean validateClonedTeststep(Long projectId, Long issueId, String reqPayLoad, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);

		for (int i = 0; i < responseJson.length(); i++) {
			JSONObject json = new JSONObject(responseJson.get(i).toString());
			Assert.assertNotNull(json.get("id").toString(), "Teststep is null.");
		}

		System.out.println("Response validated successfully.");
		System.out.println("Test step cloned successfully");
		return true;
	}

	@Override
	public boolean validateTeststepsWithData(Long projectId, Long issueId, String reqPayLoad, JSONArray response) {

		// JSONArray jsnobject = new JSONArray(response.getBody().asString());

		int resplength = response.length();

		if (new JSONObject(reqPayLoad).has("noOfTeststeps")) {
			for (int i = 0; i < resplength; i++) {
				JSONObject respjsobj = new JSONObject(response.getString(i));
				Assert.assertNotNull((respjsobj.getString("id")), "Teststep id is null.");
				Assert.assertNotNull(((respjsobj.getInt("orderId"))), "Teststep orderId id is null.");
				Assert.assertNotNull(((respjsobj.getInt("createdOn"))), "Teststep created on id is null..");
				Assert.assertEquals(respjsobj.getString("createdBy"), Config.getValue("accountId"),
						"Teststep created by is not matching.");
				Assert.assertEquals(respjsobj.get("issueId").toString(), issueId.toString(), "Issue id not matching.");

			}
		}

		else {
			JSONArray jsonStepList = new JSONObject(reqPayLoad).getJSONArray("stepList");
			JSONArray jsonDataList = new JSONObject(reqPayLoad).getJSONArray("dataList");
			JSONArray jsonResultList = new JSONObject(reqPayLoad).getJSONArray("resultList");

			for (int i = 0; i < resplength; i++) {
				JSONObject respjsobj = new JSONObject(response.getString(i));
				Assert.assertNotNull((respjsobj.getString("id")), "Teststep id is null.");
				Assert.assertNotNull(((respjsobj.getInt("orderId"))), "Teststep orderId id is null.");
				Assert.assertNotNull(((respjsobj.getInt("createdOn"))), "Teststep created on id is null..");
				Assert.assertEquals(respjsobj.getString("createdBy"), Config.getValue("accountId"),
						"Teststep created by is not matching.");
				Assert.assertEquals(respjsobj.get("issueId").toString(), issueId.toString(), "Issue id not matching.");
				// if(jsonStepList.get(i) != null){
				Assert.assertEquals(respjsobj.get("step").toString(), jsonStepList.get(i).toString(),
						"Test step name is not matching");
				// }
				// if(jsonDataList.getString(i) != null){
				Assert.assertEquals(respjsobj.get("data").toString(), jsonDataList.get(i).toString(),
						"Test data is not matching");
				// }
				// if(jsonResultList.getString(i) != null){
				Assert.assertEquals(respjsobj.get("result").toString(), jsonResultList.get(i).toString(),
						"Test step result is not matching");
				// }

			} // end for loop
		} // end else part
		System.out.println("API Response validated successfully");
		return true;
	}

	@Override
	public boolean validateUpdatedTestStepDeletedTestStep(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs500(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString().contains("Id field value null"),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Test step not created due to invalid step id");
		return true;
	}

	@Override
	public boolean validateClonedTestStepInvalidTeststep(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs500(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString().contains("Id field value null"),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Test step not cloned due to invalid step id");
		return true;
	}

	@Override
	public boolean validateTeststepsData(Long projectId, Long issueId, String reqPayLoad, Response response) {

		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		// System.out.println(responseData);
		// System.out.println(reqPayLoad);
		JSONArray responseJson = new JSONArray(responseData);
		// System.out.println(responseJson.getJSONObject(0));

		// JSONObject reqJson = new JSONObject(reqPayLoad);
		System.out.println("Response Json: " + responseJson);
		// System.out.println("Request Json: "+reqJson);

		JSONArray jsonStepList = new JSONObject(reqPayLoad).getJSONArray("stepList");
		JSONArray jsonDataList = new JSONObject(reqPayLoad).getJSONArray("dataList");
		JSONArray jsonResultList = new JSONObject(reqPayLoad).getJSONArray("resultList");

		int respLength = responseJson.length();
		// System.out.println("Length ="+ respLength);
		for (int i = 0; i < respLength; i++) {
			Assert.assertNotNull(responseJson.getJSONObject(i).getString("id"), "Teststep id is null.");
			Assert.assertNotNull(responseJson.getJSONObject(i).getInt("orderId"), "Teststep order id is null.");
			Assert.assertNotNull(((responseJson.getJSONObject(i).getInt("createdOn"))),
					"Teststep created on id is null..");
			Assert.assertEquals(responseJson.getJSONObject(i).getString("createdBy"), Config.getValue("accountId"),
					"Teststep created by is not matching.");
			Assert.assertEquals(responseJson.getJSONObject(i).get("issueId").toString(), issueId.toString(),
					"Issue id not matching.");

			// if(jsonStepList.getString(i) != null){
			Assert.assertEquals(responseJson.getJSONObject(i).get("step").toString(), jsonStepList.get(i).toString(),
					"Test step name is not matching");
			// }
			// if(jsonDataList.getString(i) != null){
			Assert.assertEquals(responseJson.getJSONObject(i).get("data").toString(), jsonDataList.get(i).toString(),
					"Test data is not matching");
			// }
			// if(jsonResultList.getString(i) != null){
			Assert.assertEquals(responseJson.getJSONObject(i).get("result").toString(),
					jsonResultList.get(i).toString(), "Test step result is not matching");
			// }
		}

		return true;
	}

	@Override
	public boolean validateClonedTestStepInvalidPositionId(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println("Test step not cloned due to invalid position id");
		return true;
	}

	@Override
	public boolean validateUpdatedTestStepInvalidIssueId(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("issueId field value null"),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Test step not created due to invalid issue id");
		return true;
	}

	@Override
	public boolean validateCreateTestStepInvalidIsueId(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);

		// RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.equals("Id field value is null or b412cfc7-ff70-4568-a81c-ca486eacb00c is not valid.")
				|| new JSONObject(responseData).get("clientMessage").toString().equals("Id field value is null")
				|| new JSONObject(responseData).get("clientMessage").toString().contains("issueId field value null"),
				"Error Code is null");

		System.out.println("Response data validated successfully.");
		System.out.println("Test step not created due to invalid issue id");

		return true;

	}

	public boolean validateCreateTestStepInvalidIsueId2(Long projectId, Long issueId, String stepid,
			Response response) {

		try {

			if (response.statusCode() == 500) {
				RestUtils.validateStatusIs500(response);
				System.out.println(
						"status code is 500, Testcase is passing but error code is wrong raised bug for this ZFJCLOUD-2614");

			} else {
				RestUtils.validateStatusIs400(response);
				System.out.println("status code is 400");
			}

			// RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
					"errortype is not ERROR.");
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.equals("Id field value is null or b412cfc7-ff70-4568-a81c-ca486eacb00c is not valid.")
					|| new JSONObject(responseData).get("clientMessage").toString().equals("Id field value is null")
					|| new JSONObject(responseData).get("clientMessage").toString()
							.contains("issueId field value null"),
					"Error Code is null");

			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"Id field value is null or " + stepid + " is not valid.", "Not provided invalid stepId.");

			System.out.println("Response data validated successfully.");
			System.out.println("Test step not created due to invalid issue id");

		}

		catch (Exception e) {
			return false;
		}

		return true;

	}

	@Override
	public boolean validateCreateTestStepInvalidProjectId(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		// Cannot parse parameter projectId as Long: For input string
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("projectId field value null")
						|| new JSONObject(responseData).get("clientMessage").toString()
								.equals("projectId field value is null or 10,299 is not valid.")
						|| new JSONObject(responseData).get("clientMessage").toString()
								.contains("Cannot parse parameter projectId as Long: For input string"),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Test step not created due to projectId field value not valid or Null");
		return true;
	}

	@Override
	public boolean validateClonedTestStepInvalidProjectId(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("rojectId field value is null or 10,200 is not valid"), "Error Code is null");

		/*
		 * Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString().
		 * contains("projectId field value null"), "Error Code is null");
		 */

		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.equals("projectId field value is null or 10,200 is not valid."), "Error code");

		System.out.println("Response data validated successfully.");
		System.out.println("Test step not created due to projectId field value not valid");
		return true;
	}

	@Override
	public boolean validateUpdatedTestStepInvalidProjectId(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("projectId field value null"),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Test step not updated due to projectId field value not valid");
		return true;
	}

	@Override
	public boolean validateCreateTestStepOtherIssueType(Long projectId, Long issueId, String reqPayLoad,
			Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println("Response data validated successfully.");
		System.out.println("Teststep not created due to issue type other than Test");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#cloneTeststep(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response cloneTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId,
			String payLoad) {
		return teststepApi.cloneTeststep(jwtGenerator, projectId, issueId, teststepId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#deleteTeststep(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId) {
		return teststepApi.deleteTeststep(jwtGenerator, projectId, issueId, teststepId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#moveTeststep(com.thed.zephyr.cloud
	 * .rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response moveTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId,
			String payLoad) {
		return teststepApi.moveTeststep(jwtGenerator, projectId, issueId, teststepId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getTeststep(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId) {
		return teststepApi.getTeststep(jwtGenerator, projectId, issueId, teststepId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getTeststeps(com.thed.zephyr.cloud
	 * .rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getTeststeps(JwtGenerator jwtGenerator, Long projectId, Long issueId) {
		return teststepApi.getTeststeps(jwtGenerator, projectId, issueId);
	}

	@Override
	public boolean validateGetStepStatuses(Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println("Reponse data: " + responseData);
		JSONArray jsarray = new JSONArray(responseData);
		System.out.println("length=" + jsarray.length());

		for (int i = 0; i < jsarray.length(); i++) {
			Assert.assertNotNull(jsarray.getJSONObject(i).getInt("id"), "Teststep status " + i + " id is null.");
			Assert.assertNotNull(jsarray.getJSONObject(i).getString("name"), "Teststep status " + i + " name is null.");
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#updateTeststep(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response updateTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId,
			String payLoad) {
		return teststepApi.updateTeststep(jwtGenerator, projectId, issueId, teststepId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getTeststepStatuses(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getTeststepStatuses(JwtGenerator jwtGenerator) {
		return teststepApi.getTeststepStatuses(jwtGenerator);
	}

	// Zql filters apis

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#createZQLFilter(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createZQLFilter(JwtGenerator jwtGenerator, String payLoad) {
		return zqlFilterApi.createZQLFilter(jwtGenerator, payLoad);
	}

	/*
	 * @Override public boolean validateZQLFilter(String reqPayLoad, Response
	 * response) { if (!new JSONObject(reqPayLoad).has("zql") || new
	 * JSONObject(reqPayLoad).get("zql").toString().equals("")) {
	 * System.out.println("ZQL is not passed.");
	 * RestUtils.validateStatusIs400(response); String responseData =
	 * response.getBody().asString(); System.out.println(responseData);
	 * Assert.assertEquals(new JSONObject(responseData).get("zql").toString(),
	 * "ZQL search text can not be empty.", "message is wrong");
	 * 
	 * } else { RestUtils.ValidateStatusIs200(response); String responseData =
	 * response.getBody().asString(); System.out.println(responseData);
	 * Assert.assertNotNull(new JSONObject(responseData).get("id"),
	 * "ZQL filter id is null."); Assert.assertEquals(new
	 * JSONObject(responseData).get("zql").toString(), new
	 * JSONObject(reqPayLoad).get("zql").toString(),
	 * "ZQL query is not validated in the Response of Create ZQL filter API.");
	 * Assert.assertEquals(new JSONObject(responseData).get("name").toString(), new
	 * JSONObject(reqPayLoad).get("name").toString(),
	 * "Zql filter name is not validated in the Response of Create ZQL filter API."
	 * ); if (new JSONObject(responseData).has("favorite")) {
	 * Assert.assertEquals(new JSONObject(responseData).get("favorite").toString(),
	 * new JSONObject(reqPayLoad).get("favorite").toString(),
	 * "Zql filter favorite value is not validated in the Response of Create ZQL filter API."
	 * ); } Assert.assertEquals(new
	 * JSONObject(responseData).get("sharePerm").toString(), new
	 * JSONObject(reqPayLoad).get("sharePerm").toString(),
	 * "Zql filter share permission is not validated in the Response of Create ZQL filter API."
	 * ); if (new JSONObject(reqPayLoad).has("description")) {
	 * Assert.assertEquals(new
	 * JSONObject(responseData).get("description").toString(), new
	 * JSONObject(reqPayLoad).get("description").toString(),
	 * "Zql filter description is not validated in the Response of Create ZQL filter API."
	 * ); } } System.out.println(
	 * "Create ZQL filter API Response data validated successfully."); return true;
	 * 
	 * }
	 */
	@Override
	public boolean validateZQLFilter(String reqPayLoad, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject zqlfilterResponseJsonObj = new JSONObject(responseData);
		JSONObject zqlfilterRequestJsonObj = new JSONObject(reqPayLoad);

		if ((!zqlfilterRequestJsonObj.has("zql"))) {
			/**
			 * Validating negative response - zql is empty, zql is null and zql not passed
			 */
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"ZQLFilter response error type is expeting ERROR type.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"zqlQuery should not be null!", "ZQLFilter response error type is expeting ERROR type.");
		} else if (zqlfilterRequestJsonObj.getString("zql") == null
				|| zqlfilterRequestJsonObj.getString("zql").equals("")) {
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"ZQLFilter response error type is expeting ERROR type.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"{\"zql\":\"ZQL search text can not be empty.\"}",
					"ZQLFilter response error type is expeting ERROR type.");

		} else if ((!zqlfilterRequestJsonObj.has("name")) || zqlfilterRequestJsonObj.getString("name").equals("")
				|| zqlfilterRequestJsonObj.getString("name") == null) {
			/**
			 * Validating negative response - name is empty, name is null and name not
			 * passed
			 */
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"ZQLFilter response error type is expeting ERROR type.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"{\"name\":\"Not a valid filter name, Please enter a valid filter name.\"}",
					"ZQLFilter response error type is expeting ERROR type.");

		} else if (zqlfilterRequestJsonObj.getString("sharePerm").isEmpty()
				|| !(zqlfilterRequestJsonObj.getString("sharePerm").equals("global")
						|| zqlfilterRequestJsonObj.getString("sharePerm").equals("private"))) {
			/**
			 * Validating negative response - shareperm is invalid, shareperm is null
			 */
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"ZQLFilter response error type is expeting ERROR type.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"SharePerm value is invalid, it should be (private/global).",
					"ZQLFilter response error type is expeting ERROR type.");
		} else {
			/**
			 * Validating positive response.
			 */
			RestUtils.ValidateStatusIs200(response);
			if (zqlfilterRequestJsonObj.has("id")) {
				Assert.assertEquals(zqlfilterResponseJsonObj.getString("id"), zqlfilterRequestJsonObj.getString("id"),
						"ZQL filter id is not validated.");
			} else {
				Assert.assertNotNull(zqlfilterResponseJsonObj.get("id"), "ZQL filter id is null.");
			}

			Assert.assertEquals(zqlfilterResponseJsonObj.get("zql").toString(),
					zqlfilterRequestJsonObj.get("zql").toString(),
					"ZQL query is not validated in the Response of Create ZQL filter API.");
			Assert.assertEquals(zqlfilterResponseJsonObj.get("name").toString(),
					zqlfilterRequestJsonObj.get("name").toString(),
					"Zql filter name is not validated in the Response of Create ZQL filter API.");

			if (zqlfilterRequestJsonObj.has("favorite")) {
				Assert.assertEquals(zqlfilterResponseJsonObj.getBoolean("favorite"),
						zqlfilterRequestJsonObj.getBoolean("favorite"),
						"Zql filter favorite value is not validated in the Response in ZQL filter API.");
			} else {
				Assert.assertEquals(zqlfilterResponseJsonObj.getBoolean("favorite"), true,
						"Zql filter favorite value is not validated in the Response in ZQL filter API.");
			}
			if (zqlfilterRequestJsonObj.has("sharePerm")) {
				Assert.assertEquals(zqlfilterResponseJsonObj.get("sharePerm").toString(),
						zqlfilterRequestJsonObj.get("sharePerm").toString(),
						"Zql filter share permission is not validated in the Response of ZQL filter API.");
			} else {
				Assert.assertEquals(zqlfilterResponseJsonObj.get("sharePerm").toString(), "global",
						"Zql filter share permission is not validated in the Response of ZQL filter API.");
			}

			if (zqlfilterRequestJsonObj.has("description")
					&& (!zqlfilterRequestJsonObj.get("description").toString().equals("null"))) {
				Assert.assertEquals(zqlfilterResponseJsonObj.get("description").toString(),
						zqlfilterRequestJsonObj.get("description").toString(),
						"Zql filter description is not validated in the Response of Create ZQL filter API.");
			}

		}
		System.out.println("ZQL filter API Response data validated successfully.");
		return true;

	}

	@Override
	public boolean validateInvalidZQLFilterId(String zqlFilterId, Response response) {
		try {
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			RestUtils.validateStatusIs400(response);
			JSONObject zqlfilterResponseJsonObj = new JSONObject(responseData);

			Assert.assertEquals(zqlfilterResponseJsonObj.get("errorType").toString(), "ERROR",
					"ZQLFilter response error type is expeting ERROR type.");
			Assert.assertEquals(zqlfilterResponseJsonObj.get("clientMessage").toString(),
					"filterId field value is null or " + zqlFilterId + " is not valid.",
					"ZQLFilter response error type is expeting ERROR code.");
			System.out.println("ZQL filter API Response data validated successfully.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateAlreadyExistsZQLFilter(Response response) {
		try {
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			RestUtils.validateStatusIs400(response);
			JSONObject zqlfilterResponseJsonObj = new JSONObject(responseData);

			Assert.assertEquals(zqlfilterResponseJsonObj.get("errorType").toString(), "ERROR",
					"ZQLFilter response error type is expeting ERROR type.");
			Assert.assertEquals(zqlfilterResponseJsonObj.get("clientMessage").toString(),
					"{\"name\":\"Filter with same name already exists.\"}",
					"ZQLFilter response error type is expeting ERROR code.");
			System.out.println("ZQL filter API Response data validated successfully.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateZQLFilterWithInvalidFilterId(String reqPayLoad, Response response) {
		RestUtils.validateStatusIs500(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(responseData.contains("No Execution Filter found by this FilterId"), "Error Code is null");
		System.out.println("ZQL filter API Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getZQLFilter(com.thed.zephyr.cloud
	 * .rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getZQLFilter(JwtGenerator jwtGenerator, String zqlFilterId) {
		return zqlFilterApi.getZQLFilter(jwtGenerator, zqlFilterId);
	}

	/*
	 * @Override public boolean validateGetZqlFilter(String reqPayLoad, Response
	 * response) {
	 * 
	 * RestUtils.ValidateStatusIs200(response); String responseData =
	 * response.getBody().asString(); System.out.println(responseData);
	 * Assert.assertNotNull(new JSONObject(responseData).get("id"),
	 * "ZQL filter id is null."); Assert.assertEquals(new
	 * JSONObject(responseData).get("id").toString(), new
	 * JSONObject(reqPayLoad).get("id").toString(),
	 * "ZQL filter Id is not validated in the Response of Get ZQL filter API.");
	 * Assert.assertEquals(new JSONObject(responseData).get("zql").toString(), new
	 * JSONObject(reqPayLoad).get("zql").toString(),
	 * "ZQL query is not validated in the Response of Get ZQL filter API.");
	 * Assert.assertEquals(new JSONObject(responseData).get("name").toString(), new
	 * JSONObject(reqPayLoad).get("name").toString(),
	 * "Zql filter name is not validated in the Response of Get ZQL filter API." );
	 * Assert.assertEquals(new JSONObject(responseData).get("favorite").toString(),
	 * new JSONObject(reqPayLoad).get("favorite").toString(),
	 * "Zql filter favorite value is not validated in the Response of Get ZQL filter API."
	 * ); Assert.assertEquals(new
	 * JSONObject(responseData).get("sharePerm").toString(), new
	 * JSONObject(reqPayLoad).get("sharePerm").toString(),
	 * "Zql filter share permission is not validated in the Response of Get ZQL filter API."
	 * ); if (new JSONObject(reqPayLoad).has("description")) Assert.assertEquals(new
	 * JSONObject(responseData).get("description").toString(), new
	 * JSONObject(reqPayLoad).get("description").toString(),
	 * "Zql filter description is not validated in the Response of Get ZQL filter API."
	 * ); System.out.println(
	 * "Create ZQL filter API Response data validated successfully."); return true;
	 * }
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#searchZQLFilter(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response quickSearchZQLFilter(JwtGenerator jwtGenerator, String zqlFilterName) {
		return zqlFilterApi.quickSearchZQLFilter(jwtGenerator, zqlFilterName);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#searchZQLFilter(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response searchZQLFilters(JwtGenerator jwtGenerator, String zqlFilter) {
		return zqlFilterApi.searchZQLFilters(jwtGenerator, zqlFilter);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getZQLFilters(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getFavouriteZQLFilters(JwtGenerator jwtGenerator, boolean byUser, boolean fav, int offset,
			int maxRecords) {
		return zqlFilterApi.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
	}

	@Override
	public Response getMyZQLFilters(JwtGenerator jwtGenerator, boolean byUser, int offset, int maxRecords) {
		return zqlFilterApi.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
	}

	@Override
	public Response getPapularZQLFilters(JwtGenerator jwtGenerator, boolean fav, int offset, int maxRecords) {
		return zqlFilterApi.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
	}

	@Override
	public boolean validateZQLFilters(Response reqPayLoad, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = reqPayLoad.getBody().asString();
		System.out.println(responseData);
		// Getting Before Create Value
		int payloadreplace = responseData.length();
		String payloadreplace1 = responseData.substring(1, payloadreplace - 1);
		String value = new JSONObject(payloadreplace1).get("totalCount").toString();
		int firstcount = Integer.parseInt(value);

		// After Create Test
		String responseData1 = response.getBody().asString();
		System.out.println(responseData1);
		// Getting Before Create Value
		int countresponse = responseData1.length();
		String payloadreplace12 = responseData1.substring(1, countresponse - 1);
		String value1 = new JSONObject(payloadreplace12).get("totalCount").toString();
		System.out.println(value1);
		int lastcount = Integer.parseInt(value1);
		if ((firstcount + 1) == lastcount) {
			System.out.println("Count is matched Sucessfully");
		}
		// Assert.assertNotNull(new
		// JSONObject(responseData).get("createdByDisplayName").toString(),
		// "createdByDisplayName in zql filter is not null.");
		// Assert.assertTrue(new
		// JSONObject(responseData).get("clientMessage").toString().contains("projectId
		// field value null"), "Error Code is null");
		System.out.println("Response data validated successfully.");
		return true;
	}

	/**
	 * ZQL APis
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getZQLFieldConfiguration(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getZQLFieldConfiguration(JwtGenerator jwtGenerator) {
		return zqlApi.getZQLFieldConfiguration(jwtGenerator);
	}

	@Override
	public boolean validateGetZQLFieldConfiguration(Response response) {

		RestUtils.ValidateStatusIs200(response);
		List<String> listOfSupportedOperators = new ArrayList<>();
		listOfSupportedOperators.add("not in");
		listOfSupportedOperators.add("in");
		listOfSupportedOperators.add("is");
		listOfSupportedOperators.add("!=");
		listOfSupportedOperators.add("is not");
		listOfSupportedOperators.add("=");
		List<String> listOfSupportedOperatorClasses = new ArrayList<>();
		listOfSupportedOperatorClasses.add("EQUALS");
		listOfSupportedOperatorClasses.add("NOT_EQUALS");
		listOfSupportedOperatorClasses.add("IN");
		listOfSupportedOperatorClasses.add("NOT_IN");
		listOfSupportedOperatorClasses.add("IS");
		listOfSupportedOperatorClasses.add("IS_NOT");
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONArray json = new JSONArray(response.getBody().asString());
		Assert.assertTrue(json.length() >= 11);
		for (int i = 0; i < json.length(); i++) {
			JSONObject jsonObject = json.getJSONObject(i);
			if ("project".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("projectId"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Project"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Project"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Long"));
				System.out.println(jsonObject.get("supportedOperators"));
				// List<String> s = jsonObject.get("supportedOperators");
				// Assert.assertTrue(jsonObject.get("supportedOperators").toString().equals(listOfSupportedOperators.toString()));
				System.out.println(jsonObject.get("supportedOperatorClasses"));
				// Assert.assertTrue(jsonObject.get("supportedOperatorClasses").toString().equals(listOfSupportedOperatorClasses.toString()));
				// List<String> myList = new
				// ArrayList<String>(Arrays.asList(jsonObject.get("supportedOperators").toString().split(",")));
				// System.out.println(myList);

			} else if ("priority".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("priorityId"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Priority"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Priority"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Long"));
			} else if ("cycleName".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("cycleId"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Cycle Name"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Cycle Name"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("String"));
			} else if ("executionStatus".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("status"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Execution Status"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Execution Status"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("String"));
			} else if ("fixVersion".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("versionId"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Fix Version"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Fix Version"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Long"));
			} else if ("executedBy".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("executor"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Executed By"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Executed By"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("String"));
			} else if ("executionDate".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("executedOn"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Executed On"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Executed On"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Date"));
			} else if ("creationDate".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("creationDate"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Creation Date"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Creation Date"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Date"));
			} else if ("component".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("componentId"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Component"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Component"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Long"));
			} else if ("issue".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("issueId"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Issue"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Issue Key"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("Long"));
			} else if ("assignee".equals(jsonObject.getString("fieldName"))) {
				Assert.assertTrue(jsonObject.getString("indexName").equals("assignedTo"));
				Assert.assertTrue(jsonObject.getString("displayName").equals("Assigned To"));
				Assert.assertTrue(jsonObject.getString("i18NName").equals("Assigned To"));
				Assert.assertTrue(jsonObject.getString("dataType").equals("String"));
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#executeZQLSearch(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response executeZQLSearch(JwtGenerator jwtGenerator, String payLoad) {
		return zqlApi.executeZQLSearch(jwtGenerator, payLoad);
	}

	@Override
	public boolean validateExecuteZQLSearch(String reqPayLoad, Response response) {
		if (!new JSONObject(reqPayLoad).has("zql")
				|| new JSONObject(reqPayLoad).get("zql").toString().equals("")) {
			System.out.println("ZQL is not passed.");
			RestUtils.validateStatusIs500(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(), "Internal Server Error",
					"message is wrong");
		} else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("ExecuteSearch API Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateZQLSearch(String reqPayLoad, Response response) {
		if (!new JSONObject(reqPayLoad).has("zqlQuery")
				|| new JSONObject(reqPayLoad).get("zqlQuery").toString().equals("")){
			System.out.println("ZQL is not passed.");
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(), "zqlQuery should not be null!");
			
			
		} else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("ExecuteSearch API Response data validated successfully.");
		return true;
	}
	
	@Override
	public boolean validateInvalidZQLSearch(String reqPayLoad, Response response) {
		if (!new JSONObject(reqPayLoad).has("zqlQuery")
						|| new JSONObject(reqPayLoad).get("zqlQuery").toString().equals("vyhvytvv")){
			System.out.println("ZQL is not passed.");
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),"Error in the ZQL Query: Expecting operator before the end of the query. The valid operators are '=', '!=', '<', '>', '<=', '>=', '~', '!~', 'IN', 'NOT IN', 'IS' and 'IS NOT'.");
			
			
		} else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("ExecuteSearch API Response data validated successfully.");
		return true;
	}
	
	@Override
	public boolean validateZQLSearchWithMaxRecordExceed(String reqPayLoad, Response response) {
		if (!new JSONObject(reqPayLoad).has("maxRecords")
								|| new JSONObject(reqPayLoad).get("maxRecords").toString().equals("51")
				) {
			System.out.println("Max record is not passed.");
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(), "size of query chunk should not exceed 50 .");
			
		} else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("ExecuteSearch API Response data validated successfully.");
		return true;
	}
	
	@Override
	public boolean validateExecuteZQLSearchWithoutPassingZql(String reqPayLoad, Response response) {
		if (!new JSONObject(reqPayLoad).has("zql")
				|| new JSONObject(reqPayLoad).get("zql").toString().equals("")) {
			System.out.println("ZQL is not passed.");
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(), "Missing parameter: executionId");
		} else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("ExecuteSearch API Response data validated successfully.");
		return true;
	}

	
	@Override
	public Response getZQLAutoComplete(JwtGenerator jwtGenerator, String fieldName, String fieldValue) {
		return zqlApi.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
	}

	@Override
	public boolean validateGetZQLAutoComplete(String textForSearch, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONArray json = new JSONArray(response.getBody().asString());
		for (int i = 0; i < json.length(); i++) {
			JSONObject json1 = json.getJSONObject(i);
			System.out.println(json1.getString("displayName") + " : " + textForSearch);
			// System.out.println(json1.getString("displayName").toLowerCase().compareToIgnoreCase(textForSearch.toLowerCase()));
			Assert.assertTrue(json1.getString("displayName").toLowerCase().contains(textForSearch.toLowerCase()));
			Assert.assertTrue(json1.getString("value").toLowerCase().contains(textForSearch.toLowerCase()));
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getZQLFieldValues(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getZQLFieldValues(JwtGenerator jwtGenerator) {
		return zqlApi.getZQLFieldValues(jwtGenerator);
	}

	@Override
	public boolean validateGetZQLFieldValues(JSONObject jsonObjectList, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		JSONObject jsonObj1 = new JSONObject(jsonObj.get("fields").toString());
		System.out.println("jsonObjectList.length(): " + jsonObjectList.length());
		Assert.assertTrue(jsonObj1.length() == 15);
		for (int i = 0; i < jsonObjectList.length(); i++) {
			if (jsonObjectList.has("project")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("project");
				System.out.println("projectJSONArray: " + projectJSONArray.toString());
				JSONArray json = jsonObj1.getJSONArray("project");
				System.out.println("json length: " + json.toString());
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				System.out.println("json length1: " + json.length());
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertTrue(getObject.get("id").toString().equals(getObject1.get("id").toString()));
							Assert.assertTrue(getObject.getString("key").equals(getObject1.getString("key")));
						}
					}
				}
				// assertEquals(o1, o2);
				// Assert.assertTrue(jsonprojectJSONArray, );
			}
			if (jsonObjectList.has("priority")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("priority");
				JSONArray json = jsonObj1.getJSONArray("priority");
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertEquals(getObject.getInt("id"), getObject1.getInt("id"));
						}
					}
				}
			}
			if (jsonObjectList.has("executionStatus")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("executionStatus");
				JSONArray json = jsonObj1.getJSONArray("executionStatus");
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertEquals(getObject.getInt("id"), getObject1.getInt("id"));
							Assert.assertTrue(
									getObject.getString("description").equals(getObject1.getString("description")));
							Assert.assertTrue(getObject.getString("color").equals(getObject1.getString("color")));
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
						}
					}
				}
			}
			if (jsonObjectList.has("assignee")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("assignee");
				JSONArray json = jsonObj1.getJSONArray("assignee");
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertEquals(getObject.getInt("id"), getObject1.getInt("id"));
							Assert.assertTrue(
									getObject.getString("description").equals(getObject1.getString("description")));
							Assert.assertTrue(getObject.getString("color").equals(getObject1.getString("color")));
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
						}
					}
				}
			}
		}
		return true;
	}
	
	@Override
	public boolean validateZQLFieldValues(JSONObject jsonObjectList, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject jsonObj = new JSONObject(response.getBody().asString());
		JSONObject jsonObj1 = new JSONObject(jsonObj.get("fields").toString());
		System.out.println("jsonObjectList.length(): " + jsonObjectList.length());
		Assert.assertTrue(jsonObj1.length() == 15);
		for (int i = 0; i < jsonObjectList.length(); i++) {
			if (jsonObjectList.has("project")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("project");
				System.out.println("projectJSONArray: " + projectJSONArray.toString());
				JSONArray json = jsonObj1.getJSONArray("project");
				System.out.println("json length: " + json.toString());
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				System.out.println("json length1: " + json.length());
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertTrue(getObject.get("id").toString().equals(getObject1.get("id").toString()));
							Assert.assertTrue(getObject.getString("key").equals(getObject1.getString("key")));
						}
					}
				}
				// assertEquals(o1, o2);
				// Assert.assertTrue(jsonprojectJSONArray, );
			}
			if (jsonObjectList.has("priority")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("priority");
				JSONArray json = jsonObj1.getJSONArray("priority");
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertEquals(getObject.getInt("id"), getObject1.getInt("id"));
						}
					}
				}
			}
			if (jsonObjectList.has("executionStatus")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("executionStatus");
				JSONArray json = jsonObj1.getJSONArray("executionStatus");
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertEquals(getObject.getInt("id"), getObject1.getInt("id"));
							Assert.assertTrue(
									getObject.getString("description").equals(getObject1.getString("description")));
							Assert.assertTrue(getObject.getString("color").equals(getObject1.getString("color")));
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
						}
					}
				}
			}
			if (jsonObjectList.has("assignee")) {
				JSONArray projectJSONArray = jsonObjectList.getJSONArray("assignee");
				JSONArray json = jsonObj1.getJSONArray("assignee");
				// JSONObject json1 = jsonObj1.getJSONObject("project");
				// JsonParser parser = new JsonParser();
				// JsonElement o1 = parser.parse("{a : {a : 2}, b : 2}");
				// JsonElement o2 = parser.parse("{b : 2, a : {a : 2}}");
				for (int j = 0; j < json.length(); j++) {
					JSONObject getObject = json.getJSONObject(j);
					JSONObject getObject1 = projectJSONArray.getJSONObject(j);
					System.out.println(getObject);

					for (int k = 0; k < getObject1.length(); k++) {
						if (getObject.getString("name").equals(getObject1.getString("name"))) {
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
							Assert.assertEquals(getObject.getInt("id"), getObject1.getInt("id"));
							Assert.assertTrue(
									getObject.getString("description").equals(getObject1.getString("description")));
							Assert.assertTrue(getObject.getString("color").equals(getObject1.getString("color")));
							Assert.assertTrue(getObject.getString("name").equals(getObject1.getString("name")));
						}
					}
				}
			}
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getServerInfo(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getServerInfo(JwtGenerator jwtGenerator) {
		return serverInfoApi.getServerInfo(jwtGenerator);
	}

	@Override
	public boolean validateServerInfo(Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
		JSONObject addonServerInfo = new JSONObject(new JSONObject(responseData).get("addonServerInfo").toString());
		JSONObject jiraServerInfo = new JSONObject(new JSONObject(responseData).get("jiraServerInfo").toString());

		Assert.assertEquals(addonServerInfo.get("version").toString(), Config.getValue("connectBuildNumber"),
				"addonServerInfo version not validated.");
		Assert.assertEquals(addonServerInfo.get("name").toString().trim(), "zephyr-connect",
				"addonServerInfo name not validated.");

		Assert.assertEquals(jiraServerInfo.get("baseUri").toString(), Config.getValue("jiraBaseUrl"),
				"jiraServerInfo baseurl not validated.");
		Assert.assertEquals(jiraServerInfo.get("serverTitle").toString(), "Jira", "jiraServerInfo name not validated.");
		Assert.assertNotNull(jiraServerInfo.get("version").toString());
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getSystemProp(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getSystemProp(JwtGenerator jwtGenerator) {
		return serverInfoApi.getSystemProp(jwtGenerator);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getGeneralConfigInfo(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getGeneralConfigInfo(JwtGenerator jwtGenerator) {
		return configApi.getGeneralConfigInfo(jwtGenerator);
	}

	@Override
	public boolean validateGeneralConfigInfo(Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
		JSONObject issueType = new JSONObject(new JSONObject(responseData).get("issueType").toString());

		Assert.assertEquals(issueType.get("self").toString(),
				Config.getValue("jiraBaseUrl") + "/rest/api/2/issuetype/" + Config.getValue("issueTypeTestId"),
				"IssueType uri not validated.");
		Assert.assertEquals(issueType.get("id").toString().trim(), Config.getValue("issueTypeTestId"),
				"IssueType test id not validated.");

		// Assert.assertEquals(issueType.get("name").toString(),
		// Config.getValue("Test"), "IssueType name not validated.");
		Assert.assertEquals(issueType.get("description").toString(),
				"This JIRA Issue Type is used to create Zephyr Tests.", "IssueType description not validated.");
		System.out.println("Response data validated successfully.");
		return true;
	}

	/**
	 * Execution Apis
	 */

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getExecutionStatuses(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecutionStatuses(JwtGenerator jwtGenerator) {
		return executionApi.getExecutionStatuses(jwtGenerator);
	}

	@Override
	public boolean validateGetExecutionStatuses(Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println("Reponse data: " + responseData);
		JSONArray jsarray = new JSONArray(responseData);
		System.out.println("length=" + jsarray.length());

		for (int i = 0; i < jsarray.length(); i++) {
			Assert.assertNotNull(jsarray.getJSONObject(i).getInt("id"), "Teststep status " + i + " id is null.");
			Assert.assertNotNull(jsarray.getJSONObject(i).getString("name"), "Teststep status " + i + " name is null.");
		}
		return true;
	}

	/**
	 * @param jwtGenerator
	 * @param issueId
	 * @param executionId
	 * @return
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public Response deleteExecution(JwtGenerator jwtGenerator, Long issueId, String executionId) {
		return executionApi.deleteExecution(jwtGenerator, issueId, executionId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getExecution(com.thed.zephyr.cloud
	 * .rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecution(JwtGenerator jwtGenerator, Long projectId, Long issueId, String executionId) {
		return executionApi.getExecution(jwtGenerator, projectId, issueId, executionId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @author Created by Praveenkumar
	 */
	@Override
	public boolean validateGetExecution(Response response, Long projectId, Long issueId) {
		if (projectId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: projectId", "should return Missing parameter: projectId");
		} else if (issueId == null) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("error").toString();
			Assert.assertEquals(res, "Missing parameter: issueId", "should return Missing parameter: issueId");
		}
		// TODO
		// Add validations
		else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#createExecution(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createExecution(JwtGenerator jwtGenerator, String payLoad) {
		return executionApi.createExecution(jwtGenerator, payLoad);
	}

	@Override
	public JSONArray createExecutions(JwtGenerator jwtGenerator, String payLoad) {
		Random random = new Random();
		JSONArray executionObjects = new JSONArray();
		String payLoadCopy = payLoad;
		JSONArray issueIdsJson = null;
		JSONArray cycleIdsJson = null;
		String cycleId = null;
		if (new JSONObject(payLoadCopy).has("issueIds")) {
			issueIdsJson = new JSONObject(payLoadCopy).getJSONArray("issueIds");
		} else {
			issueIdsJson = new JSONObject(payLoadCopy).getJSONArray("issueIds");
		}
		if (new JSONObject(payLoadCopy).has("cycleIds")) {
			cycleIdsJson = new JSONObject(payLoadCopy).getJSONArray("cycleIds");
		} else {
			cycleId = new JSONObject(payLoadCopy).getString("cycleId");
		}
		int size = new JSONObject(payLoadCopy).getInt("noOfExecutions");
		System.out.println("Started creation of " + size + " executions.");
		for (int i = 0; i < size; i++) {
			// Long cycleName = (Long) new
			// JSONObject(payLoadCopy).get("issueId");
			JSONObject json1 = new JSONObject(payLoad);
			if (json1.has("issueIds")) {
				json1.remove("issueIds");
			}
			if (size == issueIdsJson.length()) {
				json1.put("issueId", issueIdsJson.get(i));
			} else {
				json1.put("issueId", issueIdsJson.get(random.nextInt(issueIdsJson.length())));
			}
			// json1.put("issueId",
			// issueIdsJson.get(random.nextInt(issueIdsJson.length())));

			json1.remove("cycleId");
			if (new JSONObject(payLoadCopy).has("cycleIds")) {
				json1.put("cycleId", cycleIdsJson.get(random.nextInt(cycleIdsJson.length())));
			} else {
				json1.put("cycleId", cycleId);
			}

			payLoad = json1.toString();
			// System.out.println(payLoad);
			Response response = executionApi.createExecution(jwtGenerator, payLoad);
			Assert.assertTrue(validateExecution(payLoad, response), "Validated response successfully.");
			executionObjects.put(response.getBody().asString());
			System.out.println("executions created : " + (i + 1) + " .");
		}
		return executionObjects;
	}

	@Override
	public boolean validateExecution(String reqPayLoad, Response response) {
		String responseData = response.getBody().asString();
		System.out.println("Execution response : " + responseData);
		JSONObject responseJson = new JSONObject(responseData);
		JSONObject requestJson = new JSONObject(reqPayLoad);
		if (!requestJson.has("projectId")
				|| (requestJson.has("projectId") && requestJson.get("projectId").toString().equals("null"))) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(responseJson.has("errorType"), "response doesn't contains errorType.");
			Assert.assertTrue(responseJson.has("clientMessage"), "response doesn't contains clientMessage.");
			Assert.assertTrue(responseJson.get("errorType").toString().equals("ERROR"), "errortype is not ERROR.");
			Assert.assertTrue(responseJson.get("clientMessage").toString().contains("projectId field is required."),
					"Client message is not matching.");
			System.out.println("Create Execution response data validated successfully , if not passing projectId.");
		} else if (!requestJson.has("issueId")) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(responseJson.has("errorType"), "response doesn't contains errorType.");
			Assert.assertTrue(responseJson.has("clientMessage"), "response doesn't contains clientMessage.");
			Assert.assertTrue(responseJson.get("errorType").toString().equals("ERROR"), "errortype is not ERROR.");
			Assert.assertTrue(responseJson.get("clientMessage").toString().contains("issueId field is required."),
					"Client message is not matching.");
			System.out.println("Create Execution response data validated successfully , if not passing issueId.");
		} else if (requestJson.has("id") && requestJson.get("id").equals("")) {
			RestUtils.validateStatusIs400(response);
			Assert.assertTrue(responseJson.has("error"), "response doesn't contains errorType.");
			Assert.assertTrue(responseJson.get("error").toString().equals("API not found."), "error not validated.");
			System.out.println("Create Execution response data validated successfully , if not passing id.");
		} else if (!requestJson.has("versionId")) {
			RestUtils.validateStatusIs500(response);
			JSONObject responseJsonObject = new JSONObject(responseData);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
					"Error type is not validated.");
			Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
					"versionId error type is not error.");
			System.out.println("Response data validated successfully for VersionId is null.");
		}

		else {
			RestUtils.ValidateStatusIs200(response);
			System.out.println("Create Execution response status validated successfully.");
			Assert.assertTrue(responseJson.get("warningMessage").toString().equals("null"), "warningMessage is null.");
			Assert.assertTrue(responseJson.get("originMessage").toString().equals("null"), "originMessage is null.");
			Assert.assertNotNull(responseJson.has("execution"), "Updated cycle id is null.");

			JSONObject executionJson = new JSONObject(responseJson.get("execution").toString());

			Assert.assertEquals(requestJson.getLong("projectId"), executionJson.getLong("projectId"),
					"Not Matching Project Id.");
			if (requestJson.has("versionId")) {
				Assert.assertEquals(requestJson.getLong("versionId"), executionJson.getLong("versionId"),
						"Not Matching version Id.");
			} else {
				Assert.assertNotEquals(executionJson.getLong("versionId"), -1, "Not Matching version Id.");
			}

			Assert.assertEquals(requestJson.getLong("issueId"), executionJson.getLong("issueId"),
					"Not Matching issue Id.");

			if (requestJson.has("id")) {
				Assert.assertEquals(requestJson.get("id"), executionJson.get("id"), "Not Matching Execution id.");
			} else {
				Assert.assertNotNull(executionJson.get("id"), "Execution id is null.");
			}
			if (requestJson.has("cycleId")) {
				Assert.assertEquals(requestJson.get("cycleId"), executionJson.get("cycleId"), "Not Matching Cycle id.");
			} else {
				Assert.assertTrue(executionJson.get("cycleId").toString().equals("-1"), "Not Matching Cycle id.");
			}
			if (requestJson.has("comment")) {
				Assert.assertEquals(requestJson.get("comment"), executionJson.get("comment"), "Not Matching comment.");
			}
			if (requestJson.has("status")) {
				Assert.assertEquals(new JSONObject(requestJson.get("status").toString()).get("id"),
						new JSONObject(executionJson.get("status").toString()).get("id"), "Not Matching Status Id.");
			}
			if (requestJson.has("defects")) {
				// System.out.println(requestJson.get("defects").toString());
				JSONArray jsonArray1 = requestJson.getJSONArray("defects");
				List<Long> srcList = CommonUtils.convertToList(jsonArray1);
				// System.out.println(executionJson.getJSONArray("defects").toString());
				JSONArray jsonArray2 = executionJson.getJSONArray("defects");
				List<Long> destList = CommonUtils.getDataListOfLongFromJsonArray(jsonArray2, "id");
				// System.out.println(destList);
				Assert.assertTrue(destList.containsAll(srcList), "Not same both defectlist.");

				// System.out.println("Defects are validated Successfully.");
			}
			if (requestJson.has("creationDate")) {
				Assert.assertNotNull(requestJson.get("creationDate").toString(), "Creation Date is null.");
				Assert.assertNotNull(executionJson.get("creationDate").toString(), "Creation Date is null.");
			} else {
				Assert.assertNotNull(executionJson.get("creationDate").toString(), "Creation Date is null.");
			}
		}

		System.out.println("Create Execution response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateInvalidCycleId(String cycleId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.validateStatusIs500(response);
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type not validated."); Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString() .contains("Cycle " +
		 * cycleId + " is invalid or does not belong to the projectId"),
		 * "Client message not validated.");
		 */
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"versionId error type is not error.");
		Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.equals("We encountered some problems during processing this request. Please try again!"));
		System.out.println("Invalid cycle id response validated successfully.");
		return true;
	}

	/*
	 * @Override public boolean validateInvalidProjectId(Long projectId, Response
	 * response) { String responseData = response.getBody().asString();
	 * System.out.println(responseData); RestUtils.validateStatusIs400(response);
	 * NumberFormat nf1 = NumberFormat.getInstance(); // projectId =
	 * Long.parseLong(nf1.format(projectId)); // String projectId1 =
	 * nf1.format(projectId);
	 * 
	 * String projectId1=null; if(projectId!=null) { projectId1 =
	 * nf1.format(projectId); Assert.assertTrue(new
	 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
	 * "errortype is not ERROR."); //projectId field value is null or 54,679 is not
	 * valid. } Assert.assertTrue(new
	 * JSONObject(responseData).get("clientMessage").toString()
	 * .contains("invalid or not belong to projectId") || new
	 * JSONObject(responseData).get("clientMessage").toString()
	 * .contains("projectId field value is null or "+projectId1+" is not valid.")||
	 * new JSONObject(responseData).get("clientMessage").toString()
	 * .contains("Cannot parse parameter projectId as Long: For input string"),
	 * "Error Code is null");
	 * 
	 * 
	 * Assert.assertTrue(new
	 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
	 * "errortype is not ERROR."); //projectId field value is null or 54,679 is not
	 * valid. Assert.assertTrue(new
	 * JSONObject(responseData).get("clientMessage").toString()
	 * .contains("invalid or not belong to projectId") || new
	 * JSONObject(responseData).get("clientMessage").toString()
	 * .contains("projectId field value is null or "+projectId1+" is not valid."),
	 * "Error Code is null"); System.out.
	 * println("Response data validated successfully for invalid projectid.");
	 * return true; }
	 */

	@Override
	public boolean validateInvalidProjectId(Long projectId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs400(response);
		String projectId1 = null;
		if (projectId != null) {
			NumberFormat nf1 = NumberFormat.getInstance();
			// projectId = Long.parseLong(nf1.format(projectId));
			projectId1 = nf1.format(projectId);
		}

		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"projectId error type is not error.");
		Assert.assertTrue(
				responseJsonObject.get("clientMessage").toString().equals("projectId field is required.")
						|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: projectId")
						|| responseJsonObject.get("clientMessage").toString()
								.contains("projectId field value is null or " + projectId1 + " is not valid.")
						|| responseJsonObject.get("clientMessage").toString()
								.contains("Cannot parse parameter projectId as Long: For input string"),
				"projectId field is required.");

		System.out.println("Response data validated successfully for invalid project id.");
		return true;
	}

	public boolean validateInvalidProjectIdForCreateTestStep(Long projectId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// projectId = Long.parseLong(nf1.format(projectId));
		// String projectId1 = nf1.format(projectId);
		String projectId2 = null;

		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "errortype is not ERROR."); //projectId field value is null or 54,679 is not
		 * valid. Assert.assertTrue(new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("invalid or not belong to projectId") || new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("projectId field value is null or "+projectId1+" is not valid."),
		 * "Error Code is null"); System.out.
		 * println("Response data validated successfully for invalid projectid.");
		 * return true;
		 */
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"projectId error type is not error.");
		Assert.assertTrue(
				responseJsonObject.get("clientMessage").toString()
						.equals("projectId field value is null or 145,544 is not valid.")
						|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: projectId"),
				"projectId field is required.");

		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("projectId field value is null or 0 is not valid " + projectId2 +
		 * " is not valid."), "Client message is not validated for invalid  id.");
		 */
		System.out.println("Response data validated successfully for invalid project id.");
		return true;
	}

	public boolean validateNullProjectId(Long projectId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);

		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// projectId = Long.parseLong(nf1.format(projectId));
		// String projectId1 = nf1.format(projectId);
		// String projectId2 = null;

		// projectId = Long.parseLong(nf1.format(projectId));
		String projectId1 = null;
		if (projectId != null) {
			projectId1 = nf1.format(projectId);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
					"errortype is not ERROR.");
			// projectId field value is null or 54,679 is not valid.
		}
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString()
						.contains("invalid or not belong to projectId")
						|| new JSONObject(responseData).get("clientMessage").toString()
								.contains("projectId field value is null or " + projectId1 + " is not valid.")
						|| new JSONObject(responseData).get("clientMessage").toString()
								.contains("Cannot parse parameter projectId as Long: For input string"),
				"Error Code is null");

		System.out.println("Response data validated successfully for invalid projectid.");
		return true;
	}

	public boolean validateInvalidProjectIdForTestStep(Long projectId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// projectId = Long.parseLong(nf1.format(projectId));
		// String projectId1 = nf1.format(projectId);
		String projectId2 = null;

		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "errortype is not ERROR."); //projectId field value is null or 54,679 is not
		 * valid. Assert.assertTrue(new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("invalid or not belong to projectId") || new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("projectId field value is null or "+projectId1+" is not valid."),
		 * "Error Code is null"); System.out.
		 * println("Response data validated successfully for invalid projectid.");
		 * return true;
		 */
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"projectId error type is not error.");
		Assert.assertTrue(
				responseJsonObject.get("clientMessage").toString()
						.equals("projectId field value is null or 46,578 is not valid.")
						|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: projectId"),
				"projectId field is required.");

		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("projectId field value is null or 0 is not valid " + projectId2 +
		 * " is not valid."), "Client message is not validated for invalid  id.");
		 */
		System.out.println("Response data validated successfully for invalid project id.");
		return true;
	}

	public boolean validateInvalidStatusId(Long statusId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs500(response);
		/*
		 * Assert.assertTrue(new JSONObject(responseData).get("error").toString()
		 * .equals("Unable to update execution, Invalid executionStatus 100 passed"),
		 * "errortype is not ERROR.");
		 */
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"versionId error type is not error.");
		System.out.println("Response data validated successfully for invalid statusId.");
		return true;
	}

	@Override
	public boolean validateInvalidExecutionId(String executionId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);

		////

		RestUtils.validateStatusIs500(response);
		// Assert.assertTrue(
		// new JSONObject(responseData).get("error").toString().equals("Can't find such
		// execution in db."),
		// "errortype is not ERROR.");
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type is not validated.");
		 */
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString()
						.contains("We encountered some problems during processing this request. Please try again!"),
				"Client message is not validated for invalid execution id.");

		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"executionId error type is not error.");
		System.out.println("Response data validated successfully.");
		System.out.println("Execution not updated due to invalid execution Id");
		return true;

	}

	@Override
	public boolean validateInvalidIssueId(Long issueId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// issueId = Long.parseLong(nf1.format(issueId));
		// String issueId1 = nf1.format(issueId);
		// String issueId2 = null;
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type is not validated.");
		 */
		/*
		 * Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("issueId field value is null or " + issueId1 + " is not valid."),
		 * "Client message is not validated for invalid issue id.");
		 */

		// issueId = Long.parseLong(nf1.format(issueId));
		String issueId1 = null;
		if (issueId != null) {
			issueId1 = nf1.format(issueId);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
					"Error type is not validated.");
		}
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");

		System.out.println("added validation now");
		Assert.assertTrue(
				responseJsonObject.get("clientMessage").toString()
						.equals("issueId field value is null or 0 is not valid.")
						|| new JSONObject(responseData).get("clientMessage").toString()
								.equals("issueId field value is null or 15,544 is not valid.")
						|| new JSONObject(responseData).get("clientMessage").toString()
								.contains("Cannot parse parameter issueId as Long: For input string")|| new JSONObject(responseData).get("clientMessage").toString()
								.contains("We encountered some problems during processing this request. Please try again!"),
				"Error Code is null");

		System.out.println("Response data validated successfully for invalid issue id.");

		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type is not validated.");
		 * Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
		 * "projectId error type is not error.");
		 * /*Assert.assertTrue(responseJsonObject.get("clientMessage").toString().
		 * equals("issueId field is required.") ||
		 * responseJsonObject.get("clientMessage").toString().
		 * equals("Missing parameter: issueId"), "issueId field is required.");
		 */

		/*
		 * Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("issueId field value is null or " + issueId1 + " is not valid."),
		 * "Client message is not validated for invalid issue id.");
		 */

		// Assert.assertTrue(responseJsonObject.get("clientMessage").toString().equals("We
		// encountered some problems during processing this request. Please try
		// again!"));
		return true;
	}

	public boolean validateInvalidIssueIdForStep1(Long issueId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// issueId = Long.parseLong(nf1.format(issueId));
		// String issueId1 = nf1.format(issueId);
		// String issueId2 = null;
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type is not validated.");
		 */
		/*
		 * Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("issueId field value is null or " + issueId1 + " is not valid."),
		 * "Client message is not validated for invalid issue id.");
		 */

		// issueId = Long.parseLong(nf1.format(issueId));
		String issueId1 = null;
		if (issueId != null) {
			issueId1 = nf1.format(issueId);
			Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
					"Error type is not validated.");
		}

		System.out.println("Response data validated successfully for invalid issue id.");

		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type is not validated.");
		 * Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
		 * "projectId error type is not error.");
		 * /*Assert.assertTrue(responseJsonObject.get("clientMessage").toString().
		 * equals("issueId field is required.") ||
		 * responseJsonObject.get("clientMessage").toString().
		 * equals("Missing parameter: issueId"), "issueId field is required.");
		 */

		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString()
						.contains("issueId field value is null or " + issueId1 + " is not valid."),
				"Client message is not validated for invalid issue id.");

		Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.equals("issueId field value is null or 11,210 is not valid."));
		return true;
	}

	@Override
	public boolean validatenullIssueId(Long issueId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// issueId = Long.parseLong(nf1.format(issueId));
		// String issueId1 = nf1.format(issueId);
		String issueId2 = null;
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "Error type is not validated.");
		 */
		/*
		 * Assert.assertTrue( new
		 * JSONObject(responseData).get("clientMessage").toString()
		 * .contains("issueId field value is null or " + issueId1 + " is not valid."),
		 * "Client message is not validated for invalid issue id.");
		 */
		System.out.println("Response data validated successfully for invalid issue id.");

		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"projectId error type is not error.");
		Assert.assertTrue(
				responseJsonObject.get("clientMessage").toString().equals("issueId field is required.")
						|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: issueId"),
				"issueId field is required.");

		// Assert.assertTrue(responseJsonObject.get("clientMessage").toString().equals("We
		// encountered some problems during processing this request. Please try
		// again!"));
		return true;
	}

	@Override
	public boolean validateInvalidIssueTypeId(Response response) {
		try {
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println("Response--:" + responseData);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"error type is not error.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"Issue passed in the request is not of the type Test.", "Not provided invalid issueTypeId.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateInvalidStepId(String stepId, Response response) {
		try {

			if (response.statusCode() == 500) {
				RestUtils.validateStatusIs500(response);
				System.out.println(
						"status code is 500, Testcase is passing but error code is wrong raised bug for this ZFJCLOUD-2614");

			} else {
				RestUtils.validateStatusIs400(response);
				System.out.println("status code is 400");
			}
			String responseData = response.getBody().asString();
			System.out.println("Response--:" + responseData);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"error type is not error.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"Id field value is null or " + stepId + " is not valid.", "Not provided invalid stepId.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateInvalidVersionId(Long versionId, Response response) {
		String responseData = response.getBody().asString();
		JSONObject responseJsonObject = new JSONObject(responseData);
		System.out.println(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		// versionId = Long.parseLong(nf1.format(versionId));
		String versionId1 = nf1.format(versionId);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"versionId error type is not error.");
		// Assert.assertTrue(
		// new JSONObject(responseData).get("clientMessage").toString()
		// .contains("versionId field value is null or " + versionId1 + " is not
		// valid."),
		// "Client message is not validated for invalid versionId id.");
		System.out.println("Response data validated successfully for invalid version id.");
		return true;
	}

	/*
	 * @Override public boolean validateCreatedExecutionInvalidProjectId(String
	 * executionJson, Response response) { RestUtils.validateStatusIs400(response);
	 * String responseData = response.getBody().asString();
	 * System.out.println(responseData); Assert.assertTrue(new
	 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
	 * "errortype is not ERROR."); Assert.assertTrue( new
	 * JSONObject(responseData).get("clientMessage").toString().contains(
	 * "projectId field value null"), "Error Code is null"); System.out.println(
	 * "Response data validated successfully."); System.out.println(
	 * "Execution not created due to invalid project id"); return true; }
	 */

	@Override
	public boolean validateMultipleExecutionsWithSameIssueInScheduledCycle(Response response) {

		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
		// Assert.assertTrue(new
		// JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		// "errortype is not ERROR.");
		Assert.assertTrue(new JSONObject(responseData).get("warningMessage").toString()
				.contains("Test case already added to cycle"), "Duplicatecycle added");
		System.out.println(
				"Response data validated successfully, if user tried to add the Test which is already added to cycle.");
		return true;
	}

	/*
	 * @Override public boolean validateCreatedExecutionIsueIdOtherProject(String
	 * executionJson, Response response) { RestUtils.validateStatusIs400(response);
	 * String responseData = response.getBody().asString();
	 * System.out.println(responseData); Assert.assertTrue(new
	 * JSONObject(responseData).get("clientMessage").toString() .contains(
	 * "issueId not belong to projectId"), "Error Code is null");
	 * System.out.println("Response data validated successfully.");
	 * System.out.println(
	 * "Execution not created due to issue id is of other project"); return true; }
	 */

	@Override
	public boolean validateInvalidTestType(Long issueId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.validateStatusIs400(response);
		NumberFormat nf1 = NumberFormat.getInstance();
		String issueId1 = nf1.format(issueId);
		// String versionId1 = nf1.format(versionId);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString()
						.contains("The IssueId/IssueKey " + issueId1 + " is not of Issue Type Test."),
				"clientMessage is not validated.");
		System.out.println("Response data validated successfully, for other issue types.");
		return true;
	}

	@Override
	public boolean validateDeletedExecution(String Executionid, Response response) {
		try {
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			System.out.println(response.getStatusLine());
			JSONObject DeleteExecutionResponseJsonObj = new JSONObject(responseData);
			RestUtils.ValidateStatusIs200(response);

			Assert.assertTrue(
					DeleteExecutionResponseJsonObj.getString("message")
							.equals("execution " + Executionid + " successfully deleted"),
					" Delete execution message is not validated.");
			// System.out.println(1);
			Assert.assertNotNull(DeleteExecutionResponseJsonObj.get("timestamp").toString(),
					"Delete execution message is not validated.");

			// System.out.println(2);
			System.out.println("Delete execution Response data validated successfully.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateDeletedExecutionWithInvalidIsueId(Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.validateStatusIs400(response);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"Error type is not validated.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("issueId field value is null or 123 is not valid."), "Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Execution not deleted due to invalid issue id");
		return true;
	}

	@Override
	public boolean validateDeletedExecutionWithInvalidExecutionId(Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("No Execution found for executionId")|| 
				new JSONObject(responseData).get("clientMessage").toString().contains("Null or invalid Executions."), "Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Execution not deleted due to invalid execution id");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getExecutions(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecutions(JwtGenerator jwtGenerator, Long projectId, Long issueId, int offset, int size) {
		return executionApi.getExecutions(jwtGenerator, projectId, issueId, offset, size);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @author Created by Praveenkumar
	 */
	@Override
	public boolean validateGetExecutions(Response response, Long projectId, Long issueId, int offset, int size) {
		if (projectId == null) {
			RestUtils.validateStatusIs400(response);
			/*
			 * String res = new
			 * JSONObject(response.getBody().asString()).get("error").toString();
			 * Assert.assertEquals(res, "Missing parameter: projectId",
			 * "should return Missing parameter: projectId");
			 */

			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.contains("Missing parameter: projectId"), "Error Code is null");
			System.out.println("Response data validated successfully.");

		} else if (issueId == null) {
			RestUtils.validateStatusIs400(response);
			/*
			 * String res = new
			 * JSONObject(response.getBody().asString()).get("error").toString();
			 * Assert.assertEquals(res, "ERROR"); Assert.assertEquals(res,
			 * "Missing parameter: issueId", "should return Missing parameter: issueId");
			 */
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertTrue(
					new JSONObject(responseData).get("clientMessage").toString().contains("Missing parameter: issueId"),
					"Error Code is null");
			System.out.println("Response data validated successfully.");
		} else if (size >= 51) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("errorType").toString();
			Assert.assertEquals(res, "ERROR");
			res = new JSONObject(response.getBody().asString()).get("clientMessage").toString();
			Assert.assertEquals(res, "size of query chunk should not exceed 50 .",
					"Should throw error chunk should not exceed 50");
		} else if (offset > size) {
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			System.out.println(response.getStatusLine());
			JSONObject GetExecutionsJsonObj = new JSONObject(responseData);
			RestUtils.ValidateStatusIs200(response);
			Assert.assertEquals(GetExecutionsJsonObj.get("executionList").toString(),
					GetExecutionsJsonObj.get("executionList").toString(), "");
		}
		// TODO
		// Add validations
		else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateGetExecutionsWithInvalidIssueId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("issueId field value is null or 99 is not valid."), "Error Code is null");
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateGetExecutionsWithInvalidProjectId(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("projectId field value is null or 99 is not valid."), "Error Code is null");
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public Response getExecutionsByCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId,
			int offset, int size) {
		return executionApi.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
	}

	@Override
	public boolean validateGetExecutionsByCycle(Response response, Long projectId, Long versionId, String cycleId,
			int offset, int size) {
		if (projectId == null) {
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.contains("Missing parameter: projectId"), "Error Code is null");
			System.out.println("Response data validated successfully.");
		} else if (versionId == null) {
			RestUtils.validateStatusIs400(response);
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
					.contains("Missing parameter: versionId"), "Error Code is null");
			System.out.println("Response data validated successfully.");
		} else if (size >= 51) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("errorType").toString();
			Assert.assertEquals(res, "ERROR");
			res = new JSONObject(response.getBody().asString()).get("clientMessage").toString();
			Assert.assertEquals(res, "size of query chunk should not exceed 50 .",
					"Should throw error chunk should not exceed 50");
		} else if (offset > size) {
			/*
			 * RestUtils.validateStatusIs400(response); String res = new
			 * JSONObject(response.getBody().asString()).get("errorType").toString();
			 * Assert.assertEquals(res, "ERROR"); res = new
			 * JSONObject(response.getBody().asString()).get("clientMessage").toString();
			 * Assert.assertEquals(res, "offset cannot be greater than size.",
			 * "Should throw error offset cannot be greater than size");
			 */
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			System.out.println(response.getStatusLine());
			JSONObject GetExecutionsJsonObj = new JSONObject(responseData);
			RestUtils.ValidateStatusIs200(response);
		}
		// TODO
		// Add validations
		else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	public boolean validateGetExecutionsWithOtherCycleId(Response response, Long projectId, Long versionId,
			String cycleId, int offset, int size) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("errorType").toString().equals("ERROR"),
		 * "errortype is not ERROR.");
		 */
		/*
		 * Assert.assertTrue(new
		 * JSONObject(responseData).get("clientMessage").toString().equals("Cycle "
		 * +cycleId+" is invalid or does not belong to the projectId "
		 * +projectId+" and versionId "+versionId+"."), "Error Code is null");
		 */

		// Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("is
		// invalid or does not belong to the projectId "+projectId+" and versionId
		// "+versionId+"."));

		String s = String.valueOf(projectId);

		String actual = "Cycle " + cycleId + " is invalid or does not belong to the projectId " + s + " and versionId "
				+ versionId + ".";
		System.out.println(actual);

		Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.contains("is invalid or does not belong to the projectId"));

		// Assert.assertTrue(responseJsonObject.get("clientMessage").toString().equals("assigneeType
		// field value is null or assigne is not valid.") ||
		// responseJsonObject.get("clientMessage").toString().equals("assigneeType field
		// value is null or null is not valid.")

		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getExecutionsByIssue(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String, int, int)
	 * 
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	@Override
	public Response getExecutionsByIssue(JwtGenerator jwtGenerator, Long issueId, int offset, int size) {
		return executionApi.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
	}

	@Override
	public Response getExecutionsByIssue(JwtGenerator jwtGenerator, String issueKey, int offset, int size) {
		return executionApi.getExecutionsByIssue(jwtGenerator, issueKey, offset, size);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @author Created by Praveenkumar
	 */
	@Override
	public boolean validateGetExecutionsByIssue(Response response, Long issueId, int offset, int size) {
		if ((issueId == null) || (issueId == 99)) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("errorType").toString();
			Assert.assertEquals(res, "ERROR");
		} else if (size >= 51) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("errorType").toString();
			Assert.assertEquals(res, "ERROR");
			res = new JSONObject(response.getBody().asString()).get("clientMessage").toString();
			Assert.assertEquals(res, "size of execution chunk should not exceed 50 .",
					"Should throw error chunk should not exceed 50");
		} else if (offset > size) {
			RestUtils.validateStatusIs400(response);
			String res = new JSONObject(response.getBody().asString()).get("errorType").toString();
			Assert.assertEquals(res, "ERROR");
			res = new JSONObject(response.getBody().asString()).get("clientMessage").toString();
			Assert.assertEquals(res, "offset cannot be greater than size.",
					"Should throw error offset cannot be greater than size");
		}
		// TODO
		// Add validations
		else {
			RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	@Override
	public Response exportExecutions(JwtGenerator jwtGenerator, String payLoad) {
		return executionApi.exportExecution(jwtGenerator, payLoad);
		// Response response1 = executionApi.exportExecution(jwtGenerator,
		// payLoad);
		// System.out.println(response1.getBody().asString());
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// String fileName = new
		// JSONObject(response2.getBody().asString()).get("summaryMessage").toString();
		//
		//
		// return fileName;
	}

	@Override
	public boolean downloadExecutionsExportedFile(JwtGenerator jwtGenerator, String fileName) {
		try {
			Response responseOfDownloadApi = executionApi.downloadExportedFile(jwtGenerator, fileName);
			InputStream inputStream = responseOfDownloadApi.getBody().asInputStream();
			try {
				String theString = IOUtils.toString(inputStream, "UTF-8");
				IOUtils.closeQuietly(inputStream);
				File file = new File(fileName);
				FileOutputStream fop = new FileOutputStream(file);
				file.createNewFile();
				fop.write(theString.getBytes());
				fop.flush();
				fop.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public boolean validateExportExecutions(String response, String exportType) {
		if ((!(exportType.equalsIgnoreCase("xml"))) && (!(exportType.equalsIgnoreCase("csv")))
				&& (!(exportType.equalsIgnoreCase("html")))) {
			// Assert.assertEquals(response, "");
		}
		// TODO
		// Add validations
		else if (exportType.equalsIgnoreCase("xml")) {
			Assert.assertTrue(response.contains(".xml"), "Exported file is not valid");
			// RestUtils.ValidateStatusIs200(response);
		} else if (exportType.equalsIgnoreCase("csv")) {
			Assert.assertTrue(response.contains(".csv"), "Exported file is not valid");
			// RestUtils.ValidateStatusIs200(response);
		} else if (exportType.equalsIgnoreCase("html")) {
			Assert.assertTrue(response.contains(".html"), "Exported file is not valid");
			// RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getAttachmentThumbnail(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getAttachmentThumbnail(JwtGenerator jwtGenerator, String attachmentId) {
		Response response = attachmentApi.getAttachmentThumbnail(jwtGenerator, attachmentId);
		InputStream inputStream = response.getBody().asInputStream();
		String s = response.getHeader("Content-Disposition");

		ContentDisposition cd = null;
		try {
			cd = new ContentDisposition(s);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		String fileName = cd.getFileName();
		String[] arr = fileName.split("_");
		fileName = arr[0];
		try {
			FileUtils.copyInputStreamToFile(inputStream, new File(fileName));
			/*
			 * // String theString = IOUtils.toString(inputStream, "UTF-8");
			 * IOUtils.closeQuietly(inputStream); File file = new File("abc.png");
			 * FileOutputStream fop = new FileOutputStream(file); file.createNewFile();
			 * fop.write(theString.getBytes()); fop.flush(); fop.close();
			 */
		} catch (IOException e) {
			e.printStackTrace();
		}
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getAttachmentImage(com.thed.zephyr
	 * .cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	@Override
	public Response getAttachmentImage(JwtGenerator jwtGenerator, String attachmentId) {
		Response response = attachmentApi.getAttachmentImage(jwtGenerator, attachmentId);
		InputStream inputStream = response.getBody().asInputStream();
		String s = response.header("Content-Disposition");

		ContentDisposition cd = null;
		try {
			cd = new ContentDisposition(s);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		// String fileName = cd.getFileName();
		// System.out.println(fileName);
		String[] arr = s.split("''");
		String fileName = arr[1];
		try {
			FileUtils.copyInputStreamToFile(inputStream, new File(fileName));
			/*
			 * // String theString = IOUtils.toString(inputStream, "UTF-8");
			 * IOUtils.closeQuietly(inputStream); File file = new File("abc.png");
			 * FileOutputStream fop = new FileOutputStream(file); file.createNewFile();
			 * fop.write(theString.getBytes()); fop.flush(); fop.close();
			 */
		} catch (IOException e) {
			e.printStackTrace();
		}
		return response;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#deleteAttachment(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteAttachment(JwtGenerator jwtGenerator, String attachmentId) {
		return attachmentApi.deleteAttachment(jwtGenerator, attachmentId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getExecutionAttachmentsList(com.
	 * thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecutionAttachmentsList(JwtGenerator jwtGenerator, String entityId) {
		return attachmentApi.getExecutionAttachmentsList(jwtGenerator, entityId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#addAttachment(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response addAttachment(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long issueId,
			String cycleId, String entityName, String entityId, String comment, String fileName) {
		return attachmentApi.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId,
				comment, fileName);
	}

	@Override
	public JSONArray addMultipleAttachment(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long issueId,
			String cycleId, String entityName, String entityId, String comment, List<String> fileNames) {
		JSONArray jsonArray = new JSONArray();
		for (int i = 0; i < fileNames.size(); i++) {
			String fileName = fileNames.get(i);
			Response response = attachmentApi.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
					entityName, entityId, comment, fileName);
			boolean flag = validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment, fileName,
					response);
			Assert.assertTrue(flag, "Attachment " + (i + 1) + " validated.");
			// jsonArray.addpus.a = new
			// JSONArray(response.getBody().asString()).getJSONObject(0);
			jsonArray.put(new JSONArray(response.getBody().asString()).getJSONObject(0));
		}
		return jsonArray;
	}

	@Override
	public boolean validateCreatedAttachment(Long versionId, String cycleId, String entityName, String entityId,
			String comment, String fileName, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
		JSONArray jsonArray = new JSONArray(responseData);

		for (int i = 0; i < jsonArray.length(); i++) {
			JSONObject attachmentObj = new JSONObject(jsonArray.get(jsonArray.length() - 1).toString());
			Assert.assertNotNull(attachmentObj.getString("id"), "Attachment id is null");
			Assert.assertEquals(attachmentObj.getString("name"), fileName, "Attachment File name not same.");

			if (fileName.contains("\\.")) {
				String extenstion = fileName.split("\\.")[1];
				Assert.assertEquals(attachmentObj.getString("fileExtension"), extenstion,
						"Attachment File name not same.");
			}
			Assert.assertNotNull(attachmentObj.get("createDate"), "Attachment createDate not same.");

			Assert.assertEquals(attachmentObj.getString("createdBy"), Config.getValue("accountId"),
					"Attachment created by name not same.");
			Assert.assertEquals(attachmentObj.getString("entityId"), entityId, "Attachment entityId not same.");
			Assert.assertEquals(attachmentObj.getString("entityType").toLowerCase(), entityName.toLowerCase(),
					"Attachment entityName not same.");
			Assert.assertEquals(attachmentObj.getString("cycleId"), cycleId, "Attachment cycleId not same.");
			Assert.assertEquals(attachmentObj.get("versionId").toString(), versionId.toString(),
					"Attachment versionId not same.");

		}
		System.out.println("Attachment Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateGetAttachment(com.jayway.
	 * restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateGetAttachment(String entityId, JSONArray reqJsonArray, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
		// JSONArray responseJsonArray = new JSONArray(new JsonArray(""));
		//
		// for (int i = 0; i < responseJsonArray.length(); i++) {
		// JSONObject attachmentObj = new
		// JSONObject(responseJsonArray.get(i).toString());
		// Assert.assertNotNull(attachmentObj.getString("id"), "Attachment id is null");
		// Assert.assertEquals(attachmentObj.getString("name"), fileName, "Attachment
		// File name not same.");
		// System.out.println(fileName.split("\\.")[1]);
		// if(fileName.contains("\\.")){
		// String extenstion = fileName.split("\\.")[1];
		// Assert.assertEquals(attachmentObj.getString("fileExtension"), extenstion,
		// "Attachment File name not same.");
		// }
		// Assert.assertNotNull(attachmentObj.getString("createDate"), "Attachment
		// createDate not same.");
		//
		// Assert.assertEquals(attachmentObj.getString("createdBy"),
		// Config.getValue("adminUserName"), "Attachment created by name not same.");
		// Assert.assertEquals(attachmentObj.getString("entityId"), entityId,
		// "Attachment entityId not same.");
		// Assert.assertEquals(attachmentObj.getString("entityType"), entityName,
		// "Attachment entityName not same.");
		// Assert.assertEquals(attachmentObj.getString("cycleId"), cycleId, "Attachment
		// cycleId not same.");
		// Assert.assertEquals(attachmentObj.get("versionId").toString(),
		// versionId.toString(), "Attachment versionId not same.");
		//
		// }
		System.out.println("Get attachment Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateDeletedAttachment(String attachmentId, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		// System.out.println(response.getStatusLine());
		RestUtils.ValidateStatusIs200(response);

		JSONObject DeleteExecutionResponseJsonObj = new JSONObject(responseData);
		Assert.assertTrue(
				DeleteExecutionResponseJsonObj.getString("message")
						.equals("attachment " + attachmentId + " successfully deleted"),
				"attachment execution message is not validated.");
		// Calendar calendar =
		// Calendar.getInstance(TimeZone.getTimeZone("America/Chikago"));
		// Date currentDate = calendar.getTime();
		// System.out.println(currentDate);
		Assert.assertNotNull(DeleteExecutionResponseJsonObj.get("timestamp"),
				"Delete execution message is not validated.");
		System.out.println("Attachment Response data validated successfully.");
		return true;
	}

	@Override
	public boolean validateInvalidAttachmentId(String attachmentId, Response response) {

		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println(response.getStatusLine());
		RestUtils.validateStatusIs400(response);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");

		String error = "attachmentId field value is null or " + attachmentId + " is not valid.";
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString().contains(error),
				"clientMessage not validated.");
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getStepResultAttachmentsList(com.
	 * thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getStepResultAttachmentsList(JwtGenerator jwtGenerator, String stepResultId) {
		return attachmentApi.getStepResultAttachmentsList(jwtGenerator, stepResultId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#updateBulkStatus(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	@Override
	public Response updateBulkStatus(JwtGenerator jwtGenerator, String payLoad) {
		return executionApi.updateBulkStatus(jwtGenerator, payLoad);
		// Response response1 = executionApi.updateBulkStatus(jwtGenerator,
		// payLoad);
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// return response2;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#deleteBulkExecutions(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	@Override
	public Response deleteBulkExecutions(JwtGenerator jwtGenerator, String payLoad) {
		return executionApi.deleteBulkExecutions(jwtGenerator, payLoad);
		// Response response1 = executionApi.deleteBulkExecutions(jwtGenerator,
		// payLoad);
		// System.out.println(response1.getBody().asString());
		// System.out.println("Extracting job progress now.");
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// return response2;
	}

	@Override
	public Response assignBulkExecutions(JwtGenerator jwtGenerator, String payLoad) {
		return executionApi.assignBulkExecutions(jwtGenerator, payLoad);
		// Response response1 = executionApi.assignBulkExecutions(jwtGenerator,
		// payLoad);
		// System.out.println(response1.getBody().asString());
		// System.out.println("Extracting job progress now.");
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// return response2;
	}

	/**
	 * @param jwtGenerator
	 * @param executionId
	 * @param stepResultId
	 * @return
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public Response getStepResult(JwtGenerator jwtGenerator, String executionId, String stepResultId) {
		return stepresultsApi.getStepResult(jwtGenerator, executionId, stepResultId);
	}
	
	
	public boolean getStepResult2(JwtGenerator jwtGenerator, String executionId, Long projectId,Response StepResultsresponse) {
		RestUtils.ValidateStatusIs200(StepResultsresponse);
		String responseData = StepResultsresponse.getBody().asString();
		System.out.println(responseData);
		return true;
	}
	
	

	@Override
	public boolean validateStepResult(String stepResultObj, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject resStepResObj = new JSONObject(response.getBody().asString());
		JSONObject reqStepResObj = new JSONObject(stepResultObj);
		Assert.assertEquals(resStepResObj.get("id").toString(), reqStepResObj.get("id").toString(),
				"Stepresult id not validated.");
		Assert.assertEquals(resStepResObj.get("executionId").toString(), reqStepResObj.get("executionId").toString(),
				"Execution id not validated.");
		Assert.assertEquals(resStepResObj.get("stepId").toString(), reqStepResObj.get("stepId").toString(),
				"stepId not validated.");
		Assert.assertEquals(resStepResObj.get("issueId").toString(), reqStepResObj.get("issueId").toString(),
				"issueId not validated.");
		// Assert.assertEquals(resStepResObj.get("executedBy").toString(),
		// reqStepResObj.get("executedBy").toString(), "executedBy not validated.");

		if (reqStepResObj.has("comment")) {
			Assert.assertEquals(reqStepResObj.get("comment"), resStepResObj.get("comment"), "Not Matching comment.");
		}
		if (reqStepResObj.has("status")) {
			Assert.assertEquals(new JSONObject(reqStepResObj.get("status").toString()).get("id"),
					new JSONObject(resStepResObj.get("status").toString()).get("id"), "Not Matching Status Id.");
		}
		if (reqStepResObj.has("defects")) {
			// System.out.println(requestJson.get("defects").toString());
			JSONArray jsonArray1 = reqStepResObj.getJSONArray("defects");
			List<Long> srcList = CommonUtils.convertToList(jsonArray1);
			// System.out.println(executionJson.getJSONArray("defects").toString());
			JSONArray jsonArray2 = resStepResObj.getJSONArray("defects");
			List<Long> destList = CommonUtils.getDataListOfLongFromJsonArray(jsonArray2, "id");
			// System.out.println(destList);
			Assert.assertTrue(destList.containsAll(srcList), "Not same both defectlist.");

			// System.out.println("Defects are validated Successfully.");
		}
		return true;
	}

	@Override
	public boolean validateUpdatedStepResult(String stepResId, String stepResultObj, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject resStepResObj = new JSONObject(response.getBody().asString());
		JSONObject reqStepResObj = new JSONObject(stepResultObj);
		Assert.assertEquals(resStepResObj.get("id").toString(), reqStepResObj.get("id").toString(),
				"Stepresult id not validated.");
		Assert.assertEquals(resStepResObj.get("executionId").toString(), reqStepResObj.get("executionId").toString(),
				"Execution id not validated.");
		Assert.assertEquals(resStepResObj.get("stepId").toString(), reqStepResObj.get("stepId").toString(),
				"stepId not validated.");
		Assert.assertEquals(resStepResObj.get("issueId").toString(), reqStepResObj.get("issueId").toString(),
				"issueId not validated.");
		Assert.assertEquals(resStepResObj.get("executedBy").toString(), reqStepResObj.get("executedBy").toString(),
				"executedBy not validated.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getStepResults(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	@Override
	public Response getStepResults(JwtGenerator jwtGenerator, Long issueId, String executionId) {
		return stepresultsApi.getStepResults(jwtGenerator, issueId, executionId);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * getExecutionSummariesBySprintAndIssue(com.thed.zephyr.cloud.rest.client.
	 * JwtGenerator, java.lang.Long)
	 * 
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	@Override
	public Response getExecutionSummariesBySprintAndIssue(JwtGenerator jwtGenerator, Long sprintId,
			String issueIdorKeys) {
		return executionApi.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId, issueIdorKeys);
	}
	@Override
	public boolean validategetExecutionSummariesBySprintAndIssue( Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		return true;
	}
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateDeletedExecutionWithInvalidIsueId(java.lang.String,
	 * com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#updateStepResult(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.String,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	@Override
	public Response updateStepResult(JwtGenerator jwtGenerator, String stepResultId, String payLoad) {
		return stepresultsApi.updateStepResult(jwtGenerator, stepResultId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getStepDefectsByExecutionId(com.
	 * thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	@Override
	public Response getStepDefectsByExecutionId(JwtGenerator jwtGenerator, Long projectId, String executionId) {
		return stepresultsApi.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
	}

	@Override
	public boolean validateGetStepDefectsByExecutionId(Long projectId, String executionId, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getStepResultByStatus(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	@Override
	public Response getStepResultByStatus(JwtGenerator jwtGenerator, int statusId, int offset, int maxResults) {
		return stepresultsApi.getStepResultByStatus(jwtGenerator, statusId, offset, maxResults);
	}

	@Override
	public boolean validateGetStepResultByStatus(Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		return true;
	}

	@Override
	public Response exportTraceabilityReport(JwtGenerator jwtGenerator, String payLoad) {
		return traceabilityApi.exportTraceabilityReport(jwtGenerator, payLoad);
		// Response response1 =
		// traceabilityApi.exportTraceabilityReport(jwtGenerator, payLoad);
		// System.out.println(response1.getBody().asString());
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator, new
		// JSONObject(response1.getBody().asString()).get("jobProgressTicket").toString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// String fileName = new
		// JSONObject(response2.getBody().asString()).get("message").toString();
		// System.out.println(fileName);
		//
		//
		// return response2;
	}

	@Override
	public boolean downloadTraceabilityExportedFile(JwtGenerator jwtGenerator, String fileName) {
		try {
			Response responseOfDownloadApi = traceabilityApi.downloadExportedFile(jwtGenerator, fileName);
			InputStream inputStream = responseOfDownloadApi.getBody().asInputStream();
			try {
				String theString = IOUtils.toString(inputStream, "UTF-8");
				IOUtils.closeQuietly(inputStream);
				File file = new File(fileName);
				FileOutputStream fop = new FileOutputStream(file);
				file.createNewFile();
				fop.write(theString.getBytes());
				fop.flush();
				fop.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#reOrderExecutions(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	@Override
	public Response reOrderExecutions(JwtGenerator jwtGenerator, String payLoad) {
		return executionApi.reOrderExecutions(jwtGenerator, payLoad);
		// Response response1 = executionApi.reOrderExecutions(jwtGenerator,
		// payLoad);
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		// return response2;
	}

	@Override
	public Response toggleFavorite(JwtGenerator jwtGenerator, String filterId, String payLoad) {
		return zqlFilterApi.toggleFavorite(jwtGenerator, filterId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#copyFilter(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	@Override
	public Response copyFilter(JwtGenerator jwtGenerator, String payLoad) {
		return zqlFilterApi.copyFilter(jwtGenerator, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#updateFilter(com.thed.zephyr.cloud
	 * .rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	@Override
	public Response updateFilter(JwtGenerator jwtGenerator, String filterId, String payLoad) {
		return zqlFilterApi.updateFilter(jwtGenerator, filterId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#deleteFilter(com.thed.zephyr.cloud
	 * .rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	@Override
	public Response deleteFilter(JwtGenerator jwtGenerator, String filterId) {
		return zqlFilterApi.deleteFilter(jwtGenerator, filterId);
	}

	@Override
	public boolean validateDeleteZqlFilter(String zqlFilterId, Response response) {
		try {
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			JSONObject zqlfilterResponseJsonObj = new JSONObject(responseData);
			RestUtils.ValidateStatusIs200(response);

			Assert.assertTrue(
					zqlfilterResponseJsonObj.getString("message")
							.equals("zqlfilter " + zqlFilterId + " successfully deleted"),
					"Zql filter message is not validated.");
			Assert.assertNotNull(zqlfilterResponseJsonObj.get("timestamp").toString(),
					"Zql filter message is not validated.");
			System.out.println("ZQL Filter Deleted Response data validated successfully.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#generateRequirementTraceability(
	 * com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.Long,
	 * java.util.List)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response generateRequirementTraceability(JwtGenerator jwtGenerator, Long versionId,
			String requirementIdOrKeyList) {
		return traceabilityApi.generateRequirementTraceability(jwtGenerator, versionId, requirementIdOrKeyList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#generateDefectTraceability(com.
	 * thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.Long, java.util.List)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response generateDefectTraceability(JwtGenerator jwtGenerator, Long versionId, String defectIdList) {
		return traceabilityApi.generateDefectTraceability(jwtGenerator, versionId, defectIdList);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#searchExecutionsByDefect(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long, int,
	 * int)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response searchExecutionsByDefect(JwtGenerator jwtGenerator, Long versionId, Long defectId, int offset,
			int maxResult) {
		return traceabilityApi.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#searchExecutionsByTest(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long, int,
	 * int)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response searchExecutionsByTest(JwtGenerator jwtGenerator, Long versionId, Long testId, int offset,
			int maxResult) {
		return traceabilityApi.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getTestsCreated(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.Long, int, java.lang.String, int)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response getTestsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName) {
		return chartApi.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
	}

	@Override
	public boolean validateGetTestsCreated(String testsCount, Response response) {
		try {
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			JSONObject getTestsCreatedResponseJsonObj = new JSONObject(responseData);
			RestUtils.ValidateStatusIs200(response);
			System.out.println(getTestsCreatedResponseJsonObj);
			Assert.assertTrue(getTestsCreatedResponseJsonObj.get("TestsCreationCount").toString().equals(testsCount),
					"Total tests created not validated.");
			System.out.println("Total tests created Chart validated successfully.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getExecutionsCreated(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.Long, int, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response getExecutionsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious,
			String periodName) {
		return chartApi.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
	}

	@Override
	public boolean validateGetExecutionsCreated(String executionsCount, Response response) {
		try {
			int count = 0;
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			JSONObject getExecutionsCreatedResponseJsonObj = new JSONObject(responseData);
			RestUtils.ValidateStatusIs200(response);
			String s = getExecutionsCreatedResponseJsonObj.get("data").toString();
			// System.out.println("["+s+"]");
			JSONObject obj = new JSONObject(s);
			System.out.println(obj.length());
			// System.out.println(obj.keys());
			System.out.println(obj.keySet());
			Set<String> keySet = obj.keySet();
			for (Iterator<String> iterator = keySet.iterator(); iterator.hasNext();) {
				String string = (String) iterator.next();
				// System.out.println(string);
				JSONObject jsonObject = obj.getJSONObject(string);
				String executed = jsonObject.get("executed").toString();
				// System.out.println(Integer.parseInt(executed));
				count = count + Integer.parseInt(executed);
			}
			System.out.println(count);
			Assert.assertTrue(count == Integer.parseInt(executionsCount), "Total Executions created not validated.");
			System.out.println("Total tests created Chart validated successfully.");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getTestDistributionCount(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response getTestDistributionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId,
			String cycleId) {
		return jiraReportApi.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
	}

	@Override
	public boolean validateGetTestDistributionCount(JwtGenerator jwtGenerator, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject getExecutionsCountResponseJsonObj = new JSONObject(responseData);
		boolean flag = false;
		try {
			RestUtils.ValidateStatusIs200(response);
			String s = getExecutionsCountResponseJsonObj.get("data").toString();
			JSONObject obj = new JSONObject(s);
			Assert.assertNotNull(obj);
			// System.out.println(obj.length());
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#getTopDefects(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long, int, int)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response getTopDefects(JwtGenerator jwtGenerator, Long projectId, Long versionId, int issueStatuses,
			int howMany) {
		return jiraReportApi.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
	}

	@Override
	public boolean validateGetTopDefects(JwtGenerator jwtGenerator, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject getExecutionsCountResponseJsonObj = new JSONObject(responseData);
		boolean flag = false;
		try {
			RestUtils.ValidateStatusIs200(response);
			String s = getExecutionsCountResponseJsonObj.get("data").toString();
			JSONArray obj = new JSONArray(s);
			Assert.assertNotNull(obj);
			System.out.println(obj.length());
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getExecutionCount(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long,
	 * java.lang.String)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response getExecutionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String groupFld) {
		return jiraReportApi.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
	}

	@Override
	public boolean validateGetExecutionCount(JwtGenerator jwtGenerator, String groupFld, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject getExecutionsCountResponseJsonObj = new JSONObject(responseData);
		boolean flag = false;
		try {
			RestUtils.ValidateStatusIs200(response);
			String grpFId = getExecutionsCountResponseJsonObj.get("groupFld").toString();
			Assert.assertEquals(grpFId, groupFld, "Group Fid is not same.");
			String s = getExecutionsCountResponseJsonObj.get("data").toString();
			JSONArray obj = new JSONArray(s);
			Assert.assertNotNull(obj);
			System.out.println(obj.length());
			flag = true;
		} catch (Exception e) {
			flag = false;
		}
		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#updateExecution(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response updateExecution(JwtGenerator jwtGenerator, String executionId, String payLoad) {
		return executionApi.updateExecution(jwtGenerator, executionId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#moveCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response moveCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad) {
		// TODO Auto-generated method stub
		return cycleApi.moveCycle(jwtGenerator, cycleId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#cloneCycle(com.thed.zephyr.cloud.
	 * rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	@Override
	public Response cloneCycle(JwtGenerator jwtGenerator, String clonedCycleId, String payLoad) {
		return cycleApi.cloneCycle(jwtGenerator, clonedCycleId, payLoad);
	}

	@Override
	public Response cloneFolder(JwtGenerator jwtGenerator, String clonedCycleId, String clonedFolderId,
			String payLoad) {
		return cycleApi.cloneCycle(jwtGenerator, clonedCycleId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#addTestsTocycle(com.thed.zephyr.
	 * cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	@Override
	public Response addTestsTocycle(JwtGenerator jwtGenerator, String cycleId, String payLoad) {
		// Response response1 = executionApi.addTestsTocycle(jwtGenerator,
		// cycleId, payLoad);
		//
		// System.out.println(response1.getBody().asString());
		// Response response2 = null;
		// do {
		// response2 = jobProgressApi.getJobProgress(jwtGenerator,
		// response1.getBody().asString());
		// System.out.println(response2.getBody().asString());
		// } while (new
		// JSONObject(response2.getBody().asString()).get("progress").toString()
		// != null && !(new
		// JSONObject(response2.getBody().asString()).get("progress").toString().equals("1.0")));
		return executionApi.addTestsTocycle(jwtGenerator, cycleId, payLoad);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#getExecutionsByZQL(com.thed.zephyr
	 * .cloud.rest.client.JwtGenerator, java.lang.Long, java.lang.Long,
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	@Override
	public Response getExecutionsByZQL(JwtGenerator jwtGenerator, String executionId, String payLoad) {
		return executionApi.getExecutionsByZQL(jwtGenerator, executionId, payLoad);
	}

	@Override
	public boolean validateDeleteTeststep(Response response, Long projectId, Long issueId, String teststepId) {

		String responseData = response.getBody().asString();
		System.err.println("checking response");
		System.out.println(response.getStatusLine());
		System.err.println(responseData);
		if (responseData == null || responseData == "" || responseData.contains("error")) {

			if (projectId == null) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(
						new JSONObject(responseData).get("error").toString().equals("Missing parameter: projectId"));
			} else if (issueId == null) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(new JSONObject(responseData).get("error").toString()
						.contains("Cannot parse parameter issueId"));
			} /*
				 * 
				 * 
				 * else if (issueId == "") { RestUtils.validateStatusIs400(response);//giving
				 * blank response //Assert.assertTrue(new
				 * JSONObject(responseData).toString().equals(""));
				 * 
				 * }
				 */
			else if (teststepId == null) {
				// Temporary implementation,this change in future
				// need to validate change the data once it message is giving
				// data 400 error
				RestUtils.ValidateStatusIs200(response);
				// Assert.assertTrue(new
				// JSONObject(responseData).get("errorType").toString().equals("ERROR"));
				// Assert.assertTrue(new
				// JSONObject(responseData).get("clientMessage").toString().contains("invalid
				// or not belong to projectId"));
			} else if (teststepId.equals("")) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(new JSONObject(responseData).get("error").toString().equals("API not found."));
			} else {
				// RestUtils.validateStatusIs400(response);
				System.out.println(responseData);
				System.out.println("response" + response.getStatusCode());
				// Assert.assertTrue(new
				// JSONObject(responseData).get("error").toString().contains("Missing
				// parameter"));
			}

		} else {
			System.out.println(responseData);
			System.out.println("response" + response.getStatusCode());
			// RestUtils.ValidateStatusIs200(response);
		}

		return true;
	}

	@Override
	public boolean validateAttemptToDeleteTeststep(Response response, Long projectId, Long issueId) {

		String responseData = response.getBody().asString();
		System.err.println("checking response");
		System.out.println(response.getStatusLine());
		System.err.println(responseData);
		if (responseData == null || responseData == "" || responseData.contains("error")) {

			if (projectId == null) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(
						new JSONObject(responseData).get("error").toString().equals("Missing parameter: projectId"));
			} else if (issueId == null) {
				RestUtils.validateStatusIs400(response);
				Assert.assertTrue(new JSONObject(responseData).get("error").toString()
						.contains("Cannot parse parameter issueId"));
			} /*
				 * 
				 * 
				 * else if (issueId == "") { RestUtils.validateStatusIs400(response);//giving
				 * blank response //Assert.assertTrue(new
				 * JSONObject(responseData).toString().equals(""));
				 * 
				 * }
				 */
			else {
				// RestUtils.validateStatusIs400(response);
				System.out.println(responseData);
				System.out.println("response" + response.getStatusCode());
				// Assert.assertTrue(new
				// JSONObject(responseData).get("error").toString().contains("Missing
				// parameter"));
			}

		} else {
			System.out.println(responseData);
			System.out.println("response" + response.getStatusCode());
			// RestUtils.ValidateStatusIs200(response);
		}

		return true;

		// System.err.println(response.getBody().asString());
		// RestUtils.ValidateStatusIs200(response);
		// return true;
	}

	@Override
	public boolean validateMoveStep(JSONObject srcStep, JSONObject destStep, String payLoad, Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		JSONArray jsarray = new JSONArray(responseData);

		String sourceStepId = srcStep.get("id").toString();
		int sourceOrderIdAfterMove = 0;

		Iterator<String> itr = new JSONObject(payLoad).keys();
		String ss = itr.next();
		if (ss.equals("after")) {
			String destStepId = destStep.get("id").toString();
			int destOrderIdBeforeMove = (int) destStep.get("orderId");
			int destOrderIdAfterMove = 0;

			for (int i = 0; i < jsarray.length(); i++) {
				Assert.assertNotNull(jsarray.getJSONObject(i).getString("id"), "Teststep " + i + " StepId is null.");
				Assert.assertNotNull(jsarray.getJSONObject(i).get("orderId"), "Teststep " + i + " OrderId is null.");
				String s = jsarray.getJSONObject(i).getString("id");
				if (s.equals(sourceStepId)) {
					sourceOrderIdAfterMove = new JSONArray(response.getBody().asString()).getJSONObject(i)
							.getInt("orderId");
					if (srcStep.has("step")) {
						Assert.assertEquals(srcStep.get("step").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("step").toString(),
								"source step data is not same");
					}
					if (srcStep.has("data")) {
						Assert.assertEquals(srcStep.get("data").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("data").toString(),
								"source test data is not same");
					}
					if (srcStep.has("result")) {
						Assert.assertEquals(srcStep.get("result").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("result").toString(),
								"source expected result is not same");
					}
				} else if (s.equals(destStepId)) {
					destOrderIdAfterMove = new JSONArray(response.getBody().asString()).getJSONObject(i)
							.getInt("orderId");
					if (destStep.has("step")) {
						Assert.assertEquals(destStep.get("step").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("step").toString(),
								"destination step data is not same");
					}
					if (destStep.has("data")) {
						Assert.assertEquals(destStep.get("data").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("data").toString(),
								"destination test data is not same");
					}
					if (destStep.has("result")) {
						Assert.assertEquals(destStep.get("result").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("result").toString(),
								"destination expected result is not same");
					}
					Assert.assertEquals(destStepId, s, "step id of the moved step is not as expected");
				}
			}
			/*Assert.assertEquals(sourceOrderIdAfterMove, destOrderIdBeforeMove,
					"Order id of the moved step is not as expected");
			Assert.assertEquals(destOrderIdAfterMove, (destOrderIdBeforeMove + 1), "");*/
		} else {
			for (int i = 0; i < jsarray.length(); i++) {
				Assert.assertNotNull(jsarray.getJSONObject(i).getString("id"), "Teststep " + i + " StepId is null.");
				Assert.assertNotNull(jsarray.getJSONObject(i).get("orderId"), "Teststep " + i + " OrderId is null.");
				String s = jsarray.getJSONObject(i).getString("id");
				if (s.equals(sourceStepId)) {
					sourceOrderIdAfterMove = new JSONArray(response.getBody().asString()).getJSONObject(i)
							.getInt("orderId");
					if (srcStep.has("step")) {
						Assert.assertEquals(srcStep.get("step").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("step").toString(),
								"source step data is not same");
					}
					if (srcStep.has("data")) {
						Assert.assertEquals(srcStep.get("data").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("data").toString(),
								"source test data is not same");
					}
					if (srcStep.has("result")) {
						Assert.assertEquals(srcStep.get("result").toString(),
								new JSONArray(response.getBody().asString()).getJSONObject(i).get("result").toString(),
								"source expected result is not same");
					}
				}
			}
			Assert.assertEquals(sourceOrderIdAfterMove, jsarray.length(),
					"Order id of the moved step is not as expected");
		}

		// System.out.println("After move, Step id's are: " + stepId);
		System.out.println("Response data validated successfully.");
		return true;

	}

	@Override
	public boolean validateCreatedExecutionInvalidCycleId(String executionJson, Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");

		String error = "Cycle " + new JSONObject(executionJson).get("cycleId").toString()
				+ " invalid or not belong to projectId " + new JSONObject(executionJson).get("projectId").toString()
				+ " and versionId " + new JSONObject(executionJson).get("versionId").toString() + ".";
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString().contains(error),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#validateUpdatedExecution(java.lang
	 * .String, com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateUpdatedExecution(String reqPayLoad, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
		Assert.assertTrue(new JSONObject(responseData).get("warningMessage").toString().equals("null"),
				"warningMessage is null.");
		Assert.assertTrue(new JSONObject(responseData).get("originMessage").toString().equals("null"),
				"originMessage is null.");
		Assert.assertNotNull(new JSONObject(responseData).get("execution").toString(), "Updated cycle id is null.");

		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateExportTraceabilityReport(
	 * java.lang.String, java.lang.String)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateExportTraceabilityReport(String response, String exportType) {
		if ((!(exportType.equalsIgnoreCase("html"))) && (!(exportType.equalsIgnoreCase("excel")))) {
			Assert.assertTrue(new JSONObject(response).get("clientMessage").toString()
					.contains("Traceability exportType invalid. It should be HTML/EXCEL"), "Error Code is null");
		}
		// TODO
		// Add validations
		else if (exportType.equalsIgnoreCase("html")) {
			Assert.assertTrue(response.contains(".html"), "Exported file is not valid");
			// RestUtils.ValidateStatusIs200(response);
		} else if (exportType.equalsIgnoreCase("excel")) {
			Assert.assertTrue(response.contains(".xls"), "Exported file is not valid");
			// RestUtils.ValidateStatusIs200(response);
		}
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#validateAddTestsToCycle(java.lang.
	 * String, com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateAddTestsToCycle(String reqPayLoad, Response response) {

		RestUtils.ValidateStatusIs200(response);

		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println("Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateAddTestsToCycleInvalidCycleId(java.lang.String,
	 * com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateAddTestsToCycleInvalidCycleId(String executionJson, Response response) {
		RestUtils.validateStatusIs400(response);
		
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		// Assert.assertTrue(new
		// JSONObject(responseData).get("clientMessage").toString()
		// .contains("Cycle null invalid or not belong to projectId"), "Error Code is
		// null");
		
		NumberFormat myFormat = NumberFormat.getInstance();
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		String pId = myFormat.format(projectId);
		String vId = myFormat.format(versionId);
		
		
 String newString = responseJsonObject.getString("clientMessage");
 String cycleIdString =  newString.substring(6, 42);
 System.out.println("****************"+ cycleIdString);
 System.out.println("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId " +pId+ " and versionId " +vId+ "");
 
// System.out.println("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId 10,003 and versionId 10,011.", "\"errorCode\":121");
	Assert.assertTrue (responseJsonObject.get("clientMessage").toString().contains("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId 10,003 and versionId 10,006")
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId " +pId+ " and versionId " +vId)
//	|| responseJsonObject.get("clientMessage").toString().contains("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId" +projectId+ "and versionId 10,006")
   ||responseJsonObject.get("clientMessage").toString().contains("Cycle null invalid or not belong to projectId")
	|| responseJsonObject.get("clientMessage").toString().contains("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId 10,003 and versionId 10,011"),
				"\"errorCode\":121");

		System.out.println("Response data validated successfully.");
		return true;
	}
	
	
	
	
	
	@Override
	public boolean validateAddTestsToCycleInvalidIssueIdAndVersionId(String executionJson, Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		
		NumberFormat myFormat = NumberFormat.getInstance();
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		String pId = myFormat.format(projectId);
		String vId = myFormat.format(versionId);

// System.out.println("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId 10,003 and versionId 10,011.", "\"errorCode\":121");
	Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("Issue null invalid or not belong to projectId")
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid or does not belong to the projectId 10,003 and versionId 10,014.")
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid or does not belong to the projectId 10,003 and versionId 10,006.")
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid or does not belong to the projectId " +pId+ " and versionId " +vId)
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle 111 is invalid or does not belong to the projectId 10,003 and versionId 10,014.")
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle 111 is invalid or does not belong to the projectId 10,003 and versionId 10,006.")
			|| responseJsonObject.get("clientMessage").toString().contains("Cycle 111 is invalid or does not belong to the projectId " +pId+ " and versionId " +vId)
			|| responseJsonObject.get("clientMessage").toString().contains("versionId field value is null or 0 is not valid.")
			|| responseJsonObject.get("clientMessage").toString().contains("versionId field value is null or 0 is not valid.")
			|| responseJsonObject.get("clientMessage").toString().contains("projectId field value is null or 111 is not valid"),
			"\"errorCode\":121");
	//|| responseJsonObject.get("clientMessage").toString().contains("Cycle "+ cycleIdString+" is invalid or does not belong to the projectId 10,003 and versionId 10,011"),
			//	"\"errorCode\":121");
		

		System.out.println("Response data validated successfully.");
		return true;
	}
	
	
	

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateAddTestsToCycleBlankCycleId(java.lang.String,
	 * com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateAddTestsToCycleBlankCycleId(String executionJson, Response response) {

		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		
		NumberFormat myFormat = NumberFormat.getInstance();
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		String pId = myFormat.format(projectId);
		String vId = myFormat.format(versionId);
		
	//	Assert.assertTrue(new JSONObject(responseJsonObject).get("error").toString().equals("API not found.")		
		Assert.assertTrue (responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid or does not belong to the projectId 10,003 and versionId 10,014")
				|| responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid or does not belong to the projectId 10,003 and versionId 10,006.")
				|| responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid or does not belong to the projectId " +pId+ " and versionId " +vId)
				,"errortype is not ERROR.");
	//	"\"errorCode\":121");
		System.out.println("Response data validated successfully.");
		System.out.println("Tests not added due to blank string passed in cycleId");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateAddTestsToCycleInvalidId(
	 * java.lang.String, com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateAddTestsToCycleInvalidId(String executionJson, Response response) {
		RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		System.out.println("Tessts not added due invalid id");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateAddedAttachmentInvalidValues(com.jayway.restassured.response.
	 * Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateAddedAttachmentInvalidValues(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		System.out.println("Attachment not created due to invalid parameter");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateGetAttachmentThumbanail(
	 * com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateGetAttachmentThumbanail(Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println("Get Attachment Thumbnail Response data validated successfully.");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#validateSearchExecutionsByTest(com
	 * .jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateSearchExecutionsByTest(Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println("Execution by Tests fetched successfully");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateSearchExecutionsByTestInvalidIssueId(com.jayway.restassured.
	 * response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateSearchExecutionsByTestInvalidIssueId(Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("issueId field value is null"),
				"Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Invalid issue id");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#validateSearchExecutionsByDefect(
	 * com.jayway.restassured.response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateSearchExecutionsByDefect(Response response) {
		RestUtils.ValidateStatusIs200(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		System.out.println("Execution by Tests fetched successfully");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateSearchExecutionsByDefectInvalidIssueId(com.jayway.restassured.
	 * response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateSearchExecutionsByDefectInvalidIssueId(Response response) {
		// TODO Auto-generated method stub
		return false;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.thed.zephyr.service.ZAPIApiService#
	 * validateDeletedAttachmentInvalidAttachmentId(com.jayway.restassured.
	 * response.Response)
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@Override
	public boolean validateDeletedAttachmentInvalidAttachmentId(Response response) {

		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		Assert.assertTrue(new JSONObject(responseData).get("clientMessage").toString()
				.contains("attachmentId field value is null"), "Error Code is null");
		System.out.println("Response data validated successfully.");
		System.out.println("Invalid issue id");
		return true;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#pingJob(com.thed.zephyr.cloud.rest
	 * .client.JwtGenerator)
	 * 
	 * @author Created by manoj.behera on 08-Dec-2016.
	 */
	@Override
	public Response pingJob(JwtGenerator jwtGenerator) {
		// TODO Auto-generated method stub
		return zqlFilterApi.pingJob(jwtGenerator);
	}

	@Override
	public boolean validateMismatchOfProjectIdAndIssueId(Long projectId, Long issueId, Response response) {
		try {
			RestUtils.validateStatusIs400(response);
			String responseData = response.getBody().asString();
			System.out.println("Response--:" + responseData);
			NumberFormat nf1 = NumberFormat.getInstance();
			String issueId1 = nf1.format(issueId);
			String projectId1 = nf1.format(projectId);
			Assert.assertEquals(new JSONObject(responseData).get("errorType").toString(), "ERROR",
					"error type is not error.");
			Assert.assertEquals(new JSONObject(responseData).get("clientMessage").toString(),
					"Issue " + issueId1 + " does not belong to the project " + projectId1 + ".",
					"Client message is wrong");
		} catch (Exception e) {
			return false;
		}
		return true;
	}

	@Override
	public Response getListOfCyclesBySprint(JwtGenerator jwtGenerator, String payLoad) {
		return cycleApi.getListOfCyclesBySprint(jwtGenerator, payLoad);
	}

	@Override
	public Response createFolderCycle(JwtGenerator jwtGenerator, String payLoad) {
		// TODO Auto-generated method stub
		return folderApi.createfolder(jwtGenerator, payLoad);
	}

	@Override
	public Response GetFolderbyid(JwtGenerator jwtGenerator, String payLoad, String folderid) {
		// TODO Auto-generated method stub
		return folderApi.Getfolderbyid(jwtGenerator, payLoad, folderid);
	}

	/*
	 * Execution workflow (non-Javadoc)
	 * 
	 * @see
	 * com.thed.zephyr.service.ZAPIApiService#Executionworflow_Inprogress(com.thed.
	 * zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 */

	@Override
	public Response Executionworflow_Inprogress(JwtGenerator jwtGenerator, String Executionid, String Issueid) {
		// TODO Auto-generated method stub
		return executionworkflowApi.Executionworflow_inprogress(jwtGenerator, Executionid, Issueid);
	}

	@Override
	public Response Executionworflow_Done(JwtGenerator jwtGenerator, String action, String timeLogged,
			String Executionid, String Issueid) {
		// TODO Auto-generated method stub
		return executionworkflowApi.Executionworflow_Done(jwtGenerator, action, timeLogged, Executionid, Issueid);
	}

	@Override
	public Response Executionworflow_Reopen(JwtGenerator jwtGenerator, String Executionid, String Issueid) {
		// TODO Auto-generated method stub
		return executionworkflowApi.Executionworflow_Reopen(jwtGenerator, Executionid, Issueid);
	}

	@Override
	public Response Executionworflow_Modifytime(JwtGenerator jwtGenerator, String action, String timeLogged,
			String Executionid, String Issueid) {
		// TODO Auto-generated method stub
		return executionworkflowApi.Executionworflow_Modifytime(jwtGenerator, action, timeLogged, Executionid, Issueid);
	}

	@Override
	public boolean DeleteFolderId(Long projectId, Long versionId, Long cycleid, Response response) {
		// TODO Auto-generated method stub
		return false;

	}

	@Override
	public Response DeleteFolderId(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long cycleid,
			long folderId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Response clonedFolder(JwtGenerator jwtGenerator, String cycleId, String string) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean validateCreateTestStepInvalidIsueId(Long projectId, Long issueId, String reqPayLoad,
			Response response, String stepid) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean validateZQLFilters(String reqPayLoad, Response response) {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public boolean validateMoveInvalidExecutionsToCycle(Response response) {
		
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("Null or invalid Executions.")
				||
	new JSONObject(responseData).get("clientMessage").toString().contains("Null or invalid Executions."),
				"Error Code not complete");
		
		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}
	@Override
	public boolean validateCopyInvalidExecutionsToCycle(Response response) {
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("Null or invalid Executions.")
				||
	new JSONObject(responseData).get("clientMessage").toString().contains("Null or invalid Executions."),
				"Error Code not complete");
		
		if (new JSONObject(responseData).get("clientMessage").toString().
				 contains("field is required")) { RestUtils.validateStatusIs400(response);
		System.out.println("Response data validated successfully.");
		
	}
		return true;
	}
	@Override
	public boolean validategetinvalidExecutionSummariesBySprintAndIssue(Response response) {
		// TODO Auto-generated method stub
		RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		JSONObject responseJsonObject = new JSONObject(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
				Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.equals("Cannot parse parameter sprintId as Long: For input string: \"null\""));
				System.out.println("Response data validated successfully.");
		return true;
	}
	
	@Override
	public boolean validateFolder(String reqPayLoad, Response response) {
		// TODO Auto-generated method stub
		//Need to implement validation
				
		
			String responseData = response.getBody().asString();
			System.out.println(responseData);
			JSONObject requestJsonObject = new JSONObject(reqPayLoad);
			JSONObject responseJsonObject = new JSONObject(responseData);

			if (!requestJsonObject.has("projectId")) {
				System.out.println("Project id is not passed.");
				RestUtils.validateStatusIs400(response);
				Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
						"versionId error type is not error.");
				Assert.assertTrue(responseJsonObject.get("clientMessage").toString().equals("projectId field is required.")
						|| responseJsonObject.get("clientMessage").toString().equals("Missing parameter: projectId"),
						"projectId field is required.");
			} 
	 else if (!requestJsonObject.has("versionId")) {
		System.out.println("Version id is not passed.");
		RestUtils.validateStatusIs500(response);
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR",
				"versionId error type is not error.");
		
		//Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("versionId field value is null or" +versionId+ "is not valid."));

	}
			 else if (!requestJsonObject.has("cycleId")) {
					System.out.println("Cycle id is not passed");
					RestUtils.validateStatusIs400(response);
					Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR","cycleId error type is not error.");
					Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("Cycle null is invalid"));

				}
	 else if (requestJsonObject.getString("cycleId").isEmpty()) {
			System.out.println("Cycle id is empty or invalid");
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR","cycleId error type is not error.");
			Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("Cycle  is invalid"));

		}	
			
	 else if (requestJsonObject.getString("cycleId").equals("-1")) {
			System.out.println("Folder creation under ad hoc cycle is not allowed");
			RestUtils.validateStatusIs400(response);
			Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR","cycleId error type is not error.");
			Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("Folder creation under ad hoc cycle is not allowed"));

		}	
	 else if (!requestJsonObject.has("name")) {
		 System.out.println("folder name is not passed");
		RestUtils.validateStatusIs400(response);
		
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR");
		
		Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("name field is required."));
	
	} 
	 else if ( requestJsonObject.getString("name").isEmpty()) {
		 System.out.println("folder name is empty");
		RestUtils.validateStatusIs400(response);
		
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR");
		
		Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("name field value is required or cannot be null."));
	
	} 	
	 				
	 else if ( requestJsonObject.getString("name").equals("createSameFolder")) {
		 /*System.out.println("Folder name - createFolder1562742772373 should be unique");
		RestUtils.validateStatusIs400(response);
		Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR");	*/
		 
		 int getStatusCode = response.getStatusCode();
		 
		 if (getStatusCode == 400){
			 
			 RestUtils.validateStatusIs400(response);
			 Assert.assertEquals(responseJsonObject.get("errorType").toString(), "ERROR");
			 Assert.assertTrue(responseJsonObject.get("clientMessage").toString().contains("Folder name - createSameFolder should be unique"));
			 
		 }
		 
		 else{
			 return true;
			
		 } 
		 
	} 	
			
	 else {
		 RestUtils.ValidateStatusIs200(response);
	 }
			System.out.println("Folder API Response data validated successfully.");
		return true;
	}
   @Override
	public Response updateExecutionCustomfield(JwtGenerator jwtGenerator, String executionId, String payLoad) {
		// TODO Auto-generated method stub
		return executionApi.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	}

	@Override
	public boolean validateupdateExecutionCustomfield(String payLoad, Response response) {
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		RestUtils.ValidateStatusIs200(response);
	    System.out.println("Response data validated successfully.");
		return true;
	}
    @Override
	public boolean validateinvalidExecutionCustomfield(Response response,String executionId) {
       RestUtils.validateStatusIs400(response);
		String responseData = response.getBody().asString();
		System.out.println(responseData);
		Assert.assertTrue(new JSONObject(responseData).get("errorType").toString().equals("ERROR"),
				"errortype is not ERROR.");
		//new JSONObject(responseData).get("clientMessage").toString().contains("executionId field value is null or " +executionId+ " is not valid."));
		/*Assert.assertTrue(responseJsonObject.get("clientMessage").toString()
				.equals("a  is an invalid number"));*/
		Assert.assertTrue(
				new JSONObject(responseData).get("clientMessage").toString().contains("a  is an invalid number")
				||
	new JSONObject(responseData).get("clientMessage").toString().contains("executionId field value is null or 0092b928-4007-1234 is not valid.")
	|| new JSONObject(responseData).get("clientMessage").toString().contains("2019/02/30 Invalid date format. Please enter the date in the format MM/dd/yyyy"),
				"Error Code not complete");
		return true;
	}
}
