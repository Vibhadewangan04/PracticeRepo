package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

public class ToggleFavorite extends BaseTest {
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * ZQLFilter Api toggleFavorite 1.create a favorite filter and toggle the
	 * Favorite
	 * 
	 */
	@Test(priority = 1)
	public void Test1_toggleFavorite_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = "0001480405246259-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480405246259-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 2.create a non favorite filter and toggle
	 * the Favorite
	 * 
	 */
	@Test(priority = 2)
	public void Test2_toggleFavorite_non_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter \",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"private\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = "0001480405374886-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480405374886-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 3.create a favorite and shared permission
	 * global filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 3)
	public void Test3_toggleFavorite_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\" fav global\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = "0001480405462966-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480405462966-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 4.create a non favorite and shared
	 * permission global filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 4)
	public void Test4_toggleFavorite_non_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav global\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = "0001480405691432-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480405691432-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 5.create a favorite and shared permission
	 * private filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 5)
	public void Test5_toggleFavorite_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav private\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"private\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = "0001480405546162-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480405546162-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 6.create a non favorite and shared
	 * permission private filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 6)
	public void Test6_toggleFavorite_non_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav private\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = "0001480405779614-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480405779614-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Attempt cases

	/**
	 * ZQLFilter Api toggleFavorite 7.Attempt to toggle the Favorite when
	 * favorite filter is deleted
	 * 
	 */
	@Test(priority = 7)
	public void Test7_Attempt_toggleFavorite_deleted_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\" delete fav\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Delete filter code
		String filterId = "0001480407903327-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480407903327-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 8.Attempt to toggle the Favorite when non
	 * favorite filter is deleted
	 * 
	 */
	@Test(priority = 8)
	public void Test8_Attempt_toggleFavorite_deleted_non_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"delete non fav\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"private\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Delete filter code
		String filterId = "0001480407914034-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480407914034-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 9.Attempt to toggle the Favorite when
	 * favorite and shared permission global filter is deleted
	 * 
	 */
	@Test(priority = 9)
	public void Test9_Attempt_toggleFavorite_deleted_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"delete fav global\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Delete filter code
		String filterId = "0001480407942872-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480407942872-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 10.Attempt to toggle the Favorite when non
	 * favorite and shared permission global filter is deleted
	 */
	@Test(priority = 10)
	public void Test10_Attempt_toggleFavorite_deleted_non_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"delete non fav global\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Delete filter code
		String filterId = "0001480407960932-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480407960932-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 11.Attempt to toggle the Favorite when
	 * favorite and shared permission private filter is deleted
	 * 
	 */
	@Test(priority = 11)
	public void Test11_Attempt_toggleFavorite_deleted_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"delete fav private\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"private\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Delete filter code
		String filterId = "0001480407999422-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480407999422-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 12.Attempt to toggle the Favorite when non
	 * favorite and shared permission private filter is deleted
	 * 
	 */
	@Test(priority = 12)
	public void Test12_Attempt_toggleFavorite_deleted_non_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"delete non fav private\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Delete filter code
		String filterId = "0001480408051219-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480408051219-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 13.Attempt to toggle the Favorite with
	 * invalid filter id
	 * 
	 */
	@Test(priority = 13)
	public void Test13_Attempt_toggleFavorite_invalid_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"invalid \",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// pass invalid filter id in below
		String filterId = "0001480328443893-242ac1122-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480328443893-242ac1122-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 14.Attempt to toggle the Favorite with
	 * invalid filter is null or blank
	 * 
	 */
	@Test(priority = 14)
	public void Test14_Attempt_toggleFavorite_invalid_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"null\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		String filterId = null;
		// "0001480328443893-242ac1122-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"\"}";// 0001480328443893-242ac1122-0001

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 15.Update a favorite filter and toggle the
	 * Favorite
	 * 
	 */
	@Test(priority = 15)
	public void Test15_toggleFavorite_updated_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// update filter code
		String filterId = "0001480407076662-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480407076662-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 16.update a non favorite filter and toggle
	 * the Favorite
	 * 
	 */
	@Test(priority = 16)
	public void Test16_toggleFavorite_updated_non_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"private\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// update filter code
		String filterId = "0001480407028552-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480407028552-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 17.update a favorite and shared permission
	 * global filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 17)
	public void Test17_toggleFavorite_updated_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter global\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// update filter code
		String filterId = "0001480407088937-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480407088937-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 18.update a non favorite and shared
	 * permission global filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 18)
	public void Test18_toggleFavorite_updated_non_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter global\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// update filter code
		String filterId = "0001480407046124-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480407046124-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 19.update a favorite and shared permission
	 * private filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 19)
	public void Test19_toggleFavorite_updated_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter private\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// update filter code
		String filterId = "0001480407103634-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480407103634-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 20.update a non favorite and shared
	 * permission private filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 20)
	public void Test20_toggleFavorite_updated_non_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter private\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// update filter code
		String filterId = "0001480407058967-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480407058967-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 21.copy a favorite filter and toggle the
	 * Favorite
	 * 
	 */
	@Test(priority = 21)
	public void Test21_toggleFavorite_Copied_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Copy filter code
		String filterId = "0001480406180705-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480406180705-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 22.copy a non favorite filter and toggle the
	 * Favorite
	 * 
	 */
	@Test(priority = 22)
	public void Test22_toggleFavorite_Copied_non_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"private\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Copy filter code
		String filterId = "0001480406031612-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480406031612-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 23.copy a favorite and shared permission
	 * global filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 23)
	public void Test23_toggleFavorite_Copied_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter global\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Copy filter code
		String filterId = "0001480406243258-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480406243258-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 24.copy a non favorite and shared permission
	 * global filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 24)
	public void Test24_toggleFavorite_Copied_non_fav_filter_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter global\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Copy filter code
		String filterId = "0001480406046696-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480406046696-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 25.copy a favorite and shared permission
	 * private filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 25)
	public void Test25_toggleFavorite_Copied_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"fav filter private\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Copy filter code
		String filterId = "0001480406249275-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":false,\"id\":\"0001480406249275-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api toggleFavorite 26.Copy a non favorite and shared permission
	 * private filter and toggle the Favorite
	 * 
	 */
	@Test(priority = 26)
	public void Test26_toggleFavorite_Copied_non_fav_filter_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"non fav filter private\",\"description\":\"\",\"favorite\":false,\"sharePerm\":\"global\"}"
		 * ; System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, payLoad);
		 */
		// new JSONObject(response.getBody().asString()).get("id").toString();
		// Copy filter code

		String filterId = "0001480406054920-242ac1123-0001";
		String TogglepayLoad = "{\"favorite\":true,\"id\":\"0001480406054920-242ac1123-0001\"}";

		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, TogglepayLoad);
		Assert.assertNotNull(response, "Toggle Favourite  Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Favourite Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
