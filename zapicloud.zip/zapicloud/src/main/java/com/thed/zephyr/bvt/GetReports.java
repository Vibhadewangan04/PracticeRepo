/**
 * Created by manoj.behera on 07-Dec-2016.
 */
package com.thed.zephyr.bvt;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 07-Dec-2016
 *
 */
public class GetReports extends BaseTest {
	@Test(priority = 1, enabled = testEnabled)
	public void getExecutionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String groupFld = "cycle";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions Count Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean flag = zapiService.validateGetExecutionCount(jwtGenerator, groupFld, response);
		Assert.assertTrue(flag, "Response not validated.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2, enabled = testEnabled)
	public void getTopDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int issueStatuses = 10000;
		int howMany = 10;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Top Defects Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean flag = zapiService.validateGetTopDefects(jwtGenerator, response);
		Assert.assertTrue(flag, "Response not validated.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 3, enabled = testEnabled)
	public void getTestDistributionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String cycleId = "-1";
		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Test Distribution Count Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean flag = zapiService.validateGetTestDistributionCount(jwtGenerator, response);
		Assert.assertTrue(flag, "Response not validated.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
