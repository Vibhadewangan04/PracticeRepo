/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
public interface ProjectApi {

	/**
	 * @param basicAuth
	 * @param recent
	 * @return
	 * @author Created by manoj.behera on 03-Dec-2016.
	 */
	Response getProjects(RequestSpecification basicAuth, String recent);

	/**
	 * @param basicAuth
	 * @param projectIdOrKey
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getProjectVersions(RequestSpecification basicAuth, String projectIdOrKey);

	/**
	 * @param basicAuth
	 * @param projectIdOrKey
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getProjectComponents(RequestSpecification basicAuth, String projectIdOrKey);

	/**
	 * @param basicAuth
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getAllProjects(RequestSpecification basicAuth);

	/**
	 * @param basicAuth
	 * @return
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	Response getAllProjectTypes(RequestSpecification basicAuth);

}
