/**
 *
 */
package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class SearchApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	JwtGenerator jwtGeneratorForUser = null;
	String zql = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
		jwtGeneratorForUser = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("userAccessKey"),
				Config.getValue("userSecretKey"), Config.getValue("userUsername"));
	}

	//	search zql filters, without passing any parameter
	@Test(priority = 1)
	public void test1_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		//zqlFilter.setName("hp");
		//		zqlFilter.setOwner(Config.getValue("accountId"));
		//zqlFilter.setSharePerm("global");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	
		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");
		//zqlfilterSearch.setZql("project ="+Config.getValue("projectKey"));		
		//zqlfilterSearch.setName(createFilterName);
		//zqlfilterSearch.setFavorite(false);
		//zqlfilterSearch.setSharePerm("global");		
		//zqlfilterSearch.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
		
	}

	//	search zql filters, by passing only filterName
	@Test(priority = 2)
	public void test2_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	
		
		Zqlfilter beforezqlfilterSearch = new Zqlfilter("search filter");
		beforezqlfilterSearch.setName("search");	
		System.out.println("zqlfilterJson: " + beforezqlfilterSearch.toString() );
		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, beforezqlfilterSearch.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = "+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	
		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");	
		zqlfilterSearch.setName("search");
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters, by passing only ownerName of zqlilter
	@Test(priority = 3)
	public void test3_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		// search before
		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		zqlFilter.setOwner(Config.getValue("accountId"));
		System.out.println(zqlFilter.toString());

		Response beforeResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeResponse.getBody().asString());
		
		//create filter
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());
		
		//search After 
		Zqlfilter zqlFilterAfter = new Zqlfilter("searchZQLFilters");
		zqlFilterAfter.setOwner(Config.getValue("accountId"));
		System.out.println(zqlFilter.toString());

		Response afterResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(afterResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterResponse.getBody().asString());
		boolean status = zapiService.validateZQLFilters(beforeResponse, afterResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	search zql filters, by passing filterName and ownerName of Zql filter
	@Test(priority = 4)
	public void test4_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		
		
		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		zqlFilter.setName("search");
		zqlFilter.setOwner(Config.getValue("accountId"));
		//zqlFilter.setSharePerm("global");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	
		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");
		//zqlfilterSearch.setZql("project ="+Config.getValue("projectKey"));		
		zqlFilter.setName("search");
		zqlFilter.setOwner(Config.getValue("accountId"));
		//zqlfilterSearch.setFavorite(false);
		//zqlfilterSearch.setSharePerm("global");		
		//zqlfilterSearch.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters, by passing filterName and sharePerm of Zql filter
	@Test(priority = 5)
	public void test5_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		zqlFilter.setName("search");
		//zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("global");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	

		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");	
		zqlfilterSearch.setName("search");
		zqlfilterSearch.setSharePerm("global");
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters, by passing ownerName and sharePerm of Zql filter
	@Test(priority = 6)
	public void test6_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		//zqlFilter.setName("search");
		zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("global");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	

		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");	
		//zqlfilterSearch.setName("search");
		zqlfilterSearch.setSharePerm("global");
		zqlfilterSearch.setOwner(Config.getValue("accountId"));
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters by passing only sharePerm , when sharePerm is 'Global'
	@Test(priority = 7)
	public void test7_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		//zqlFilter.setName("search");
		//zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("global");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	

		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");	
		//zqlfilterSearch.setName("search");
		zqlfilterSearch.setSharePerm("global");
		//zqlfilterSearch.setOwner(Config.getValue("accountId"));
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters by passing only sharePerm , when sharePerm is 'Private'
	@Test(priority = 8)
	public void test8_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		//zqlFilter.setName("search");
		//zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("private");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	

		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");	
		//zqlfilterSearch.setName("search");
		zqlfilterSearch.setSharePerm("private");
		//zqlfilterSearch.setOwner(Config.getValue("accountId"));
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters, when sharePerm is 'Global' (along with passing all parameter)
	@Test(priority = 9)
	public void test9_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		zqlFilter.setName("search");
		zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("global");
		System.out.println(zqlFilter.toString());

		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("search api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
	

		Zqlfilter zqlfilterSearch = new Zqlfilter("search filter");	
		zqlfilterSearch.setName("search");
		zqlfilterSearch.setSharePerm("global");
		zqlfilterSearch.setOwner(Config.getValue("accountId"));
		System.out.println("zqlfilterJson: " + zqlfilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlfilterSearch.toString());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters, when sharePerm is 'Private' (along with passing all parameter)
	@Test(priority = 10)
	public void test10_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("search filter");	
		zqlFilter.setName("create");
		zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("global");
		System.out.println("zqlfilterJson: " + zqlFilter.toString() );
		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		System.out.println(beforeSearchResponse.getStatusCode());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("Create api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
		Zqlfilter zqlFilterSearch = new Zqlfilter("search filter");	
		zqlFilterSearch.setName("create");
		zqlFilterSearch.setOwner(Config.getValue("accountId"));
		zqlFilterSearch.setSharePerm("global");
		System.out.println("zqlfilterJson: " + zqlFilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilterSearch.toString());
		System.out.println(afterSearchResponse.getStatusCode());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	//	search zql filters by passing ownerName, when owner name is in capital letter
	//	search zql filters by passing ownerName, when owner name is in small letter
	//	search zql filters by passing ownerName, when owner name is in numeric
	//	search zql filters by passing ownerName, when owner name is in alphanumeric
	//	search zql filters by passing ownerName, when owner name is in  special char
	//	search zql filters by passing ownerName, when owner name is in  international char
	//	search zql filters by passing filetrName, when owner name is in capital letter
	//	search zql filters by passing filetrName, when owner name is in small letter
	//	search zql filters by passing filetrName, when owner name is in numeric
	//	search zql filters by passing filetrName, when owner name is in alphanumeric
	//	search zql filters by passing filetrName, when owner name is in  special char
	//	search zql filters by passing filetrName, when owner name is in  international char

	@Test(priority = 11)
	public void test11_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Zqlfilter zqlFilter = new Zqlfilter("search filter");	
		//zqlFilter.setName("create");
		zqlFilter.setOwner(Config.getValue("accountId"));
		zqlFilter.setSharePerm("global");
		System.out.println("zqlfilterJson: " + zqlFilter.toString() );
		
		Response beforeSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		System.out.println(beforeSearchResponse.getStatusCode());
		Assert.assertNotNull(beforeSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(beforeSearchResponse.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));		
		zqlfilterJson.setName("Create api filter for toggle " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");	
		System.out.println("zqlfilterJson: " + zqlfilterJson.toString() );
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
		
		Zqlfilter zqlFilterSearch = new Zqlfilter("search filter");	
		//zqlFilterSearch.setName("create");
		zqlFilterSearch.setOwner(Config.getValue("accountId"));
		zqlFilterSearch.setSharePerm("global");
		System.out.println("zqlfilterJson: " + zqlFilterSearch.toString() );
		
		Response afterSearchResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilterSearch.toString());
		System.out.println(afterSearchResponse.getStatusCode());
		Assert.assertNotNull(afterSearchResponse, "Search Api Response is null.");
		test.log(LogStatus.PASS, "Search Api executed successfully.");
		System.out.println(afterSearchResponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(beforeSearchResponse, afterSearchResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

}
