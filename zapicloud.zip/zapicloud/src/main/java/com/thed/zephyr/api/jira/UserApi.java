/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
public interface UserApi {


//	/**
//	 * @param basicAuth
//	 * @param recent
//	 * @return
//	 * @author Created by manoj.behera on 04-Dec-2016.
//	 */
//	Response getUsersFromPicker(RequestSpecification basicAuth);

	/**
	 * @param basicAuth
	 * @param query
	 * @param offset
	 * @param maxResults
	 * @param showAvatar
	 * @param exclude
	 * @return
	 * @author Created by manoj.behera on 04-Dec-2016.
	 */
	Response getUsersFromPicker(RequestSpecification basicAuth, String query, int offset, int maxResults,
			boolean showAvatar, String exclude);

}
