/**
 * Created by manoj.behera on 21-Mar-2017.
 */
package com.thed.zephyr.bvt;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;

/**
 * @author manoj.behera 21-Mar-2017
 *
 */
public class DataSetup extends BaseTest {
	JSONObject teststepObj = null;
	String teststepId = null;
	AtomicInteger ai = new AtomicInteger(1);
	@Test(enabled = true, invocationCount=2)
	public void test2(){
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String projectKey = Config.getValue("projectKey");
		int i = ai.incrementAndGet();
		String versionPayLoad = "{\"name\": \"New Version "+i+" \",\"project\": \""+projectKey+"\",\"projectId\": "+projectId+"}";
		Response versionResponse = jiraService.createVersion(basicAuth, versionPayLoad);
		Assert.assertNotNull(versionResponse, "Create Execution Api Response is null.");
		System.out.println(versionResponse.getBody().asString());
		String versionId = new JSONObject(versionResponse.getBody().asString()).getString("id");
		System.out.println("versionId : "+versionId);
		
		// Create component
		String componentPayLoad = "{\"project\":\""+projectKey+"\",\"projectId\": "+projectId+",\"description\":\"\",\"leadUserName\":\"\",\"name\":\"Component "+i+"\",\"assigneeType\":\"PROJECT_LEAD\"}";
		Response componentResponse = jiraService.createComponent(basicAuth, componentPayLoad);
		Assert.assertNotNull(componentResponse, "Create Execution Api Response is null.");
		System.out.println(componentResponse.getBody().asString());
		String componetId = new JSONObject(componentResponse.getBody().asString()).getString("id");
		System.out.println("componetId : "+componetId);
		
		//List<Long> tests = new ArrayList<Long>();
		// Create Issues
		/**
		 * Creating Tests
		 */
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(projectId.toString());
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Test "+i);
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		JSONArray versionsArray = new JSONArray();
		versionsArray.put(new JSONObject().put("id", versionId));
		issuePayLoad.setFixVersions(versionsArray);
		JSONArray componentsArray = new JSONArray();
		componentsArray.put(new JSONObject().put("id", componetId));
		issuePayLoad.setComponents(componentsArray);
		JSONArray labels = new JSONArray();
		labels.put("Bug_Fix_"+i);
		issuePayLoad.setLabels(labels);

		List<String> issueList = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		
		List<Long> tests = CommonUtils.getListAsLong(issueList, "id");
//		for (int j = 0; j < 10; j++) {
//			Issue issuePayLoad = new Issue();
//			issuePayLoad.setProject(projectId.toString());
//			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
//			issuePayLoad.setSummary("Test "+i);
//			issuePayLoad.setPriority("1");
//			issuePayLoad.setReporter(Config.getValue("adminUserName"));
//
//			JSONArray versionsArray = new JSONArray();
//			versionsArray.put(new JSONObject().put("id", versionId));
////			j.put(new JSONObject().put("id", 10001));
//			issuePayLoad.setFixVersions(versionsArray);
//			JSONArray componentsArray = new JSONArray();
//			componentsArray.put(new JSONObject().put("id", componetId));
//			issuePayLoad.setComponents(componentsArray);
//			JSONArray labels = new JSONArray();
//			labels.put("Bug_Fix_"+i);
//			issuePayLoad.setLabels(labels);
//
//			Response issueRresponse = jiraService.createIssues(basicAuth, issuePayLoad.toString());
//			Assert.assertNotNull(issueRresponse, "Create Issue Api Response is null.");
//			//
//			boolean status = jiraService.validateCreateIssueApi(issueRresponse);
//			Assert.assertTrue(status, "Response Validation Failed.");
//			Long issueId = Long.parseLong(new JSONObject(issueRresponse.body().asString()).getString("id"));
//			System.out.println("issueId :"+issueId);
//			tests.add(issueId);
//			
//			
//		}
		/**
		 * Creating Bugs
		 */
		List<String> bugIssueKeyList = new ArrayList<String>();
		List<Long> bugIssueList = new ArrayList<Long>();
		for (int i1 = 1; i1 <= 5; i1++) {
			Issue issuePayload = new Issue();
			issuePayload.setSummary("Bug " + i1);
			issuePayload.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayload.setProject(projectId+"");
			issuePayload.setPriority("1");
			issuePayload.setReporter(Config.getValue("adminUserName"));
			
			Response response = jiraService.createIssue(basicAuth, issuePayload.toString());
			Assert.assertNotNull(response, "Create Test Response is null.");

			String bugId = new JSONObject(response.getBody().asString()).get("id").toString();
			System.out.println("Bug : " + bugId);
			bugIssueList.add(Long.parseLong(bugId));
			String bugKey = new JSONObject(response.getBody().asString()).get("key").toString();
			System.out.println("Bug : " + bugKey);
			bugIssueKeyList.add(bugKey);
		}
		
		for (int j = 0; j < 5; j++) {
			//Crating cycle
			Cycle cycleJson = new Cycle();
			cycleJson.setName("Cycle "+(j+1));
			cycleJson.setBuild("#12345");
			cycleJson.setEnvironment("Windows");
			cycleJson.setDescription("Cycle desc");
			cycleJson.setStartDate("2016-11-14");
			cycleJson.setEndDate("2016-11-30");
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(versionId));

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Update Cycle Api Response is null.");
			
			//Validating created cycle
			boolean cycleResponseStatus = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(cycleResponseStatus, "Response Validation Failed.");
			String cycleId = new JSONObject(cycleResponse.getBody().asString()).get("id").toString();
			
			for (int k = 0; k < tests.size(); k++) {
				Long issueId = tests.get(k);
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId);
				executionJson.setVersionId(Long.parseLong(versionId));

				Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");

				boolean status1 = zapiService.validateExecution(executionJson.toString(), executionResponse);
				Assert.assertTrue(status1, "Create Execution Api Response Validation Failed.");
				
				JSONObject executionObject = new JSONObject(new JSONObject(executionResponse.getBody().asString()).get("execution").toString());
				String executionId = executionObject.get("id").toString();
				System.out.println("executionId : "+executionId);
				
				/**
				 * Update execution randomly
				 */
				executionJson.setExecutionId(executionId);
				Long statusId = CommonUtils.getStatusId("unexecuted", "default");
				executionJson.setStatusId(statusId);
				executionJson.setAssigneeType("currentUser");
				executionJson.setChangeAssignee(true);
				executionJson.setComment("comment");
				if(statusId == 2){
					Long bugId = bugIssueList.get(new Random().nextInt(bugIssueList.size()));
					List<Long> defectList = new ArrayList<>();
					defectList.add(bugId);
					executionJson.setDefects(defectList);
				}
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				System.out.println(updateExecutionResponse.getBody().asString());

				boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
						updateExecutionResponse);
				Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
				System.out.println("Execution Updated successfully.");
				
				
				if(statusId == 2){
					String entityName = "execution";
					String entityId = executionId;
					String comment = "comment";
					String fileName = "attachment.png";
					Response response = zapiService.addAttachment(jwtGenerator, projectId, Long.parseLong(versionId), issueId, cycleId, entityName,
							entityId, comment, fileName);
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
//					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateCreatedAttachment(Long.parseLong(versionId), cycleId, entityName, entityId, comment,
							fileName, response);
					Assert.assertTrue(status, "Not validated added attachment");

					JSONArray jsonArray = new JSONArray(response.getBody().asString());
					JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
					String testAattachmentId = testAattachmentObj.getString("id");
					System.err.println("Attachment added to Test level : "+testAattachmentId);
				}
				/**
				 * Create Teststeps
				 */
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("step");
				teststepJson.setData("data");
				teststepJson.setResult("result");

				Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
						teststepJson.toString());
				Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
				System.out.println(createTeststepResponse.getBody().asString());

				boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
						teststepJson.toString(), createTeststepResponse);
				Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");

				teststepObj = new JSONObject(createTeststepResponse.body().asString());
				System.out.println(teststepObj);
				teststepId = teststepObj.getString("id");
				
				/**
				 * Get StepResults
				 */
				Response stepResultsResponse = zapiService.getStepResults(jwtGenerator, issueId, executionId);
				Assert.assertNotNull(stepResultsResponse, "getStepResults Api Response is null.");
				System.out.println(stepResultsResponse.getBody().asString());

//				JSONObject stepResJSONObj = new JSONObject(stepResultsResponse.getBody().asString()).getJSONArray("stepResults").getJSONObject(0);
//				
//				String stepResId = stepResJSONObj.getString("id");
//				System.err.println(stepResId);
//				System.out.println(stepResJSONObj.toString());
//				
//				Stepresult stepResJson = new Stepresult();
//				stepResJson.setId(stepResJSONObj.getString("id"));
//				stepResJson.setStepId(stepResJSONObj.getString("stepId"));
//				stepResJson.setExecutionId(stepResJSONObj.getString("executionId"));
//				stepResJson.setIssueId(stepResJSONObj.getLong("issueId"));
//				
//				statusId = CommonUtils.getStatusId("unexecuted", "default");
//				stepResJson.setStatusId(statusId);
//				stepResJson.setComment("Comment");
//				if(statusId == 2){
//					Long bugId = bugIssueList.get(new Random().nextInt(bugIssueList.size()));
//					List<Long> defectList = new ArrayList<>();
//					defectList.add(bugId);
//					stepResJson.setDefects(defectList);
//				}
//
//				Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
//				Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
//				System.out.println(stepResultResponse.getBody().asString());
//				
//				boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
//				Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");
//				
//				String stepResultId = new JSONObject(stepResultResponse.getBody().asString()).get("id").toString();
//				
//				if(statusId == 2){
//					String entityName = "stepResult";
//					String entityId = stepResultId;
//					String comment = "comment";
//					String fileName = "attachment.png";
//					Response response = zapiService.addAttachment(jwtGenerator, projectId, Long.parseLong(versionId), issueId, cycleId, entityName,
//							entityId, comment, fileName);
//					Assert.assertNotNull(response, "Create Execution Api Response is null.");
//
//					boolean status = zapiService.validateCreatedAttachment(Long.parseLong(versionId), cycleId, entityName, entityId, comment,
//							fileName, response);
//					Assert.assertTrue(status, "Not validated added attachment");
//
//					JSONArray jsonArray = new JSONArray(response.getBody().asString());
//					JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
//					String testAattachmentId = testAattachmentObj.getString("id");
//					System.err.println("Attachment added to Step level : "+testAattachmentId);
//				}
			}
			
			/**
			 * Create ZQL Filters 
			 */
			for (int k = 1; k <= 10; k++) {
				Zqlfilter zqlfilterJson = new Zqlfilter("save filter");
				zqlfilterJson.setZql("project = " + Config.getValue("projectKey"));
				zqlfilterJson.setName("Create api filter" + System.currentTimeMillis());
				if(k == 5 || k==6 || k==7){
					zqlfilterJson.setFavorite(false);
				}else{
					zqlfilterJson.setFavorite(true);
				}
				
				zqlfilterJson.setSharePerm("private");

				Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				System.out.println(response.getBody().asString());

				boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
				Assert.assertTrue(status);
				JSONObject zqlFilterObject = new JSONObject(response.getBody().asString());
				System.out.println("Filter created :"+zqlFilterObject.toString());
			}
		}
		
		
		
		
//		String executionId = new JSONObject(executionResponse.getBody().asString()).get("id").toString();
//		System.out.println("executionId : "+executionId);
	}
	/**
	 * This method is used to create the below dataset.
	 * Create 1 project, 1 version, 1 component, 1 issue, 1 cycle and 1 execution
	 * This is used in the test summary data creation.
	 * @author Created by manoj.behera on 30-Mar-2017.
	 */
	@Test(enabled = false, invocationCount = 500)
	public void test1(){
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String projectKey = Config.getValue("projectKey");
		int i = ai.incrementAndGet();
		String versionPayLoad = "{\"name\": \"New Version "+i+" \",\"project\": \""+projectKey+"\",\"projectId\": "+projectId+"}";
		Response versionResponse = jiraService.createVersion(basicAuth, versionPayLoad);
		Assert.assertNotNull(versionResponse, "Create Execution Api Response is null.");
		System.out.println(versionResponse.getBody().asString());
		String versionId = new JSONObject(versionResponse.getBody().asString()).getString("id");
		System.out.println("versionId : "+versionId);
		
		// Create component
		String componentPayLoad = "{\"project\":\""+projectKey+"\",\"projectId\": "+projectId+",\"description\":\"\",\"leadUserName\":\"\",\"name\":\"Component "+i+"\",\"assigneeType\":\"PROJECT_LEAD\"}";
		Response componentResponse = jiraService.createComponent(basicAuth, componentPayLoad);
		Assert.assertNotNull(componentResponse, "Create Execution Api Response is null.");
		System.out.println(componentResponse.getBody().asString());
		String componetId = new JSONObject(componentResponse.getBody().asString()).getString("id");
		System.out.println("componetId : "+componetId);
		// Create Issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(projectId.toString());
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Test "+i);
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		JSONArray versionsArray = new JSONArray();
		versionsArray.put(new JSONObject().put("id", versionId));
//		j.put(new JSONObject().put("id", 10001));
		issuePayLoad.setFixVersions(versionsArray);
		JSONArray componentsArray = new JSONArray();
		componentsArray.put(new JSONObject().put("id", componetId));
		issuePayLoad.setComponents(componentsArray);
		JSONArray labels = new JSONArray();
		labels.put("Bug_Fix_"+i);
		issuePayLoad.setLabels(labels);

		Response issueRresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(issueRresponse, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(issueRresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		Long issueId = Long.parseLong(new JSONObject(issueRresponse.body().asString()).getString("id"));
		System.out.println("issueId :"+issueId);
		
		
		//Crating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Empty Cycle");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(versionId));

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Update Cycle Api Response is null.");
		
		//Validating created cycle
		boolean cycleResponseStatus = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(cycleResponseStatus, "Response Validation Failed.");
		String cycleId = new JSONObject(cycleResponse.getBody().asString()).get("id").toString();
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(Long.parseLong(versionId));

		Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");

		boolean status1 = zapiService.validateExecution(executionJson.toString(), executionResponse);
		Assert.assertTrue(status1, "Create Execution Api Response Validation Failed.");
		
//		String executionId = new JSONObject(executionResponse.getBody().asString()).get("id").toString();
//		System.out.println("executionId : "+executionId);
	}
}
