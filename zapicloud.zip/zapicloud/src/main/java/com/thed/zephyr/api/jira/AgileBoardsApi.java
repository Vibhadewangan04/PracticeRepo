package com.thed.zephyr.api.jira;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

public interface AgileBoardsApi {
	/**
	 * @param basicAuth
	 * @param projectId
	 * @return
	 * @author Created by poornachandra k on 05-JUL-2019.
	 */
	Response getProjectBoard(RequestSpecification basicAuth, String projectId);

	/**
	 * @param basicAuth
	 * @param projectId
	 * @return
	 * @author Created by poornachandra k on 05-JUL-2019.
	 */
	Response createSprint(RequestSpecification basicAuth, String payload);
	
	Response addissuetosprint(RequestSpecification basicAuth, Long sprintId,String payload);
	
	Response updatesprint(RequestSpecification basicAuth, Long sprintId,String payload);
	
	Response deletesprint(RequestSpecification basicAuth, Long sprintId);
	
}
