package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.ExecutionworkflowApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

@Service("executionworkflowApi")
public class Executionworkflowimpl implements ExecutionworkflowApi {

	@Override
	public Response Executionworflow_inprogress(JwtGenerator jwtGenerator,String Executionid,String Issueid) {
		
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/workflow/"+Executionid+"/inProgress";//+"?"+"issueId="+Issueid;		
		URI uri = null;	
		uri = UriBuilder.fromUri(uriStr).queryParam("issueId", Issueid).build();
			
		/*try {
			uri = new URI();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}*/
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
//		headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		String payLoad ="{ }";
		//System.out.println(payLoad);
		//return given().headers(headers).body(payLoad).when().put(uri);
		//return given().headers(headers).when().put(uri);
		return given().headers(headers).body(payLoad).when().put(uri);
		
	}

	
	@Override
	public Response Executionworflow_Done(JwtGenerator jwtGenerator,String action,String timeLogged,String Executionid,String Issueid) {
				
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/workflow/"+Executionid+"/complete";//+"?"+"issueId="+Issueid;		
		URI uri = null;	
		uri = UriBuilder.fromUri(uriStr).queryParam("issueId", Issueid).queryParam("action",action).queryParam("timeLogged",timeLogged).build();
			
		/*try {
			uri = new URI();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}*/
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		//headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		String payLoad ="{ }";
		//System.out.println(payLoad);
		//return given().headers(headers).body(payLoad).when().put(uri);
		//return given().headers(headers).when().put(uri);
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	
	@Override
	public Response Executionworflow_Modifytime(JwtGenerator jwtGenerator,String action,String timeLogged,String Executionid,String Issueid) {
				
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/workflow/"+Executionid+"/logtime";//+"?"+"issueId="+Issueid;		
		URI uri = null;	
		uri = UriBuilder.fromUri(uriStr).queryParam("issueId", Issueid).queryParam("action",action).queryParam("timeLogged",timeLogged).build();
			
		/*try {
			uri = new URI();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}*/
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		//headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		String payLoad ="{ }";
		//System.out.println(payLoad);
		//return given().headers(headers).body(payLoad).when().put(uri);
		//return given().headers(headers).when().put(uri);
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	@Override
	public Response Executionworflow_Reopen(JwtGenerator jwtGenerator,String Executionid, String Issueid) {
				
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/workflow/"+Executionid+"/reopen";//+"?"+"issueId="+Issueid;		
		URI uri = null;	
		uri = UriBuilder.fromUri(uriStr).queryParam("issueId", Issueid).build();
			
		/*try {
			uri = new URI();
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}*/
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		//headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		String payLoad ="{ }";
		//System.out.println(payLoad);
		//return given().headers(headers).body(payLoad).when().put(uri);
		//return given().headers(headers).when().put(uri);
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	

}
