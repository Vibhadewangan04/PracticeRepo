package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.google.gson.JsonArray;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

import net.minidev.json.JSONArray;

public class GetFilters extends BaseTest {
	int offset = 0;
	boolean byuser;
	boolean fav;
	JwtGenerator jwtGenerator = null;
	JwtGenerator jwtGeneratorForUser = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
		jwtGeneratorForUser = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("userSecretKey"), Config.getValue("userUsername"));
	}

	// favorite

	// by user is false: getting global
	// by user is true: Getting both private and global
	/**
	 * ZQLFilter Api getFilters 1.Get Favorite Execution Filters created by user
	 * Using Get filters Api (both private and global)
	 */
	@Test(priority = 1) // getting only favorite filters in both private and
						// global
	public void Test1_getZqlFilters_user_favourite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			
		System.out.println(response.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		
		 boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		 Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api (both
	 * private and global) 2.Get user non favorite filters created by user (both
	 * private and global).
	 */
	@Test(priority = 2) // 34-including private and global which are not
						// favorite(all- created by user)
	public void Test2_getZqlFilters_user_favourite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
			
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api 3.Get
	 * user non favorite filters(only private )
	 */
	@Test(priority = 3) // 28-getting global which are not favorite (Excluding
						// private)
	public void Test3_getZqlFilters_user_favourite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api 4.Get
	 * user favorite filters( private)
	 */
	@Test(priority = 4) // 0-getting global and fav filters (which is favourite)
	public void Test4_getZqlFilters_user_favourite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = false;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// my

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api 5.Get
	 * filters created by user((both private and global)
	 */
	@Test(priority = 5)
	public void Test5_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api 6.Get
	 * filters created by user( private )
	 */
	@Test(priority = 6)
	public void Test6_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);

		boolean byUser = false;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());


		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api 7.Get
	 * user popular favorite filters
	 */
	@Test(priority = 7)
	public void Test7_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api 8.Get
	 * user popular non favorite filters
	 */
	@Test(priority = 8)
	public void Test8_getZqlFilters_p() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// ===================================================================

	// Add delete filter code before the get filters
	// =====================================================================

	// favorite
	/**
	 * ZQLFilter Api getFilters 9.Attempt to Get Deleted Favorite Execution
	 * Filters ( Delete private or global created by user)
	 */
	@Test(priority = 9)
	public void Test9_getZqlFilters_user_favorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
		
		//get filter code
		
		Response getResponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		
		//delete filter code
		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		
		//get filter code
		
		Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 10.Attempt to Get Deleted non Favorite Execution Filters ( Delete private
	 * or global created by user)
	 */
	@Test(priority = 10)
	public void Test10_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		// Delete filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		
		 boolean status = zapiService.validateZQLFilters(response, response);
		 Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 11.Attempt to Get Deleted Favorite Execution Filters ( Delete private
	 * filter created by user)
	 */
	@Test(priority = 11)
	public void Test11_getZqlFiltersOnFavPrivateFilterDelete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
		
		//get filter code
		
		Response getResponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		
		//delete filter code
		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		
		//get filter code
		
		Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 12.Attempt to Get Deleted non Favourite Execution Filters ( Delete
	 * private filter created by user)
	 */
	@Test(priority = 12)
	public void Test12_getZqlFiltersOnNonFavPrivateFilterDelete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = false;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
		
		//get filter code
		
		Response getResponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		
		//delete filter code
		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		
		//get filter code
		
		Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// my

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 13.Attempt to Get Deleted My Execution Filters ( Delete favorite filter
	 * created by user)
	 */
	@Test(priority = 13)
	public void Test13_getZqlFiltersOnNonFavFilterDelete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
		
		//get filter code
		
		Response getResponse = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
		
		
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		
		//delete filter code
		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		
		//get filter code
		
		Response deleteAfterresponse = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 14.Attempt to Get Deleted My Execution Filters (Delete non-favorite
	 * filter created by user)
	 */
		@Test(priority = 14)
	public void Test14_getZqlFiltersOnNonFavFilterDelete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		

		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
				
		//get filter code
		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;	
		Response getResponse = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
				
		//delete filter code
				
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
				
		//get filter code
				
		Response deleteAfterresponse = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
				
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 15.Attempt to Get Deleted Popular Execution Filters (Delete popular- fav
	 * filter created by user)
	 */
	@Test(priority = 15)
	public void Test15_getZqlFiltersOnDeleteFavPopularFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
				
		//get filter code
		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;	
		Response getResponse = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
				
		//delete filter code
				
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
				
		//get filter code
				
		Response deleteAfterresponse = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
				
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 16.Attempt to Get Deleted Popular Execution Filters (Delete
	 * popular-non-favorite filter created by user)
	 */
	@Test(priority = 16)
	public void Test16_getZqlFiltersOnDeletePopularNonFav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
						
				//get filter code
				boolean byUser = true;
				int offset = 0;
				int maxRecords = 50;	
				Response getResponse = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
				Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + getResponse.getBody().asString());
						
						
				boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
				Assert.assertTrue(status);
				String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
						
				//delete filter code
						
				response = zapiService.deleteFilter(jwtGenerator, filterId);
				Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
				test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
				System.out.println("Delete filter response" + response.getBody().asString());

				status = zapiService.validateDeleteZqlFilter(filterId, response);
				Assert.assertTrue(status);
						
				//get filter code
						
				Response deleteAfterresponse = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
				Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
						
				boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
				Assert.assertTrue(FilterCompare);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}

	// =============================================================================
	// get Updated filter by getfilters Api
	// ==============================================================================

	// favorite
	/**
	 * ZQLFilter Api getFilters 17. Get updated Favorite Execution Filters (
	 * Delete private or global created by user)
	 */
	@Test(priority = 17)
	public void Test17_getZqlFilters_user_favorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		
		
		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
			
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		
		Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(updateFilterResponse.getBody().asString());
		boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
		Assert.assertTrue(updateFilterStatus);
		
		
		Response createAfterresponse = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(createAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createAfterresponse.getBody().asString());
		
		boolean status = zapiService.validateZQLFilters(response, createAfterresponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
		/*
		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;

		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get response" +response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Create Filter response" + response.getBody().asString());
		
				
				System.out.println("Response:-->" + createFilterResponse.getBody().asString());
				boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
				Assert.assertTrue(createFilterStatus);
				
				String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				zqlfilterJson.setId(filterId);
				zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
				System.out.println(zqlfilterJson.toString());
				Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
				Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println(updateFilterResponse.getBody().asString());
				boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
				Assert.assertTrue(updateFilterStatus);
				
				Response Afterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
				Assert.assertNotNull(Afterresponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(Afterresponse.getBody().asString());
				
				
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);*/
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 18.Get updated non Favourite Execution Filters ( Delete private or global
	 * created by user)
	 */
	@Test(priority = 18)
	public void Test18_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		// update filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create  ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(updateFilterResponse.getBody().asString());
		boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
		Assert.assertTrue(updateFilterStatus);
		
		Response Afterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(Afterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(Afterresponse.getBody().asString());
		
		
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 19.Get updated Favorite Execution Filters ( Delete private filter created
	 * by user)
	 */
	@Test(priority = 19)
	public void Test19_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		// update filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 20.Get updated non Favorite Execution Filters ( Delete private filter
	 * created by user)
	 */
	@Test(priority = 20)
	public void Test20_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = false;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		// update filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create  ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(updateFilterResponse.getBody().asString());
		boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
		Assert.assertTrue(updateFilterStatus);
		
		Response Afterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(Afterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(Afterresponse.getBody().asString());
		
		
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}

	// my

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 21.Get updated My Execution Filters ( Delete favorite filter created by
	 * user)
	 */
	@Test(priority = 21)
	public void Test21_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		// update filter code
		Response response = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);


		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey"));
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create  ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(updateFilterResponse.getBody().asString());
		boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
		Assert.assertTrue(updateFilterStatus);
		
		Response Afterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(Afterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(Afterresponse.getBody().asString());
		
		
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 22.Get updated My Execution Filters (Delete non-favorite filter created
	 * by user)
	 */
	@Test(priority = 22)
	public void Test22_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		
		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
				
		//get filter code
				
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		boolean byUser = false;

		
				
		Response getResponse = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//copy filter code
		
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("updateFilterResponse: " + updateFilterResponse.getBody().asString());
		boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
		Assert.assertTrue(updateFilterStatus);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 23.Get updated Popular Execution Filters (Delete popular- fav filter
	 * created by user)
	 */
	@Test(priority = 23)
	public void Test23_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
				
		//get filter code
				
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		boolean byUser = false;

		
				
		Response getResponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//copy filter code
		
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("updateFilterResponse: " + updateFilterResponse.getBody().asString());
		boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
		Assert.assertTrue(updateFilterStatus);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 24.Get updated Popular Execution Filters (Delete popular-non-favorite
	 * filter created by user)
	 */
	@Test(priority = 24)
	public void Test24_getZqlFilters_p() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
	
				
				//Create Filter code
				
				Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
				zqlfilterJson.setZql("project is EMPTY");		
				zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
				zqlfilterJson.setFavorite(false);
				zqlfilterJson.setSharePerm("global");		
				zqlfilterJson.setDescription("Description");		
				Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
				Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
						
				//get filter code
						
				boolean fav = false;
				int offset = 0;
				int maxRecords = 50;
				boolean byUser = false;

				
						
				Response getResponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
				Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + getResponse.getBody().asString());
						
						
				boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
				Assert.assertTrue(status);
				String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
						
				//copy filter code
				
				zqlfilterJson.setId(filterId);
				zqlfilterJson.setName("Api filter Updated "+ System.currentTimeMillis());
				System.out.println(zqlfilterJson.toString());
				Response updateFilterResponse = zapiService.updateFilter(jwtGeneratorForUser, filterId, zqlfilterJson.toString());
				Assert.assertNotNull(updateFilterResponse, "Update ZQL Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println("updateFilterResponse: " + updateFilterResponse.getBody().asString());
				boolean updateFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), updateFilterResponse);
				Assert.assertTrue(updateFilterStatus);
						
				//get filter code
				
				Response deleteAfterresponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
				Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
				
				boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
				Assert.assertTrue(FilterCompare);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}

	// ===================================================
	// get Copied Filters using GetfiltersAPI
	// ===================================================
	// favorite
	/**
	 * ZQLFilter Api getFilters 25.Get Copied Favorite Execution Filters (
	 * Delete private or global created by user)
	 */
	@Test(priority = 25)
	public void Test25_getZqlFilters_user_favorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
				
		//get filter code
				
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		boolean byUser = false;

		
				
		Response getResponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//copy filter code
		
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		zqlfilterJson.setId(filterId);
		Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("copyFilterResponse: " + copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 26.Get Copied non Favourite Execution Filters ( Delete private or global
	 * created by user)
	 */
	@Test(priority = 26)
	public void Test26_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
				
		//get filter code
				
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		boolean byUser = false;

		
				
		Response getResponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//copy filter code
		
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		zqlfilterJson.setId(filterId);
		Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("copyFilterResponse: " + copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 27.Get Copied Favorite Execution Filters ( Delete private filter created
	 * by user)
	 */
	@Test(priority = 27)
	public void Test27_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
				
		//get filter code
				
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		boolean byUser = false;

		
				
		Response getResponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//copy filter code
		
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		zqlfilterJson.setId(filterId);
		Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("copyFilterResponse: " + copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 28.Get Copied non Favorite Execution Filters ( Delete private filter
	 * created by user)
	 */
	@Test(priority = 28)
	public void Test28_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
				
		//Create Filter code
		
				Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
				zqlfilterJson.setZql("project is EMPTY");		
				zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
				zqlfilterJson.setFavorite(false);
				zqlfilterJson.setSharePerm("global");		
				zqlfilterJson.setDescription("Description");		
				Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
				Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
						
				//get filter code
						
				boolean fav = false;
				int offset = 0;
				int maxRecords = 50;
				boolean byUser = false;

				
						
				Response getResponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
				Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + getResponse.getBody().asString());
						
						
				boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
				Assert.assertTrue(status);
				String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
						
				//copy filter code
				
				zqlfilterJson.setId(filterId);
				zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
				System.out.println(zqlfilterJson.toString());
				zqlfilterJson.setId(filterId);
				Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
				Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println("copyFilterResponse: " + copyFilterResponse.getBody().asString());
				String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
				zqlfilterJson.setId(copyfilterId);
				boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
				Assert.assertTrue(copyFilterStatus);
						
				//get filter code
				
				Response deleteAfterresponse = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
				Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
				
				boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
				Assert.assertTrue(FilterCompare);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}

	// my

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 29.Get Copied My Execution Filters ( Delete favorite filter created by
	 * user)
	 */
	@Test(priority = 29)
	public void Test29_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
				
		//get filter code
				
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		boolean byUser = false;

		
				
		Response getResponse = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//copy filter code
		
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		zqlfilterJson.setId(filterId);
		Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("copyFilterResponse: " + copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api Get
	 * Copied My Execution Filters (Delete non-favorite filter created by user)
	 */
	@Test(priority = 30)
	public void Test30_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
				Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
				zqlfilterJson.setZql("project is EMPTY");		
				zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
				zqlfilterJson.setFavorite(true);
				zqlfilterJson.setSharePerm("global");		
				zqlfilterJson.setDescription("Description");		
				Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
				Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println("createFilterResponse: " + createFilterResponse.getBody().asString());	
						
				//get filter code
						
				boolean fav = false;
				int offset = 0;
				int maxRecords = 50;
				boolean byUser = false;

				
						
				Response getResponse = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
				Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + getResponse.getBody().asString());
						
						
				boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
				Assert.assertTrue(status);
				String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
						
				//copy filter code
				
				zqlfilterJson.setId(filterId);
				zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
				System.out.println(zqlfilterJson.toString());
				zqlfilterJson.setId(filterId);
				Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
				Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
				test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
				System.out.println("copyFilterResponse: " + copyFilterResponse.getBody().asString());
				String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
				zqlfilterJson.setId(copyfilterId);
				boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
				Assert.assertTrue(copyFilterStatus);
						
				//get filter code
				
				Response deleteAfterresponse = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
				Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
				
				boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
				Assert.assertTrue(FilterCompare);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
		
		
		
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 31.Get Copied Popular Execution Filters (Delete popular- fav filter
	 * created by user)
	 */
	@Test(priority = 31)
	public void Test31_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		// Copy filter code
		
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = "+Config.getValue("projectKey"));		
		zqlfilterJson.setName("create api filter new " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.err.println("createFilterResponse: " + createFilterResponse.getBody().asString());
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		Response beforeResponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(beforeResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(beforeResponse.getBody().asString());
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("Api filter copied - "+ System.currentTimeMillis());
		System.out.println(zqlfilterJson.toString());
		zqlfilterJson.setId(filterId);
		Response copyFilterResponse = zapiService.copyFilter(jwtGeneratorForUser, zqlfilterJson.toString());
		Assert.assertNotNull(copyFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(copyFilterResponse.getBody().asString());
		String copyfilterId = new JSONObject(copyFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(copyfilterId);
		boolean copyFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), copyFilterResponse);
		Assert.assertTrue(copyFilterStatus);
		
		Response afterResponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(afterResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(afterResponse.getBody().asString());
		
		boolean copyFilter = zapiService.validateZQLFilters(beforeResponse, afterResponse);
		Assert.assertTrue(copyFilter);
		
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 32.Get Copied Popular Execution Filters (Delete popular-non-favorite
	 * filter created by user)
	 */
	@Test(priority = 32)
	public void Test32_getZqlFilters_p() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Create Filter code
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGeneratorForUser,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("createFilterResponse: " + createFilterResponse);	
				
		//get filter code
				
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
				
		Response getResponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(getResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + getResponse.getBody().asString());
				
				
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(status);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
				
		//delete filter code
		
		Response response = zapiService.deleteFilter(jwtGeneratorForUser, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println("Delete filter response" + response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
				
		//get filter code
		
		Response deleteAfterresponse = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(deleteAfterresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Get Filter response" + deleteAfterresponse.getBody().asString());	
		
		boolean FilterCompare = zapiService.validateZQLFilters(getResponse, deleteAfterresponse);
		Assert.assertTrue(FilterCompare);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// ============================================
	// Togglefavorite filter code
	// ============================================

	// favorite
	/**
	 * ZQLFilter Api getFilters 33.Get Toggledfavorite the Favorite Execution
	 * Filters ( Delete private or global created by user)
	 */
	@Test(priority = 33)
	public void Test33_getZqlFilters_user_favorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code

		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 34.Get Toggledfavorite the non Favourite Execution Filters ( Delete
	 * private or global created by user)
	 */
	@Test(priority = 34)
	public void Test34_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 35.Get Toggledfavorite the Favorite Execution Filters ( Delete private
	 * filter created by user)
	 */
	@Test(priority = 35)
	public void Test35_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = true;
		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 36.Get Toggledfavorite the non Favorite Execution Filters ( Delete
	 * private filter created by user)
	 */
	@Test(priority = 36)
	public void Test36_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(false);
		zqlFilter.setOffset(0);
		boolean byUser = false;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code
		Response response = zapiService.getFavouriteZQLFilters(jwtGeneratorForUser, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// my

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 37.Get Toggledfavorite the My Execution Filters ( Delete favorite filter
	 * created by user)
	 */
	@Test(priority = 37)
	public void Test37_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code
		Response response = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 38.Get Toggledfavorite the My Execution Filters (Delete non-favorite
	 * filter created by user)
	 */
	@Test(priority = 38)
	public void Test38_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = false;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code
		Response response = zapiService.getMyZQLFilters(jwtGeneratorForUser, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 39.Get Toggledfavorite the Popular Execution Filters (Delete popular- fav
	 * filter created by user)
	 */
	@Test(priority = 39)
	public void Test39_getZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		// Toggle filter code
		Response response = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// popular:
	/**
	 * ZQLFilter Api getFilters get the zql filters using �getFilters� Api
	 * 40.Get Toggledfavorite the Popular Execution Filters (Delete
	 * popular-non-favorite filter created by user)
	 */
	@Test(priority = 40)
	public void Test40_getZqlFilters_p() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(false);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean fav = false;
		int offset = 0;
		int maxRecords = 50;
		// update filter code
		Response response = zapiService.getPapularZQLFilters(jwtGeneratorForUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
