/**
 * Created by manoj.behera on 07-Dec-2016.
 */
package com.thed.zephyr.bvt;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 07-Dec-2016
 *
 */
public class ZqlfilterApiBvt extends BaseTest {
	JSONObject zqlFilterObject = null;
	JSONObject zqlFilterObject1 = null;
//	@BeforeClass
//	public void beforeClass() {
//		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
//				Config.getValue("secretKey"), Config.getValue("adminUserName"));
//	}
	@Test(priority = 86, enabled = testEnabled)
	public void bvt86_saveFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlfilterJson = new Zqlfilter("copy filter");
		zqlfilterJson.setZql("project = " + Config.getValue("projectKey"));
		zqlfilterJson.setName("Create api filter" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		zqlFilterObject = new JSONObject(response.getBody().asString());

		extentReport.endTest(test);
	}

	@Test(priority = 87, enabled = testEnabled)
	public void bvt87_getZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		/*
		 * Zqlfilter zqlfilterJson = new Zqlfilter("get filter");
		 * zqlfilterJson.setZql("project = IE"); zqlfilterJson.setName(
		 * "Get api filter" + System.currentTimeMillis());
		 * zqlfilterJson.setFavorite(true);
		 * zqlfilterJson.setSharePerm("global"); // String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"api filter // 1231111\
		 * ",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		 * // System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		 * Assert.assertNotNull(response,
		 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
		 * "Update Cycle Api executed successfully.");
		 * System.out.println(response.getBody().asString());
		 * 
		 * boolean status =
		 * zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		 * Assert.assertTrue(status);
		 */

		String filterId = zqlFilterObject.get("id").toString();

		Response response = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlFilterObject.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 88, enabled = testEnabled)
	public void bvt88_updateFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		/*
		 * Zqlfilter zqlfilterJson = new Zqlfilter(); zqlfilterJson.setZql(
		 * "project = IE"); zqlfilterJson.setName("Update api filter " +
		 * System.currentTimeMillis()); zqlfilterJson.setFavorite(true);
		 * zqlfilterJson.setSharePerm("global"); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		 * Assert.assertNotNull(response,
		 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
		 * "Update Cycle Api executed successfully.");
		 * System.out.println(response.getBody().asString());
		 * 
		 * boolean status =
		 * zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		 * Assert.assertTrue(status);
		 * 
		 * // Copy filter String filterId = new
		 * JSONObject(response.getBody().asString()).get("id").toString();
		 * zqlfilterJson.setId(filterId); zqlfilterJson.setName(
		 * "api filter for update1");
		 */

		// String payLoad =
		// "{\"favorite\":true,\"id\":\"0001479409306195-242ac113a-0001\",\"description\":\"\",\"name\":\"sd42\",\"sharePerm\":\"global\",\"zql\":\"project
		// = IE\"}";
		String filterId = zqlFilterObject.get("id").toString();
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql(zqlFilterObject.get("zql").toString());
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setId(filterId);

		Response response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 89, enabled = testEnabled)
	public void bvt89_copyFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		/*
		 * Zqlfilter zqlfilterJson = new Zqlfilter("copy filter");
		 * zqlfilterJson.setZql("project = IE"); zqlfilterJson.setName(
		 * "copy api filter for copy " + System.currentTimeMillis());
		 * zqlfilterJson.setFavorite(true);
		 * zqlfilterJson.setSharePerm("global"); // String payLoad =
		 * "{\"zql\":\"project = IE\",\"name\":\"api filter // 1231111\
		 * ",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		 * // System.out.println(payLoad); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		 * Assert.assertNotNull(response,
		 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
		 * "Update Cycle Api executed successfully.");
		 * System.out.println(response.getBody().asString());
		 * 
		 * boolean status =
		 * zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		 * Assert.assertTrue(status);
		 * 
		 * // Copy filter String filterId = new
		 * JSONObject(response.getBody().asString()).get("id").toString();
		 * zqlfilterJson.setId(filterId); zqlfilterJson.setName(
		 * "api filter for copy " + System.currentTimeMillis()); // String
		 * payLoad = //
		 * "{\"id\":\"0001479409306195-242ac113a-0001\",\"name\":\"Copy of //
		 * filter 1 2 from api48958511\",\"zql\":\"project = IE AND fixVersion =
		 * // v1\",\"favorite\":true}";
		 * 
		 */
		String filterId = zqlFilterObject.get("id").toString();
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql(zqlFilterObject.get("zql").toString());
		zqlfilterJson.setName("Copy api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setId(filterId);
		
		Response response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(null);
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		zqlFilterObject1 = new JSONObject(response.getBody().asString());
	}
	@Test(priority = 90, enabled = testEnabled)
	public void bvt90_updateFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		/*
		 * Zqlfilter zqlfilterJson = new Zqlfilter(); zqlfilterJson.setZql(
		 * "project = IE"); zqlfilterJson.setName("Update api filter " +
		 * System.currentTimeMillis()); zqlfilterJson.setFavorite(true);
		 * zqlfilterJson.setSharePerm("global"); Response response =
		 * zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		 * Assert.assertNotNull(response,
		 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
		 * "Update Cycle Api executed successfully.");
		 * System.out.println(response.getBody().asString());
		 * 
		 * boolean status =
		 * zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		 * Assert.assertTrue(status);
		 * 
		 * // Copy filter String filterId = new
		 * JSONObject(response.getBody().asString()).get("id").toString();
		 * zqlfilterJson.setId(filterId); zqlfilterJson.setName(
		 * "api filter for update1");
		 */

		// String payLoad =
		// "{\"favorite\":true,\"id\":\"0001479409306195-242ac113a-0001\",\"description\":\"\",\"name\":\"sd42\",\"sharePerm\":\"global\",\"zql\":\"project
		// = IE\"}";
		String filterId = zqlFilterObject1.get("id").toString();
		Zqlfilter zqlfilterJson = new Zqlfilter();
//		zqlfilterJson.setZql(zqlFilterObject1.get("zql").toString());
//		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
//		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setId(filterId);

//		Response response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
//		Assert.assertNotNull(response, "Create Execution Api Response is null.");
//		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		Response response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 91, enabled = testEnabled)
	public void bvt91_getFavouriteZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 92, enabled = testEnabled)
	public void bvt92_getMyZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 94, enabled = testEnabled)
	public void bvt94_quickSearchZQLFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		

		String filterName = zqlFilterObject.get("name").toString();
		Response response1 = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());
		// status = zapiService.validateZQLFilter(zqlfilterJson.toString(),
		// response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 95, enabled = testEnabled)
	public void bvt95_deleteFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		

		// Delete filter
		String filterId = zqlFilterObject1.get("id").toString();
		System.err.println(filterId);

		// String filterId = "0001480574298023-242ac112-0001";
		Response response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	
//	@Test(priority = 2)
	public void searchZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		zqlFilter.setName("a");

		Response response = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilters("", response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
}
