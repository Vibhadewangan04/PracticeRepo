/**
 * Created by manoj.behera on 21-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 21-Nov-2016
 *
 */
public interface ChartApi {

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param daysPrevious
	 * @param periodName
	 * @param maxResults
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getTestsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param daysPrevious
	 * @param periodName
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getExecutionsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName);

	
}
