package com.thed.zephyr.bvt;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zql;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class ZAPIBvt extends BaseTest {

	String cycleId = null;
	String cycleIdScheduledVersion = null;
	JSONObject cycleIdScheduledVersionObj = null;
	String issueKey = null;
	String executionObject = null;
	long issueId;
	long issueId1;
	JSONObject teststepObj = null;
	long StoryId ;
	Long defectId;
	Long cycleid = null;
	Long folderId = null;

	@BeforeClass
	public void beforeClass() {
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "JIra create issue Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
	}

	/**
	 * Get the General Config Info
	 */

	@Test(priority = 3, enabled = testEnabled)
	public void bvt3_getGeneralConfigInfo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getGeneralConfigInfo(jwtGenerator);
		Assert.assertNotNull(response, "Get the General Config Info response is null.");
		test.log(LogStatus.PASS, "Get the General Config Info Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean generalConfigInfoStatus = zapiService.validateGeneralConfigInfo(response);
		Assert.assertTrue(generalConfigInfoStatus, "Get the General Config Info Api validation failed.");
		test.log(LogStatus.PASS, "Get the General Config Info Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get the ServerInfo
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void bvt4_getServerInfo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getServerInfo(jwtGenerator);
		Assert.assertNotNull(response, "Get  the ServerInfo Api Response is null.");
		test.log(LogStatus.PASS, "Get  the ServerInfo Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean serverInfoStatus = zapiService.validateServerInfo(response);
		Assert.assertTrue(serverInfoStatus, "Get  the ServerInfo Api validation failed.");
		test.log(LogStatus.PASS, "Get the ServerInfo Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add a test step to test by adding test description, data and expected
	 * results
	 */

	@Test(priority = 5, enabled = testEnabled)
	public void bvt5_createTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
				teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
		System.out.println(teststepObj);
		extentReport.endTest(test);
	}

	/**
	 * Get the teststep by providing teststepId
	 * 
	 */
	@Test(priority = 6, enabled = testEnabled)
	public void bvt6_getTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueId = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		Response getStepResponse = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(getStepResponse, "Get Test step response is not validated");
		System.out.println(getStepResponse.getBody().asString());
		boolean status = zapiService.validateTeststep(projectId, issueId, teststepObj.toString(), getStepResponse);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get Teststep Response validated suuccessfully.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get test steps by issueid
	 * 
	 */
	@Test(priority = 7, enabled = testEnabled)
	public void bvt7_getTeststeps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueId = teststepObj.getLong("issueId");
		Response response = zapiService.getCycles(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(response, "Get Teststeps API Response is null.");
		test.log(LogStatus.PASS, "Get Teststeps Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, issueId, response);
		Assert.assertTrue(status, "Get Test steps Response Validation Failed.");
		test.log(LogStatus.PASS, "Get Test steps Response validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Edit and modify a test step by adding test description, data and expected
	 * results
	 * 
	 */
	@Test(priority = 8, enabled = testEnabled)
	public void bvt8_updateTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));

		//creating issueid1
			Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad1.setSummary("test with steps");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad1.toString());
			Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
			Assert.assertNotNull(response1, "Create Issue Api Response is null.");
			
			boolean status = jiraService.validateCreateIssueApi(response1);
			Assert.assertTrue(status, "Response Validation Failed.");
			issueId1 = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
			String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
			
			//cretae teststeps to issue
			
			Teststep teststepJson = new Teststep();
			teststepJson.setStep("step");
			teststepJson.setData("data");
			teststepJson.setResult("result");

			Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId1,
					teststepJson.toString());
			Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
			test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
			System.out.println(createTeststepResponse.getBody().asString());

			boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId1,
					teststepJson.toString(), createTeststepResponse);
			Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
			test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

			teststepObj = new JSONObject(createTeststepResponse.body().asString());
			System.err.println("Test step response: " + teststepObj);
			extentReport.endTest(test);
			
	      // Long issueId = teststepObj.getLong("issueId");
	     //  Long issueId = Long.parseLong("issueId1");
		   String stepId = teststepObj.getString("id");
		  //update the testdtep

		Teststep teststepJson1 = new Teststep();
		teststepJson1.setStep("updated step");
		teststepJson1.setData("updated test data");
		teststepJson1.setResult("updated expected result");
		teststepJson1.setId(stepId);

		Response response = zapiService.updateTeststep(jwtGenerator, projectId, issueId1, stepId,teststepJson1.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.err.println(response.getBody().asString());

		boolean status1 = zapiService.validateUpdatedTeststep(projectId, issueId1, teststepJson1.toString(), response);
		Assert.assertTrue(status1);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		extentReport.endTest(test);
	}

	/**
	 * Clone a teststep
	 * 
	 * clone teststep -1 - clone after , 0 - before, -2 - last step, position -
	 * position need to give
	 */
	@Test(priority = 9, enabled = testEnabled)
	public void bvt9_cloneTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
				teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
		System.out.println(teststepObj);
		extentReport.endTest(test);
		
		Long issueId = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");

		String payLoad = "{\"step\":\"step\",\"data\":\"data\",\"result\":\"result\",\"position\":\"-1\"}";
		
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Clone Testspep Api Response is null.");
		test.log(LogStatus.PASS, "Clone Testspep Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Clone Testspep Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Clone a teststep
	 * 
	 * Should able to Rearrange test step
	 */
	@Test(priority = 10, enabled = testEnabled)
	public void bvt10_moveTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueTypeTestId = Long.parseLong(Config.getValue("issueTypeTestId"));
		String issueKey = null;

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeTestId));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("id").toString();
		// System.out.println("this is the issue key "+ issueKey);
		issueId = Long.parseLong(issueKey);
		test.log(LogStatus.PASS, "Response validated successfully.");

		List<String> step = new ArrayList<>();
		step.add("8765rtfgjhy89iujhgv");
		step.add("&*()(*&^%$()+_)(*&^%$#@");
		step.add("");
		step.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		step.add("Nuevo status de ejecuci�n para coincidir con ejecuciones");

		List<String> stepData = new ArrayList<>();
		stepData.add("hsgytd87yhjuy89iu");
		stepData.add("+_)(*&^%$");
		stepData.add("");
		stepData.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepData.add("Zugangserlaubnis zu Zephyr f�r Jira Cloud bez�glich HipChat gew�hrt.");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("~!@#$%");
		stepRes.add("Supprimer cette �tape de statut d'ex�cution");
		stepRes.add("");
		stepRes.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepRes.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		System.out.println("Response:--> " + getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);

		JSONArray jsarray = new JSONArray(getResponse.getBody().asString());
		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(0);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response1 = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response1, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status1 = zapiService.validateMoveStep(srcStep, destStep, payLoad, response1);
		Assert.assertTrue(status1);
		test.log(LogStatus.PASS, "Move test step Api Response validated suuccessfully.");		
		extentReport.endTest(test);
	}

	/**
	 * Delete a teststep
	 */
	@Test(priority = 11, enabled = testEnabled)
	public void bvt11_deleteTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Delete test step with wiki format");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "create issue Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);
		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("h1. Biggest heading");
		TeststepJson.setData("h1. Biggest heading");
		TeststepJson.setResult("h1. Biggest heading");
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Test step API  Response is null.");
		test.log(LogStatus.PASS, "Create Test step API executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		TeststepJson.setStep("h1. Biggest heading");
		TeststepJson.setData("h1. Biggest heading");
		TeststepJson.setResult("h1. Biggest heading");
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Test step API  Response is null.");
		test.log(LogStatus.PASS, "Create Test step API executed successfully.");		
	
		String stepid1 = new JSONObject(response.body().asString()).get("id").toString();		
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Create Test step API Response validated suuccessfully.");
		
		test.log(LogStatus.PASS, "Create Test step API Response validated suuccessfully.");
		Response deletestepresponse = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid1);
		System.err.println("Delete test step Response" + deletestepresponse.getBody().asString());
		Assert.assertNotNull(response, "Delete Step Api Response is null.");
		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		System.out.println(deletestepresponse.getBody().asString());
		String S = deletestepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(deletestepresponse, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete teststep Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// get TestStep Statuses
	@Test(priority = 12, enabled = testEnabled)
	public void test12_getTeststepStatuses() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Response response = zapiService.getTeststepStatuses(jwtGenerator);
		Assert.assertNotNull(response, "get TestStep Statuses API Response is null.");
		test.log(LogStatus.PASS, "get TestStep Statuses APi  executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepStatuses(response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "get TestStep Statuses API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create a new cycle under planned version, with all fields filled.
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void test13_createCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle one created");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("1.0");
		cycleJson.setEnvironment("QA-Bench");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Create Cycle Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Cycle Api Response validated successfully.");
		cycleIdScheduledVersion = new JSONObject(response.body().asString()).get("id").toString();
		cycleIdScheduledVersionObj = new JSONObject(response.body().asString());
		extentReport.endTest(test);
	}

	/**
	 * Create Execution in an adhoc cycle, in unscheduled version of the project
	 */
	@Test(priority = 14)
	public void test14_createExecution_adhoc_unsheduled() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 15, enabled = testEnabled)
	public void test15_createExecution_sheduled_plannedCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(cycleIdScheduledVersionObj.getLong("projectId"));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleIdScheduledVersionObj.getString("id"));
		executionJson.setVersionId(cycleIdScheduledVersionObj.getLong("versionId"));
		// set the assignee
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
		String executionId = new JSONObject(new JSONObject(response.getBody().asString()).get("execution").toString())
				.getString("id");
		executionJson.setExecutionId(executionId);
		executionObject = executionJson.toString();
	}

	@Test(priority = 16, enabled = testEnabled)
	public void test16_createExecution_sheduled_plannedCycle_addAssigneeAsOtherUser() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		//executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	    executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
		//jsonResponse.getJSONArray("executios").length();
        String executionId= jsonResponse.getJSONObject("execution").getString("id");
		// set the assignee
		executionJson.setChangeAssignee(true);
		executionJson.setAssigneeType("assignee");
		executionJson.setAssignee(Config.getValue("accountId"));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
		//String executionId1 = new JSONObject(new JSONObject(response.getBody().asString()).get("execution").toString())
				//.getString("id");
		executionJson.setExecutionId(executionId);
		executionObject = executionJson.toString();
	}

	/**
	 * Get the execution statuses
	 */
	@Test(priority = 17, enabled = testEnabled)
	public void bvt17_getExecutionStatuses() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getExecutionStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Get Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Execution by issue id
	 */
	@Test(priority = 16, enabled = false)
	public void bvt16_getExecutionsByIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String issueIdOrKey = this.issueKey;
		int offset = 0;
		int size = 50;
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOrKey, offset, size);
		Assert.assertNotNull(response, "Get Execution By issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution By issue Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Get Execution By issue Api validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get execution by executionIid
	 */
	@Test(priority = 17, enabled = testEnabled)
	public void bvt17_getExecutionByExecutionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = new JSONObject(executionObject).getLong("projectId");
		Long issueId = new JSONObject(executionObject).getLong("issueId");
		String executionId = new JSONObject(executionObject).getString("id");
		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution By id Api Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution By id Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Get Execution By id API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add Multiple tests by issueids to planned Cycle ()
	 */
	@Test(priority = 18, enabled = testEnabled)
	public void bvt18_addTestsTocycle_individually() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));			
		String cycleId = "-1";		
		//String payLoad = "{\"issues\":[\"AT-30\",\"AT-31\"],\"versionId\":10011,\"projectId\":10006,\"method\":\"1\"}";		
		String payLoad = "{\"issues\":["+issueId+"],\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"1\"}";
		
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.err.println(response.getBody().asString());
		
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add Tests to a Cycle from another Cycle (no filter)
	 */
	@Test(priority = 19, enabled = testEnabled)
	public void bvt19_addTestsTocycle3_fromAnotherCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionOneid= Long.parseLong(Config.getValue("versionOneId"));
		Long versionTwoid= Long.parseLong(Config.getValue("versionTwoId"));
		String cycleId = "-1";	
		

		/*Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10006l);
		//Long projectId = cycleIdScheduledVersionObj.getLong("projectId");
		executionJson.setIssueId(10099l);
		executionJson.setVersionId(10009l);
		//Long versionOneId = cycleIdScheduledVersionObj.getLong("versionOneId");
		//Long versionTwoId = cycleIdScheduledVersionObj.getLong("versionTwoId");
		String cycleId = "18c6cfce-bc84-42df-ae8e-a01c4db0887a";
		//String cycleId = cycleIdScheduledVersionObj.getString("id");
*/		
		//String payLoad = "{\"versionId\":"+versionOneid+"fromVersionId\":\"+versionTwoid+",\"priorities\":\"\",\"statuses\":\"\",\"components\":\"\",\"labels\":\"\",\"hasDefects\":false,\"projectId\":10006,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"fromCycleId\":"+cycleId+"}";
		String payLoad = "{\"versionId\":"+versionOneid+",\"fromVersionId\":"+versionTwoid+",\"fromCycleId\":"+cycleId+",\"properties\":\"\",\"statauses\":\"\",\"components\":\"\",\"labels\":\"\",\"hasDefects\":false,\"clearCustomFieldsFlag\":true,\"projectId\":"+projectid+",\"method\":\"3\",\"withStatuses\":\"\"}";
	
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add Tests to a Cycle from another Cycle (with execution status fail or blocked and have linked defects)
	 */
	@Test(priority = 20, enabled = testEnabled)
	public void bvt20_addTestsTocycle3_from_another_cycle_with_status_and_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid1= Long.parseLong(Config.getValue("versionOneId"));
		Long versionId2= Long.parseLong(Config.getValue("versionTwoId"));
		String cycleId = "-1";	
		

		/*Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10006l);
		 executionJson.setIssueId(10069l);
		executionJson.setVersionId(10009l);
		String cycleId = "18c6cfce-bc84-42df-ae8e-a01c4db0887a";*/
	//	String payLoad = "{\"versionId\":10010,\"fromVersionId\":\"10009\",\"fromCycleId\":\"9ad7930b-b87a-4918-bbad-030e4b2e1ec7\",\"priorities\":\"\",\"statuses\":\"4\",\"components\":\"\",\"labels\":\"\",\"hasDefects\":true,\"withStatuses\":\"\",\"projectId\":10006\"method\":\"3\"}";
		String payLoad = "{\"versionId\":"+versionId2+",\"fromVersionId\":"+versionid1+",\"fromCycleId\":"+cycleId+",\"properties\":\"\",\"statauses\":\"4\",\"components\":\"\",\"labels\":\"\",\"hasDefects\":true,\"clearCustomFieldsFlag\":true,\"projectId\":"+projectid+",\"method\":\"3\",\"withStatuses\":\"\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add Tests to a Cycle by using Jira Filter(JQL)
	 */
	@Test(priority = 21, enabled = testEnabled)
	public void bvt21_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("Cycle with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);		
		
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND priority = Low\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add Tests to a Cycle by using Jira Filter(JQL) and add assignee to other user
	 */
	@Test(priority = 22, enabled = testEnabled)
	public void bvt22_addTestsTocycle_scheduled_plannedCycle_by_filter_and_asignee_to_otherUser() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFiveId"));
		String userUsername= Config.getValue("userUsername").toString();
		String projectKey = Config.getValue("projectKey");
		String userID= Config.getValue("userID");
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test "+System.currentTimeMillis());
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
			
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("Cycle with Add test to Cycle using Filter  with Assignee");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());

		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);		
		
		String payLoad = "{\"jql\":\"project="+projectKey+" AND issuetype=Test AND priority = Low\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"assigneeType\":\"assignee\",\"assigneeAccountId\":\""+userID+"\",\"method\":\"2\"}";
		//String payLoad = "{\"jql\":\"project=11404 AND issuetype=Test\",\"versionId\":11409,\"projectId\":11404,\"assigneeType\":\"assignee\",\"assignee\":\"2345\",\"changeAssignee\":true,\"method\":\"2\"}";
		System.err.println(payLoad);
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution by adding assignee to current user
	 */
	@Test(priority = 24, enabled = testEnabled)
	public void bvt24_updateExecution_changeAssigne() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString()).getString("id");
		// set the assignee
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update an execution by adding assignee to current user  Api Response is null.");
		test.log(LogStatus.PASS, "Update an execution by adding assignee to current user Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Update an execution by adding assignee to current user API Response Validation Failed.");
		test.log(LogStatus.PASS, "Update an execution by adding assignee to current user API Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Update an execution by adding assignee to current user API Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * 
	 * Update Execution to Default Status
	 */

	@Test(priority = 25, enabled = testEnabled)
	public void bvt25_updateExecution_defaultStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution to Default Status Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution to Default Status Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Update Execution to Default Status API Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Update Execution to Default Status API Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

	/**
	 * 
	 * Update Execution to Customized Status
	 */
	@Test(priority = 26, enabled = testEnabled)
	public void bvt26_updateExecution_customStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(5l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution to Customized Status Response is null.");
		test.log(LogStatus.PASS, "Update Execution to Customized Status Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Update Execution to Customized Status API Response Validation Failed.");
		test.log(LogStatus.PASS, "Update Execution to Customized Status API Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Update Execution to Customized Status API Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

	/**
	 * 
	 * Update Execution with single defect
	 * 
	 */

	@Test(priority = 27, enabled = testEnabled)
	public void bvt27_updateExecution_singleDefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Update Execution with single defect API Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Update Execution with single defect API Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking multiple defects
	 */
	@Test(priority = 28, enabled = testEnabled)
	public void bvt28_updateExecution_multipleDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Update an execution by linking multiple defects API Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Update an execution by linking multiple defects API Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by add and modify comment
	 */
	@Test(priority = 29, enabled = testEnabled)
	public void bvt29andbvt30_updateExecution_addAndModifyComment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("comment");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String comment = executionJson.getComment() + " edited";
		executionJson.setComment(comment);
		updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId, executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Update an execution by add and modify comment API Response validated suuccessfully.");
		extentReport.endTest(test);
		test.log(LogStatus.PASS, "Update an execution by add and modify comment API Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to current user, add a defect,update status to FAIL and add a sample comment
	 */
	@Test(priority = 31, enabled = testEnabled)
	public void bvt31_updateExecution_addAll() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setStatusId(2l);
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);
		// set the comment
		executionJson.setComment("\\");
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Update an execution by adding assignee to current user, add a defect,update status to FAIL and add a sample comment API Response Validation Failed.");
		test.log(LogStatus.PASS, "Update an execution by adding assignee to current user, add a defect,update status to FAIL and add a sample comment API Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Get the the of Cycle from a single version.
	 */
	@Test(priority = 32, enabled = testEnabled)
	public void bvt32_getCycle_by_cycleId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = cycleIdScheduledVersionObj.getLong("projectId");
		Long versionId = cycleIdScheduledVersionObj.getLong("versionId");
		String cycleId = cycleIdScheduledVersionObj.getString("id");

		Response response = zapiService.getCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleIdScheduledVersionObj.toString(), response);
		Assert.assertTrue(status, "Get the the of Cycle from a single version API Response not validated.");

		test.log(LogStatus.PASS, "Get the the of Cycle from a single version. API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get the List of Cycles from a single version.
	 * 
	 */
	@Test(priority = 33, enabled = testEnabled)
	public void test33_getCycles_of_singleVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, " Get the List of Cycles from a single version API Response is null.");
		test.log(LogStatus.PASS, " Get the List of Cycles from a single version API executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, " Get the List of Cycles from a single version API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update the Cycle by changing names and dates
	 * 
	 */
	@Test(priority = 34, enabled = testEnabled)
	public void bvt34_updateCycleIfCycleIsEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		// Creating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Empty Cycle");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		// Validating created cycle
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "create cycle API Response Validation Failed.");
		test.log(LogStatus.PASS, "create cycle API Response validated successfully.");

		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// Updating cycle
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Empty Cycle Updated");
		updateCycleJson.setBuild("#12345");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("Cycle desc");
		updateCycleJson.setStartDate("2016-11-14");
		updateCycleJson.setEndDate("2016-11-30");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		// Validating updated cycle
		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Update the Cycle by changing names and dates API Response Validation Failed.");
		test.log(LogStatus.PASS, "Update the Cycle by changing names and dates API Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle to another Version if empty
	 * @throws InterruptedException 
	 */
	@Test(priority = 35, enabled = testEnabled)
	public void bvt35_moveCycle_empty_cycle() throws InterruptedException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Moved Cycle");
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		// Set Description
		cycleJson.setDescription("Cycle moved from version -1");

		// Creating cycle
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();

		// Set version which we want move
		Long move_to_version = Long.parseLong(Config.getValue("versionTwoId"));
		cycleJson.setVersionId(move_to_version);
		Thread.sleep(1000);
		// Move cycle
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, " Cycle Api updateCycle Move cycle to another Version if empty API Response Validation Failed.");
		test.log(LogStatus.PASS, " Cycle Api updateCycle Move cycle to another Version if empty API Response validated suuccessfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, " Cycle Api updateCycle Move cycle to another Version if empty APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Clone partially executed planned Cycle
	 * @throws InterruptedException 
	 */
	@Test(priority = 36, enabled = testEnabled)
	public void bvt36_cloneCycle_Emptycycle() throws InterruptedException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Cycle_Emptycycle";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");

		// Create cycle
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		cycleJson.setName("CLONE-" + Cyclename);
		
		
		Thread.sleep(1000);

		// Cloning cycle
		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());

		// Validating clonned cycle
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		extentReport.endTest(test);
	}

	/**
	 * Delete partially executed planned Cycle
	 * 
	 */
	@Test(priority = 39, enabled = testEnabled)
	public void reg_tc39_deleteCycle_without_schdule() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleid = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleid);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleid);
		String myRes = response.getBody().asString();
		System.err.println(myRes);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleid, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export and download Cycle to CSV, HTML and XML Format
	 * 
	 */
	@Test(priority = 38, enabled = testEnabled)
	public void bvt37_bvt38_exportCycle_AllFormats() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		// Crating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Cycle for export");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		// Validating created cycle
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(versionId);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String cycleId = cycleId;
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "CSV Export cycle with Execution Api Response is null.");
		test.log(LogStatus.PASS, "CSV Export cycle with  Execution Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "CSV File not downloaded.");
		test.log(LogStatus.PASS, "CSV File downloaded successfully.");

		exportType = "HTML";
		Response responseOfHTMLExport = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId,
				exportType);
		Assert.assertNotNull(response, "HTML Export cycle with Execution Api Response is null.");
		test.log(LogStatus.PASS, "HTML Export cycle with  Execution Api executed successfully.");
		System.out.println(responseOfHTMLExport.getBody().asString());

		Response jobProgressResponseForHTMLExport = zapiService.jobProgressHandler(jwtGenerator,
				responseOfHTMLExport.getBody().asString());
		Assert.assertNotNull(jobProgressResponseForHTMLExport, "HTML Export cycle with  Execution Api Response is null.");
		String htmlfileName = new JSONObject(jobProgressResponseForHTMLExport.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, htmlfileName);
		Assert.assertTrue(status, "HTML File not downloaded.");
		test.log(LogStatus.PASS, "HTML File downloaded successfully.");

		exportType = "XML";
		Response responseOfXMLExport = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "XML Export cycle with Execution Api Response is null.");
		test.log(LogStatus.PASS, "XML Export cycle with Execution Api executed successfully.");
		System.out.println(responseOfXMLExport.getBody().asString());

		Response jobProgressResponseForXMLExport = zapiService.jobProgressHandler(jwtGenerator,responseOfXMLExport.getBody().asString());
		Assert.assertNotNull(jobProgressResponseForHTMLExport, "XML Export cycle with  Execution Api Response is null.");
		String xmlfileName = new JSONObject(jobProgressResponseForXMLExport.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, xmlfileName);
		Assert.assertTrue(status, "XML File not downloaded.");
		test.log(LogStatus.PASS, "XML File downloaded successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export and download Cycle to CSV Format
	 * 
	 */
	// @Test(priority = 37)
	public void bvt37_exportCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String cycleId = "-1";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "Export and download Cycle to CSV Format Api Response is null.");
		test.log(LogStatus.PASS, "Export and download Cycle to CSV Format Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Export and download Cycle to CSV Format API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Copy test executions with status and defects carried over
	 */
	@Test(priority = 39, enabled = testEnabled)
	public void bvt39_copyExecutionsToCycle_statusAndDefect_carried() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//Create issue1
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("summary1");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
		
		//Create Execution API1
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		
		
		//Create issue2
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("summary1");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				//
		boolean status1 = jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		issueKey = new JSONObject(response3.body().asString()).getString("key");
				
				//Create Execution API1
				
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject jsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(jsonResponse2.toString());
		System.out.println(jsonResponse2.get("execution").toString());
		String executionId2 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
	
		
		String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":false,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for copy execution");
		
		Response response5 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload1);
		System.out.println(response5.getBody().asString());
		Assert.assertNotNull(response5, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		response = zapiService.jobProgressHandler(jwtGenerator, response5.getBody().asString());
		System.out.println(response5.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Copy test executions to a different Cycle - by clearing statuses and carry defects
	 * 
	 */
	@Test(priority = 40, enabled = testEnabled)
	public void bvt40_copyExecutionsToCycle_clerastatus_carrieddefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//Create issue1
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("summary1");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
		
		//Create Execution API1
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		
		
		//Create issue2
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("summary1");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				//
		boolean status1 = jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		issueKey = new JSONObject(response3.body().asString()).getString("key");
				
				//Create Execution API1
				
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject jsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(jsonResponse2.toString());
		System.out.println(jsonResponse2.get("execution").toString());
		String executionId2 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
	
		
		String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":false,\"clearStatusFlag\":true,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for copy execution");
		
		Response response5 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload1);
		System.out.println(response5.getBody().asString());
		Assert.assertNotNull(response5, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		response = zapiService.jobProgressHandler(jwtGenerator, response5.getBody().asString());
		System.out.println(response5.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Copy test executions to a different Cycle - by clearing defects and carry statuses
	 * 
	 */
	@Test(priority = 41, enabled = testEnabled)
	public void bvt41_copyExecutionsToCycle_carriedStatus_clearDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//Create issue1
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("summary1");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
		
		//Create Execution API1
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		
		
		//Create issue2
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("summary1");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				//
		boolean status1 = jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		issueKey = new JSONObject(response3.body().asString()).getString("key");
				
				//Create Execution API1
				
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject jsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(jsonResponse2.toString());
		System.out.println(jsonResponse2.get("execution").toString());
		String executionId2 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
	
		
		String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for copy execution");
		
		Response response5 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload1);
		System.out.println(response5.getBody().asString());
		Assert.assertNotNull(response5, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		response = zapiService.jobProgressHandler(jwtGenerator, response5.getBody().asString());
		System.out.println(response5.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Copy test executions to a different Cycle - by clearing defects and statuses
	 * 
	 * 
	 */
	@Test(priority = 42, enabled = testEnabled)
	public void bvt42_copyExecutionsToCycle_clear_statusAndDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//Create issue1
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("summary1");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
		
		//Create Execution API1
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		
		
		//Create issue2
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("summary1");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				//
		boolean status1 = jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		issueKey = new JSONObject(response3.body().asString()).getString("key");
				
				//Create Execution API1
				
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject jsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(jsonResponse2.toString());
		System.out.println(jsonResponse2.get("execution").toString());
		String executionId2 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
	
		
		String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":true,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for copy execution");
		
		Response response5 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload1);
		System.out.println(response5.getBody().asString());
		Assert.assertNotNull(response5, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		response = zapiService.jobProgressHandler(jwtGenerator, response5.getBody().asString());
		System.out.println(response5.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Move test executions with defects and status carried
	 * 
	 */
	@Test(priority = 43, enabled = testEnabled)
	public void bvt43_moveExecutionsToCycle_statusAndDefect_carried() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//Create issue1
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("summary1");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
		
		//Create Execution API1
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		
		
		//Create issue2
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("summary1");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				//
		boolean status1 = jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		issueKey = new JSONObject(response3.body().asString()).getString("key");
				
				//Create Execution API1
				
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject jsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(jsonResponse2.toString());
		System.out.println(jsonResponse2.get("execution").toString());
		String executionId2 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
	
		
		String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":false,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for move execution");
		
		Response response30 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload1);
		Assert.assertNotNull(response30, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response30.getBody().asString());
		response30 = zapiService.jobProgressHandler(jwtGenerator, response30.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Move test executions to a different Cycle - by clearing statuses and carry defects
	 * 
	 */
	 @Test(priority = 44, enabled = testEnabled)
	public void bvt44_moveExecutionsToCycleByClearStatusCarryDefects() {
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long projectid= Long.parseLong(Config.getValue("projectId"));
			Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
			
			//Create issue1
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("summary1");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad.toString());
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			//
			boolean status = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
			issueKey = new JSONObject(response.body().asString()).getString("key");
			
			//Create Execution API1
			
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setIssueId(this.issueId);
			executionJson.setCycleId("-1");
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			System.out.println("Execution"+response1.getBody().asString());
			JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
			System.out.println(jsonResponse.toString());
			System.out.println(jsonResponse.get("execution").toString());
			String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
			
			
			
			//Create issue2
			Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad1.setSummary("summary1");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad.toString());
			Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response3, "Create Issue Api Response is null.");
					//
			boolean status1 = jiraService.validateCreateIssueApi(response3);
			Assert.assertTrue(status1, "Response Validation Failed.");
			issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
			issueKey = new JSONObject(response3.body().asString()).getString("key");
					
					//Create Execution API1
					
			Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson1.setIssueId(this.issueId);
			executionJson1.setCycleId("-1");
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response4, "Create Execution Api Response is null.");
			System.out.println("Execution"+response4.getBody().asString());
			JSONObject jsonResponse2 = new JSONObject(response4.getBody().asString());
			System.out.println(jsonResponse2.toString());
			System.out.println(jsonResponse2.get("execution").toString());
			String executionId2 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
			
			String cycleId = "-1";
			String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
			System.err.println(payload1+"payload for move execution");
			
			Response response30 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload1);
			Assert.assertNotNull(response30, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response30.getBody().asString());
			response30 = zapiService.jobProgressHandler(jwtGenerator, response30.getBody().asString());
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	}

	/**
	 * Bulk Move test executions to a different Cycle - by clearing defects and carry statuses
	 * 
	 */
	 @Test(priority = 45,enabled = testEnabled)
	public void bvt45_moveExecutionsToCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		//Long issueId1 = issueId;
		
		//creating issueid1
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response.body().asString()).getString("key");
		
		
		// Creating defect
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary1 " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));

			//Creating execution1 with associate defect

				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				//executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setProjectId(projectid);
				executionJson.setIssueId(this.issueId);
				executionJson.setCycleId("-1");
				//executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setVersionId(versionid);

				Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

				boolean status1 = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
				Assert.assertTrue(status1, "Create Execution Api Response Validation Failed.");
				test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

				String executionId1 = new JSONObject(
						new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
								.getString("id");
				// set the status to pass (1)
				 executionJson.setStatusId(1l);
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);
				executionJson.setDefects(defectsList);
				executionJson.setExecutionId(executionId1);
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId1,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());

				boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
						updateExecutionResponse);
				Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
				executionObject = executionJson.toString();
				
				//Creating execution2 with associate defect

				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				//executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setProjectId(projectid);
				executionJson1.setIssueId(this.issueId1);
				executionJson1.setCycleId("-1");
				//executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson1.setVersionId(versionid);

				Response createExecutionResponse1 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(createExecutionResponse1, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

				boolean status11 = zapiService.validateExecution(executionJson1.toString(), createExecutionResponse1);
				Assert.assertTrue(status11, "Create Execution Api Response Validation Failed.");
				test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

				String executionId2 = new JSONObject(
						new JSONObject(createExecutionResponse1.getBody().asString()).get("execution").toString())
								.getString("id");
				// set the status to pass (1)
				 executionJson1.setStatusId(1l);
				List<Long> defectsList1 = new ArrayList<>();
				defectsList.add(bugId);
				executionJson1.setDefects(defectsList1);
				executionJson1.setExecutionId(executionId2);
				Response updateExecutionResponse1 = zapiService.updateExecution(jwtGenerator, executionId2,
						executionJson1.toString());
				Assert.assertNotNull(updateExecutionResponse1, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse1.getBody().asString());

				boolean updateExecutionStatus1 = zapiService.validateExecution(executionJson1.toString(),
						updateExecutionResponse1);
				Assert.assertTrue(updateExecutionStatus1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
			

		String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for move execution");
		//String payload = "{\"executions\":[\"0001481183453148-242ac112-0001\",\"0001481183408728-242ac112-0001\"],\"projectId\":11201,\"versionId\":11201,\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		
		Response response30 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload1);
		Assert.assertNotNull(response30, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response30.getBody().asString());
		response30 = zapiService.jobProgressHandler(jwtGenerator, response30.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Move test executions to a different Cycle - by clearing defects and statuses
	 */
	@Test(priority = 46, enabled = testEnabled)
	public void bvt46_moveExecutionsToCycle_clear_statusAndDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//creating issueid1
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response, "Create Issue Api Response is null.");
				//
				boolean status = jiraService.validateCreateIssueApi(response);
				Assert.assertTrue(status, "Response Validation Failed.");
				issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response.body().asString()).getString("key");
				
				// Creating defect
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary1 " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				
				//Creating execution1 with associate defect

				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				//executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setProjectId(projectid);
				executionJson.setIssueId(this.issueId);
				executionJson.setCycleId("-1");
				//executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson.setVersionId(versionid);

				Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

				boolean status1 = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
				Assert.assertTrue(status1, "Create Execution Api Response Validation Failed.");
				test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

				String executionId1 = new JSONObject(
						new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
								.getString("id");
				// set the status to pass (1)
				 executionJson.setStatusId(1l);
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);
				executionJson.setDefects(defectsList);
				executionJson.setExecutionId(executionId1);
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId1,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());

				boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
						updateExecutionResponse);
				Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
				executionObject = executionJson.toString();
				
				//Creating execution2 with associate defect

				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
			//	executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setProjectId(projectid);
				executionJson1.setIssueId(this.issueId1);
				executionJson1.setCycleId("-1");
				//executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				executionJson1.setVersionId(versionid);

				Response createExecutionResponse1 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(createExecutionResponse1, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

				boolean status11 = zapiService.validateExecution(executionJson1.toString(), createExecutionResponse1);
				Assert.assertTrue(status11, "Create Execution Api Response Validation Failed.");
				test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

				String executionId2 = new JSONObject(
						new JSONObject(createExecutionResponse1.getBody().asString()).get("execution").toString())
								.getString("id");
				// set the status to pass (1)
				 executionJson1.setStatusId(1l);
				List<Long> defectsList1 = new ArrayList<>();
				defectsList.add(bugId);
				executionJson1.setDefects(defectsList1);
				executionJson1.setExecutionId(executionId2);
				Response updateExecutionResponse1 = zapiService.updateExecution(jwtGenerator, executionId2,
						executionJson1.toString());
				Assert.assertNotNull(updateExecutionResponse1, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse1.getBody().asString());

				boolean updateExecutionStatus1 = zapiService.validateExecution(executionJson1.toString(),
						updateExecutionResponse1);
				Assert.assertTrue(updateExecutionStatus1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);	
		
		
		String cycleId = "-1";
		//String payload = "{\"executions\":[\"0001481359285270-242ac112-0001\",\"0001481359286025-242ac112-0001\"],\"projectId\":11404,\"versionId\":11408,\"clearDefectMappingFlag\":true,\"clearStatusFlag\":true,\"clearAssignmentsFlag\":true}";

		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":true,\"clearAssignmentsFlag\":true}";
		System.err.println(payload1+"payload for move execution");
		
		Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload1);
		Assert.assertNotNull(response11, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a created Execution
	 */
	@Test(priority = 48, enabled = testEnabled)
	public void bvt48_deleteExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		// Long issueId = issueId;
		String executionId = new JSONObject(new JSONObject(response.getBody().asString()).get("execution").toString()).getString("id");
		// String executionId = "0001481359285270-242ac112-0001";

		Response deleteResponse = zapiService.deleteExecution(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(deleteResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Delete Execution Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean flag = zapiService.validateDeletedExecution(executionId, deleteResponse);
		Assert.assertTrue(flag, "Execution Not deleted Successfully");
		test.log(LogStatus.PASS, "Delete a created Execution API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Execution by cycle id of adhoc cycle, in unscheduled version of the project
	 * 
	 */
	@Test(priority = 49, enabled = testEnabled)
	public void bvt49_getExecutionsByCycle_adhoc_unscheduled() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = -1l;
		String cycleId = "-1";

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, 0, 50);
		Assert.assertNotNull(response, "Get Execution by cycle id of adhoc cycle, in unscheduled version Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution by cycle id of adhoc cycle, in unscheduled version Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean flag = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, 0, 50);
		Assert.assertTrue(flag, "Get Execution by cycle id of adhoc cycle, in unscheduled version API Not Validated");
		test.log(LogStatus.PASS, "Get Execution by cycle id of adhoc cycle, in unscheduled version API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Execution by cycle id of non-adhoc cycle, in scheduled version of the project
	 * 
	 */
	@Test(priority = 50, enabled = testEnabled)
	public void bvt50_getExecutionsByCycle_planeedCycle_scheduled() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		// Creating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Get Executions from cycle");
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "create Cycle API Api Response is null.");
		test.log(LogStatus.PASS, "create Cycle API Api executed successfully.");

		// Validating created cycle
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "create Cycle API Response Validation Failed.");
		test.log(LogStatus.PASS, "create Cycle API Response validated successfully.");

		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(versionId);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "create Execution API Response Validation Failed.");
		test.log(LogStatus.PASS, "create Execution API  Response validated suuccessfully.");

		
//		String cycleId = "0001481367113402-242ac112-0001";

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, 0, 50);
		Assert.assertNotNull(response, " Get Execution by cycle id of non-adhoc cycle, in scheduled version of the project Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution by cycle id of non-adhoc cycle, in scheduled version of the project Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean flag = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, 0, 50);
		Assert.assertTrue(flag, "Get Execution by cycle id of non-adhoc cycle, in scheduled version of the project Response validation Failed");
		test.log(LogStatus.PASS, "Get Execution by cycle id of non-adhoc cycle, in scheduled version of the project Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get executions by issueId
	 * 
	 */
	@Test(priority = 50, enabled = testEnabled)
	public void bvt50_getExecutionByIssueId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Sagar Mule");
		Long issueId1 = issueId;
		System.err.println(issueId);
		
		//Create Execution API
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("Execution"+response.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
		//jsonResponse.getJSONArray("executios").length();
        String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		int offset = 0;
		int size = 10;

		Response response1 = zapiService.getExecutionsByIssue(jwtGenerator, issueId1, offset, size);
		Assert.assertNotNull(response1, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response1.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response1, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get the executionSummaries By SprintAndIssue
	 * 
	 */
	@Test(priority = 2, enabled = testEnabled)
	public void getExecutionSummariesBySprintAndIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//String issueIdOrKey = "10000";
		String issueKey = "issueKey";
		System.err.println(issueKey);
		
		//Create Execution API
		
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(this.issueId);
				executionJson.setCycleId("-1");
			    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				System.out.println("Execution"+response.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
				//jsonResponse.getJSONArray("executios").length();
		        String executionId1 = jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		
		int offset = 0;
		int size = 10;

		Response response1 = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, 1l, issueKey);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 *  partially executed planned Folder
	 * 
	 */
    @Test()
    public void bvt_partially_executed_planned_Folder() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson.setName("Cycle one created");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("Environment");		
		Response Cycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		JSONObject responseJsonObject = new JSONObject(Cycleresponse.getBody().asString()); 
		//String responseData = Cycleresponse.getBody().asString();
		String CycleId =responseJsonObject.getString("id").toString();	
		System.out.println(Cycleresponse.getBody().asString());
		System.out.println("Cycleid"+CycleId);
		String foldername = "Folder" + System.currentTimeMillis();
		String FolderRequestpayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+Config.getValue("versionFourId")+",\"projectId\":"+Config.getValue("projectId")+"}";
		
		Response FolderResponse = zapiService.createFolderCycle(jwtGenerator, FolderRequestpayload);
		JSONObject FolderResponseObj = new JSONObject(FolderResponse.getBody().asString());
		System.out.println(FolderResponse.getBody().asString());
		
		Assert.assertNotNull(FolderResponse, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "create Folder Api executed successfully.");
		System.out.println(FolderResponse.getBody().asString());
		String FolderId = FolderResponseObj.getString("id").toString(); 

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		//Add executions to folder
		Execution executionJson = new Execution();
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		//executionJson.setFolderId(FolderId);;
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		 Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId(CycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject ExecutionjsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(ExecutionjsonResponse2.toString());
		System.out.println(ExecutionjsonResponse2.get("execution").toString());
		
		Response response = zapiService.clonedFolder(jwtGenerator, cycleId, cycleJson.toString());

		System.out.println(response);

}


	/*
	 * Bulk Update Status of test executions exclude stepstatus
	 */
	 
	 
	@Test(priority = 52, enabled = testEnabled)
	public void bvt52_updateBulkStatus_only_testStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));
		
		//creating issueid1
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test for update ststus");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response3 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				
				boolean status3= jiraService.validateCreateIssueApi(response3);
				Assert.assertTrue(status3, "Response Validation Failed.");
				issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response3.body().asString()).getString("key");
				
				//creating teststep for issueid

				Teststep teststepJson = new Teststep();
				teststepJson.setStep("step");
				teststepJson.setData("data");
				teststepJson.setResult("result");

				Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectid, issueId,
				teststepJson.toString());
				Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
				test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
				System.out.println(createTeststepResponse.getBody().asString());

				boolean createTeststepValidationStatus = zapiService.validateTeststep(projectid, issueId,
				teststepJson.toString(), createTeststepResponse);
				Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
				test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

				teststepObj = new JSONObject(createTeststepResponse.body().asString());
				System.out.println(teststepObj);
				extentReport.endTest(test);
						
						//creating teststep for issueid1

				Teststep teststepJson1= new Teststep();
				teststepJson1.setStep("step1");
				teststepJson1.setData("data1");
				teststepJson1.setResult("result1");

				Response createTeststepResponse1 = zapiService.createTeststep(jwtGenerator, projectid, issueId1,
				teststepJson1.toString());
				Assert.assertNotNull(createTeststepResponse1, "Create Teststep Api Response is null.");
				test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
				System.out.println(createTeststepResponse1.getBody().asString());

				boolean createTeststepValidationStatus1 = zapiService.validateTeststep(projectid, issueId1,
				teststepJson1.toString(), createTeststepResponse1);
				Assert.assertTrue(createTeststepValidationStatus1, "Create Teststep Api response not validated.");
				test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

				teststepObj = new JSONObject(createTeststepResponse1.body().asString());
				System.out.println(teststepObj);
				extentReport.endTest(test);
		
		//Create Execution1 API
		
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				//executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setProjectId(projectid);
				executionJson1.setIssueId(this.issueId);
				executionJson1.setCycleId("-1");
			   // executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			    executionJson1.setVersionId(versionid);
				Response response1 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response1, "Create Execution Api Response is null.");
				System.out.println("Execution"+response1.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response1.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
				//jsonResponse.getJSONArray("executios").length();
		        String executionId1 = jsonResponse1.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
		        
		      //Create Execution2 API
				
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				//executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setProjectId(projectid);
				executionJson.setIssueId(this.issueId1);
				executionJson.setCycleId("-1");
			   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			    executionJson.setVersionId(versionid);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
				//jsonResponse.getJSONArray("executios").length();
		        String executionId= jsonResponse.getJSONObject("execution").getString("id"); //.getJSONObject("execution")

		//String payLoad = "{\"executions\":[\"0001481357725960-242ac112-0001\",\"0001481359286025-242ac112-0001\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
		String payLoad ="{\"executions\":[\""+executionId1+"\",\""+executionId+"\"],\"status\":1,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Bulk Update Status of test executions including Steps
	 */
	@Test(priority = 53, enabled = testEnabled)
	public void bvt53_updateBulkStatus_withStepStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));
		//Long versionTwoid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//creating issueid1
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test with steps for bulk status update");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
		
		boolean status3= jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status3, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response3.body().asString()).getString("key");
		
		//creating teststep for issueid

		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectid, issueId,
		teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectid, issueId,
		teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
		System.out.println(teststepObj);
		extentReport.endTest(test);
				
		//creating teststep for issueid1

		Teststep teststepJson1= new Teststep();
		teststepJson1.setStep("step1");
		teststepJson1.setData("data1");
		teststepJson1.setResult("result1");

		Response createTeststepResponse1 = zapiService.createTeststep(jwtGenerator, projectid, issueId1,
		teststepJson1.toString());
		Assert.assertNotNull(createTeststepResponse1, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse1.getBody().asString());

		boolean createTeststepValidationStatus1 = zapiService.validateTeststep(projectid, issueId1,
		teststepJson1.toString(), createTeststepResponse1);
		Assert.assertTrue(createTeststepValidationStatus1, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse1.body().asString());
		System.out.println(teststepObj);
		extentReport.endTest(test);
						
		//Create Execution1 API
						
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
						//executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setProjectId(projectid);
			executionJson.setIssueId(this.issueId);
			executionJson.setCycleId("-1");
					  //  executionJson.setVersionId(Long.parseLong(Config.getValue("versionid")));
		    executionJson.setVersionId(versionid);
			Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			System.out.println("Execution"+response1.getBody().asString());
			JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
			System.out.println(jsonResponse.toString());
			System.out.println(jsonResponse.get("execution").toString());
						//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
						//jsonResponse.getJSONArray("executios").length();
	        String executionId2 = jsonResponse.getJSONObject("execution").getString("id"); 
				        
		    //Create Execution2 API
						
			Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
						//executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson1.setProjectId(projectid);
			executionJson1.setIssueId(this.issueId1);
			executionJson1.setCycleId("-1");
					   // executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		    executionJson1.setVersionId(versionid);
		    Response response2 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		    Assert.assertNotNull(response2, "Create Execution Api Response is null.");
			System.out.println("Execution"+response2.getBody().asString());
			JSONObject jsonResponse2 = new JSONObject(response2.getBody().asString());
			System.out.println(jsonResponse2.toString());
			System.out.println(jsonResponse2.get("execution").toString());
						//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
						//jsonResponse.getJSONArray("executios").length();
			String executionId1 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")

						
		//String payLoad = "{\"executions\":[\"0001481357725960-242ac112-0001\",\"0001481359286025-242ac112-0001\"],\"status\":3,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
		String payLoad = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"status\":3,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Add assignee to bulk executions
	 */

	@Test(priority = 54, enabled = testEnabled)
	public void bvt54_assignBulkExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));
		String userUsername= Config.getValue("userUsername").toString();
		String userID=Config.getValue("userID").toString();
		//creating issueid1
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test with for bulk assignee");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				
		boolean status3= jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status3, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response3.body().asString()).getString("key");
		
		//Create Execution1 API
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(versionid);
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		 String executionId2 = jsonResponse.getJSONObject("execution").getString("id"); 
		 
		//Create Execution2 API
			
			Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(projectid);
			executionJson1.setIssueId(this.issueId1);
			executionJson1.setCycleId("-1");
		    executionJson1.setVersionId(versionid);
		    Response response2 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		    Assert.assertNotNull(response2, "Create Execution Api Response is null.");
			System.out.println("Execution"+response2.getBody().asString());
			JSONObject jsonResponse2 = new JSONObject(response2.getBody().asString());
			System.out.println(jsonResponse2.toString());
			System.out.println(jsonResponse2.get("execution").toString());
			String executionId1 = jsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
			String adminAccountId = Config.getValue("accountId");
			String payLoad = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"assigneeType\":\"assignee\",\"assignee\":\""+adminAccountId+"\",\"assigneeAccountId\":\""+adminAccountId+"\"}";
		
			System.out.println(payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Bulk delete executions of non-adhoc cycle, in scheduled version of the project
	 */
	@Test(priority = 55, enabled = testEnabled)
	public void bvt55_deleteBulkExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFiveId"));
		
		//creating issueid1
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test created for delete the testcases");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response3 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				
				boolean status = jiraService.validateCreateIssueApi(response3);
				Assert.assertTrue(status, "Response Validation Failed.");
				issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
				String issueKey1 = new JSONObject(response3.body().asString()).getString("key");
		
		//create Cycle code 
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectid);
				cycleJson.setVersionId(versionid);
				cycleJson.setName("2Cycle with Add test to Cycle using individually");
				cycleJson.setDescription("Cycle one desc");
				cycleJson.setBuild(Config.getValue("connectBuildNumber"));
				cycleJson.setEnvironment("QA-environment");
				Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				System.out.println(createcycleresponse.getBody().asString());
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
				System.out.println(Cycleid);
				
		
//Create Execution1 API
				
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectid);
				executionJson1.setIssueId(this.issueId);
				executionJson1.setCycleId(Cycleid);
			    executionJson1.setVersionId(versionid);
				Response response1 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response1, "Create Execution Api Response is null.");
				System.out.println("Execution"+response1.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response1.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
				//jsonResponse.getJSONArray("executios").length();
		        String executionId1= jsonResponse.getJSONObject("execution").getString("id"); 
		        
//Create Execution2 API
				
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectid);
				executionJson.setIssueId(this.issueId1);
				executionJson.setCycleId(Cycleid);
			    executionJson.setVersionId(versionid);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				//System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
				//jsonResponse.getJSONArray("executios").length();
		        String executionId2= jsonResponse1.getJSONObject("execution").getString("id");
		        
		//String payLoad = "{\"executions\":[\"0001481357725960-242ac112-0001\",\"0001481359286025-242ac112-0001\"]}";
		String payLoad = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get executions by zql (for example : �project = IE�)
	 */
	@Test(priority = 56, enabled = testEnabled)
	public void bvt56_getExecutionsByZQL() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(versionId);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		
		String projectKey = Config.getValue("projectKey");
		String executionId = new JSONObject(new JSONObject(response.getBody().asString()).get("execution").toString())
				.getString("id");
//		//String executionId = "0001488538319862-242ac112-0001";
		String payLoad = "{\"maxRecords\":20,\"offset\":0,\"zqlQuery\":\"project = "+projectKey+"\"}";
		Response response1 = zapiService.getExecutionsByZQL(jwtGenerator, executionId, payLoad);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get step result of an execution by providing stepresultId and execution id
	 */
	@Test(priority = 57, enabled = false)
	public void bvt57_getStepResult_by_stepResultId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create Test with test steps 
		//create Execution with that test has step
		//Get Execution id and Get Step result Id 

		String executionId = "0001481359286206-242ac112-0001";
		String stepResultId = "0001481370178329-242ac112-0001";
		Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
		Assert.assertNotNull(response, "Get step result of an execution by providing stepresultId and execution id Api Response is null.");
		test.log(LogStatus.PASS, "Get step result of an execution by providing stepresultId and execution id Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateStepResult(stepResultId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Get step result of an execution by providing stepresultId and execution id API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get step results of an execution by providing issueId and executionId
	 * 
	 */
	@Test(priority = 58, enabled = false)
	public void bvt58_getStepResults_by_issueId_and_executionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create Test with test steps 
		//create Execution with that test has step
		//Get Execution id and issue ID 
		
		String executionId = "0001481359286206-242ac112-0001";
		Long issueId = 15719l;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Get step results of an execution by providing issueId and executionId Api Response is null.");
		test.log(LogStatus.PASS, "Get step results of an execution by providing issueId and executionId Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Get step results of an execution by providing issueId and executionId API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the step result with status to default status
	 * 
	 */
	@Test(priority = 59, enabled = false)
	public void bvt59_updateStepResult_defaultStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create Test with test steps 
		//create Execution with that test has step
		//Get Execution id and Get Step result Id 
		// Long projectId = 11404l;
		
		String stepResultId = "0001481370178329-242ac112-0001";
		String executionId = "0001481370178329-242ac112-0001";
		String stepId= "0001481370140007-242ac112-0001";
		String payLoad = "{\"status\":{\"id\":2},\"issueId\":15719,\"stepId\":\"0001481370140007-242ac112-0001\",\"executionId\":\"0001481359286206-242ac112-0001\"}";

		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, payLoad);
		Assert.assertNotNull(response, "Update the step result with status to default status Api Response is null.");
		test.log(LogStatus.PASS, "Update the step result with status to default status Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Update the step result with status to default status API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the step result with status to custom status
	 * 
	 */
	@Test(priority = 60, enabled = false)
	public void bvt60_updateStepResult_customStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Long projectId = 11201l;
		String stepResultId = "0001481370178329-242ac112-0001";
		String executionId = "0001481370178329-242ac112-0001";
		String stepId= "0001481370140007-242ac112-0001";
		
		String payLoad = "{\"status\":{\"id\":6},\"issueId\":15719,\"stepId\":\"0001481370140007-242ac112-0001\",\"executionId\":\"0001481359286206-242ac112-0001\"}";

		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, payLoad);
		Assert.assertNotNull(response, "Update the step result with status to custom status Api Response is null.");
		test.log(LogStatus.PASS, "Update the step result with status to custom status Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Update the step result with status to custom status API Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the step result with new defects associated
	 * 
	 */
	@Test(priority = 61, enabled = false)
	public void bvt61_updateStepResult_with_defect_added() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Long projectId = 11201l;
		String stepResultId = "0001481370178329-242ac112-0001";

		String payLoad = "{\"defects\":[15726],\"executionId\":\"0001481359286206-242ac112-0001\",\"issueId\":15719,\"stepId\":\"0001481370140007-242ac112-0001\"}";

		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the step result with existing defects associated
	 * 
	 */
	@Test(priority = 62, enabled = testEnabled)
	public void bvt62_updateStepResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");

		
		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
				//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
						new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
								.getString("id");
				
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
						executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),updateExecutionResponse);
		//to get step result id
		Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		System.out.println(StepResultsresponse.getBody().asString());
		
		JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
		JSONArray value = js1.getJSONArray("stepResults");
		JSONObject stepResult = value.getJSONObject(0);
		String stepresultid = stepResult.get("id").toString();
		stepId= stepResult.get("stepId").toString();
		executionId =stepResult.get("executionId").toString();
		issueId =Long.parseLong(stepResult.get("issueId").toString());
		System.err.println(stepresultid);
		
		String payLoad = "{\"executionId\":\"" +executionId+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +" ,\"defects\":["+ bugId +"]}";
		System.err.println(payLoad);

		//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

		Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response2.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the step result with comments associated
	 * 
	 * 
	 */
	@Test(priority = 63, enabled = false)
	public void bvt63_updateStepResult_with_comment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Long projectId = 11201l;
		String stepResultId = "0001481370178329-242ac112-0001";

		String payLoad = "{\"comment\":\"comment added\",\"stepId\":\"0001481370140007-242ac112-0001\",\"executionId\":\"0001481359286206-242ac112-0001\",\"issueId\":15719}";

		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the step result with status, comment and defect associated
	 * 
	 */
	@Test(priority = 64, enabled = false)
	public void bvt64_updateStepResult_with_StatusCommentAndDefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Long projectId = 11201l;
		String stepResultId = "0001481370178329-242ac112-0001";

		String payLoad = "{\"status\":{\"id\":3},\"defects\":[15725],\"comment\":\"comment edited\",\"stepId\":\"0001481370140007-242ac112-0001\",\"executionId\":\"0001481359286206-242ac112-0001\",\"issueId\":15719}";

		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the step defects id by providing projectId and executionId
	 * 
	 */
	@Test
	public void bvt65_getStepDefectsByExecutionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		JSONObject stepid = new JSONObject(createTeststepResponse.body().asString());
		
		String stepId = stepid.getString("id");
		
		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
				//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
						new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
								.getString("id");
				
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
						executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),updateExecutionResponse);
		//to get step result id
		Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		System.out.println(StepResultsresponse.getBody().asString());
		
		JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
		JSONArray value = js1.getJSONArray("stepResults");
		JSONObject stepResult = value.getJSONObject(0);
		String stepresultid = stepResult.get("id").toString();
		stepId= stepResult.get("stepId").toString();
		executionId =stepResult.get("executionId").toString();
		issueId =Long.parseLong(stepResult.get("issueId").toString());
		System.err.println(stepresultid);
		
		String payLoad = "{\"executionId\":\"" +executionId+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +" ,\"defects\":["+ bugId +"]}";
		System.err.println(payLoad);
		Response response1 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.err.println(response1.getBody().asString());System.out.println(response1.getStatusCode());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
				
		Response response2 = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response2.getBody().asString());

		boolean status2 = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response2);
		Assert.assertTrue(status2);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the stepresults statuses // already added previously
	 */
	// @Test(priority = 66)
	public void bvt66_getStepResultByStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Response response = zapiService.getTeststepStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepStatuses(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the executionCount by providing projectId, versionId and groupFld
	 * 
	 */
	@Test(priority = 67, enabled = false)
	public void bvt67_getExecutionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String groupFld = "cycle";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the top defects by providing projectId, versionId , issueStatuses
	 * 
	 */
	@Test(priority = 68, enabled = false)
	public void bvt_68getTopDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 11404l;
		Long versionId = 11408l;
		int issueStatuses = 10200;
		int howMany = 10;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the testDistributionCount by providing projectId, versionId and cycle
	 * 
	 */
	@Test(priority = 69, enabled = false)
	public void bvt69_getTestDistributionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 11404l;
		Long versionId = 11408l;
		String cycleId = "-1";
		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the list of tests created for a periodic time(for example 30days)
	 * 
	 */
	@Test(priority = 70, enabled = false)
	public void getTestsCreated() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 11404l;
		int daysPrevious = 30;
		String periodName = "daily";
		int maxResults = 5;
		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the list of executions created for a periodic time(for example
	 * 30days)
	 * 
	 */
	@Test(priority = 71, enabled = false)
	public void bvt71_getExecutionsCreated() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 11404l;
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Export test executions in CSV format
	 */
	@Test(priority = 72, enabled = false)
	public void bvt72_exportExecutions_csv() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "-1";
		String exportType = "CSV";
		String payLoad = "{\"exportType\":\"csv\",\"expand\":\"teststeps\",\"executions\":[\"0001481183087512-242ac112-0001\"],\"startIndex\":0,\"maxAllowed\":true,\"zqlQuery\":\"project = Troy\"}";

		Response response = zapiService.exportExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadExecutionsExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Export test executions in HTML format
	 */
	// @Test(priority = 73)
	public void bvt73_exportExecutions_html() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "-1";
		String exportType = "HTML";
		String payLoad = "{\"exportType\":\"html\",\"expand\":\"teststeps\",\"executions\":[\"0001481183087512-242ac112-0001\"],\"startIndex\":0,\"maxAllowed\":true,\"zqlQuery\":\"project = Troy\"}";

		Response response = zapiService.exportExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadExecutionsExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment at test level(JPEG) by providing entityName, entityId,
	 * projectId, issueId, cycleId, versionId
	 */

	// @Test(priority = 74)
	public void bvt74_addAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 11200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "addins";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		/*boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");*/
		extentReport.endTest(test);
	}

	/**
	 * Get the execution Attachments List by providing entityId(execution Id)
	 * 
	 */

	// @Test(priority = 75)
	public void bvt75_getExecutionAttachmentsList_test2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "11201";
		String issueId = "12275";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		/*Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");*/
		extentReport.endTest(test);
	}

	/**
	 * Should able to add attachment at step level(PNG) by providing entityName,
	 * entityId, executionId, projectId, issueId, cycleId, versionId
	 */
	// @Test(priority = 76)
	public void bvt76_addAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480414409285-242ac1123-0001";
		Long projectId = 11201l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		/*boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");*/
		extentReport.endTest(test);
	}

	/**
	 * Get the step level execution Attachments List by providing
	 * entityId(stepresultId)
	 * 
	 */

	// @Test(priority = 77)
	public void bvt77_getStepResultAttachmentsList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String stepResultId = "0001480513561347-242ac1124-0001";
		String projectId = "11201";
		String issueId = "12275";
		Response response = zapiService.getStepResultAttachmentsList(jwtGenerator, stepResultId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		/*Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");*/
		extentReport.endTest(test);
	}

	/*
	 * Get the attachment thumbnail of added attachment by providing
	 * attachmentId
	 * 
	 */
	// @Test(priority = 78)
	public void bvt78_getAttachmentThumbnail() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001479733330468-242ac111e-0001";
		Response response = zapiService.getAttachmentThumbnail(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the attachmentImage of added attachment by providing attachmentId
	 * 
	 */
	// @Test(priority = 79)
	public void bvt79_getAttachmentImage() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001479733330468-242ac111e-0001";
		Response response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Delete an attachment at test level by providing attachmentId
	 * 
	 */
	// @Test(priority = 80)
	public void bvt80_deleteAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001480521683914-242ac112-0001";
		Response response = zapiService.deleteAttachment(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Delete an attachment at step level by providing attachmentId
	 * 
	 */
	// @Test(priority = 81)
	public void bvt81_deleteAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001480521683997-242ac112-0001";
		Response response = zapiService.deleteAttachment(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get all the ZQLFieldConfiguration
	 * 
	 */
	// @Test(priority = 82)
	public void bvt82_getZQLFieldConfiguration() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getZQLFieldConfiguration(jwtGenerator);
		Assert.assertNotNull(response, "getZQLFieldConfiguration Api Response is null.");
		test.log(LogStatus.PASS, "getZQLFieldConfiguration Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldConfiguration(response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldConfiguration Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get ZQLFieldValues
	 * 
	 */
	// @Test(priority = 83)
	public void bvt83_getZQLFieldValues() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject json = new JSONObject();

		Response getAllProjectResponse = jiraService.getProjects(basicAuth, "2");
		Assert.assertNotNull(getAllProjectResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(getAllProjectResponse.getBody().asString());
		JSONArray projectJsonArray = new JSONArray(getAllProjectResponse.getBody().asString());
		json.put("project", projectJsonArray);

		Response response = zapiService.getZQLFieldValues(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldValues(json, response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldValues Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Execute the zql query i.e cycleName = cycle
	 */
	 @Test(priority = 84, enabled = testEnabled)
	public void bvt84_SearchZqlFilter_by_project_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Sagar mule");
		String projectName =Config.getValue("projectName");
		String zqlQuery ="project = "+projectName+"";
		System.out.println(zqlQuery);
		int offset = 0;
		int maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}

	/*
	 * Create a private zql filter
	 * 
	 */

	// @Test(priority = 85)
	public void bvt85_getZQLAutoComplete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "fixVersion";
		String fieldValue = "v";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 86)
	public void bvt86_createZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = TROY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");

		System.out.println(zqlfilterJson.toString());
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response : " + response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the private /Own zql filter
	 * 
	 */
	// @Test(priority = 87)
	public void bvt87_getZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter("get filter");
		zqlfilterJson.setZql("project = TROY");
		zqlfilterJson.setName("Get api filter" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();

		response = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update the zql Filter private to public filter and add the description
	 * 
	 */
	// @Test(priority = 88)
	public void bvt88_updateFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = TROY");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");
		zqlfilterJson.setSharePerm("global");

		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Copy the zql filter
	 * 
	 */
	// @Test(priority = 89)
	public void bvt89_copyFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlfilterJson = new Zqlfilter("copy filter");
		zqlfilterJson.setZql("project = TROY");
		zqlfilterJson.setName("copy api filter for copy " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");

		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		// Copy filter
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());

		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Update to favourite filter
	 */
	// @Test(priority = 90)
	public void bvt90_updateFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = TROY");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");
		zqlfilterJson.setFavorite(true);

		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the list of favourite zql filters
	 * 
	 */
	// @Test(priority = 91)
	public void getFavouriteZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the list of my zql filters
	 * 
	 */
	// @Test(priority = 92)
	public void bvt92_getMyZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Quick Search the zql filter
	 * 
	 */
	// @Test(priority = 93)
	public void bvt93_quickSearchZQLFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String filterName = "ppp";
		Response response = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// status = zapiService.validateZQLFilter(zqlfilterJson.toString(),
		// response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Search the zql filter by providing name
	 * 
	 */
	@Test(priority = 94, enabled = testEnabled)
	public void bvt94_searchZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String projectKey = Config.getValue("projectKey");
		
		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		Response beforeResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(beforeResponse, "Search the zql filter by providing name Api Response is null.");
		test.log(LogStatus.PASS, "Search the zql filter by providing name Api executed successfully.");
		System.err.println(beforeResponse.getBody().asString());
		
		
		//create zqlfilter
				Zqlfilter zqlfilterJson1 = new Zqlfilter("create filter");
				//zqlfilterJson.setZql("project = TROY");
				zqlfilterJson1.setZql("project = "+projectKey+"");
				zqlfilterJson1.setName("zapi" + System.currentTimeMillis());
				zqlfilterJson1.setFavorite(true);
				zqlfilterJson1.setSharePerm("global");

				System.out.println("Response" + zqlfilterJson1.toString());
				Response response1 = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson1.toString());
				Assert.assertNotNull(response1, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.err.println("Response : " + response1.getBody().asString());

				boolean status1 = zapiService.validateZQLFilter(zqlfilterJson1.toString(), response1);
				Assert.assertTrue(status1);

				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
				//search filter

	
		Response afterResponse = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(afterResponse, "Search the zql filter by providing name Api Response is null.");
		test.log(LogStatus.PASS, "Search the zql filter by providing name Api executed successfully.");
		System.err.println(afterResponse.getBody().asString());
		boolean status = zapiService.validateZQLFilters(beforeResponse, afterResponse);
		Assert.assertTrue(status);
		System.err.println(status);
		test.log(LogStatus.PASS, "Search the zql filter by providing name Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Delete zql filter
	 * 
	 */
	@Test(priority = 95, enabled = false)
	public void bvt95_deleteFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = TROY");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();

		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Generate the Requirements to Defects Traceability report by providing
	 * requirementIdOrKeyList and versionId
	 * 
	 */
	@Test(priority = 96, enabled = testEnabled)
	public void bvt96_generateRequirementTraceability() throws UnsupportedEncodingException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		requirementIdOrKeyList.add(Long.parseLong(Config.getValue("StoryId")));
		//requirementIdOrKeyList.add(15717l);

		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Generate the Defects to Requirements Traceability report by providing
	 * defectIdList and versionId
	 * 
	 */
	@Test(priority = 97, enabled = testEnabled)
	public void bvt97_generateDefectTraceability() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Long versionId = 11404l;
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		List<Long> defectIdList = new ArrayList<>();
		defectIdList.add(Long.parseLong(Config.getValue("StoryId")));
		//defectIdList.add(15725l);
		//defectIdList.add(15726l);
		String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
		Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Search the linked Executions details By providing Test Id in traceability
	 * 
	 */
	@Test(priority = 98, enabled = testEnabled)
	public void bvt98_searchExecutionsByTest() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test with steps for bulk status update");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
		
		Long issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));


		//Long versionId = 11404l;
		//Long testId = 12717l;
		
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		Long testId = issueId1;
		int offset = 0;
		
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//extentReport.endTest(test);
	}

	/*
	 * Search the linked executions details by providing Defect Id in
	 * traceability
	 * 
	 */
	@Test(priority = 99, enabled = testEnabled)
	public void bvt99_searchExecutionsByDefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test with steps for bulk status update");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
		
		Long issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		//Long versionId = 11404l;
		//Long defectId = 15725l;
		defectId = issueId1;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//extentReport.endTest(test);
	}

	/*
	 * Download Requirements to Defects Traceability after export to HTML format
	 * 
	 */
	@Test(priority = 100, enabled = testEnabled)
	public void exportTraceabilityReport() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long StoryId= Long.parseLong(Config.getValue("StoryId"));
		
		Long VersionId= Long.parseLong(Config.getValue("versionOneId"));

		String payLoad = "{\"exportType\":\"html\",\"requirementIdList\":"+StoryId+",\"versionId\":"+VersionId+"}";
		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator,
				new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Download Requirements to Defects Traceability after export to HTML format
	 * 
	 */
	@Test(priority = 101, enabled = testEnabled)
	public void bvt101_exportTraceabilityReport() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long StoryId= Long.parseLong(Config.getValue("StoryId"));
		
		Long VersionId= Long.parseLong(Config.getValue("versionOneId"));

		//String payLoad = "{\"exportType\":\"excel\",\"defectIdList\":[\"15725\"],\"versionId\":11408}";
		String payLoad = "{\"exportType\":\"excel\",\"defectIdList\":"+StoryId+",\"versionId\":"+VersionId+"}";
		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator,
				new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Newly added cases need to check with validation for below cases- partially completed
	
	@Test(priority = 102, enabled = testEnabled)
	public void bvt_102_createfolder() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle one created");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("Environment");		
		Response Cycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		JSONObject responseJsonObject = new JSONObject(Cycleresponse.getBody().asString()); 
		//String responseData = Cycleresponse.getBody().asString();
		String CycleId =responseJsonObject.getString("id").toString();	
		System.out.println(Cycleresponse.getBody().asString());
		System.out.println("Cycleid"+CycleId);
		String foldername = "Folder" + System.currentTimeMillis();
		String FolderRequestpayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+Config.getValue("versionTwoId")+",\"projectId\":"+Config.getValue("projectId")+"}";
		
		Response FolderResponse = zapiService.createFolderCycle(jwtGenerator, FolderRequestpayload);
		System.out.println(FolderResponse.getBody().asString());
		
		Assert.assertNotNull(FolderResponse, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "create Folder Api executed successfully.");
		System.out.println(FolderResponse.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
		
	@Test(priority = 103, enabled = testEnabled)
		public void Update_Execution_workflow_inprogress() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	
	String Executionid =Config.getValue("Execution_WorkflowId");
	//String Executionid="633a4162-a743-418c-8040-36dbe0a59091";
	String Issueid=Config.getValue("issueId");
	Response response1 = zapiService.Executionworflow_Inprogress(jwtGenerator, Executionid, Issueid);
	System.out.println(response1.getStatusLine());
	System.out.println(response1.getBody().asString());
		
	}
		
	@Test(priority = 104, enabled = testEnabled)
	public void Update_Execution_workflow_Done_Appendtime() {ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Poornachandra");
	//String payload= "";
	//String Executionid="633a4162-a743-418c-8040-36dbe0a59091";
	String Executionid =Config.getValue("Execution_WorkflowId");
	//String Issueid="10056";
	String Issueid=Config.getValue("issueId");
	String action="append";
	String timeLogged="1h";
	Response response = zapiService.Executionworflow_Done(jwtGenerator, action, timeLogged, Executionid, Issueid);
	System.out.println(response.getStatusLine());
	System.out.println(response.getBody().asString());
		
	}
	@Test(priority = 105, enabled = testEnabled)
	public void Update_Execution_workflow_Done_Replacetime() 
	{ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Poornachandra");
	//String payload= "";
	//String Executionid="633a4162-a743-418c-8040-36dbe0a59091";
	String Executionid =Config.getValue("Execution_WorkflowId");
	//String Issueid="10056";
	String Issueid=Config.getValue("issueId");
	String action="replace";
	String timeLogged="1w";
	Response response = zapiService.Executionworflow_Done(jwtGenerator, action, timeLogged, Executionid, Issueid);
	System.out.println(response.getStatusLine());
	System.out.println(response.getBody().asString());		
	}
	
	@Test(priority = 106,enabled = testEnabled)
	public void Update_Execution_workflow_Modify_Appendtime() {ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Poornachandra");
	//String payload= "";
	//String Executionid="633a4162-a743-418c-8040-36dbe0a59091";
	String Executionid =Config.getValue("Execution_WorkflowId");
	//String Issueid="10056";
	String Issueid=Config.getValue("issueId");
	String action="append";
	String timeLogged="1h";
	Response response = zapiService.Executionworflow_Modifytime(jwtGenerator, action, timeLogged, Executionid, Issueid);
	System.out.println(response.getStatusLine());
	System.out.println(response.getBody().asString());
		
	}
	@Test(priority = 107,enabled = testEnabled)
	public void Update_Execution_workflow_Modify_Replacetime() {ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Poornachandra");
	//String payload= "";
	//String Executionid="633a4162-a743-418c-8040-36dbe0a59091";
	String Executionid =Config.getValue("Execution_WorkflowId");
	//String Issueid="10056";
	String Issueid=Config.getValue("issueId");
	String action="replace";
	String timeLogged="1w";
	Response response = zapiService.Executionworflow_Modifytime(jwtGenerator, action, timeLogged, Executionid, Issueid);
	System.out.println(response.getStatusLine());
	System.out.println(response.getBody().asString());		
	}
	
	
	@Test(priority = 108,enabled = testEnabled)
	public void Update_Execution_workflow_Reopen()
	{ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Poornachandra");
	//String payload= "";
	//String Executionid="633a4162-a743-418c-8040-36dbe0a59091";
	String Executionid =Config.getValue("Execution_WorkflowId");
	//String Issueid="100560";
	String Issueid=Config.getValue("issueId");
	Response response = zapiService.Executionworflow_Reopen(jwtGenerator, Executionid, Issueid);
	System.out.println(response.getStatusLine());
	System.out.println(response.getBody().asString());
		
	}
	
	@Test(priority = 109,enabled = false)
	public void getExecutionByExecutionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId =10007l;
				//new JSONObject(executionObject).getLong("projectId");
		Long issueId = 10056l;
				//new JSONObject(executionObject).getLong("issueId");
		String executionId ="633a4162-a743-418c-8040-36dbe0a59091";
				//new JSONObject(executionObject).getString("id");
		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get execution Api executed successfully.");
		JSONObject jsonResponse = new JSONObject(response.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
		//jsonResponse.getJSONArray("executios").length();
		
		String executionId1 = jsonResponse.getJSONObject("execution").getJSONObject("execution").getString("id");
		
		String workflowStatus= jsonResponse.getJSONObject("execution").getJSONObject("execution").getString("workflowStatus");
		
		System.out.println(executionId1 +" workflow Status is "+ workflowStatus);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

@Test(priority = 109, enabled = testEnabled)
	public void bvt109_updateTeststepWithCustomField() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		String NumberCustomField = Config.getValue("NumberCustomField");
		
		String payload = "{\"id\":\"" + stepId +"\",\"customFieldValues\":[{\"customFieldId\":\"" +NumberCustomField+ "\",\"value\":{\"value\":\"9999\"}}]}" ; 
				
		Response response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId,payload);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString() , response);
		//need to add custom field value validation
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		extentReport.endTest(test);
	}
	
	//Create Execution in an non-adhoc cycle, in scheduled version of the project and add the current assignee
	
	@Test(priority = 110, enabled = testEnabled)
	public void bvt_110_createExecution_nonadhoc() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
		
		//create Cycle code 
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectid);
				cycleJson.setVersionId(versionid);
				cycleJson.setName("Cycle in non-adhoc cycle");
				cycleJson.setDescription("Cycle one desc");
				cycleJson.setBuild(Config.getValue("connectBuildNumber"));
				cycleJson.setEnvironment("QA-Bench");
				Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				System.out.println(createcycleresponse.getBody().asString());

				boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
				System.out.println(Cycleid);	
		
		//create execution nonadhoc with current assignee
		  Execution executionJson = new Execution();
		 executionJson.setStatusId(-1l);
		   
		 //executionJson.setProjectId(cycleIdScheduledVersionObj.getLong("projectId"));
		 executionJson.setProjectId(projectid);
		 executionJson.setIssueId(this.issueId);
		//executionJson.setCycleId(cycleIdScheduledVersionObj.getString("id"));
		 executionJson.setCycleId(Cycleid);
		//executionJson.setVersionId(cycleIdScheduledVersionObj.getLong("versionId"));
		 executionJson.setVersionId(versionid);
		// set the assignee
		 executionJson.setAssigneeType("currentUser");
		 executionJson.setChangeAssignee(true);
		// executionJson.setStatusId(2l);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
		String executionId = new JSONObject(new JSONObject(response.getBody().asString()).get("execution").toString())
				.getString("id");
		executionJson.setExecutionId(executionId);
		executionObject = executionJson.toString();
		
		
	}
	//Move execution from cycle to Folder
	
	@Test(priority = 111, enabled = testEnabled)
	public void bvt111_MoveExecutionsCyclesToFolder() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFiveId"));
		
		//Create issue1
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("summary1");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		issueKey = new JSONObject(response.body().asString()).getString("key");
		
		//Create issue2
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("summary1");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response3 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response3, "Create Issue Api Response is null.");
				//
		boolean status1 = jiraService.validateCreateIssueApi(response3);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId1 = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
		issueKey = new JSONObject(response3.body().asString()).getString("key");
				
		//Create Cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
		cycleJson.setName("Cycle new shru created");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("Environment");		
		Response createCycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		JSONObject responseJsonObject = new JSONObject(createCycleResponse.getBody().asString()); 
		//String responseData = response1.getBody().asString();
		String CycleId =responseJsonObject.getString("id").toString();
		String CycleName =responseJsonObject.getString("name").toString();
		System.out.println("Cycle create response: " + createCycleResponse.getBody().asString());
		System.out.println("Cycleid"+CycleId);
			
		//Create Execution API1
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(CycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
		Response response1 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		System.out.println("Execution"+response1.getBody().asString());
		JSONObject ExecutionjsonResponse1 = new JSONObject(response1.getBody().asString());
		System.out.println(ExecutionjsonResponse1.toString());
		System.out.println(ExecutionjsonResponse1.get("execution").toString());
		String executionId1 = ExecutionjsonResponse1.getJSONObject("execution").getString("id"); //.getJSONObject("execution")
				
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(this.issueId);
		executionJson1.setCycleId(CycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
		Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response4, "Create Execution Api Response is null.");
		System.out.println("Execution"+response4.getBody().asString());
		JSONObject ExecutionjsonResponse2 = new JSONObject(response4.getBody().asString());
		System.out.println(ExecutionjsonResponse2.toString());
		System.out.println(ExecutionjsonResponse2.get("execution").toString());
		String executionId2 = ExecutionjsonResponse2.getJSONObject("execution").getString("id"); //.getJSONObject("execution")

		/*String cycleId = "-1";
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for move execution");
		*/
		
		
		String payload1 = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(payload1+"payload for move execution");
		
		Response response30 = zapiService.moveExecutionsToCycle(jwtGenerator, CycleId, payload1);
		Assert.assertNotNull(response30, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response30.getBody().asString());
		response30 = zapiService.jobProgressHandler(jwtGenerator, response30.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		System.out.println("**********Executions added to cycle***************");
		
		//**********************
		
		String foldername = "Folder" + System.currentTimeMillis();
		String CreateFolderPayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+versionid+",\"projectId\":"+projectid+"}";
		
		Response createFolderCycleResponse = zapiService.createFolderCycle(jwtGenerator, CreateFolderPayload);
		JSONObject responseJsonObjectforFolder = new JSONObject(createFolderCycleResponse.getBody().asString());
		System.out.println("Folder create response: " + createFolderCycleResponse.getBody().asString());
		String FolderId =responseJsonObjectforFolder.getString("id").toString();	 
		System.err.println("cycle id: " + CycleId);
		System.err.println("Folder id: " + FolderId);

		Assert.assertNotNull(createFolderCycleResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("createFolderCycleResponse: " + createFolderCycleResponse.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
	
		String moveToFolderPayload = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"projectId\":"+projectid+",\"versionId\":"+versionid+",\"cycleName\":\""+CycleName+"\",\"folderId\":\""+FolderId+"\",\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false,\"clearAssignmentsFlag\":false}";
		System.err.println(moveToFolderPayload +"payload for move execution");
		
		//String payload = "{\"clearAssignmentsFlag\":false,\"clearDefectMappingFlag\":true,\"clearCustomFieldsFlag\":false,\"clearStatusFlag\":true,\"projectId\":\"10014\",\"versionId\":\"10028\",\"cycleName\":"",\"folderId\":\"570a164e-c146-4112-b03d-0363430575d6\","folderName":"","executions":["0fe98337-9dbf-464a-91c5-118edee47109"]} 

		
		Response moveExecutionsToFolder = zapiService.moveExecutionsToCycle(jwtGenerator, CycleId, moveToFolderPayload);
		
		
		Assert.assertNotNull(moveExecutionsToFolder, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(moveExecutionsToFolder.getBody().asString());
		moveExecutionsToFolder = zapiService.jobProgressHandler(jwtGenerator, moveExecutionsToFolder.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 112, enabled = testEnabled)
	public void bvt_112getExecutionTimeTracking() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Shruthi Yogendra");

	Long projectid= Long.parseLong(Config.getValue("projectId"));
	Long versionid= Long.parseLong(Config.getValue("versionTwoId"));
	String cycleId=Config.getValue("cyleId");
	//String folderId="d3000a1f-e662-4c97-86e1-fe46f2e26cf2";
	Response response = zapiService.getExecutionTimeTracking(jwtGenerator, projectid, versionid, cycleId);
	System.out.println(response.getStatusLine());
	System.out.println(response.getBody().asString());	
	}
	
	@Test(priority = 113, enabled = testEnabled)
	public void bvt113_GetCycleSummaryFromVersion() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	Long projectid= Long.parseLong(Config.getValue("projectId"));
	Long versionid= Long.parseLong(Config.getValue("versionFiveId"));
	
	//Create issue1
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(Config.getValue("projectId"));
	issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
	issuePayLoad.setSummary("summary1");
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));
	System.out.println(issuePayLoad.toString());
	Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(response, "Create Issue Api Response is null.");
	//
	boolean status = jiraService.validateCreateIssueApi(response);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
	issueKey = new JSONObject(response.body().asString()).getString("key");
	
	//Create Cycle
	
	Cycle cycleJson = new Cycle();
	cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
	cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
	cycleJson.setName("Cycle new shru created");
	cycleJson.setDescription("Cycle one desc");
	cycleJson.setBuild(Config.getValue("connectBuildNumber"));
	cycleJson.setEnvironment("Environment");		
	Response createCycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
	JSONObject responseJsonObject = new JSONObject(createCycleResponse.getBody().asString()); 
	//String responseData = response1.getBody().asString();
	String CycleId =responseJsonObject.getString("id").toString();
	String CycleName =responseJsonObject.getString("name").toString();
	System.out.println("Cycle create response: " + createCycleResponse.getBody().asString());
	System.out.println("Cycleid"+CycleId);
		
	boolean validateCycleStatus = zapiService.validateCycle(cycleJson.toString(), createCycleResponse);
	Assert.assertTrue(validateCycleStatus, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated successfully.");
	cycleIdScheduledVersion = new JSONObject(createCycleResponse.body().asString()).get("id").toString();
	cycleIdScheduledVersionObj = new JSONObject(createCycleResponse.body().asString());
	extentReport.endTest(test);
	
	
	Response getCyclebyidResponse = zapiService.getCycles(jwtGenerator, projectid, versionid);
	System.out.println("Cycles summary: " + getCyclebyidResponse.getBody().asString());
	Assert.assertNotNull(getCyclebyidResponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	
	
	boolean cycleStatus = zapiService.validateGetCycles(projectid, versionid, getCyclebyidResponse);
	Assert.assertTrue(cycleStatus, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Get cycle summary Api validated successfully.");

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);		
	}
	
	@Test(priority = 114, enabled = testEnabled)
	public void bvt114_GetFolderSummaryOnExpandingCycle() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	Long projectid= Long.parseLong(Config.getValue("projectId"));
	Long versionid= Long.parseLong(Config.getValue("versionFiveId"));
	
	//Create issue1
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(Config.getValue("projectId"));
	issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
	issuePayLoad.setSummary("summary1");
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));
	System.out.println(issuePayLoad.toString());
	Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(response, "Create Issue Api Response is null.");
	//
	boolean status = jiraService.validateCreateIssueApi(response);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId1 = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
	issueKey = new JSONObject(response.body().asString()).getString("key");
	
	//Create Cycle
	
	Cycle cycleJson = new Cycle();
	cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
	cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
	cycleJson.setName("Cycle new shru created");
	cycleJson.setDescription("Cycle one desc");
	cycleJson.setBuild(Config.getValue("connectBuildNumber"));
	cycleJson.setEnvironment("Environment");		
	Response createCycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
	JSONObject responseJsonObject = new JSONObject(createCycleResponse.getBody().asString()); 
	//String responseData = response1.getBody().asString();
	String CycleId =responseJsonObject.getString("id").toString();
	String CycleName =responseJsonObject.getString("name").toString();
	System.out.println("Cycle create response: " + createCycleResponse.getBody().asString());
	System.out.println("Cycleid"+CycleId);
		
	boolean validateCycleStatus = zapiService.validateCycle(cycleJson.toString(), createCycleResponse);
	Assert.assertTrue(validateCycleStatus, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated successfully.");
	cycleIdScheduledVersion = new JSONObject(createCycleResponse.body().asString()).get("id").toString();
	cycleIdScheduledVersionObj = new JSONObject(createCycleResponse.body().asString());
	extentReport.endTest(test);
	//Create folders
	
	System.out.println("***************Create folders*******");
	
	String foldername1 = "Folder" + System.currentTimeMillis();
	
	String CreateFolderPayload= "{\"name\":\""+foldername1+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+versionid+",\"projectId\":"+projectid+"}";
	
	Response createFolderCycleResponse = zapiService.createFolderCycle(jwtGenerator, CreateFolderPayload);
	JSONObject responseJsonObjectforFolder = new JSONObject(createFolderCycleResponse.getBody().asString());
	System.out.println("Folder create response: " + createFolderCycleResponse.getBody().asString());
	String FolderId =responseJsonObjectforFolder.getString("id").toString();	 
	System.err.println("cycle id: " + CycleId);
	System.err.println("Folder id: " + FolderId);
	
	String foldername2 = "Folder" + System.currentTimeMillis();
	
	String CreateFolderPayload2= "{\"name\":\""+foldername2+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+versionid+",\"projectId\":"+projectid+"}";
	
	Response createFolderCycleResponse2 = zapiService.createFolderCycle(jwtGenerator, CreateFolderPayload2);
	JSONObject responseJsonObjectforFolder2 = new JSONObject(createFolderCycleResponse2.getBody().asString());
	System.out.println("Folder create response: " + createFolderCycleResponse2.getBody().asString());
	String FolderId2 =responseJsonObjectforFolder2.getString("id").toString();	 
	System.err.println("cycle id2: " + CycleId);
	System.err.println("Folder id2: " + FolderId2);

	
	Assert.assertNotNull(createFolderCycleResponse2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println("createFolderCycleResponse: " + createFolderCycleResponse2.getBody().asString());
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	
	
	
	
	Response getFolderbyidResponse = zapiService.getFolders(jwtGenerator, projectid, versionid, CycleId);
	System.out.println("Cycles summary: " + getFolderbyidResponse.getBody().asString());
	Assert.assertNotNull(getFolderbyidResponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	
	
	boolean folderStatus = zapiService.validateGetFolders(projectid, versionid, CycleId, getFolderbyidResponse);
	Assert.assertTrue(folderStatus, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Get Folder summary Api validated successfully.");

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);

	}
	
	@Test(priority = 115, enabled = testEnabled)
	public void bvt_deleteFolder() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson.setName("Cycle one created");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("Environment");		
		Response Cycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		JSONObject responseJsonObject = new JSONObject(Cycleresponse.getBody().asString()); 
		//String responseData = Cycleresponse.getBody().asString();
		String CycleId =responseJsonObject.getString("id").toString();	
		System.out.println(Cycleresponse.getBody().asString());
		System.out.println("Cycleid"+CycleId);
		String foldername = "Folder" + System.currentTimeMillis();
		String FolderRequestpayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+Config.getValue("versionFourId")+",\"projectId\":"+Config.getValue("projectId")+"}";
	//	String FolderId =responseJsonObject.getString("folderid").toString();
		
		
		Response FolderResponse = zapiService.createFolderCycle(jwtGenerator, FolderRequestpayload);
		System.out.println(FolderResponse.getBody().asString());
		
		Assert.assertNotNull(FolderResponse, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "create Folder Api executed successfully.");
		System.out.println(FolderResponse.getBody().asString());
		
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
	
		//Add Executions to folder
		Execution executionJson = new Execution();
        //executionJson.setStatusId(-1l);
       // executionJson.setProjectId(Long.parseLong(Config.getValue("versionFourId")));
        executionJson.setProjectId(projectId);
        executionJson.setIssueId(this.issueId);
        executionJson.setCycleId(CycleId);
       // executionJson.setFolderId("FolderId");
        executionJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
        executionJson.setVersionId(versionId);
        Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
        Assert.assertNotNull(response2, "Create Execution Api Response is null.");
        System.out.println("Execution"+response2.getBody().asString());
        JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
        System.out.println(jsonResponse.toString());
        System.out.println(jsonResponse.get("execution").toString());
        //System.out.println("poorna "+ jsonResponse.getJSONObject("execution").get("execution").toString());
        //jsonResponse.getJSONArray("executions").length();
        String executionId= jsonResponse.getJSONObject("execution").getString("id");
        
        Response response = zapiService.DeleteFolderId(jwtGenerator, projectId, versionId, cycleid, folderId);
		String myRes = response.getBody().asString();
		System.err.println(myRes);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Folder Api executed successfully.");

		boolean status = zapiService.DeleteFolderId(projectId, versionId, cycleid, response);
		//Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
        
}


	    @Test(priority = 115, enabled = testEnabled)
	    public void bvt_addExecutionsToFolder() {
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			test.assignAuthor("poornachandra");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson.setName("Cycle one created");
			cycleJson.setDescription("Cycle one desc");
			cycleJson.setBuild(Config.getValue("connectBuildNumber"));
			cycleJson.setEnvironment("Environment");		
			Response Cycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			JSONObject responseJsonObject = new JSONObject(Cycleresponse.getBody().asString()); 
			//String responseData = Cycleresponse.getBody().asString();
			String CycleId =responseJsonObject.getString("id").toString();	
			System.out.println(Cycleresponse.getBody().asString());
			System.out.println("Cycleid"+CycleId);
			String foldername = "Folder" + System.currentTimeMillis();
			String FolderRequestpayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+Config.getValue("versionFourId")+",\"projectId\":"+Config.getValue("projectId")+"}";
			
			Response FolderResponse = zapiService.createFolderCycle(jwtGenerator, FolderRequestpayload);
			JSONObject FolderResponseObj = new JSONObject(FolderResponse.getBody().asString());
			System.out.println(FolderResponse.getBody().asString());
			
			Assert.assertNotNull(FolderResponse, "Create Folder Api Response is null.");
			test.log(LogStatus.PASS, "create Folder Api executed successfully.");
			System.out.println(FolderResponse.getBody().asString());
			String FolderId = FolderResponseObj.getString("id").toString(); 

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			
			//Add executions to folder
			Execution executionJson = new Execution();
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setIssueId(this.issueId);
			//executionJson.setFolderId(FolderId);;
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
			 Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson1.setIssueId(this.issueId);
			executionJson1.setCycleId(CycleId);
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
			Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response4, "Create Execution Api Response is null.");
			System.out.println("Execution"+response4.getBody().asString());
			JSONObject ExecutionjsonResponse2 = new JSONObject(response4.getBody().asString());
			System.out.println(ExecutionjsonResponse2.toString());
			System.out.println(ExecutionjsonResponse2.get("execution").toString());
		}
			
			@Test(priority = 116, enabled = testEnabled)
    		public void bvt_updateFolder() {
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			test.assignAuthor("Sagar");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson.setName("Cycle one created");
			cycleJson.setDescription("Cycle one desc");
			cycleJson.setBuild(Config.getValue("connectBuildNumber"));
			cycleJson.setEnvironment("Environment");		
			Response Cycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			JSONObject responseJsonObject = new JSONObject(Cycleresponse.getBody().asString()); 
			//String responseData = Cycleresponse.getBody().asString();
			String CycleId =responseJsonObject.getString("id").toString();	
			System.out.println(Cycleresponse.getBody().asString());
			System.out.println("Cycleid"+CycleId);
			String foldername = "Folder" + System.currentTimeMillis();
			String FolderRequestpayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+Config.getValue("versionFourId")+",\"projectId\":"+Config.getValue("projectId")+"}";
			
			Response FolderResponse = zapiService.createFolderCycle(jwtGenerator, FolderRequestpayload);
			JSONObject FolderResponseObj = new JSONObject(FolderResponse.getBody().asString());
			System.out.println(FolderResponse.getBody().asString());
			
			Assert.assertNotNull(FolderResponse, "Create Folder Api Response is null.");
			test.log(LogStatus.PASS, "create Folder Api executed successfully.");
			System.out.println(FolderResponse.getBody().asString());
			String FolderId = FolderResponseObj.getString("id").toString(); 

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			
			//Add executions to folder
			Execution executionJson = new Execution();
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setIssueId(this.issueId);
			//executionJson.setFolderId(FolderId);;
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
			 Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson1.setIssueId(this.issueId);
			executionJson1.setCycleId(CycleId);
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
			Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response4, "Create Execution Api Response is null.");
			System.out.println("Execution"+response4.getBody().asString());
			JSONObject ExecutionjsonResponse2 = new JSONObject(response4.getBody().asString());
			System.out.println(ExecutionjsonResponse2.toString());
			System.out.println(ExecutionjsonResponse2.get("execution").toString());
			
			// Updating folder
			//Folder updateFolderJson = new Folder();
			//updateFolderJson.setId(cycleId);
			//updateFolderJson.setName("Empty Cycle Updated");
			//updateFolderJson.setDescription("#12345");
			
			//updateFolderJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			//updateFolderJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

			// Validating updated cycle
			//Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateFolderJson.toString());
			//Assert.assertNotNull(response, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
	}
	
	@Test(priority = 117, enabled = testEnabled)
	    public void bvt_cloneFolder() {
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson.setName("Cycle one created");
			cycleJson.setDescription("Cycle one desc");
			cycleJson.setBuild(Config.getValue("connectBuildNumber"));
			cycleJson.setEnvironment("Environment");		
			Response Cycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			JSONObject responseJsonObject = new JSONObject(Cycleresponse.getBody().asString()); 
			//String responseData = Cycleresponse.getBody().asString();
			String CycleId =responseJsonObject.getString("id").toString();	
			System.out.println(Cycleresponse.getBody().asString());
			System.out.println("Cycleid"+CycleId);
			String foldername = "Folder" + System.currentTimeMillis();
			String FolderRequestpayload= "{\"name\":\""+foldername+"\",\"description\":\"\",\"cycleId\":\""+CycleId+"\",\"versionId\":"+Config.getValue("versionFourId")+",\"projectId\":"+Config.getValue("projectId")+"}";
			
			Response FolderResponse = zapiService.createFolderCycle(jwtGenerator, FolderRequestpayload);
			JSONObject FolderResponseObj = new JSONObject(FolderResponse.getBody().asString());
			System.out.println(FolderResponse.getBody().asString());
			
			Assert.assertNotNull(FolderResponse, "Create Folder Api Response is null.");
			test.log(LogStatus.PASS, "create Folder Api executed successfully.");
			System.out.println(FolderResponse.getBody().asString());
			String FolderId = FolderResponseObj.getString("id").toString(); 

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			
			//Add executions to folder
			Execution executionJson = new Execution();
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setIssueId(this.issueId);
			//executionJson.setFolderId(FolderId);;
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
			 Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson1.setIssueId(this.issueId);
			executionJson1.setCycleId(CycleId);
			executionJson.setVersionId(Long.parseLong(Config.getValue("versionFiveId")));
			Response response4 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response4, "Create Execution Api Response is null.");
			System.out.println("Execution"+response4.getBody().asString());
			JSONObject ExecutionjsonResponse2 = new JSONObject(response4.getBody().asString());
			System.out.println(ExecutionjsonResponse2.toString());
			System.out.println(ExecutionjsonResponse2.get("execution").toString());
			
			Response response = zapiService.clonedFolder(jwtGenerator, cycleId, cycleJson.toString());

			System.out.println(response);
		}
}

