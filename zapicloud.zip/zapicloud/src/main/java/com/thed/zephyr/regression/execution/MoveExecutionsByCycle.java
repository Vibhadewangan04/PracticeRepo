/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.bouncycastle.util.Arrays;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.CopyMoveExecutions;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class MoveExecutionsByCycle extends BaseTest {

	JwtGenerator jwtGenerator = null;
	Long versionId = null;
	Long projectId = null;
	String cycleId = null;
	boolean clearDefectMappingFlag;
	boolean clearStatusFlag;
	private boolean clearAssignmentsFlag;
	private boolean clearCustomFieldsFlag;
	private String cycleName;
	private String folderName;
	private boolean clearDefectMappingFlag1;
	private boolean clearStatusFlag1;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//	Bulk move test executions with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 1, enabled = testEnabled)
	public void test1_BulkMoveTestExecutionsWithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331535002-242ac1139-0001","0001479716399433-242ac111e-0001","0001479898038015-242ac1121-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
        
		String[] executions = {executionId,executionId1};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	
	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects
	//TODO
	@Test(priority = 2,enabled = testEnabled)
	public void test2_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefects(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Move execution cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};	

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);
		

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry statuses
	//TODO
	@Test(priority = 3,enabled = testEnabled)
	public void test3_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStatuses(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);
		

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried
	//TODO
	@Test(priority = 4, enabled = testEnabled)
	public void test4_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Move execution cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};	
				
				CopyMoveExecutions payload = new CopyMoveExecutions();
				payload.setExecutions(executions);
				payload.setProjectId(projectId);
				payload.setVersionId(versionId);
				payload.setClearDefectMappingFlag(clearDefectMappingFlag);
				payload.setClearStatusFlag(clearStatusFlag);
				System.err.println("status");
				System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 5, enabled = testEnabled)
	public void test5_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 6, enabled = testEnabled)
	public void test6_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Move execution cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
					
		        
				String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);


		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry stasuses from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 7, enabled = testEnabled)
	public void test7_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 8, enabled = testEnabled)
	public void test8_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);
		
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 9, enabled = testEnabled)
	public void test9_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);
		

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 10,enabled = testEnabled)
	public void test10_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry stasuses from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 11,enabled = testEnabled)
	public void test11_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 12, enabled = testEnabled)
	public void test12_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 13, enabled = testEnabled)
	public void test13_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);
		

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 14,enabled = testEnabled)
	public void test14_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry statuses from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 15, enabled = testEnabled)
	public void test15_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStatusesFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 16,enabled = testEnabled)
	public void test16_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 17, enabled = testEnabled)
	public void test17_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 18, enabled = testEnabled)
	public void test18_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry stasuses from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 19, enabled = testEnabled)
	public void test19_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 20, enabled = testEnabled)
	public void test20_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 21, enabled = testEnabled)
	public void test21_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 22, enabled = testEnabled)
	public void test22_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);


		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry stasuses from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 23, enabled = testEnabled)
	public void test23_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);


		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 24, enabled = testEnabled)
	public void test24_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Move execution cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from one cycle scheduled version to another cycle to other version
	//TODO
	@Test(priority = 25, enabled = testEnabled)
	public void test25_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromOneCycleScheduledVersionToAnotherCycleToOtherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from one cycle scheduled version to another version
	//TODO
	@Test(priority = 26,  enabled = testEnabled)
	public void test26_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromOneCycleScheduledVersionToAnotherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);
		
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry stasuses from one cycle scheduled version to another version
	//TODO
	@Test(priority = 27, enabled = testEnabled)
	public void test27_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromOneCycleScheduledVersionToAnotherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from one cycle scheduled version to another cycle to other version
	//TODO
	@Test(priority = 28, enabled = testEnabled)
	public void test28_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromOneCycleScheduledVersionToAnotherCycleToOtherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 29, enabled = testEnabled)
	public void test29_BulkMoveTestExecutionsWithDefectsAndStatusCarriedFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing statuses and carry defects from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 30, enabled = testEnabled)
	public void test30_BulkMoveTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);
		
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions to a different Cycle - by clearing defects and carry stasuses from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 31, enabled = testEnabled)
	public void test31_BulkMoveTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);
		
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with both defects and status not carried from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 32, enabled = testEnabled)
	public void test32_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);
		

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects and status carried in Unscheduled version, then Bulk move back to previous cycle with both defects and status not carried
	//TODO
	@Test(priority = 33, enabled = testEnabled)
	public void test33_BulkMoveTestExecutionsWithDefectsAndStatusCarriedInUnscheduledVersionThenBulkMoveBackToPreviousCycleWithBothDefectsAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag1 = true;
		clearStatusFlag1 = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
	}

	//	Bulk move test executions with defects and status not carried in Unscheduled version, then Bulk move back to previous cycle with defects not carried and status carried
	//TODO
	@Test(priority = 34, enabled = testEnabled)
	public void test34_BulkMoveTestExecutionsWithDefectsAndStatusNotCarriedInUnscheduledVersionThenBulkMoveBackToPreviousCycleWithDefectsNotCarriedAndStatusCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag1 = true;
		clearStatusFlag1 = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk move test executions with defects not carried and status carried in Unscheduled version, then Bulk move back to previous cycle with defects carried and status not carried
	//TODO
	@Test(priority = 35, enabled = testEnabled)
	public void test35_BulkMoveTestExecutionsWithDefectsNotCarriedAndStatusCarriedInUnscheduledVersionThenBulkMoveBackToPreviousCycleWithDefectsCarriedAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag1 = false;
		clearStatusFlag1 = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		
	}

	//	Bulk move test executions with both defects and status not carried in Unscheduled version, then Bulk move back to previous cycle with defects carried and status not carried
	//TODO
	@Test(priority = 36, enabled = testEnabled)
	public void test36_BulkMoveTestExecutionsWithBothDefectsAndStatusNotCarriedInUnscheduledVersionThenBulkMoveBackToPreviousCycleWithDefectsCarriedAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionTwoId"));
		//cycleId = "-1";
		clearDefectMappingFlag1 = false;
		clearStatusFlag1 = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
	}

	//	Attempt to bulk move by providing the wrong project id
	//TODO
	@Test(priority = 37, enabled = testEnabled)
	public void test37_AttemptToBulkMoveByProvidingTheWrongProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = 987654l;
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);
		

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateMoveExecutionsToCycleWithInvalidProjectId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk move by not providing the project id
	//TODO
	@Test(priority = 38, enabled = testEnabled)
	public void test38_AttemptToBulkMoveByNotProvidingTheProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
	//	projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
//payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateMoveExecutionsToCycleWithInvalidProjectId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk move by providing the wrong version id
	//TODO
	@Test(priority = 39, enabled = testEnabled)
	public void test39_AttemptToBulkMoveByProvidingTheWrongVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = 987654321l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateMoveExecutionsToCycleWithInvalidVersionId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk move by not providing version id
	//TODO
	@Test(priority = 40, enabled = testEnabled)
	public void test40_AttemptToBulkMoveByNotProvidingVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
//payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateMoveExecutionsToCycleWithInvalidVersionId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk move by not providing the Issuetype id
	//	Attempt to bulk move by not providing the defect id

	//	Attempt to Bulk move by providing wrong cycle id
	//TODO
	@Test(priority = 43, enabled = testEnabled)
	public void test43_AttemptToBulkMoveByProvidingWrongCycleId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		cycleId = "987654321";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateMoveExecutionsToCycleWithInvalidCycleId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to Bulk move by providing blank cycle id
	//TODO
	@Test(priority = 44, enabled = testEnabled)
	public void test44_AttemptToBulkMoveByProvidingBlankCycleId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateMoveExecutionsToCycleWithInvalidCycleId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to Bulk move by not providing execution ids
	//TODO
	@Test(priority = 45, enabled = testEnabled)
	public void test45_AttemptToBulkMoveByNotProvidingExecutionIds(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				

		CopyMoveExecutions payload = new CopyMoveExecutions();
		//payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
				boolean status = zapiService.validateMoveInvalidExecutionsToCycle(response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
	}

	//	Attempt to Bulk move by providing wrong execution ids bug id= ZFJCLOUD-4931
	//TODO
	@Test(priority = 46, enabled = testEnabled)
	public void test46_AttemptToBulkMoveByProvidingWrongExecutionIds(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] executions = {"12345","67890"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateMoveInvalidExecutionsToCycle(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	// Bulk move by not providing clearDefectMappingFlag flag
	//TODO
	@Test(priority = 47, enabled = testEnabled)
	public void test47_BulkMoveByNotProvidingClearDefectmappingflagFlag(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
//payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	// Bulk move by not providing clearStatusFlag flag
	//TODO
	@Test(priority = 48, enabled = testEnabled)
	public void test48_BulkMoveByNotProvidingClearStatusFlag(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
 //payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "MoveExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateMoveExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

}
