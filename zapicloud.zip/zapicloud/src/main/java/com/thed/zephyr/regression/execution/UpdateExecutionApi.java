/**
 * Created by debadatta.kathar on 22-Nov-2016.
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

/**
 * @author debadatta.kathar 14-Nov-2016
 *
 */

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;

public class UpdateExecutionApi extends BaseTest {

	String cycleId = null;
	String issueKey = null;
	Long issueId = null;

	String cycleIdScheduledVersion = null;
	String cycleIdUnscheduledVersion = null;
	String executionObject = null;

	@BeforeClass
	public void beforeClass() {

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		System.out.println(cycleJson.toString());
		Response response1 = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response1, "Create Cycle Api Response is null.");
		System.out.println(response1.getBody().asString());

		boolean status1 = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		cycleIdScheduledVersion = new JSONObject(response1.getBody().asString()).getString("id");

		// Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		System.out.println(cycleJson.toString());
		Response response2 = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response2, "Create Cycle Api Response is null.");
		System.out.println(response2.getBody().asString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), response2);
		Assert.assertTrue(status2, "Response Validation Failed.");
		cycleIdUnscheduledVersion = new JSONObject(response2.getBody().asString()).getString("id");
	}

	@BeforeMethod
	public void beforeMethod() {
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		//issuePayLoad.setparent(Config.getValue("issueKey"));
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		System.out.println(issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
	}

	/**
	 * Update an execution to PASS status in scheduled cycle of scheduled
	 * version
	 */
	@Test(priority = 1, enabled = testEnabled)
	public void reg_tc1_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution to FAIL if already executed to PASS in scheduled
	 * cycle of un-scheduled version
	 */
	@Test(priority = 2, enabled = testEnabled)
	public void reg_tc2_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(2l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to FAIL status in scheduled cycle of scheduled
	 * version
	 */
	@Test(priority = 3, enabled = testEnabled)
	public void reg_tc3_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(2l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to WIP if already executed to FAIL in scheduled cycle
	 * of scheduled version
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void reg_tc4_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(3l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to WIP status in scheduled cycle of scheduled version
	 */
	@Test(priority = 5, enabled = testEnabled)
	public void reg_tc5_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(3l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to BLOCKED if already executed to WIP in scheduled
	 * cycle of scheduled version
	 */
	@Test(priority = 6, enabled = testEnabled)
	public void reg_tc6_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(4l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to BLOCKED status in scheduled cycle of scheduled
	 * version
	 */
	@Test(priority = 7, enabled = testEnabled)
	public void reg_tc7_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(4l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to BLOCKED if already executed to WIP in scheduled
	 * cycle of scheduled version
	 */
	@Test(priority = 8, enabled = testEnabled)
	public void reg_tc8_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(5l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to CUSTOM status in scheduled cycle of scheduled
	 * version
	 */
	@Test(priority = 9, enabled = testEnabled)
	public void reg_tc9_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setStatusId(5l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to BLOCKED if already executed to WIP in scheduled
	 * cycle of scheduled version
	 */
	@Test(priority = 10, enabled = testEnabled)
	public void reg_tc10_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(1l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to PASS status in adhoc cycle of scheduled version
	 */
	@Test(priority = 11, enabled = testEnabled)
	public void reg_tc11_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution to Unexecuted status in adhoc cycle of scheduled
	 * version if already executed
	 */
	@Test(priority = 12, enabled = testEnabled)
	public void reg_tc12_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(-1l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution to Custom status in adhoc cycle of un-scheduled
	 * version
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void reg_tc13_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		executionJson.setStatusId(1l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Revert back status to "Unexecuted" of an execution if already executed in
	 * unscheduled version
	 */
	@Test(priority = 14, enabled = testEnabled)
	public void reg_tc14_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution(executionObject);
		String executionId = executionJson.getExecutionId();
		executionJson.setStatusId(-1l);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update an execution by linking Test as a defect
	 */
	@Test(priority = 15, enabled = testEnabled)
	public void reg_tc15_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking Bug as a defect
	 */
	@Test(priority = 16, enabled = testEnabled)
	public void reg_tc16_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking Task as a defect
	 */
	@Test(priority = 17, enabled = testEnabled)
	public void reg_tc17_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTaskId"));
		issuePayLoad.setSummary("Task Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking subtask as a defect
	 */
	@Test(priority = 18, enabled = testEnabled)
	public void reg_tc18_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTaskId"));
		issuePayLoad.setSummary("bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		//issuePayLoad.setparent(Config.getValue("issueKey"));
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		String bugissueKey = new JSONObject(response.body().asString()).getString("key");
		
		// Creating subtask
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeSubTaskId"));
		issuePayLoad1.setSummary("Sub task Summary " + System.currentTimeMillis());
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setparent(bugissueKey);
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		//
		boolean issueStatus1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus1, "Response Validation Failed.");
		Long subtaskid = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(subtaskid);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking story as a defect
	 */
	@Test(priority = 19, enabled = testEnabled)
	public void reg_tc19_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeStoryId"));
		issuePayLoad.setSummary("Story Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking Epic as a defect
	 */
	@Test(priority = 20, enabled = testEnabled)
	public void reg_tc20_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setEpicName("EpicName");
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeEpicId"));
		
		issuePayLoad.setSummary("Epic Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking Improvement as a defect
	 */
	@Test(priority = 21, enabled = testEnabled)
	public void reg_tc21_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeImprovementId"));
		issuePayLoad.setSummary("Improvement Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking New feature as a defect
	 */
	@Test(priority = 22, enabled = testEnabled)
	public void reg_tc22_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeNewFetureId"));
		issuePayLoad.setSummary("New feature Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking User defined issue as a defect
	 */
	@Test(priority = 23, enabled = testEnabled)
	public void reg_tc23_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeUserDefinedId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		// executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking multiple defects
	 */
	@Test(priority = 24, enabled = testEnabled)
	public void reg_tc24_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking 10 defects
	 */
	@Test(priority = 25, enabled = testEnabled)
	public void reg_tc25_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 10);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking 50 defects
	 * @throws InterruptedException 
	 */
	@Test(priority = 26, enabled = false)
	public void reg_tc26_updateExecution() throws InterruptedException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 50);
		Thread.sleep(200);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking single defect and change status to PASS
	 */
	@Test(priority = 27, enabled = testEnabled)
	public void reg_tc27_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the status to pass (1)
		executionJson.setStatusId(1l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking multiple defects and change status to FAIL
	 */
	@Test(priority = 28, enabled = testEnabled)
	public void reg_tc28_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set status and defects
		executionJson.setStatusId(2l);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking 10 defects and change status to BLOCKED
	 */
	@Test(priority = 29, enabled = testEnabled)
	public void reg_tc29_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 10);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set status and defects
		executionJson.setStatusId(4l);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by linking 50 defects and chnage status to CUSTOM
	 * Status
	 */
	@Test(priority = 30, enabled = false)
	public void reg_tc30_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 50);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		// set status and defects
		executionJson.setStatusId(5l);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to current user
	 */
	@Test(priority = 31, enabled = testEnabled)
	public void reg_tc31_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to different than current user
	 */
	@Test(priority = 32, enabled = testEnabled)
	public void reg_tc32_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setAssigneeType("assignee");
		executionJson.setChangeAssignee(true);
		//executionJson.setAssignee("user1");
		executionJson.setassignedTo(Config.getValue("userID"));
		executionJson.setassignedToAccountId(Config.getValue("userID"));
		//setReporter(Config.getValue("adminUserName"))
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to current user and update status
	 * to PASS
	 */
	@Test(priority = 33, enabled = testEnabled)
	public void reg_tc33_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setStatusId(1l);
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to different user and add a single
	 * defect
	 */
	@Test(priority = 34, enabled = testEnabled)
	public void reg_tc34_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setAssigneeType("assignee");
		executionJson.setChangeAssignee(true);
		//executionJson.setAssignee("user1");
		executionJson.setassignedTo(Config.getValue("userID"));
		executionJson.setassignedToAccountId(Config.getValue("userID"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as lower case letters
	 */
	@Test(priority = 35, enabled = testEnabled)
	public void reg_tc35_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("comment");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as upper case letters
	 */
	@Test(priority = 36, enabled = testEnabled)
	public void reg_tc36_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("COMMENT");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as alpha numeric chars
	 */
	@Test(priority = 37, enabled = testEnabled)
	public void reg_tc37_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("Alpha 123");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as numeric chars
	 */
	@Test(priority = 38, enabled = testEnabled)
	public void reg_tc38_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("1234567890");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as special chars
	 */
	@Test(priority = 39, enabled = testEnabled)
	public void reg_tc39_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("!@#$%^&");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as internatianal chars
	 */
	@Test(priority = 40, enabled = testEnabled)
	public void reg_tc40_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("ã‚¯ãƒªã‚±ãƒƒãƒˆ");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as 1 chars
	 */
	@Test(priority = 41, enabled = testEnabled)
	public void reg_tc41_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("z");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as internatianal chars
	 */
	@Test(priority = 42, enabled = testEnabled)
	public void reg_tc42_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("comment");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// set the comment
		executionJson.setComment("COMMENT");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse1 = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse1, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse1.getBody().asString());

		boolean updateExecutionStatus1 = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse1);
		Assert.assertTrue(updateExecutionStatus1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment with URL"link" in comment (ex:
	 * http://www.getzephyr.com)
	 */
	@Test(priority = 43, enabled = testEnabled)
	public void reg_tc43_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("[http://www.getzephyr.com]");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding comment as more chars(750 chars)
	 */
	@Test(priority = 44, enabled = testEnabled)
	public void reg_tc44_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		String s = "111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111111112222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222222233333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333333";
		executionJson.setComment(s);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Delete a comment from an execution if already added
	 */
	@Test(priority = 45, enabled = testEnabled)
	public void reg_tc45_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("comment added");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		// set the comment
		executionJson.setComment(null);
		executionJson.setExecutionId(executionId);
		updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId, executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (h1. Biggest heading)
	 */
	@Test(priority = 46, enabled = testEnabled)
	public void reg_tc46_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("h1. Biggest heading");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (*strong*)
	 */
	@Test(priority = 47, enabled = testEnabled)
	public void reg_tc47_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("*strong*");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (_emphasis_)
	 */
	@Test(priority = 48, enabled = testEnabled)
	public void reg_tc48_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("_emphasis_");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (??citation??)
	 */
	@Test(priority = 49, enabled = testEnabled)
	public void reg_tc49_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("??citation??");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (-deleted-)
	 */
	@Test(priority = 50, enabled = testEnabled)
	public void reg_tc50_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("-deleted-");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (+inserted+)
	 */
	@Test(priority = 51, enabled = testEnabled)
	public void reg_tc51_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("+inserted+");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment ({color:red}look ma,
	 * red text!{color})
	 */
	@Test(priority = 52, enabled = testEnabled)
	public void reg_tc52_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("{color:red}look ma, red text!{color}");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding wiki format comment (\\)
	 */
	@Test(priority = 53, enabled = testEnabled)
	public void reg_tc53_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the comment
		executionJson.setComment("\\");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to current user and add a sample
	 * comment
	 */
	@Test(priority = 54, enabled = testEnabled)
	public void reg_tc54_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);
		// set the comment
		executionJson.setComment("\\");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to current user, add a defect,
	 * update status to FAIL and add a sample comment
	 */
	@Test(priority = 55, enabled = testEnabled)
	public void reg_tc55_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setStatusId(2l);
		executionJson.setAssigneeType("currentUser");
		executionJson.setChangeAssignee(true);
		// set the comment
		executionJson.setComment("\\");
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to differnt user than logged in
	 * user, add 10 defect, update status to CUSTOM and add a sample comment
	 */
	@Test(priority = 56, enabled = testEnabled)
	public void reg_tc56_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 10);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setStatusId(5l);
		// set the assignee
		executionJson.setAssigneeType("assignee");
		executionJson.setChangeAssignee(true);
		//executionJson.setAssignee("user1");
		executionJson.setassignedTo(Config.getValue("userID"));
		executionJson.setassignedToAccountId(Config.getValue("userID"));
		// set the comment
		executionJson.setComment("comment");
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Update an execution by adding assignee to differnt user than logged in
	 * user, add a defect, update status to Blocked, add a sample comment and
	 * add a attachment
	 */
	@Test(priority = 57, enabled = testEnabled)
	public void reg_tc57_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 10);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setStatusId(5l);
		// set the assignee
		executionJson.setAssigneeType("assignee");
		executionJson.setChangeAssignee(true);
		//executionJson.setAssignee("user1");
		executionJson.setassignedTo(Config.getValue("userID"));
		executionJson.setassignedToAccountId(Config.getValue("userID"));
		// set the comment
		executionJson.setComment("comment");
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		// TODO
		// Add attachment
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Revert back the status to â€œunexecutedâ€�if executed the execution by adding
	 * assignee to differnt user than logged in user, add 10 defect, update
	 * status to CUSTOM and add a sample comment
	 */
	@Test(priority = 58, enabled = testEnabled)
	public void reg_tc58_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 10);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set the assignee
		executionJson.setStatusId(5l);
		// set the assignee
		executionJson.setAssigneeType("assignee");
		executionJson.setChangeAssignee(true);
		//executionJson.setAssignee("user1");
		executionJson.setassignedTo(Config.getValue("userID"));
		executionJson.setassignedToAccountId(Config.getValue("userID"));
		// set the comment
		executionJson.setComment("comment");
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// Revert to unexecuted
		// set the assignee
		executionJson.setStatusId(-1l);
		
		executionJson.setExecutionId(executionId);
		updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId, executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}

	/**
	 * Attempt to update an execution using invalid projectId
	 */
	@Test(priority = 59, enabled = testEnabled)
	public void reg_tc59_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setProjectId(1000004l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidProjectId(executionJson.getProjectId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution using invalid versionId,should get 400 but getting  200 
	 * bug is there=ZFJCLOUD-2595
	 */
	@Test(priority = 60, enabled = testEnabled)
	public void reg_tc60_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		//executionJson.setVersionId(1000004l);
		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setVersionId(1234567894l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidVersionId(executionJson.getVersionId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution using invalid issueId
	 */
	@Test(priority = 61, enabled = testEnabled)
	public void reg_tc61_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		executionJson.setIssueId(1000004l);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

	//	boolean updateExecutionStatus = zapiService.validateInvalidVersionId(executionJson.getIssueId(), updateExecutionResponse);
		boolean updateExecutionStatus = zapiService.validateInvalidIssueId(executionJson.getIssueId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution using invalid executionId
	 */
	@Test(priority = 62, enabled = testEnabled)
	public void reg_tc62_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		/*String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");*/
		String executionId = "1234";
		executionJson.setExecutionId(executionId+12345);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidExecutionId(executionJson.getExecutionId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution using invalid statusId
	 */
	@Test(priority = 63, enabled = testEnabled)
	public void reg_tc63_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		Long statusId = 1686504l;
		executionJson.setStatusId(statusId);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidStatusId(statusId, updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if not passing project
	 */
	@Test(priority = 64, enabled = testEnabled)
	public void reg_tc64_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		String payLoad = new JSONObject(executionJson).remove("projectId").toString();
		executionJson.setExecutionId(executionId);
		/*Long projectId = 1234l;
		executionJson.setProjectId(projectId);*/
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if not passing versionId
	 * ZAPICLOUD-191,ZFJCLOUD-2595
	 */
	@Test(priority = 65, enabled = testEnabled)
	public void reg_tc65_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		JSONObject payLoad = new JSONObject(executionJson);
		payLoad.remove("versionId");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				payLoad.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(payLoad.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if not passing issueId
	 */
	@Test(priority = 66, enabled = testEnabled)
	public void reg_tc66_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		JSONObject payLoad = new JSONObject(executionJson);
		payLoad.remove("issueId");
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				payLoad.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(payLoad.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if not passing statusId
	 */
	@Test(priority = 67, enabled = testEnabled)
	public void reg_tc67_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		JSONObject payLoad = new JSONObject(executionJson);
		payLoad.remove("status");
//		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				payLoad.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(payLoad.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if projectId is null
	 */
	@Test(priority = 68, enabled = testEnabled)
	public void reg_tc68_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		executionJson.setProjectId(null);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidProjectId(executionJson.getProjectId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if VersionId is null=ZFJCLOUD-2595
	 */
	@Test(priority = 69, enabled = testEnabled)
	public void reg_tc69_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		executionJson.setVersionId(null);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidVersionId(executionJson.getVersionId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if issueId is null
	 */
	@Test(priority = 70, enabled = testEnabled)
	public void reg_tc70_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		executionJson.setIssueId(null);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validatenullIssueId(executionJson.getIssueId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if executionId is null
	 */
	@Test(priority = 71, enabled = testEnabled)
	public void reg_tc71_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		/*String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");*/
		
		executionJson.setExecutionId(null);
		String executionId= null;
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateInvalidExecutionId(executionJson.getExecutionId(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if executionId is blank
	 */
	@Test(priority = 72, enabled = testEnabled)
	public void reg_tc72_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
		executionJson.setExecutionId("");
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionJson.getExecutionId(),
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Attempt to update an execution if executionId is blank
	 */
//	@Test(priority = 73, enabled = testEnabled)
	public void reg_tc73_updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		List<Long> defectsList = new ArrayList<>();
		Long defectId = 155555555l;
		defectsList.add(defectId);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionJson.getExecutionId(),
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

	//	boolean updateExecutionStatus = zapiService.validateInvalidIssueId(defectId, updateExecutionResponse);
		boolean updateExecutionStatus = zapiService.validateInvalidExecutionId(executionId, updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
	/**
	 * Update an execution by linking 10 defects and change status to BLOCKED
	 */
	@Test(priority = 29, enabled = true, invocationCount = 1)
	public void reg_tc29_updateExecution1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Creating defect
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("User defined Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
//		List<Long> defectsList = CommonUtils.getListAsLong(response, "id");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		// set status and defects
		executionJson.setStatusId(4l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(11156l);
		executionJson.setDefects(defectsList);
		executionJson.setExecutionId(executionId);
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());

		boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(),
				updateExecutionResponse);
		Assert.assertTrue(updateExecutionStatus, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		executionObject = executionJson.toString();
	}
}
