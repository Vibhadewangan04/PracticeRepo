package com.thed.zephyr.regression.cycle;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class ExportCycleAPi extends BaseTest {
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * Export empty cycle to CSV Created by Poornachandra.k on 16-Nov-2016
	 */
	 @Test(priority = 1, enabled= testEnabled)
	public void test1_export_Empty_Cycle_toCSV() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Empty cycle csv export");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		//String cycleId = "0001480932580991-242ac112-0001";
		String exportType = "CSV";
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export adhoc cycle to CSV Created by Poornachandra.k on 16-Nov-2016
	 */
	 @Test(priority = 2, enabled= testEnabled)
	public void test2_export_Adhoc_Cycle_toCSV() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));

		String cycleId = "-1";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export planned cycle with environment/build/start date to CSV Created by
	 * Poornachandra.k on 16-Nov-2016
	 */

	 @Test(priority = 3, enabled= testEnabled)
	public void test3_export_Empty_Cycle_All_fields_toCSV() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export empty cycle all fields");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");
		cycleJson.setStartDate("2016-11-11");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		//String cycleId = "0001480932580991-242ac112-0001";
		String exportType = "CSV";
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 1 schedule to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 4, enabled= testEnabled)
	public void test4_export_Cycle_having_one_Exe_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with one execution
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having one execution to csv");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

			
		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is having one execution
		
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
				
		//String cycleId = "0001480931248523-242ac112-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		System.err.println("data");
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 50 schedule to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 5, enabled= testEnabled)
	public void test5_export_Cycle_having_50_Exe_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		
		// implement cycle with one execution
		int numberOfExecutions = 50;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 50 execution to csv");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		
		// implement cycle with 50 execution
		//String cycleId = "0001480941028418-242ac112-0001";
		String exportType = "csv";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 500 schedule to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 6, enabled= false)
	public void test6_export_Cycle_having_500_Exe_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with 500 execution
		int numberOfExecutions = 500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 500 execution to csv");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 1000 schedule to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 7, enabled= false)
	public void test7_export_Cycle_having_1000_Exe_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with 1000 execution
		int numberOfExecutions = 1000;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 1000 execution to csv");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with >5000 schedule to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 8, enabled= false)
	public void test8_export_Cycle_having_Greaterthan_5000_Exe_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with >5000 execution
		int numberOfExecutions = 5500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having >5000 execution to csv");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export partially executed cycle to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 9, enabled= testEnabled)
	public void test9_export_Cycle_having_partially_Exe_Test_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with partially test executed
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length()-1;j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(1l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		//String cycleId = "-1";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export fully executed cycle to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 10, enabled= testEnabled)
	public void test10_export_Cycle_having_fully_Exe_Test_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with fully executed test executed
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		//String cycleId = "-1";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle executed to different statuses to CSV Created by
	 * Poornachandra.k on 16-Nov-2016
	 */

	@Test(priority = 11, enabled= testEnabled)
	public void test11_export_Cycle_having_different_Test_Exe_status_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with executed schedules having defect
	 * links/comments/component/label to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 12, enabled= testEnabled)
	public void test12_export_Cycle_having_defects_comment_component_label_Test_Exe_status_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response1 = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * //Export Cycle after Edit the Cycle to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 13, enabled= testEnabled)
	public void test13_export_Cycle_After_edit_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle edit and pass cycle id
		
		/*
		 * Creating cycle
		 * Set the required parameters to create cycle
		 */
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Create new cycle");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		
		//Fetching the created cycleId
		String cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		/*
		 * Updating cycle name
		 * Set the updated cycle name
		 */
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle name for export");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId,updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response1 = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export Cycle after Move the Cycle Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 14, enabled= testEnabled)
	public void test14_export_Cycle_After_Move_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionFourId"));
		
		// implement cycle move and pass cycle id, and new version id which your
		// are moving
			
		//create cycle
		
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is having one execution
		
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle for export ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle moved");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionTwoId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");

		// Move cycle
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response1 = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status2 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export Cycle after Clone the Cycle Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 15, enabled= testEnabled)
	public void test15_export_Cycle_After_Clone_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle clone and pass cycle id,version id which your are
		// clone
		int numberOfExecutions = 1;
		String Cyclename = "Cycle_with_oneExecution";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");

		// pass cycleid below with cycle has one Execution
		//String cycleId = "5302ed44-dae7-4b34-9517-34b9fac93b35";
					
		cycleJson.setName("CLONE for export-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		int offset = 0;
		int size = 5;
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response1 = zapiService.exportCycle(jwtGenerator, Projectid, Versionid, clonnedCycleId, exportType);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing project ID from Cycle Object
	 * before passing to Export Cycle to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */
	// ================================================================================================
	 @Test(priority = 16, enabled= testEnabled)
	public void test16_Attempt_export_Cycle_with_empty_projectid_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		
		response = zapiService.exportCycle(jwtGenerator, 0l , VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing Version Id from Cycle Object
	 * before passing to Export Cycle to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 17, enabled= testEnabled)
	public void test17_Attempt_export_Cycle_with_empty_versionid_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		// CycleId = "0001479189557520-242ac1134-0001";
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		response = zapiService.exportCycle(jwtGenerator, projectId, 0l, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing Version Id from Cycle Object
	 * before passing to Export Cycle to CSV Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 18, enabled= testEnabled)
	public void test18_Attempt_export_Cycle_with_empty_cycleid_toCSV() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		String CycleId = "null";
		String exportType = "CSV";
		Response	response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean	status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/*
	 * =====================================================================
	 * HTML cycle Exports Code starting below
	 * ===================================================================
	 */

	/**
	 * Export empty cycle to HTML Created by Poornachandra.k on 16-Nov-2016
	 */
	 @Test(priority = 19, enabled= testEnabled)
	public void test19_export_Empty_Cycle_toHTML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export adhoc cycle to HTML Created by Poornachandra.k on 16-Nov-2016
	 */
	 @Test(priority = 20, enabled= testEnabled)
	public void test20_export_Adhoc_Cycle_toHTML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));

		String CycleId = "-1";
		// String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export planned cycle with environment/build/start date to HTML Created by
	 * Poornachandra.k on 16-Nov-2016
	 */
	@Test(priority = 21, enabled= testEnabled)
	public void test21_export_Empty_Cycle_All_fields_toHTML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");
		cycleJson.setStartDate("2016-11-11");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// CycleId = "0001479189557520-242ac1134-0001";
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 1 schedule to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 22 , enabled= testEnabled)
	public void test22_export_Cycle_having_one_Exe_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having one execution to html");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		// implement cycle with one execution
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 50 schedule to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 23, enabled= false)
	public void test23_export_Cycle_having_50_Exe_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		int numberOfExecutions = 50;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 50 execution to HTML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		// implement cycle with 50 execution
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 500 schedule to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 24, enabled= false)
	public void test24_export_Cycle_having_500_Exe_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with 500 execution
		int numberOfExecutions = 500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 500 execution to HTML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 1000 schedule to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 25, enabled= false)
	public void test25_export_Cycle_having_1000_Exe_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 1000;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 1000 execution to HTML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		// implement cycle with 1000 execution
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with >5000 schedule to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 26, enabled= false)
	public void test26_export_Cycle_having_Greaterthan_5000_Exe_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with >5000 execution
		int numberOfExecutions = 5500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having >5500 execution to HTML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export partially executed cycle to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 27, enabled= testEnabled)
	public void test27_export_Cycle_having_partially_Exe_Test_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with partially test executed
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having partial exec in html");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length()-1;j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(1l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export fully executed cycle to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 28, enabled= testEnabled)
	public void test28_export_Cycle_having_fully_Exe_Test_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with fully executed test executed
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having full exec in html");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle executed to different statuses to HTML Created by
	 * Poornachandra.k on 16-Nov-2016
	 */

	 @Test(priority = 29, enabled= testEnabled)
	public void test29_export_Cycle_having_different_Test_Exe_status_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having diff exec status in html");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with executed schedules having defect
	 * links/comments/component/label to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 30, enabled= testEnabled)
	public void test30_export_Cycle_having_defects_comment_component_label_Test_Exe_status_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		Response response1 = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing project ID from Cycle Object
	 * before passing to Export Cycle to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 31, enabled= testEnabled)
	public void test31_Attempt_export_Cycle_with_empty_projectid_toHTML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		projectId = 0l;
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		System.out.println("Not able to export as projectid is null");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing Version Id from Cycle Object
	 * before passing to Export Cycle to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 32, enabled= testEnabled)
	public void test32_Attempt_export_Cycle_with_empty_versionid_toHTML() {

		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long projectId = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// Create cycle
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Cycle for html export");
			cycleJson.setDescription("Cycle one desc");

			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			String CycleId = new JSONObject(response.body().asString()).get("id").toString();
			System.err.println("cycle id " + CycleId);
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			
			// CycleId = "0001479189557520-242ac1134-0001";
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "HTML";
			response = zapiService.exportCycle(jwtGenerator, projectId, 0l, CycleId, exportType);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	}

	// Attempt to Export Cycle without providing Cycle Id from Cycle Object
	// before passing to Export Cycle to HTML

	/**
	 * Attempt to Export Cycle without providing Version Id from Cycle Object
	 * before passing to Export Cycle to HTML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 33, enabled= testEnabled)
	public void test33_Attempt_export_Cycle_with_empty_cycleid_toHTML() {

		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long projectId = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// Create cycle
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Cycle example");
			cycleJson.setDescription("Cycle one desc");

			String CycleId = "null";
			String exportType = "HTML";
			Response	response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean	status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	}

	/*
	 * 
	 * XML cycle Exports Code starting below
	 * 
	 */

	/**
	 * Export empty cycle to XML Created by Poornachandra.k on 16-Nov-2016
	 */
	@Test(priority = 34, enabled= testEnabled)
	public void test34_export_Empty_Cycle_toXML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// CycleId = "0001479189557520-242ac1134-0001";
		String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export adhoc cycle to XML Created by Poornachandra.k on 16-Nov-2016
	 */
	 @Test(priority = 35, enabled= testEnabled)
	public void test35_export_Adhoc_Cycle_toXML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));

		String CycleId = "-1";
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export planned cycle with environment/build/start date to XML Created by
	 * Poornachandra.k on 16-Nov-2016
	 */

	@Test(priority = 36, enabled= testEnabled)
	public void test36_export_Empty_Cycle_All_fields_toXML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle for xml export");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");
		cycleJson.setStartDate("2016-11-11");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// CycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 1 schedule to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 37, enabled= testEnabled)
	public void test37_export_Cycle_having_one_Exe_toXML() {


		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with one execution
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having one execution to csv");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

			
		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is having one execution
		
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
				
		//String cycleId = "0001480931248523-242ac112-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		System.err.println("data");
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 50 schedule to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 38, enabled= false)
	public void test38_export_Cycle_having_50_Exe_toXML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		int numberOfExecutions = 50;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 50 execution to XML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		// implement cycle with 50 execution
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 500 schedule to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 39, enabled= false)
	public void test39_export_Cycle_having_500_Exe_toXML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with 500 execution
		int numberOfExecutions = 500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 500 execution to XML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with 1000 schedule to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 40, enabled= false)
	public void test40_export_Cycle_having_1000_Exe_toXML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 1000;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having 1000 execution to XML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		// implement cycle with 1000 execution
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with >5000 schedule to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 41, enabled= false)
	public void test41_export_Cycle_having_Greaterthan_5000_Exe_toXML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with >5000 execution
		int numberOfExecutions = 5500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cycle having >5500 execution to HTML");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export partially executed cycle to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 42, enabled= testEnabled)
	public void test42_export_Cycle_having_partially_Exe_Test_toXML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// implement cycle with partially test executed
			int numberOfExecutions = 2;

			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Export cyle having partial exec in XML");
			cycleJson.setDescription("Cycle for export");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(issueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
		
			//create executions
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(VersionID);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);
			System.out.println(executionJson.toString());

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length()-1;j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId = issueIds.get(j);
				executionJson.setIssueId(issueId);
				System.out.println(issueId);
				executionJson.setStatusId(1l);
				executionJson.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "XML";
			Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status1, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	}

	/**
	 * Export fully executed cycle to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 43, enabled= testEnabled)
	public void test43_export_Cycle_having_fully_Exe_Test_toXML() {

		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// implement cycle with fully executed test executed
			int numberOfExecutions = 2;

			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Export cyle having full exec in XML");
			cycleJson.setDescription("Cycle for export");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(issueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
		
			//create executions
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(VersionID);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);
			System.out.println(executionJson.toString());

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId = issueIds.get(j);
				executionJson.setIssueId(issueId);
				System.out.println(issueId);
				executionJson.setStatusId(2l);
				executionJson.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "XML";
			Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status1, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	}

	/**
	 * Export cycle executed to different statuses to XML Created by
	 * Poornachandra.k on 16-Nov-2016
	 */

	@Test(priority = 44, enabled= testEnabled)
	public void test44_export_Cycle_having_different_Test_Exe_status_toXML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		String CycleId = "0001479360969317-242ac1139-0001";
		String exportType = "XML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export cycle with executed schedules having defect
	 * links/comments/component/label to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 45, enabled= testEnabled)
	public void test45_export_Cycle_having_defects_comment_component_label_Test_Exe_status_toXML() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Export cyle having diff exec status in xml");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "xml";
		Response response = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status1, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing project ID from Cycle Object
	 * before passing to Export Cycle to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	@Test(priority = 46, enabled= testEnabled)
	public void test46_Attempt_export_Cycle_with_empty_projectid_toXML() {


		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String CycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + CycleId);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		//String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "XML";
		
		response = zapiService.exportCycle(jwtGenerator, 0l , VersionID, CycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Export Cycle without providing Version Id from Cycle Object
	 * before passing to Export Cycle to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 47, enabled= testEnabled)
	public void test47_Attempt_export_Cycle_with_empty_versionid_toXML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long projectId = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// Create cycle
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Cycle for export in xml");
			cycleJson.setDescription("Cycle one desc");

			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			String CycleId = new JSONObject(response.body().asString()).get("id").toString();
			System.err.println("cycle id " + CycleId);
			boolean status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			
			// CycleId = "0001479189557520-242ac1134-0001";
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "xml";
			response = zapiService.exportCycle(jwtGenerator, projectId, 0l, CycleId, exportType);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);	}

	// Attempt to Export Cycle without providing Cycle Id from Cycle Object
	// before passing to Export Cycle to XML

	/**
	 * Attempt to Export Cycle without providing Version Id from Cycle Object
	 * before passing to Export Cycle to XML Created by Poornachandra.k on
	 * 16-Nov-2016
	 */

	 @Test(priority = 48, enabled= testEnabled)
	public void test48_Attempt_export_Cycle_with_empty_cycleid_toXML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long projectId = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// Create cycle
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Cycle example");
			cycleJson.setDescription("Cycle one desc");

			String CycleId = "null";
			String exportType = "HTML";
			Response	response = zapiService.exportCycle(jwtGenerator, projectId, VersionID, CycleId, exportType);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean	status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	}

	 /**
		 * After editing the cycle export to HTML
		 * Created by Jagadeesh on
		 * 14-June-2019
		 */
	 
	 @Test(priority = 49, enabled= testEnabled)
		public void test49_export_Cycle_After_edit_toHTML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Jagadeesh");
			Long projectId = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// implement cycle edit and pass cycle id
			
			/*
			 * Creating cycle
			 * Set the required parameters to create cycle
			 */
			Cycle cycleJson = new Cycle();
			cycleJson.setName("Create new cycle");
			cycleJson.setBuild("#12345");
			cycleJson.setEnvironment("Windows");
			cycleJson.setDescription("Cycle desc");
			cycleJson.setStartDate("2016-11-14");
			cycleJson.setEndDate("2016-11-30");
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(VersionID);

			Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(res, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			
			JSONObject obj = new JSONObject(res.getBody().asString());
			System.out.println(obj);
			
			//Fetching the created cycleId
			String cycleId = obj.get("id").toString();
			System.out.println(cycleId);

			/*
			 * Updating cycle name
			 * Set the updated cycle name
			 */
			Cycle updateCycleJson = new Cycle();
			updateCycleJson.setId(cycleId);
			updateCycleJson.setName("Updated Cycle name for export in HTML");
			updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

			Response response = zapiService.updateCycle(jwtGenerator, cycleId,updateCycleJson.toString());
			Assert.assertNotNull(response, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());			
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "HTML";
			Response response1 = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response1.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}	 


	 /**
		 * After Moving the cycle export to HTML
		 * Created by Jagadeesh on
		 * 14-June-2019
		 */
	 
	 @Test(priority = 50, enabled= testEnabled)
		public void test50_export_Cycle_After_Move_toHTML(){
		 
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Jagadeesh");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionFourId"));
			
			// implement cycle move and pass cycle id, and new version id which your
			// are moving
				
			//create cycle
			
			int numberOfExecutions = 1;

			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Move Cycle");
			cycleJson.setDescription("Cycle moved");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");

			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(VersionID);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
			//Cycle cycleJson = new Cycle();
			// Set which cycle you want to move and which version
			// Set the cycleId which is having one execution
			
			//String cycleId = "0001482927072336-242ac112-0001";
			cycleJson.setId(cycleId);
			cycleJson.setName("Moved Cycle for export ");
			cycleJson.setProjectId(ProjectID);
			// Set Description
			cycleJson.setDescription("Cycle moved");
			// Set version which we want to move
			Long move_to_version = Long.parseLong(Config.getValue("versionTwoId"));
			cycleJson.setVersionId(move_to_version);

			// Get the execution count of cycle before move
			int offset = 0;
			int size = 10;
			Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
			Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
			String sourceCycle = responseGetExecutions.getBody().asString();
			System.out.println("Cycle before move " + sourceCycle);

			String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
			Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
			System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
			boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
			Assert.assertTrue(status1, "Response Validation Failed.");

			// Move cycle
			Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
			Assert.assertNotNull(response, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			// Get executions of cycle after move
			Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
					move_to_version, cycleId, offset, size);
			Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
			String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
			System.out.println("Cycle after move " + movedCycle);
			String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
					.get("totalCount").toString();
			Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
			System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
			status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
					cycleId, offset, size);
			Assert.assertTrue(status, "Response Validation Failed.");

			status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");

			Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "HTML";
			Response response1 = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response1.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status2 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status2, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		 
		 }
	 
	 /**
		 * After cLONING the cycle export to HTML
		 * Created by Jagadeesh on
		 * 14-June-2019
		 */
	 
	 @Test(priority = 51, enabled= testEnabled)
		public void test51_export_Cycle_After_Clone_toHTML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Jagadeesh");
			Long Projectid = Long.parseLong(Config.getValue("projectId"));
			Long Versionid = Long.parseLong(Config.getValue("versionOneId"));
			// implement cycle clone and pass cycle id,version id which your are
			// clone
			int numberOfExecutions = 1;
			String Cyclename = "Cycle_with_oneExecution";
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Projectid);
			cycleJson.setVersionId(Versionid);
			cycleJson.setName(Cyclename);
			cycleJson.setDescription("Cycle Empty cycle");

			// pass cycleid below with cycle has one Execution
			//String cycleId = "5302ed44-dae7-4b34-9517-34b9fac93b35";
						
			cycleJson.setName("CLONE for export-" + Cyclename);
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			String cycleId = new JSONObject(response.body().asString()).get("id").toString();
			System.err.println("cycle id " + cycleId);
			
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(Projectid));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			
			
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(Projectid);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(Versionid);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);

			int offset = 0;
			int size = 5;
			
			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
					offset, size);
			Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

			int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
			System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

			Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
			Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

			String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

			Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
					Versionid, clonnedCycleId, offset, size);
			Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

			int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
					.getInt("totalCount");
			System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

			boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
					Versionid, cycleId, offset, size);
			Assert.assertTrue(status, "Response Validation Failed.");

			status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");
			
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "HTML";
			Response response1 = zapiService.exportCycle(jwtGenerator, Projectid, Versionid, clonnedCycleId, exportType);
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response1.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status1, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

	 
	 /**
		 * After editing the cycle export to XML
		 * Created by Jagadeesh on
		 * 14-June-2019
		 */
	 
	 @Test(priority = 52, enabled= testEnabled)
		public void test52_export_Cycle_After_edit_toXML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Jagadeesh");
			Long projectId = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
			// implement cycle edit and pass cycle id
			
			/*
			 * Creating cycle
			 * Set the required parameters to create cycle
			 */
			Cycle cycleJson = new Cycle();
			cycleJson.setName("Create new cycle");
			cycleJson.setBuild("#12345");
			cycleJson.setEnvironment("Windows");
			cycleJson.setDescription("Cycle desc");
			cycleJson.setStartDate("2016-11-14");
			cycleJson.setEndDate("2016-11-30");
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(VersionID);

			Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(res, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			
			JSONObject obj = new JSONObject(res.getBody().asString());
			System.out.println(obj);
			
			//Fetching the created cycleId
			String cycleId = obj.get("id").toString();
			System.out.println(cycleId);

			/*
			 * Updating cycle name
			 * Set the updated cycle name
			 */
			Cycle updateCycleJson = new Cycle();
			updateCycleJson.setId(cycleId);
			updateCycleJson.setName("Updated Cycle name for export in XML");
			updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

			Response response = zapiService.updateCycle(jwtGenerator, cycleId,updateCycleJson.toString());
			Assert.assertNotNull(response, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());			
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "XML";
			Response response1 = zapiService.exportCycle(jwtGenerator, projectId, VersionID, cycleId, exportType);
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response1.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}	 


	 /**
		 * After Moving the cycle export to XML
		 * Created by Jagadeesh on
		 * 14-June-2019
		 */
	 
	 @Test(priority = 53, enabled= testEnabled)
		public void test53_export_Cycle_After_Move_toXML(){
		 
		 ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Jagadeesh");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long VersionID = Long.parseLong(Config.getValue("versionFourId"));
			
			// implement cycle move and pass cycle id, and new version id which your
			// are moving
				
			//create cycle
			
			int numberOfExecutions = 1;

			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(VersionID);
			cycleJson.setName("Move Cycle");
			cycleJson.setDescription("Cycle moved");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");

			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(VersionID);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
			//Cycle cycleJson = new Cycle();
			// Set which cycle you want to move and which version
			// Set the cycleId which is having one execution
			
			//String cycleId = "0001482927072336-242ac112-0001";
			cycleJson.setId(cycleId);
			cycleJson.setName("Moved Cycle for export ");
			cycleJson.setProjectId(ProjectID);
			// Set Description
			cycleJson.setDescription("Cycle moved");
			// Set version which we want to move
			Long move_to_version = Long.parseLong(Config.getValue("versionTwoId"));
			cycleJson.setVersionId(move_to_version);

			// Get the execution count of cycle before move
			int offset = 0;
			int size = 10;
			Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
			Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
			String sourceCycle = responseGetExecutions.getBody().asString();
			System.out.println("Cycle before move " + sourceCycle);

			String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
			Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
			System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
			boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
			Assert.assertTrue(status1, "Response Validation Failed.");

			// Move cycle
			Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
			Assert.assertNotNull(response, "Update Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			// Get executions of cycle after move
			Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
					move_to_version, cycleId, offset, size);
			Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
			String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
			System.out.println("Cycle after move " + movedCycle);
			String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
					.get("totalCount").toString();
			Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
			System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
			status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
					cycleId, offset, size);
			Assert.assertTrue(status, "Response Validation Failed.");

			status = zapiService.validateCycle(cycleJson.toString(), response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");

			Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "XML";
			Response response1 = zapiService.exportCycle(jwtGenerator, ProjectID, VersionID, cycleId, exportType);
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response1.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status2 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status2, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		 
		 }
	 
	 /**
		 * After cLONING the cycle export to XML
		 * Created by Jagadeesh on
		 * 14-June-2019
		 */
	 
	 @Test(priority = 54, enabled= testEnabled)
		public void test54_export_Cycle_After_Clone_toXML() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Jagadeesh");
			Long Projectid = Long.parseLong(Config.getValue("projectId"));
			Long Versionid = Long.parseLong(Config.getValue("versionOneId"));
			// implement cycle clone and pass cycle id,version id which your are
			// clone
			int numberOfExecutions = 1;
			String Cyclename = "Cycle_with_oneExecution";
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Projectid);
			cycleJson.setVersionId(Versionid);
			cycleJson.setName(Cyclename);
			cycleJson.setDescription("Cycle Empty cycle");

			// pass cycleid below with cycle has one Execution
			//String cycleId = "5302ed44-dae7-4b34-9517-34b9fac93b35";
						
			cycleJson.setName("CLONE for export-" + Cyclename);
			
			Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(response, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
			String cycleId = new JSONObject(response.body().asString()).get("id").toString();
			System.err.println("cycle id " + cycleId);
			
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(Projectid));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			
			
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(Projectid);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(Versionid);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);

			int offset = 0;
			int size = 5;
			
			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
					offset, size);
			Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

			int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
			System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

			Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
			Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

			String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

			Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
					Versionid, clonnedCycleId, offset, size);
			Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

			int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
					.getInt("totalCount");
			System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

			boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
					Versionid, cycleId, offset, size);
			Assert.assertTrue(status, "Response Validation Failed.");

			status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");
			
			
			//String cycleId = "0001479189557520-242ac1134-0001";
			String exportType = "XML";
			Response response1 = zapiService.exportCycle(jwtGenerator, Projectid, Versionid, clonnedCycleId, exportType);
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response1.getBody().asString());

			Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
			String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

			boolean status1 = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
			Assert.assertTrue(status1, "Response Validation Failed.");

			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 

		}
	