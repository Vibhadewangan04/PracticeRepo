package com.thed.zephyr.bvt;

import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.service.ZAPIApiService;
import com.thed.zephyr.service.jira.JiraApiService;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.util.RestUtils;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class APITest extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"),Config.getValue("accountId"));
	}
	/**
	 * Create a Cycle
	 * Created by manoj.behera on 14-Nov-2016.
	 */
	//@Test(priority = 1)
	public void test1_createCycle1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Cycle one");
		cycleJson.setDescription("Cycle one desc");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(response.body().asString()).get("id").toString();
		extentReport.endTest(test);
	}
	/**
	 * Delete a Cycle
	 * Created by manoj.behera on 14-Nov-2016.
	 */
	@Test(priority = 3)
	public void test3_deleteCycle1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId= Long.parseLong(Config.getValue("projectId"));
		Long VersionID= Long.parseLong(Config.getValue("versionOneId"));
	
		cycleId= "0001479116490511-242ac1134-0001";
		Response response = zapiService.deleteCycle(jwtGenerator, projectId,VersionID, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");
		
		boolean status = zapiService.validateDeletedCycle( projectId, VersionID, cycleId,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update a Cycle
	 * Created by manoj.behera on 14-Nov-2016.
	 */
	//@Test(priority = 2)
	public void test2_updateCycle(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Cycle one");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setId(cycleId);
		
		Response response = zapiService.updateCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateUpdateCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Create a Issue
	 * Created by manoj.behera on 14-Nov-2016.
	 */
	//@Test(priority = 4)
	public void test4_createIssue(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10000");
		issuePayLoad.setIssuetype("First test");
		issuePayLoad.setSummary("10005");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	/**
	 * Delete an Issue
	 * Created by manoj.behera on 14-Nov-2016.
	 */
	//@Test(priority = 5)
	public void test5_deleteIssue(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Response response = jiraService.deleteIssue(basicAuth, issueKey);
		Assert.assertNotNull(response, "Delete Issue Api Response is null.");
		test.log(LogStatus.PASS, "Delete Issue Api executed successfully.");
		
		RestUtils.ValidateStatusIs204(response);
		
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
}
