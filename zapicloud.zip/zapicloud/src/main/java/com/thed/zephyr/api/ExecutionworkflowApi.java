package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

public interface ExecutionworkflowApi {
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_inprogress(JwtGenerator jwtGenerator,String Executionid,String Issueid);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_Done(JwtGenerator jwtGenerator,String action,String timeLogged,String Executionid,String Issueid);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017. */
	
	
	Response Executionworflow_Modifytime(JwtGenerator jwtGenerator,String action,String timeLogged,String Executionid,String Issueid);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_Reopen(JwtGenerator jwtGenerator,String Executionid,String Issueid);
	

}
