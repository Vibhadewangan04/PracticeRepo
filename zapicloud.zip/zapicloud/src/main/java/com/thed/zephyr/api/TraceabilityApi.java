/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.api;

import java.util.List;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public interface TraceabilityApi {

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response exportTraceabilityReport(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param downloadFilename
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response downloadExportedFile(JwtGenerator jwtGenerator, String downloadFilename);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param requirementIdOrKeyList
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response generateRequirementTraceability(JwtGenerator jwtGenerator, Long versionId, String requirementIdOrKeyList);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param defectIdList
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response generateDefectTraceability(JwtGenerator jwtGenerator, Long versionId, String defectIdList);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param defectId
	 * @param offset
	 * @param maxResult
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response searchExecutionsByDefect(JwtGenerator jwtGenerator, Long versionId, Long defectId, int offset,
			int maxResult);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param defectId
	 * @param offset
	 * @param maxResult
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response searchExecutionsByTest(JwtGenerator jwtGenerator, Long versionId, Long defectId, int offset,
			int maxResult);

}
