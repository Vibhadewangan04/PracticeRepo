/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.stepresult;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class GetStepResultsApi extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//Attempt to getTestStepResults with no valid authentication */
	//@Test(priority = 2)
	public void getStepResults1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479158020117-242ac1134-0001";
		Long issueId = 10100l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getTestStepResults with no browse permission to project */
	//@Test(priority = 2)
	public void getStepResults2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479158020117-242ac1134-0001";
		Long issueId = 10100l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getTestStepResults with no browse permission to project */
	//@Test(priority = 2)
	public void getStepResults3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479158020117-242ac1134-0001";
		Long issueId = 10100l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getTestStepResults with no steps */
	//@Test(priority = 2)
	public void getStepResults4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479158020117-242ac1134-0001";
		Long issueId = 10100l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with 10 step unexecuted */
	//@Test(priority = 2)
	public void getStepResults5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with 10 steps partially executed to PASS/FAIL/WIP/BLOCKED/CUSTOM */
	@Test(priority = 2)
	public void getStepResults6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479944969667-242ac1121-0001";
		Long issueId = 10580l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with 10 steps completely executed */
	//@Test(priority = 2)
	public void getStepResults7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults with 100 steps unexecuted */
	//@Test(priority = 2)
	public void getStepResults8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with 100 steps partially executed */
	//@Test(priority = 2)
	public void getStepResults9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with 100 steps completely executed */
	//@Test(priority = 2)
	public void getStepResults10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with defects linked in some steps
	//@Test(priority = 2)
	public void getStepResults11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with defects linked in all steps
	//@Test(priority = 2)
	public void getStepResults12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with 20 defects linked to a step
	//@Test(priority = 2)
	public void getStepResults13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479254342965-242ac1137-0001";
		Long issueId = 10202l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with comment and defect in a step
	//@Test(priority = 2)
	public void getStepResults14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479254342965-242ac1137-0001";
		Long issueId = 10202l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestStepResults with comments in partial steps
	//@Test(priority = 2)
	public void getStepResults15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults with numeric comments in parital steps
	//@Test(priority = 2)
	public void getStepResults16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults with international chars comments in all steps
	//@Test(priority = 2)
	public void getStepResults17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults with special chars in comments in all steps
	//@Test(priority = 2)
	public void getStepResults18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults with aplha numeric chars in comments in all steps
	//@Test(priority = 2)
	public void getStepResults19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps unexecuted
	//@Test(priority = 2)
	public void getStepResults20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479256072154-242ac1137-0001";
		Long issueId = 10203l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps executed to PASS
	//@Test(priority = 2)
	public void getStepResults21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479256072154-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps executed to FAIL
	//@Test(priority = 2)
	public void getStepResults22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps executed to WIP
	//@Test(priority = 2)
	public void getStepResults23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps executed to BLOCKED
	//@Test(priority = 2)
	public void getStepResults24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps executed to CUSTOM
	//@Test(priority = 2)
	public void getStepResults25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps linked to defects
	//@Test(priority = 2)
	public void getStepResults26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps linked to defects, comments
	//@Test(priority = 2)
	public void getStepResults27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps linked to  attachments
	//@Test(priority = 2)
	public void getStepResults28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479249034769-242ac1137-0001";
		Long issueId = 10201l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestStepResults of issue with cloned steps linked to  attachments, defects and comments
	//@Test(priority = 2)
	public void getStepResults29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10204l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getTestStepResults with wrong ProjectID but valid executionId and Valid IssueId
	//@Test(priority = 2)
	public void getStepResults30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10204l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	

	//getTestsStepResults in step order with isOrdered set to false should fetch all stepResults( but they will not be in step order)
	//@Test(priority = 2)
	public void getStepResults31(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10204l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	//Attempt to getTestStepResults with wrong ExecutionID but valid ProjectId and Valid IssueId
	//@Test(priority = 2)
	public void getStepResults32(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271000000-242ac1137-0001";
		Long issueId = 10204l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	//Attempt to getTestStepResults with wrong IssueID but valid executionId and Valid projectID
	//@Test(priority = 2)
	public void getStepResults33(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 9999l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	

	//Attempt to getTestStepResults with IssueId as null
	//@Test(priority = 2)
	public void getStepResults34(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = null;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	//Attempt to getTestStepResults with ExecutionId as null
	//@Test(priority = 2)
	public void getStepResults35(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = null;
		Long issueId = 10204l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	

	/*Manual - getStepResults of a Cloned test to cycle through UI
	 *Create a test with steps. Clone the test and add it to a cycle through UI.
	 *Make a call by passing the issueId and executionId of the cloned test.
	 **/

	//@Test(priority = 2)
	public void getStepResults36(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	/*Bulk copy test to cycle through UI and get  getStepResults
	 *Create a test with steps. Add it to a cycle. Bulk copy this execution to another cycle through UI.
	 *Make a call by passing the issueId and executionId of this copied execution
	 **/
	//@Test(priority = 2)
	public void getStepResults37(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*Attempt to getStepResult if Bulk copy test to cycle through UI and stepResult does not exist 
	 *Create a test with no steps. Add it to a cycle. Bulk copy this execution to another cycle through UI.
	 *Make a call by passing the issueId and executionId of this copied execution
	 **/

	//@Test(priority = 2)
	public void getStepResults38(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	
	/*Bulk copy test to cycle through API and get  getStepResults
	 *Create a test wit steps. Add it to a cycle. Bulk copy this execution to another cycle with API
	 *Make a call by passing the issueId and executionId of this copied execution
	 **/
	//@Test(priority = 2)
	public void getStepResults39(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*Attempt to getStepResult if Bulk copy test to cycle through API and stepResult does not exist 
	 *Create a test with no steps. Add it to a cycle. Bulk copy this execution to another cycle with API
	 *Make a call by passing the issueId and executionId of this copied execution
	 **/
	//@Test(priority = 2)
	public void getStepResults40(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	
	/*getStepResults by Bulk copy test to cycle by clearing defect mapping, execution, assignment flags 
	 *Create a test with no steps. Add it to a cycle. Bulk copy this execution to another cycle with API by clearing defect mapping and execution
	 *Make a call by passing the issueId and executionId of this copied execution
	 */
	@Test(priority = 2)
	public void getStepResults41(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	
	/*getStepResults by Bulk copy test to cycle without clearing defect mapping, execution, assignment flags getStepResults by Bulk copy test to cycle WITHOUT clearing defect mapping, execution, assignment flags 
	 *Create a test with no steps. Add it to a cycle. Bulk copy this execution to another cycle with API by clearing defect mapping and execution
	 *Make a call by passing the issueId and executionId of this copied execution
	 */
	//@Test(priority = 2)
	public void getStepResults42(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");


		String executionId = "0001479271706163-242ac1137-0001";
		Long issueId = 10205l;
		Boolean isOrdered = true;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}			
}
