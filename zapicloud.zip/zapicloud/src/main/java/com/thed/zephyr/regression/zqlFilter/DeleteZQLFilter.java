package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

public class DeleteZQLFilter extends BaseTest {

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 1.Delete a favorite filter
 * 
 */
 @Test(priority = 1)
	public void Test1_deleteFilter_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 2.Delete non favorite filter
 * 
 */

@Test(priority = 2)
	public void Test2_deleteFilter_non_favorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 *  3.Delete favorite and shared permission global
 * filter
 * 
 */
@Test(priority = 3)
	public void Test3_deleteFilter_fav_and_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 4.Delete non favorite and shared permission global filter
 * 
 */
@Test(priority = 4)
	public void Test4_deleteFilter_non_fav_and_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 5.Delete favorite and shared permission private filter
 * 
 */
@Test(priority = 5)
	public void Test5_deleteFilter_favorite_and_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 *  6.Delete non favorite and shared permission private filter
 * 
 */
@Test(priority = 6)
	public void Test6_deleteFilter_non_fav_and_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();	
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Attempt cases

/**
 * ZQLFilter Api DeleteFilter
 *  7.Attempt to Delete the deleted Favorite filter
 * 
 */
@Test(priority = 7)
	public void Test7_Attempt_deleteFilter_deleted_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		// Attempting to Delete already deleted filter
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		System.out.println(filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 * 8.Attempt to Delete the deleted non favorite filter
 * 
 */
@Test(priority = 8)
	public void Test8_Attempt_deleteFilter_delted_non_fav_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
	
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		// Attempting to Delete already deleted filter
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 9.Attempt Delete the deleted favorite and shared permission global filter
 * 
 */
@Test(priority = 9)
	public void Test9_Attempt_deleteFilter_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
	
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		// Attempting to Delete already deleted filter
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 10.Attempt Delete the deleted non favorite and shared permission global filter
 * 
 */
@Test(priority = 10)
	public void Test10_Attempt_deleteFilter_non_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
	
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		// Attempting to Delete already deleted filter
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 11.Attempt Delete the deleted favorite and shared permission private filter
 * 
 */
@Test(priority = 11)
	public void Test11_Attempt_deleteFilter_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
	
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		// Attempting to Delete already deleted filter
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 12.Attempt Delete the deleted non favorite and shared permission private filter
 * 
 */
@Test(priority = 12)
	public void Test12_Attempt_deleteFilter_non_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
	
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		// Attempting to Delete already deleted filter
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 13.Attempt Delete the filter with invalid Filter id
 * 
 */
@Test(priority = 13)
	public void Test13_Attempt_deleteFilter_invalid_filter_id() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		String filterId = "0001480574298023-242ac112-0001123";
		Response response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter DeleteFilter 
 * 14.Attempt Delete the filter with null Filter id
 * 
 */
@Test(priority = 14)
	public void Test14_deleteFilter_null_filter_id() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		String filterId = null;
		Response response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateInvalidZQLFilterId(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 15.Delete Updated a favorite filter.
 * 
 */
@Test(priority = 15)
	public void Test15_deleteFilter_updated_fav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");		
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Update Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Update Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 16.Delete updated a non favorite filter
 * 
 */
@Test(priority = 16)
	public void Test16_deleteFilter_updated_non_fav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");		
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Update Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Update Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 17. Delete Filter updated a favorite and shared permission global.
 * 
 */
@Test(priority = 17)
	public void Test17_deleteFilter_updated_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");		
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Update Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Update Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 18.Delete updated a non favorite and shared permission global filter
 * 
 */
@Test(priority = 18)
	public void Test18_deleteFilter_updated_non_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");		
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Update Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Update Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 * 19.Delete updated favorite and shared permission private filter
 * 
 */
@Test(priority = 19)
	public void Test19_deleteFilter_updated_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");		
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Update Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Update Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 20.Delete updated non favorite and shared permission private filter
 * 
 */
@Test(priority = 20)
	public void Test20_deleteFilter_updated_non_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");		
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Update Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Update Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);		
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 21. Delete copied Filter favorite filter
 * 
 */
@Test(priority = 21)
	public void Test21_deletefilter_copied_fav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());		
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		Assert.assertNotNull(response, "Copy Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Copy Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(filterId);
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		// Delete filter code
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 22.Delete Filter copy a non favorite filter
 */
@Test(priority = 22)
	public void Test22_deletefilter_copied_non_fav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());		
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		Assert.assertNotNull(response, "Copy Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Copy Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(filterId);
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		// Delete filter code
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 23. Delete filter copy a favorite and shared permission global filter
 * 
 */
@Test(priority = 23)
	public void Test23_deletefilter_copied_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());		
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		Assert.assertNotNull(response, "Copy Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Copy Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(filterId);
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		// Delete filter code
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 *  24. Delete filter copy a non favorite and shared permission global filter
 * 
 */
@Test(priority = 24)
	public void Test24_deletefilter_copied_non_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());		
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		Assert.assertNotNull(response, "Copy Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Copy Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(filterId);
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		// Delete filter code
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 25. Delete filter copy a favorite and shared permission private filter
 * 
 */
@Test(priority = 25)
	public void Test25_deletefilter_copied_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());		
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		Assert.assertNotNull(response, "Copy Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Copy Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(filterId);
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		// Delete filter code
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 *  26. Delete filter copy a non favorite and shared permission private filter
 * 
 */
@Test(priority = 26)
	public void Test26_deletefilter_copied_non_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());		
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		Assert.assertNotNull(response, "Copy Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Copy Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		zqlfilterJson.setId(filterId);
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		// Delete filter code
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Delete Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Delete Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 27.Delete toggled favorite filter
 * 
 */
@Test(priority = 27)
	public void Test27_deleteFilter_toggle_fav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(false);
		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Toggle Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 28.Delete toggled non favorite filter
 * 
 */

@Test(priority = 28)
	public void Test28_deleteFilter_toggle_non_fav() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(true);
		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Toggle Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter 
 * 29.Delete Toggled filter a favorite and shared permission global filter
 * 
 */

@Test(priority = 29)
	public void Test29_deleteFilter_toggle_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(false);
		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Toggle Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 *  30.Delete Toggled filter a non favorite and shared permission global filter
 * 
 */

@Test(priority = 30)
	public void Test30_deleteFilter_toggle_non_fav_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(true);
		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Toggle Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * ZQLFilter Api DeleteFilter
 *  31.Delete Toggled filter a favorite and shared permission private filter
 * 
 */

@Test(priority = 31)
	public void Test31_deleteFilter_toggle_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(false);
		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Toggle Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);	}

/**
 * ZQLFilter Api DeleteFilter
 *  32.Delete Toggled filter a non favorite and shared permission private filter
 * 
 */
@Test(priority = 32)
	public void Test32_deleteFilter_toggle_non_fav_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);	
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(true);
		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Toggle Zql filter Api Response is null.");
		test.log(LogStatus.PASS, "Toggle Zql filter Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Delete Zql filter APi Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
