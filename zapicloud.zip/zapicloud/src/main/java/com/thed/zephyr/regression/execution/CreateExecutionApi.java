/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.execution;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class CreateExecutionApi extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	Long issueId = null;

	String cycleIdScheduledVersion = null;
	String cycleIdUnscheduledVersion = null;

	@BeforeClass
	public void beforeClass() {
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("zephyr");

		System.out.println(cycleJson.toString());
		Response response1 = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response1, "Create Cycle Api Response is null.");
		System.out.println(response1.getBody().asString());

		boolean status1 = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		cycleIdScheduledVersion = new JSONObject(response1.getBody().asString()).getString("id");

		// Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("zephyr");

		System.out.println(cycleJson.toString());
		Response response2 = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response2, "Create Cycle Api Response is null.");
		System.out.println(response2.getBody().asString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), response2);
		Assert.assertTrue(status2, "Response Validation Failed.");
		cycleIdUnscheduledVersion = new JSONObject(response2.getBody().asString()).getString("id");
	}

	@BeforeMethod
	public void handleTestMethodName(Method method) {
		String testName = method.getName();
		System.out.println(testName);
	}

	/**
	 * Create an execution in an non-adhoc cycle of a scheduled version
	 */
	@Test(priority = 1, enabled = testEnabled)
	public void reg_tc1_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create an execution in an adhoc cycle of a scheduled version
	 */
	@Test(priority = 2, enabled = testEnabled)
	public void reg_tc2_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create an execution in an non-adhoc cycle of a un-scheduled version
	 */
	@Test(priority = 3, enabled = testEnabled)
	public void reg_tc3_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdUnscheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create an execution in an adhoc cycle of a un-scheduled version
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void reg_tc4_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Creating execution without providing VersionId and CycleId It will create
	 * the execution in Unscheduled version and adhoc cycle=ZFJCLOUD-2595
	 */
	@Test(priority = 5, enabled = testEnabled)
	public void reg_tc5_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		// executionJson.setCycleId(this.cycleIdUnscheduledVersion);
		// executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Creating execution without providing CycleId in a Scheduled Version. It
	 * will create the execution in adhoc cycle
	 */
	@Test(priority = 6, enabled = testEnabled)
	public void reg_tc6_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		// executionJson.setCycleId(this.cycleIdUnscheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Creating execution without providing versionId and scheduled cycle. It
	 * will create the execution in unscheduled version
	 */
	@Test(priority = 7, enabled = testEnabled)
	public void reg_tc7_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdUnscheduledVersion);
		//executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO
	//@Test(priority = 2)
	public void test1_createExecution1s() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		List<Long> list = new ArrayList<>();
		list.add(10050l);
		list.add(10051l);
		list.add(10052l);
		list.add(10053l);
		list.add(10054l);
		executionJson.setIssueIds(list);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setNoOfExecutions(5);
		executionJson.setCycleId("-1");

		JSONArray response = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		extentReport.endTest(test);
	}

	//@Test(priority = 2)
	public void test1_createExecution2s() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		List<Long> list = new ArrayList<>();
		list.add(10050l);
		executionJson.setIssueIds(list);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setNoOfExecutions(5);
		executionJson.setCycleId("-1");

		JSONArray response = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create multiple executions in un-scheduled version scheduled cycle(5
	 * executions)
	 * 
	 */
	@Test(priority = 10, enabled = testEnabled)
	public void reg_tc10_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		executionJson.setNoOfExecutions(5);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create multiple executions in scheduled version adhoc cycle(50
	 * executions)
	 * 
	 */
	@Test(priority = 11, enabled = false)
	public void reg_tc11_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		cycleId = "-1";

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 50);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setNoOfExecutions(50);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(50 executions) successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create multiple executions in scheduled version non-adhoc cycle(500
	 * executions) with different tests
	 * 
	 */
	@Test(priority = 12, enabled = false)
	public void reg_tc12_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 500);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setNoOfExecutions(500);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(500 executions) successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create multiple executions in un-scheduled version adhoc cycle(500
	 * executions) with same test
	 * 
	 */
	@Test(priority = 13, enabled = false)
	public void reg_tc13_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		cycleId = "-1";

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		executionJson.setNoOfExecutions(500);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create an execution after cloning a test This is a manual case for now
	 */
	@Test(priority = 14, enabled = testEnabled)
	public void reg_tc14_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//creating issueid1
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		
		//cloned 
		Issue issuePayLoad3 = new Issue();
		// String clonedIssue = issuePayLoad3.cloneIssue(issueKey1);
		 issuePayLoad3.setProject(Config.getValue("projectId"));
			issuePayLoad3.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad3.setSummary("cloned issue");
			issuePayLoad3.setPriority("1");
			issuePayLoad3.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad3.toString());
			//clone issue
			Response response3 = jiraService.createIssue(basicAuth, issuePayLoad3.toString());
			Assert.assertNotNull(response3, "Clone Issue Api Response is null.");
			
			boolean issueStatus = jiraService.validateCreateIssueApi(response3);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long cloneissueId = Long.parseLong(new JSONObject(response3.body().asString()).getString("id"));
			String cloneissueKey = new JSONObject(response3.body().asString()).getString("key");
			
//create execution
    Execution executionJson = new Execution();
    executionJson.setStatusId(-1l);
    executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
    executionJson.setIssueId(cloneissueId);
    executionJson.setCycleId(this.cycleIdScheduledVersion);
    executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

   Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
   Assert.assertNotNull(response, "Create Execution Api Response is null.");
   test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

   boolean status = zapiService.validateExecution(executionJson.toString(), response);
   Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
   test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
   extentReport.endTest(test);
}


/**
	 * Change issue type from bug/new feature/improvement/task/custom type to
	 * test then add test to cycle This is a manual case for now
	 */
	@Test(priority = 15, enabled = false)
	public void reg_tc15_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(10050l);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Create execution without providing projectId
	 */
	@Test(priority = 16, enabled = testEnabled)
	public void reg_tc16_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		//executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(this.cycleIdUnscheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Create execution without providing issueId
	 */
	@Test(priority = 17, enabled = testEnabled)
	public void reg_tc17_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		// executionJson.setIssueId(issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to create execution in a cycle that does not belong to that
	 * version
	 */
	@Test(priority = 18, enabled = testEnabled)
	public void reg_tc18_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String cycleId = cycleIdScheduledVersion;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateInvalidCycleId(cycleId, response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to create execution for an issue that belongs to different
	 * project
	 */
	@Test(priority = 19, enabled = testEnabled)
	public void reg_tc19_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		long issueId = 2198233l;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateInvalidIssueId(issueId, response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to create execution by providing valid cycle id and invalid
	 * version id
	 */
	@Test(priority = 20, enabled = testEnabled)
	public void reg_tc20_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		long versionId = 14551l;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(versionId);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateInvalidVersionId(versionId, response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to create execution by providing INVALID cycle id
	 */
	@Test(priority = 21, enabled = testEnabled)
	public void reg_tc21_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String cycleId = "14455";
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateInvalidCycleId(cycleId, response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to create execution by providing invalid project id
	 */
	@Test(priority = 22, enabled = testEnabled)
	public void reg_tc22_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		long projectId = 14551l;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateNullProjectId(projectId, response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create multiple executions in scheduled version non-adhoc cycle(500
	 * executions) with different tests
	 * 
	 */
	@Test(priority = 23, enabled = false)
	public void reg_tc23_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 500);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setNoOfExecutions(500);
		executionJson.setCycleId(cycleId);

		Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Created execution validated successully.");

		status = zapiService.validateExecution(executionJson.toString(), executionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Created execution validated successully.");

		status = zapiService.validateMultipleExecutionsWithSameIssueInScheduledCycle(executionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Create execution with an invalid issueId
	 */
	@Test(priority = 24, enabled = testEnabled)
	public void reg_tc24_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		long issueId = 2198233l;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateInvalidIssueId(issueId, response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to add issue of type Bug to cycle
	 */
	@Test(priority = 25, enabled = testEnabled)
	public void reg_tc25_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug summary");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response issueResponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(issueResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		//executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		Long issueIdBug = Long.parseLong(new JSONObject(issueResponse.body().asString()).getString("id"));
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueIdBug);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response ExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(ExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateInvalidTestType(issueIdBug, ExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to add issue of type Story to cycle
	 */
	@Test(priority = 26, enabled = testEnabled)
	public void reg_tc26_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeStoryId"));
		issuePayLoad.setSummary("Story summary");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response issueResponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(issueResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		Long issueIdStory = Long.parseLong(new JSONObject(issueResponse.body().asString()).getString("id"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueIdStory);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response ExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(ExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateInvalidTestType(issueIdStory, ExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to add issue of type New Feature/Epic to cycle
	 */
	@Test(priority = 27, enabled = testEnabled)
	public void reg_tc27_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setEpicName("EpicName");
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeEpicId"));
		issuePayLoad.setSummary("Epic summary");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response issueResponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(issueResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		Long issueIdEpic = Long.parseLong(new JSONObject(issueResponse.body().asString()).getString("id"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueIdEpic);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response ExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(ExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateInvalidTestType(issueIdEpic, ExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to add issue of type Task to cycle
	 */
	@Test(priority = 28, enabled = testEnabled)
	public void reg_tc28_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTaskId"));
		issuePayLoad.setSummary("Task summary");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response issueResponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(issueResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		Long issueIdTask = Long.parseLong(new JSONObject(issueResponse.body().asString()).getString("id"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueIdTask);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response ExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(ExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateInvalidTestType(issueIdTask, ExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to add issue of type Sub-task to cycle This is a manual case for
	 * now
	 */
	@Test(priority = 29, enabled = testEnabled)
	public void reg_tc29_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Long issueIdSubTask = 1000l;
		// Creating defect
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTaskId"));
				issuePayLoad.setSummary("bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				//issuePayLoad.setparent(Config.getValue("issueKey"));
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad.toString());
				Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response, "Create Issue Api Response is null.");
				//
				boolean issueStatus = jiraService.validateCreateIssueApi(response);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
				String bugissueKey = new JSONObject(response.body().asString()).getString("key");
				
				// Creating subtask
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeSubTaskId"));
				issuePayLoad1.setSummary("Sub task Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setparent(bugissueKey);
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				System.out.println(issuePayLoad1.toString());
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				//
				boolean issueStatus1 = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus1, "Response Validation Failed.");
				Long subtaskid = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(subtaskid);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response ExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(ExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateInvalidTestType(subtaskid, ExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to add issue of type user-defined type to cycle
	 */
	@Test(priority = 30, enabled = testEnabled)
	public void reg_tc30_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeUserDefinedId"));
		issuePayLoad.setSummary("userdefined summary");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response issueResponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(issueResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		Long issueIdUserdefined = Long.parseLong(new JSONObject(issueResponse.body().asString()).getString("id"));
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueIdUserdefined);
		executionJson.setCycleId(cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response ExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(ExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		status = zapiService.validateInvalidTestType(issueIdUserdefined, ExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Manual - Attempt to create execution if user has no access to the project
	 * This is a manual case, need to check
	 */
	@Test(priority = 31, enabled = false)
	public void reg_tc31_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create an execution where Test is created in the UI. This is a manual
	 * case.
	 */
	@Test(priority = 32, enabled = testEnabled)
	public void reg_tc32_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		/**
		 * Manually provide the issue id.
		 */
		executionJson.setIssueId(Long.parseLong(Config.getValue("issueId")));
		executionJson.setCycleId(this.cycleIdScheduledVersion);
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
