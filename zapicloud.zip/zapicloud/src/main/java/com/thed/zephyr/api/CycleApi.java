package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

import javax.ws.rs.core.UriBuilder;

import java.io.IOException;

import static com.jayway.restassured.RestAssured.given;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface CycleApi {
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createCycle(JwtGenerator jwtGenerator, String payLoad);
	 /**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response updateCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	 /**
	 * @param jwtGenerator
	 * @param cycleId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);
	/**
	 * @param jwtGenerator
	 * @param cycleId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response moveExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param cycleId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response copyExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getCycles(JwtGenerator jwtGenerator, Long projectId, Long versionId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @param exportType
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response exportCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId,
			String exportType);
	/**
	 * @param jwtGenerator
	 * @param downloadFilename
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response downloadExportedFile(JwtGenerator jwtGenerator, String downloadFilename);
	/**
	 * @param jwtGenerator
	 * @param cycleId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response moveCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param clonedCycleId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response cloneCycle(JwtGenerator jwtGenerator, String clonedCycleId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 10-Jan-2017.
	 */
	Response getListOfCyclesBySprint(JwtGenerator jwtGenerator, String payLoad);
	

	
}
