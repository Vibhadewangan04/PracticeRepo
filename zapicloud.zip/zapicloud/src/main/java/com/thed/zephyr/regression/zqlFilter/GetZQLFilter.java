package com.thed.zephyr.regression.zqlFilter;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

public class GetZQLFilter extends BaseTest {

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * Test case - 1 Get ZQL filter when filter has: "Zql":
	 * "project = projectName"
	 */

	// get ZQL filter: "Zql":"project = IE"
	@Test(priority = 1)
	public void test1_getZqlFilter_by_project_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = " + Config.getValue("projectKey"));
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(), getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 2 Get ZQL filter when filter has: "Zql":
	 * "project != projectName"
	 */
	// get ZQL filter: "Zql":"project != IE"
	@Test(priority = 2)
	public void test2_getZqlFilter_by_project_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project != " + Config.getValue("projectKey"));
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(), getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 3 Get ZQL filter when filter has:"Zql":"project is not Empty"
	 */

	// get ZQL filter: "Zql":"project is not Empty"
	@Test(priority = 3)
	public void test3_getZqlFilter_by_project_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is not EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(), getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 4 Get ZQL filter when filter has: "Zql":"project is EMPTY"
	 */
	// get ZQL filter: "Zql":"project is Empty"
	@Test(priority = 4)
	public void test4_getZqlFilter_by_project_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(), getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 5 Get ZQL filter when filter has: "Zql":
	 * "project not in (projectkey,projectkey1)"
	 */

	// get ZQL filter: "Zql":"project not in (IE,Rock)"
	@Test(priority = 5)
	public void test5_getZqlFilter_by_project_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"project not in" + "(" + Config.getValue("projectKey") + "," + Config.getValue("projectKey1") + ")");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(), getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 6 Get ZQL filter when filter has: "Zql":
	 * "project in (projectkey,projectkey1)"
	 */

	// get ZQL filter: "Zql":"project in (IE,Rock,RUBY)"
	@Test(priority = 6)
	public void test6_getZqlFilter_by_project_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"project in" + "(" + Config.getValue("projectKey") + "," + Config.getValue("projectKey1") + ")");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 7 Get ZQL filter when filter has: "Zql":"priority = Highest"
	 */

	// get ZQL filter: "Zql":"priority = Highest"
	@Test(priority = 7)
	public void test7_getZqlFilter_by_priority_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority = Highest");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 8 Get ZQL filter when filter has: "Zql":"priority != Medium"
	 */

	// get ZQL filter: "Zql":"priority != Medium"
	@Test(priority = 8)
	public void test8_getZqlFilter_by_priority_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority != Medium");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 9 Get ZQL filter when filter has:"Zql":
	 * "priority is not EMPTY"
	 */

	// get ZQL filter: "Zql":"priority is not Empty"
	@Test(priority = 9)
	public void test9_getZqlFilter_by_priority_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority is not EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 10 Get ZQL filter when filter has: "Zql":"priority is EMPTY"
	 */

	// get ZQL filter: "Zql":"priority is Empty"
	@Test(priority = 10)
	public void test10_getZqlFilter_by_priority_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority is EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 11 Get ZQL filter when filter has: "Zql":
	 * "priority not in (Low,Lowest,Medium)"
	 */

	// get ZQL filter: "Zql":"priority not in (Low,Lowest,Medium)"
	@Test(priority = 11)
	public void test11_getZqlFilter_by_priority_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority not in (Low,Lowest,Medium)");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 12 Get ZQL filter when filter has: "Zql":
	 * "priority in (Low,Lowest,Medium)"
	 */

	// get ZQL filter: "Zql":"priority in (Highest,High)"
	@Test(priority = 12)
	public void test12_getZqlFilter_by_priority_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority in (Low,Lowest,Medium)");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 13 Get ZQL filter when filter has: "Zql":
	 * "component = component name"
	 */
	// get ZQL filter: "Zql":"component = RC10"
	@Test(priority = 13)
	public void test13_getZqlFilter_by_component_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component =" + Config.getValue("component"));
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 14 Get ZQL filter when filter has: "Zql":
	 * "component != component name"
	 */
	// get ZQL filter: "Zql":"component != RC10"
	@Test(priority = 14)
	public void test14_getZqlFilter_by_component_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component !=" + Config.getValue("component"));
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 15 Get ZQL filter when filter has: "Zql":
	 * "component is not Empty"
	 */
	// get ZQL filter: "Zql":"component is not Empty"
	@Test(priority = 15)
	public void test15_getZqlFilter_by_component_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component is not EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 16 Get ZQL filter when filter has: "Zql":"component is Empty"
	 */

	// get ZQL filter: "Zql":"component is Empty"
	@Test(priority = 16)
	public void test16_getZqlFilter_by_component_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component is EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 17 Get ZQL filter when filter has: "Zql":
	 * "component not in (component,component1)"
	 */
	// get ZQL filter: "Zql":"component not in (RC10,RC20)"
	@Test(priority = 17)
	public void test17_getZqlFilter_by_component_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"component not in (" + Config.getValue("component") + "," + Config.getValue("component1") + ")");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 18 Get ZQL filter when filter has: "Zql":
	 * "component not in (component,component1)"
	 */
	// get ZQL filter: "Zql":"component in (RC10,RC20,c1)"
	@Test(priority = 18)
	public void test18_getZqlFilter_by_component_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson
				.setZql("component in (" + Config.getValue("component") + "," + Config.getValue("component1") + ")");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 19 Get ZQL filter when filter has:
	 * "Zql":cycleName="cyclename"
	 */
	// get ZQL filter: "Zql":"cycleName = 123"
	@Test(priority = 19)
	public void test19_getZqlFilter_by_cycleName_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName=\"" + Config.getValue("cyclename") + "\"");
		zqlfilterJson.setName("cyclename1 " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 20 Get ZQL filter when filter has:
	 * "Zql":cycleName!="cyclename"
	 */

	// get ZQL filter: "Zql":"cycleName != 123"
	@Test(priority = 20)
	public void test20_getZqlFilter_by_cycleName_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName!=\"" + Config.getValue("cyclename") + "\"");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 21 Get ZQL filter when filter has: "Zql":cycleName is not
	 * EMPTY"
	 */
	// get ZQL filter: "Zql":"cycleName is not Empty"
	@Test(priority = 21)
	public void test21_getZqlFilter_by_cycleName_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName is not EMPTY");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 22 Get ZQL filter when filter has: "Zql":cycleName is EMPTY"
	 */
	// get ZQL filter: "Zql":"cycleName is Empty"
	@Test(priority = 22)
	public void test22_getZqlFilter_by_cycleName_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName is EMPTY");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 23 Get ZQL filter when filter has: "Zql":cycleName not in
	 * (cyclename,cyclename1)"
	 */
	// get ZQL filter: "Zql":"cycleName not in (123,50 exe)"
	@Test(priority = 23)
	public void test23_getZqlFilter_by_cycleName_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"cycleName not in (" + Config.getValue("cyclename") + "," + Config.getValue("cyclename1") + ")");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 24 Get ZQL filter when filter has: "Zql":cycleName in
	 * (cyclename,cyclename1)"
	 */
	// get ZQL filter: "Zql":"cycleName in (123,50 exe,Ad hoc)"
	@Test(priority = 24)
	public void test24_getZqlFilter_by_cycleName_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson
				.setZql("cycleName in (" + Config.getValue("cyclename") + "," + Config.getValue("cyclename1") + ")");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 25 Get ZQL filter when filter has: "Zql":cycleName ~ad"
	 */
	// get ZQL filter: "Zql":"cycleName ~ 123"
	@Test(priority = 25)
	public void test25_getZqlFilter_by_cycleName_tilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName ~ad");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 26 Get ZQL filter when filter has: "Zql":cycleName !~ad"
	 */
	// get ZQL filter: "Zql":"cycleName !~ 123"
	@Test(priority = 26)
	public void test26_getZqlFilter_by_cycleName_NotTilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName !~ad");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 27 Get ZQL filter when filter has: "Zql":fixVersion =
	 * fixversioname"
	 */
	// get ZQL filter: "Zql": fixVersion = "RUBY#2.0"
	@Test(priority = 27)
	public void test27_getZqlFilter_by_fixVersion_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion = " + Config.getValue("fixVersion"));
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 28 Get ZQL filter when filter has: "Zql":fixVersion !=
	 * fixversioname"
	 */
	// get ZQL filter: "Zql":"fixVersion != RUBY#2.0"
	@Test(priority = 28)
	public void test28_getZqlFilter_by_fixVersion_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion != " + Config.getValue("fixVersion"));
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 29 Get ZQL filter when filter has: "Zql":fixVersion !=
	 * fixversioname"
	 */
	// get ZQL filter: "Zql":"fixVersion is not Empty"
	@Test(priority = 29)
	public void test29_getZqlFilter_by_fixVersion_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion is not EMPTY");
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 30 Get ZQL filter when filter has: "Zql":fixVersion is EMPTY"
	 */
	// get ZQL filter: "Zql":"fixVersion is Empty"
	@Test(priority = 30)
	public void test30_getZqlFilter_by_fixVersion_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion is EMPTY");
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 31 Get ZQL filter when filter has: "Zql":fixVersion not
	 * in(fixVersion,fixVersion1)"
	 */
	// get ZQL filter: "Zql":"fixVersion not in (RUBY#2.0,50)"
	@Test(priority = 31)
	public void test31_getZqlFilter_by_fixVersion_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"fixVersion not in (" + Config.getValue("fixVersion") + "," + Config.getValue("fixVersion1") + ")");
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 32 Get ZQL filter when filter has: "Zql":fixVersion in
	 * (fixVersion,fixVersion1)"
	 */
	// get ZQL filter: "Zql":"fixVersion in (RUBY#2.0,50,Unscheduled)"
	@Test(priority = 32)
	public void test32_getZqlFilter_by_fixVersion_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson
				.setZql("fixVersion in (" + Config.getValue("fixVersion") + "," + Config.getValue("fixVersion1") + ")");
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 33 Get ZQL filter when filter has: "Zql":executionStatus =
	 * WIP"
	 */
	// get ZQL filter: "Zql": "executionStatus = WIP"
	@Test(priority = 33)
	public void test33_getZqlFilter_by_executionStatus_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus =" + Config.getValue("executionStatus"));
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 34 Get ZQL filter when filter has: "Zql":executionStatus !=
	 * FAIL"
	 */
	// get ZQL filter: "Zql":"executionStatus != FAIL"
	@Test(priority = 34)
	public void test34_getZqlFilter_by_executionStatus_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus !=" + Config.getValue("executionStatus1"));
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 35 Get ZQL filter when filter has: "Zql":executionStatus is
	 * not Empty"
	 */
	// get ZQL filter: "Zql":"executionStatus is not Empty"
	@Test(priority = 35)
	public void test35_getZqlFilter_by_executionStatus_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus is not Empty");
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 36 Get ZQL filter when filter has: "Zql":executionStatus is
	 * not Empty"
	 */
	// get ZQL filter: "Zql":"executionStatus is Empty"
	@Test(priority = 36)
	public void test36_getZqlFilter_by_executionStatus_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus is Empty");
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 37 Get ZQL filter when filter has: "Zql":executionStatus not
	 * in (executionStatus,executionStatus1)"
	 */

	// get ZQL filter: "Zql":"executionStatus not in (PASSED,WIP)"
	@Test(priority = 37)
	public void test37_getZqlFilter_by_executionStatus_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus not in (" + Config.getValue("executionStatus") + ","
				+ Config.getValue("executionStatus1") + ")");
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 38 Get ZQL filter when filter has: "Zql":executionStatus in
	 * (BLOCKED,UNEXECUTED,new!)"
	 */
	// get ZQL filter: "Zql":"executionStatus in (BLOCKED,UNEXECUTED,new!)"
	@Test(priority = 38)
	public void test38_getZqlFilter_by_executionStatus_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus in (" + Config.getValue("executionStatus") + ","
				+ Config.getValue("executionStatus1") + "," + Config.getValue("customStatus") + ")");
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 39 Get ZQL filter when filter has: "Zql":executedBy = admin"
	 */
	// get ZQL filter: "Zql": "executedBy = admin"
	@Test(priority = 39)
	public void test39_getZqlFilter_by_executedBy_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy = admin");
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 40 Get ZQL filter when filter has: "Zql":executedBy != admin"
	 */
	// get ZQL filter: "Zql":"executedBy != admin"
	@Test(priority = 40)
	public void test40_getZqlFilter_by_executedBy_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy != admin");
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 41 Get ZQL filter when filter has: "Zql":executedBy is not
	 * Empty"
	 */
	// get ZQL filter: "Zql":"executedBy is not Empty"
	@Test(priority = 41)
	public void test41_getZqlFilter_by_executedBy_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy is not Empty");
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 42 Get ZQL filter when filter has: "Zql":executedBy is Empty"
	 */
	// get ZQL filter: "Zql":"executedBy is Empty"
	@Test(priority = 42)
	public void test42_getZqlFilter_by_executedBy_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy is Empty");
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 43 Get ZQL filter when filter has: "Zql":executedBy not in
	 * (admin,user1)"
	 */
	// get ZQL filter: "Zql":"executedBy not in (admin,user1)"
	@Test(priority = 43)
	public void test43_getZqlFilter_by_executedBy_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy not in (" + Config.getValue("user") + "," + Config.getValue("user1") + ")");
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 44 Get ZQL filter when filter has: "Zql":executedBy in
	 * (admin,user1)"
	 */
	// get ZQL filter: "Zql":"executedBy in (admin,user2,user3)"
	@Test(priority = 44)
	public void test44_getZqlFilter_by_executedBy_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy in (" + Config.getValue("user") + "," + Config.getValue("user1") + ")");
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 45 Get ZQL filter when filter has: "Zql":assignee = admin"
	 */
	// get ZQL filter: "Zql": "assignee = admin"
	@Test(priority = 45)
	public void test45_getZqlFilter_by_assignee_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee = admin");
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 46 Get ZQL filter when filter has: "Zql":assignee != admin"
	 */
	// get ZQL filter: "Zql":"assignee != admin"
	@Test(priority = 46)
	public void test46_getZqlFilter_by_assignee_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee != admin");
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 47 Get ZQL filter when filter has: "Zql":assignee is not
	 * Empty"
	 */
	// get ZQL filter: "Zql":"assignee is not Empty"
	@Test(priority = 47)
	public void test47_getZqlFilter_by_assignee_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee is not Empty");
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 48 Get ZQL filter when filter has: "Zql":assignee is Empty"
	 */
	// get ZQL filter: "Zql":"assignee is Empty"
	@Test(priority = 48)
	public void test48_getZqlFilter_by_assignee_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee is Empty");
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 49 Get ZQL filter when filter has: "Zql":assignee not in
	 * (admin,user1)"
	 */
	// get ZQL filter: "Zql":"assignee not in (admin,user1)"
	@Test(priority = 49)
	public void test49_getZqlFilter_by_assignee_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee not in (" + Config.getValue("user") + "," + Config.getValue("user1") + ")");
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 50 Get ZQL filter when filter has: "Zql":assignee not in
	 * (admin,user1)"
	 */
	// get ZQL filter: "Zql":"assignee in (admin,user2,user3)"
	@Test(priority = 50)
	public void test50_getZqlFilter_by_assignee_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee in (" + Config.getValue("user") + "," + Config.getValue("user1") + ")");
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 51 Get ZQL filter when filter has: "Zql":issue = IE-1"
	 */
	// get ZQL filter: "Zql": "issue = IE-1"
	@Test(priority = 51)
	public void test51_getZqlFilter_by_issue_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue =" + Config.getValue("issueid"));
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 52 Get ZQL filter when filter has: "Zql":issue = IE-1"
	 */
	// get ZQL filter: "Zql":"issue != IE-1"
	@Test(priority = 52)
	public void test52_getZqlFilter_by_issue_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue !=" + Config.getValue("issueid"));
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 53 Get ZQL filter when filter has: "Zql":issue <= IE-1"
	 */
	// get ZQL filter: "Zql":"issue <= IE-1"
	@Test(priority = 53)
	public void test53_getZqlFilter_by_issue_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue <=" + Config.getValue("issueid"));
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 54 Get ZQL filter when filter has: "Zql":issue >= IE-1"
	 */
	// get ZQL filter: "Zql":"issue >= IE-1"
	@Test(priority = 54)
	public void test54_getZqlFilter_by_isuue_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue >=" + Config.getValue("issueid"));
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 55 Get ZQL filter when filter has: "Zql":issue < IE-1"
	 */
	// get ZQL filter: "Zql":"issue < IE-1"
	@Test(priority = 55)
	public void test55_getZqlFilter_by_issue_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue <" + Config.getValue("issueid"));
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 56 Get ZQL filter when filter has: "Zql":issue > IE-1"
	 */
	// get ZQL filter: "Zql":"issue > IE-1"
	@Test(priority = 56)
	public void test56_getZqlFilter_by_issue_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue >" + Config.getValue("issueid"));
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 57 Get ZQL filter when filter has: "Zql":issue not in
	 * (IE-1,IE-2)"
	 */
	// get ZQL filter: "Zql":"issue not in (IE-1,IE-2)"
	@Test(priority = 57)
	public void test57_getZqlFilter_by_issue_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue not in (" + Config.getValue("issueid") + Config.getValue("issueid1") + ")");
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 58 Get ZQL filter when filter has: "Zql":issue not in
	 * (IE-1,IE-2)"
	 */
	// get ZQL filter: "Zql":"assignee in (issue1,issue2,issue3)"
	@Test(priority = 58)
	public void test58_getZqlFilter_by_issue_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue not in (" + Config.getValue("issueid") + "," + Config.getValue("issueid1") + ","
				+ Config.getValue("issueid2") + ")");
		zqlfilterJson.setName("issue" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 59 Get ZQL filter when filter has: "Zql":creationDate =
	 * yyyy-MM-dd"
	 */
	// get ZQL filter: "Zql": "creationDate = 2016-11-23"
	@Test(priority = 59)
	public void test59_getZqlFilter_by_creationDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate =" + Config.getValue("creationdate"));
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 60 Get ZQL filter when filter has: "Zql":creationDate !=
	 * yyyy-MM-dd"
	 */
	// get ZQL filter: "Zql":"creationDate != 2016-11-23"
	@Test(priority = 60)
	public void test60_getZqlFilter_by_creationDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate !=" + Config.getValue("creationdate"));
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 61 Get ZQL filter when filter has: "Zql":creationDate <=
	 * yyyy-MM-dd"
	 */
	// get ZQL filter: "Zql":"creationDate <= 2016-11-23"
	@Test(priority = 61)
	public void test61_getZqlFilter_by_creationDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate <=" + Config.getValue("creationdate"));
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 62 Get ZQL filter when filter has: "Zql":creationDate >=
	 * yyyy-MM-dd"
	 */
	// get ZQL filter: "Zql":"creationDate >= 2016-11-23"
	@Test(priority = 62)
	public void test62_getZqlFilter_by_creationDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate >=" + Config.getValue("creationdate"));
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 63 Get ZQL filter when filter has: "Zql":creationDate <
	 * yyyy-MM-dd"
	 */
	// get ZQL filter: "Zql":"creationDate < 2016-11-23"
	@Test(priority = 63)
	public void test63_getZqlFilter_by_creationDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate <" + Config.getValue("creationdate"));
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 64 Get ZQL filter when filter has: "Zql":creationDate >
	 * yyyy-MM-dd"
	 */
	// get ZQL filter: "Zql":"creationDate > 2016-11-23"
	@Test(priority = 64)
	public void test64_getZqlFilter_by_creationDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate >" + Config.getValue("creationdate"));
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 65 Get ZQL filter when filter has: "Zql":creationDate not in
	 * (yyyy-MM-dd,yyyy-MM-dd)"
	 */
	// get ZQL filter: "Zql":"creationDate not in (2016-11-23,2016-11-22)"
	@Test(priority = 65)
	public void test65_getZqlFilter_by_creationDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"creationDate not in (" + Config.getValue("creationdate") + Config.getValue("creationdate") + ")");
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 66 Get ZQL filter when filter has: "Zql":creationDate in
	 * (yyyy-MM-dd,yyyy-MM-dd)"
	 */
	// get ZQL filter: "Zql":"creationDate in
	// (2016-11-23,2016-11-22,2016-11-21)"
	@Test(priority = 66)
	public void test66_getZqlFilter_by_creationDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson
				.setZql("creationDate in (" + Config.getValue("creationdate") + Config.getValue("creationdate") + ")");
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 67 Get ZQL filter when filter has: "Zql":creationDate is not
	 * Empty"
	 */
	// get ZQL filter: "Zql":"creationDate is not Empty"
	@Test(priority = 67)
	public void test67_getZqlFilter_by_creationDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate is not Empty");
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 68 Get ZQL filter when filter has: "Zql":creationDate is
	 * Empty"
	 */
	// get ZQL filter: "Zql":"creationDate is Empty"
	@Test(priority = 68)
	public void test68_getZqlFilter_by_creationDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate is Empty");
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 69 Get ZQL filter when filter has: "Zql":executionDate =
	 * yyyy-mm-dd"
	 */
	// get ZQL filter: "Zql": "executionDate = 2016-11-23"
	@Test(priority = 69)
	public void test69_getZqlFilter_by_executionDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate =" + Config.getValue("executionDate"));
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 70 Get ZQL filter when filter has: "Zql":executionDate !=
	 * yyyy-mm-dd"
	 */
	// get ZQL filter: "Zql":"executionDate != 2016-11-23"
	@Test(priority = 70)
	public void test70_getZqlFilter_by_executionDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate !=" + Config.getValue("executionDate"));
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 71 Get ZQL filter when filter has: "Zql":executionDate <=
	 * yyyy-mm-dd"
	 */
	// get ZQL filter: "Zql":"executionDate <= 2016-11-23"
	@Test(priority = 71)
	public void test71_getZqlFilter_by_executionDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate <=" + Config.getValue("executionDate"));
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 72 Get ZQL filter when filter has: "Zql":executionDate >=
	 * yyyy-mm-dd"
	 */
	// get ZQL filter: "Zql":"executionDate >= 2016-11-23"
	@Test(priority = 72)
	public void test72_getZqlFilter_by_executionDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate >=" + Config.getValue("executionDate"));
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 73 Get ZQL filter when filter has: "Zql":executionDate <
	 * yyyy-mm-dd"
	 */
	// get ZQL filter: "Zql":"executionDate < 2016-11-23"
	@Test(priority = 73)
	public void test73_getZqlFilter_by_executionDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate <" + Config.getValue("executionDate"));
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 74 Get ZQL filter when filter has: "Zql":executionDate >
	 * yyyy-mm-dd"
	 */
	// get ZQL filter: "Zql":"executionDate > 2016-11-23"
	@Test(priority = 74)
	public void test74_getZqlFilter_by_executionDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate >" + Config.getValue("executionDate"));
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 75 Get ZQL filter when filter has: "Zql":executionDate not in
	 * (yyy-mm-dd,yyyy-mm-dd)"
	 */
	// get ZQL filter: "Zql":"executionDate not in (2016-11-23,2016-11-22)"
	@Test(priority = 75)
	public void test75_getZqlFilter_by_executionDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate not in (" + Config.getValue("executionDate") + ","
				+ Config.getValue("executionDate1") + ")");
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 76 Get ZQL filter when filter has: "Zql":executionDate in
	 * (yyy-mm-dd,yyyy-mm-dd)"
	 */
	// get ZQL filter: "Zql":"executionDate in
	// (2016-11-23,2016-11-22,2016-11-21)"
	@Test(priority = 76)
	public void test76_getZqlFilter_by_executionDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql(
				"executionDate in (" + Config.getValue("executionDate") + Config.getValue("executionDate1") + ")");
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 77 Get ZQL filter when filter has: "Zql":executionDate is not
	 * Empty"
	 */
	// get ZQL filter: "Zql":"executionDate is not Empty"
	@Test(priority = 77)
	public void test77_getZqlFilter_by_executionDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is not Empty");
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);

		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 78 Get ZQL filter when filter has: "Zql":executionDate is
	 * Empty"
	 */
	// get ZQL filter: "Zql":"executionDate is Empty"
	@Test(priority = 78)
	public void test78_getZqlFilter_by_executionDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is Empty");
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("Description");
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create ZQL Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		System.out.println("Response:-->" + createFilterResponse.getBody().asString());
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		String filterId = new JSONObject(createFilterResponse.getBody().asString()).get("id").toString();

		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");

		boolean getFilterStatus = zapiService.validateZQLFilter(createFilterResponse.getBody().asString(),
				getFilterresponse);
		Assert.assertTrue(getFilterStatus);

		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 79 Get ZQL filter when filter has:
	 * "Attempt to get Zql filter with invalid filter id "
	 */
	// Attempt to get Zql filter with invalid filter id
	@Test(priority = 79)
	public void test79_Attempt_getZqlFilter_by_invalid_filterid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		String filterId = "1234567890";
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateInvalidZQLFilterId(filterId, getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}

	/**
	 * Test case - 80 Get ZQL filter when filter has:
	 * "Attempt to get Zql filter with null filter id "
	 */
	// Attempt to get Zql filter with null filter id
	@Test(priority = 80)
	public void test80_Attempt_getZqlFilter_by_null_filterid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");

		String filterId = null;
		Response getFilterresponse = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(getFilterresponse, "Get ZqlFilter Api Response is null.");
		boolean getFilterStatus = zapiService.validateInvalidZQLFilterId(filterId, getFilterresponse);
		Assert.assertTrue(getFilterStatus);
		test.log(LogStatus.PASS, "Get filter Api Response validated successfully.");
		extentReport.endTest(test);
	}
}
