package com.thed.zephyr.regression.traceability;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.cloud.rest.model.StepResult;
import com.thed.zephyr.cloud.rest.util.json.StepResultJsonParser;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class SearchExecutionsByTest extends BaseTest {

	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test has only 1 execution
	 */
	
//	@Test(priority = 1)
	public void searchExecutionsByTest_test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10737l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test has 10 executions
	 */
	
	//@Test(priority = 2)
	public void searchExecutionsByTest_test2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test has no defects
	 */
	
	//@Test(priority = 3)
	public void searchExecutionsByTest_test3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10737l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test has unexecuted status
	 */
	
	//@Test(priority = 5)
	public void searchExecutionsByTest_test5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10737l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test has executed in Pass status
	 */
	
	//@Test(priority = 6)
	public void searchExecutionsByTest_test6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10737l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in Fail status
	 */
	
	//@Test(priority = 7)
	public void searchExecutionsByTest_test7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in Blocked status
	 */
	
	//@Test(priority = 8)
	public void searchExecutionsByTest_test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in WIP status
	 */
	
	//@Test(priority = 9)
	public void searchExecutionsByTest_test9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in Custom status
	 */
	
	//@Test(priority = 10)
	public void searchExecutionsByTest_test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in Adhoc Unscheduled
	 */
	
	//@Test(priority = 11)
	public void searchExecutionsByTest_test11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in non-adhoc unscheduled
	 */
	
	//@Test(priority = 12)
	public void searchExecutionsByTest_test12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in adhoc scheduled version
	 */
	
	//@Test(priority = 13)
	public void searchExecutionsByTest_test13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed in non adhoc scheduled version
	 */
	
	//@Test(priority = 14)
	public void searchExecutionsByTest_test14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10737l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed has 1 defect
	 */
	
	//@Test(priority = 15)
	public void searchExecutionsByTest_test15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed has 10 defects
	 */
	
	//@Test(priority = 16)
	public void searchExecutionsByTest_test16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed defects are in TODO status
	 */
	
	//@Test(priority = 17)
	public void searchExecutionsByTest_test17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed defect is In Progress status
	 */
	
	//@Test(priority = 18)
	public void searchExecutionsByTest_test18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test executed defect is in Done Status
	 */
	
	//@Test(priority = 19)
	public void searchExecutionsByTest_test19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test step has no defects
	 */
	
	//@Test(priority = 20)
	public void searchExecutionsByTest_test20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test step has 1 defect
	 */
	
	//@Test(priority = 21)
	public void searchExecutionsByTest_test21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test step has 10 defects
	 */
	
	//@Test(priority = 22)
	public void searchExecutionsByTest_test22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test step has defect is in TODO status
	 */
	
	//@Test(priority = 23)
	public void searchExecutionsByTest_test23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test step defect is In progress status
	 */
	
	//@Test(priority = 24)
	public void searchExecutionsByTest_test24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test step defect is in Done status
	 */
	
	//@Test(priority = 25)
	public void searchExecutionsByTest_test25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * SearchExecutionsByTest where test is scheduled 50 times
	 */
	
	//@Test(priority = 26)
	public void searchExecutionsByTest_test26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Attempt to SearchExecutionsByTest more than 10 executions where maxResult is set to 10
	 */
	
	//@Test(priority = 27)
	public void searchExecutionsByTest_test27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Set offset=5 and maxResult=10 and SearchExecutionsByTest
	 */
	
	//@Test(priority = 28)
	public void searchExecutionsByTest_test28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 5;
		int maxResult = 15;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Attempt to search an execution when the execution is deleted
	 */
	
	//@Test(priority = 29)
	public void searchExecutionsByTest_test29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10735l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Attempt to searchExecutionsByTest when the test is deleted
	 */
	
	//@Test(priority = 30)
	public void searchExecutionsByTest_test30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTestInvalidIssueId(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Attempt to searchExecutionsByTest more than offset limit(for 10 executions, set offset = 15)
	 */
	
	//@Test(priority = 31)
	public void searchExecutionsByTest_test31(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long testId = 10736l;
		int offset = 20;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByTest(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
