/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface ExecutionApi {

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createExecution(JwtGenerator jwtGenerator, String payLoad);


	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param executionId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getExecution(JwtGenerator jwtGenerator, Long projectId, Long issueId, String executionId);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param offset
	 * @param size
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getExecutions(JwtGenerator jwtGenerator, Long projectId, Long issueId, int offset, int size);

	/**
	 * @param jwtGenerator
	 * @param issueId
	 * @param executionId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteExecution(JwtGenerator jwtGenerator, Long issueId, String executionId);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @param offset
	 * @param size
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getExecutionsByCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId, int offset, int size);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response updateBulkStatus(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response deleteBulkExecutions(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response assignBulkExecutions(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param issueIdOrKey
	 * @param offset
	 * @param size
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getExecutionsByIssue(JwtGenerator jwtGenerator, Long issueId, int offset, int size);
	Response getExecutionsByIssue(JwtGenerator jwtGenerator, String issueKey, int offset, int size);

	/**
	 * @param jwtGenerator
	 * @param sprintId
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getExecutionSummariesBySprintAndIssue(JwtGenerator jwtGenerator, Long sprintId, String issueIdorKeys);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response exportExecution(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param downloadFilename
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response downloadExportedFile(JwtGenerator jwtGenerator, String downloadFilename);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response reOrderExecutions(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param cycleId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	Response addTestsTocycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param executionId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	Response getExecutionsByZQL(JwtGenerator jwtGenerator, String executionId, String payLoad);

	/**
	 * @param jwtGenerator
	 * @return
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	Response getExecutionStatuses(JwtGenerator jwtGenerator);


	/**
	 * @param jwtGenerator
	 * @param executionId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	Response updateExecution(JwtGenerator jwtGenerator, String executionId, String payLoad);


	Response getExecutionTimeTracking(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);

	Response updateExecutionCustomfield(JwtGenerator jwtGenerator, String executionId, String payLoad);

}
