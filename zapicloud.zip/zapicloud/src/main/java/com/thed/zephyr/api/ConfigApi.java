/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface ConfigApi {
	
	/**
	 * @param jwtGenerator
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getGeneralConfigInfo(JwtGenerator jwtGenerator);
}
