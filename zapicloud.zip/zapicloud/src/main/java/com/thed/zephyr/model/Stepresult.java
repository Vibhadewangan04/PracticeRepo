/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.model;

import java.util.List;

import org.json.JSONObject;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class Stepresult {

	private String id;
	private Long issueId;
	private String executionId;
	private String stepId;
	private String comment;
	private Long statusId;
	private List<Long> defects;
	
	
	/**
	 * @return the id
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the issueId
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public Long getIssueId() {
		return issueId;
	}


	/**
	 * @param issueId the issueId to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setIssueId(Long issueId) {
		this.issueId = issueId;
	}


	/**
	 * @return the executionId
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public String getExecutionId() {
		return executionId;
	}


	/**
	 * @param executionId the executionId to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}


	/**
	 * @return the stepId
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public String getStepId() {
		return stepId;
	}


	/**
	 * @param stepId the stepId to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setStepId(String stepId) {
		this.stepId = stepId;
	}


	/**
	 * @return the comment
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public String getComment() {
		return comment;
	}


	/**
	 * @param comment the comment to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}


	/**
	 * @return the statusId
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public Long getStatusId() {
		return statusId;
	}


	/**
	 * @param statusId the statusId to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}


	/**
	 * @return the defects
	 * Created by manoj.behera on 27-Mar-2017.
	 */
	public List<Long> getDefects() {
		return defects;
	}


	/**
	 * @param defects the defects to set
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	public void setDefects(List<Long> defects) {
		this.defects = defects;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	@Override
	public String toString() {
		JSONObject stepresultJson = new JSONObject();
		stepresultJson.put("executionId", this.executionId);
		stepresultJson.put("issueId", this.issueId);
		stepresultJson.put("stepId", this.stepId);
		stepresultJson.put("id", this.id);
		if (statusId != null) {
			stepresultJson.put("status", new JSONObject().put("id", this.statusId));
		}
		if (this.defects != null) {
			stepresultJson.put("defects", this.defects);
		}
		if (this.comment != null) {
			stepresultJson.put("comment", this.comment);
		}
		return stepresultJson.toString();
	}
	
}
