/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.cycle;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class DeleteCycleApi extends BaseTest {

	/**
	 * Delete cycle without schedule.
	 */
	@Test(priority = 1, enabled= testEnabled) 
	public void reg_tc1_deleteCycle_without_schdule() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle "+System.currentTimeMillis());
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleid = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleid);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleid);
		String myRes = response.getBody().asString();
		System.err.println(myRes);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleid, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete cycle in unscheduled version.
	 */
	@Test(priority = 2, enabled= testEnabled)
	public void reg_tc2_deleteCycle_unschdule_version() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle "+System.currentTimeMillis());
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleid = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleid);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleid);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleid, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete cycle in scheduled version.
	 */
	@Test(priority = 3, enabled= testEnabled)
	public void reg_tc3_deleteCycle_schdule_version() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle "+System.currentTimeMillis());
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleid = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleid);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleid);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleid, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Delete a un-executed cycle
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void reg_tc4_deleteCycle_unexecutedExecution() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		/**
		 * Need to execute few cases
		 */
		// Delete cycle
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Delete a partially executed cycle.
	 */
	@Test(priority = 5, enabled = testEnabled)
	public void reg_tc5_deleteCycle_partiallyExecuted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 5;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Delete a fully executed cycle.
	 */
	@Test(priority = 6, enabled = testEnabled)
	public void reg_tc6_deleteCycle_fullyExecuted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 5;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		/**
		 * Need to execute all cases
		 */
		// Delete cycle
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete cycle with 50 Test scheduled.
	 */
	@Test(priority = 7, enabled = false)
	public void reg_tc7_deleteCycle_having_50_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 50;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete cycle with 500 Test scheduled.
	 */
	@Test(priority = 8, enabled = false)
	public void reg_tc8_deleteCycle_having_500_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete cycle with 1000 Test scheduled.
	 */
	@Test(priority = 9, enabled= false)
	public void reg_tc9_deleteCycle_having_1000_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 1000;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete cycle with 5000 Test scheduled.
	 */
	@Test(priority = 10, enabled = false)
	public void reg_tc10_deleteCycle_having_5000_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 5000;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Delete Multiple cycles.
	 */
	@Test(priority = 11, enabled= testEnabled)
	public void reg_tc11_deleteCycle_Multiple() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleid = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleid);
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleid);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleid, response);

		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		// Create cycle
		cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		cycleid = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleid);
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleid);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(projectId, versionId, cycleid, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}
	/**
	 * Delete Multiple cycles Delete Cycle if version contains 50 Cycles Created
	 */
	@Test(priority = 12, enabled = false)
	public void reg_tc12_deleteCycle_schdule_version_byid_having_50cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		int numberOfCycles = 50;
		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Created Cycles through Api successfully.");

		String CycleId = new JSONObject(response.get(2).toString()).getString("id");
		System.err.println(CycleId);
		// delete cycle
		// we have to give cycle id of particular cycle in CycleId
		Response Deletecycleresponse = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, Deletecycleresponse);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete Multiple cycles Delete Cycle if version contains 500 Cycles
	 */

	@Test(priority = 13, enabled = false)
	public void reg_tc13_deleteCycle_schdule_version_byid_having_500cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		int numberOfCycles = 500;
		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Created Cycles through Api successfully.");

		String CycleId = new JSONObject(response.get(498).toString()).getString("id");
		System.err.println(CycleId);
		// delete cycle
		// we have to give cycle id of particular cycle in CycleId
		Response Deletecycleresponse = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, Deletecycleresponse);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete Multiple cycles Delete Cycle if version contains 1000Cycles
	 */

	@Test(priority = 14, enabled = false) 
	public void reg_tc14_deleteCycle_schdule_version_byid_having_1000cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		int numberOfCycles = 1000;
		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Created Cycles through Api successfully.");

		String CycleId = new JSONObject(response.get(998).toString()).getString("id");
		System.err.println(CycleId);
		// delete cycle
		// we have to give cycle id of particular cycle in CycleId
		Response Deletecycleresponse = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, Deletecycleresponse);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * * Delete Cycle if version contains 5000 Cycles .
	 */
	@Test(priority = 15, enabled = false)
	public void reg_tc15_deleteCycle_schdule_version_byid_having_5000cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		int numberOfCycles = 5000;
		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numberOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Created Cycles through Api successfully.");

		String CycleId = new JSONObject(response.get(4998).toString()).getString("id");
		System.err.println(CycleId);
		// delete cycle
		// we have to give cycle id of particular cycle in CycleId
		Response Deletecycleresponse = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, Deletecycleresponse);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete Cycle if Cycle is Created in UI.
	 */
	@Test(priority = 16, enabled = false)
	public void reg_tc16_deleteCycle_Created_manually_UI() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		// Copy the cycle id from UI and paste in below String.
		String CycleId = "";
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to delete by providing invalid cycle id 
	 */
	@Test(priority = 17, enabled= testEnabled)
	public void reg_tc17_Attempt_deleteCycle_Invalid_cycleid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		String CycleId = "123l";
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateInvalidCycleId(CycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Delete Cycle by providing null projectId
	 */
	@Test(priority = 18, enabled = testEnabled)
	public void reg_tc18_Attempt_deleteCycle_NUll_projectid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = null;
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		String CycleId = "0001483461534890-242ac112-0001";
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Delete Cycle by providing null versionId
	 */
	@Test(priority = 19, enabled = testEnabled)
	public void reg_tc19_Attempt_deleteCycle_NUll_Versionid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = null;
		String CycleId = "0001483461534890-242ac112-0001";
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, CycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, CycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Delete Cycle by providing null cycleId
	 */
	@Test(priority = 20, enabled = testEnabled)
	public void reg_tc20_Attempt_deleteCycle_NUll_cycleid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		String cycleId = null;
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");
		
		boolean status = zapiService.validateInvalidCycleId(cycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Attempt to Delete Cycle by providing blank cycleId
	 */
	@Test(priority = 21, enabled= testEnabled)
	public void reg_tc21_Attempt_deleteCycle_blank_cycleid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Poornachandra");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		String cycleId = "";
		Response response = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");
		
		boolean status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
}
