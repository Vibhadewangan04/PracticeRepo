/**
 *
 */
package com.thed.zephyr.regression.execution;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetExecutionByIdApi extends BaseTest{

	JwtGenerator jwtGenerator = null;
	Long projectId = null;
	Long issueId = null;
	String executionId = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//TODO
	//Get execution in a non-adhoc cycle of scheduled version
	@Test(priority = 1)
	public void test1_getExecutionInNonAdhocCycleOfScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get execution in ADHOC cycle of scheduled version
	@Test(priority = 2)
	public void test2_getExecutionInAdhocCycleOfScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get execution in Non ADHOC cycle of Unscheduled version
	@Test(priority = 3)
	public void test3_getExecutionInNonAdhocCycleOfUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get execution in ADHOC cycle of Unscheduled version
	@Test(priority = 4)
	public void test4_getExecutionInAdhocCycleOfUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get Execution with comments
	@Test(priority = 5)
	public void test5_getExecutionWithComments(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get Execution with defects linked to it
	@Test(priority = 6)
	public void test6_getExecutionWithDefectsLinked(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get Execution with attachments
	@Test(priority = 7)
	public void test7_getExecutionWithAttachments(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get ExecutionId of an execution whose status has changed (update execution to PASS/FAIL/WIP/BLOCKED/CUSTOM)
	@Test(priority = 8)
	public void test8_getExecutionWhoseStatusChanged(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get ExecutionId of an execution with comments, defects,attachments and Status changed
	@Test(priority = 9)
	public void test9_getExecutionWithCommentsAttachmentsDefectsLinkedStatusChanged(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//FIXME
	/**
	 * Attempt to Get Execution by passing valid issueId and deleted executionId
	 * BugId = ZAPICLOUD-65
	 */
	@Test(priority = 10)
	public void test10_attemptToGetExecutionByValidIssueIdAndDeletedExecutionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "0001479213324053-242ac1136-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//TODO
	//FIXME
	/**
	 * Attempt to Get Execution By passing valid issueId and invalid executionId
	 * BugId = ZAPICLOUD-65
	 */
	@Test(priority = 11)
	public void test11_attemptToGetExecutionByValidIssueIdAndInvalidExecutionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = 10000l;
		executionId = "987654321";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//Attempt to Get Executions if projectId is "null"
	@Test(priority = 12)
	public void test12_attemptToGetExecutionIfProjectIdIsNull(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = null;
		issueId = 10000l;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to Get Executions if issueId is "null"
	@Test(priority = 13)
	public void test13_attemptToGetExecutionIfIssueIdIsNull(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		issueId = null;
		executionId = "0001479213324053-242ac1135-0001";

		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Get Execution Api Response is null.");
		test.log(LogStatus.PASS, "Get Execution Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

}
