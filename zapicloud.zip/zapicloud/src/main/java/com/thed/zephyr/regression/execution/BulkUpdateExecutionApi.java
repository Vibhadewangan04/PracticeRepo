/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */

public class BulkUpdateExecutionApi extends BaseTest{
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	private long issueId1;
	private long issueId2;
	private Execution executionJson11;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//Manual - Attempt to do bulk change status with invalid authentication
	//@Test(priority = 2)
	public void updateBulkStatus1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479189122203-242ac1134-0001\",\"0001479189123203-242ac1134-0001\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":2}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Manual - Attempt to do bulk change status if user has no browse permissions
	//@Test(priority = 2)
	public void updateBulkStatus2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479189122203-242ac1134-0001\",\"0001479189123203-242ac1134-0001\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":2}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to bulk update execution when stepstatusId is invalid
	@Test(priority = 3,enabled=testEnabled)
	public void updateBulkStatus3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
				//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		   String ex1=exeIds.get(0).toString();
		   System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		  String ex2=exeIds.get(1).toString();
		  System.err.println("executionid2:"+ex2);

//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
     String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":444441}";
     System.out.println(payLoad);
     Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
     Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
     test.log(LogStatus.PASS, "Bulk update status executed successfully.");
     System.out.println(response.getBody().asString());
     System.out.println("Bulk update executions statuses Sucessfully");
	 boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
	 Assert.assertTrue(status);
	 test.log(LogStatus.PASS, "Response validated suuccessfully.");
	 extentReport.endTest(test);
	}

	//Bulk change status on test executions to status PASS and "null" for stepstatusId
	@Test(priority = 4,enabled=testEnabled)
	public void updateBulkStatus4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
				//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);

       //String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		System.out.println(response.getBody().asString());
		
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk  Update executions statuses Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Bulk change status on test executions and steps executions to Same status FAIL
	@Test(priority = 5,enabled=testEnabled)
	public void updateBulkStatus5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//create test steps for issue1
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
		
		//create test steps for issue2
		Teststep teststepJson1 = new Teststep();
		teststepJson1.setStep("stepValue");
		teststepJson1.setData("dataValue");
		teststepJson1.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson1.toString());
		Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
		Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
	//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		
//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":2,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":2}";
    System.out.println(payLoad);
    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response.getBody().asString());
    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
    Assert.assertNotNull(response, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status = zapiService.validateJobProgress(response,payLoad);
    Assert.assertTrue(status);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
	}
	
	//Bulk change status on test executions and steps executions to Same status WIP
	@Test(priority = 6,enabled=testEnabled)
	public void updateBulkStatus6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));

		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
				//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				
		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":3,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":3}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);

		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
	}
	
	//Bulk change status on test executions and steps executions to Same status Blocked
	@Test(priority = 7,enabled=testEnabled)
	public void updateBulkStatus7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//create test steps for issue1
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
		
		//create test steps for issue2
		Teststep teststepJson1 = new Teststep();
		teststepJson1.setStep("stepValue");
		teststepJson1.setData("dataValue");
		teststepJson1.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson1.toString());
		Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
		Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		
//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":4,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":4}";
    System.out.println(payLoad);
    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response.getBody().asString());
    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
    Assert.assertNotNull(response, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status = zapiService.validateJobProgress(response,payLoad);
    Assert.assertTrue(status);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
	}
	
	//Bulk change status on test executions and steps executions to Same status CUSTOM
	@Test(priority = 8,enabled=testEnabled)
	public void updateBulkStatus8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));

           //create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
			//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				
		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":5,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":5}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);

		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
	}
	
	//Bulk revert change status on test executions and steps executions to Same status Unexecuted
	@Test(priority = 9,enabled=testEnabled)
	public void updateBulkStatus9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
	//create test steps for issue1
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
		
	//create test steps for issue2
		Teststep teststepJson1 = new Teststep();
		teststepJson1.setStep("stepValue");
		teststepJson1.setData("dataValue");
		teststepJson1.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson1.toString());
		Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
		Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
	//update
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		
//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":5,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":5}";
    System.out.println(payLoad);
    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response.getBody().asString());
    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
    Assert.assertNotNull(response, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status = zapiService.validateJobProgress(response,payLoad);
    Assert.assertTrue(status);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
    
    //revert back to unexecuted status
    String payLoad1 = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":-1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
    System.out.println(payLoad1);
    Response response1 = zapiService.updateBulkStatus(jwtGenerator, payLoad1);
    Assert.assertNotNull(response1, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response1.getBody().asString());
    response1 = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
    Assert.assertNotNull(response1, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response1.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status1 = zapiService.validateJobProgress(response1,payLoad1);
    Assert.assertTrue(status1);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
    
	}
	
	//Bulk change status on test executions to PASS while steps execution status  to Unexecuted
	@Test(priority = 10,enabled=testEnabled)
	public void updateBulkStatus10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));

        //create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
			//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				
		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);

		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
}
	
	//Bulk change status on test executions to FAIL while steps execution to different status PASS
	@Test(priority = 11,enabled=testEnabled)
	public void updateBulkStatus11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));
           //create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
			//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				
		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":2,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);

		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
	}
	
	//Bulk change status on test executions to WIP while steps execution to New Custom Status
	@Test(priority = 12,enabled=testEnabled)
	public void updateBulkStatus12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
         //create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
			//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				
		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":3,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":5}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);

		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
	}

	//Bulk change status on test executions to Blocked while steps execution to any Status
	@Test(priority = 13,enabled=testEnabled)
	public void updateBulkStatus13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));
        //create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
			//create test steps for issue1
				Teststep teststepJson = new Teststep();
				teststepJson.setStep("stepValue");
				teststepJson.setData("dataValue");
				teststepJson.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson.toString());
				Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
				
			//create test steps for issue2
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("stepValue");
				teststepJson1.setData("dataValue");
				teststepJson1.setResult("resultValue");
				System.out.println("payload-->"+ teststepJson1.toString());
				Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
				Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
			//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				
		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":4,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":5}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);

		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
	}
	
	//Bulk change status on test executions to CUSTOM while steps execution to Unexecuted with testStepStatusChangeflag set to true
	@Test(priority = 14,enabled=testEnabled)
	public void updateBulkStatus14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));
	        //create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
					
				//create test steps for issue1
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("stepValue");
					teststepJson.setData("dataValue");
					teststepJson.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson.toString());
					Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
					Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
					
				//create test steps for issue2
					Teststep teststepJson1 = new Teststep();
					teststepJson1.setStep("stepValue");
					teststepJson1.setData("dataValue");
					teststepJson1.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson1.toString());
					Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
					Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
			//2 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId("-1");

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
				//update
					List<String> exeIds = new ArrayList<>() ;
					JSONArray jsarray2 = new JSONArray(executionResponse.toString());
					System.out.println("length="+jsarray2.length());
					for (int j=0;j<jsarray2.length();j++){
						JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
						String exeid =jsobj2.getJSONObject("execution").get("id").toString();
						exeIds.add(exeid);
						Long issueId11 = issueIds.get(j);
						executionJson11.setIssueId(issueId11);
						System.out.println(issueId11);
					//	executionJson11.setStatusId(1l);
						executionJson11.setExecutionId(exeid);
						Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
								executionJson11.toString());
						Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
						System.out.println(updateExecutionResponse.getBody().asString());
						System.out.println("updated execution");
					}
					//String	ex1=jsarray2.getString(0).toString();
					String	ex1=exeIds.get(0).toString();
					System.err.println("executionid1:"+ex1);
//				String ex2=jsarray2.getString(1).toString();
					String	ex2=exeIds.get(1).toString();
					System.err.println("executionid2:"+ex2);
					
			//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
			    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":5,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
			    System.out.println(payLoad);
			    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
			    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
			    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
			    System.out.println(response.getBody().asString());
			    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			    Assert.assertNotNull(response, "Job progress Api Response is null.");
			    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

			    System.out.println("Bulk  Update executions statuses Sucessfully");
			    boolean status = zapiService.validateJobProgress(response,payLoad);
			    Assert.assertTrue(status);

			    test.log(LogStatus.PASS, "Response validated suuccessfully.");
			    extentReport.endTest(test);
	}
	//Bulk change status on test executions to Unexecuted while steps execution to status PASS with testStepStatusFlag set to true
	@Test(priority = 15,enabled=testEnabled)
	public void updateBulkStatus15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));
	        //create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
					
				//create test steps for issue1
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("stepValue");
					teststepJson.setData("dataValue");
					teststepJson.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson.toString());
					Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
					Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
					
				//create test steps for issue2
					Teststep teststepJson1 = new Teststep();
					teststepJson1.setStep("stepValue");
					teststepJson1.setData("dataValue");
					teststepJson1.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson1.toString());
					Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
					Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
			//2 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId("-1");

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
				//update
					List<String> exeIds = new ArrayList<>() ;
					JSONArray jsarray2 = new JSONArray(executionResponse.toString());
					System.out.println("length="+jsarray2.length());
					for (int j=0;j<jsarray2.length();j++){
						JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
						String exeid =jsobj2.getJSONObject("execution").get("id").toString();
						exeIds.add(exeid);
						Long issueId11 = issueIds.get(j);
						executionJson11.setIssueId(issueId11);
						System.out.println(issueId11);
					//	executionJson11.setStatusId(1l);
						executionJson11.setExecutionId(exeid);
						Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
								executionJson11.toString());
						Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
						System.out.println(updateExecutionResponse.getBody().asString());
						System.out.println("updated execution");
					}
					//String	ex1=jsarray2.getString(0).toString();
					String	ex1=exeIds.get(0).toString();
					System.err.println("executionid1:"+ex1);
//				String ex2=jsarray2.getString(1).toString();
					String	ex2=exeIds.get(1).toString();
					System.err.println("executionid2:"+ex2);
					
			//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
			    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":-1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
			    System.out.println(payLoad);
			    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
			    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
			    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
			    System.out.println(response.getBody().asString());
			    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			    Assert.assertNotNull(response, "Job progress Api Response is null.");
			    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

			    System.out.println("Bulk  Update executions statuses Sucessfully");
			    boolean status = zapiService.validateJobProgress(response,payLoad);
			    Assert.assertTrue(status);

			    test.log(LogStatus.PASS, "Response validated suuccessfully.");
			    extentReport.endTest(test);
	}
	//Bulk Change status in Unscheduled Cycle to any status at only Test level, with NO status change at step level execution
    @Test(priority = 16,enabled=testEnabled)
	public void updateBulkStatus16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));
	        //create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
					
				//create test steps for issue1
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("stepValue");
					teststepJson.setData("dataValue");
					teststepJson.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson.toString());
					Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
					Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
					
				//create test steps for issue2
					Teststep teststepJson1 = new Teststep();
					teststepJson1.setStep("stepValue");
					teststepJson1.setData("dataValue");
					teststepJson1.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson1.toString());
					Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
					Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
			//2 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId("-1");

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
				//update
					List<String> exeIds = new ArrayList<>() ;
					JSONArray jsarray2 = new JSONArray(executionResponse.toString());
					System.out.println("length="+jsarray2.length());
					for (int j=0;j<jsarray2.length();j++){
						JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
						String exeid =jsobj2.getJSONObject("execution").get("id").toString();
						exeIds.add(exeid);
						Long issueId11 = issueIds.get(j);
						executionJson11.setIssueId(issueId11);
						System.out.println(issueId11);
					//	executionJson11.setStatusId(1l);
						executionJson11.setExecutionId(exeid);
						Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
								executionJson11.toString());
						Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
						System.out.println(updateExecutionResponse.getBody().asString());
						System.out.println("updated execution");
					}
					//String	ex1=jsarray2.getString(0).toString();
					String	ex1=exeIds.get(0).toString();
					System.err.println("executionid1:"+ex1);
//				String ex2=jsarray2.getString(1).toString();
					String	ex2=exeIds.get(1).toString();
					System.err.println("executionid2:"+ex2);
					
			//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
			    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":5,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":-1}";
			    System.out.println(payLoad);
			    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
			    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
			    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
			    System.out.println(response.getBody().asString());
			    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			    Assert.assertNotNull(response, "Job progress Api Response is null.");
			    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

			    System.out.println("Bulk  Update executions statuses Sucessfully");
			    boolean status = zapiService.validateJobProgress(response,payLoad);
			    Assert.assertTrue(status);

			    test.log(LogStatus.PASS, "Response validated suuccessfully.");
			    extentReport.endTest(test);
	}
	//Bulk Change status to New Status at only step level, with NO status change at test level execution
	@Test(priority = 17,enabled=testEnabled)
	public void updateBulkStatus17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));
	        //create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
					
				//create test steps for issue1
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("stepValue");
					teststepJson.setData("dataValue");
					teststepJson.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson.toString());
					Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
					Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
					
				//create test steps for issue2
					Teststep teststepJson1 = new Teststep();
					teststepJson1.setStep("stepValue");
					teststepJson1.setData("dataValue");
					teststepJson1.setResult("resultValue");
					System.out.println("payload-->"+ teststepJson1.toString());
					Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
					Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
			//2 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId("-1");

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
				//update
					List<String> exeIds = new ArrayList<>() ;
					JSONArray jsarray2 = new JSONArray(executionResponse.toString());
					System.out.println("length="+jsarray2.length());
					for (int j=0;j<jsarray2.length();j++){
						JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
						String exeid =jsobj2.getJSONObject("execution").get("id").toString();
						exeIds.add(exeid);
						Long issueId11 = issueIds.get(j);
						executionJson11.setIssueId(issueId11);
						System.out.println(issueId11);
					//	executionJson11.setStatusId(1l);
						executionJson11.setExecutionId(exeid);
						Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
								executionJson11.toString());
						Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
						System.out.println(updateExecutionResponse.getBody().asString());
						System.out.println("updated execution");
					}
					//String	ex1=jsarray2.getString(0).toString();
					String	ex1=exeIds.get(0).toString();
					System.err.println("executionid1:"+ex1);
//				String ex2=jsarray2.getString(1).toString();
					String	ex2=exeIds.get(1).toString();
					System.err.println("executionid2:"+ex2);
					
			//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
			    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":-1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":5}";
			    System.out.println(payLoad);
			    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
			    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
			    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
			    System.out.println(response.getBody().asString());
			    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			    Assert.assertNotNull(response, "Job progress Api Response is null.");
			    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

			    System.out.println("Bulk  Update executions statuses Sucessfully");
			    boolean status = zapiService.validateJobProgress(response,payLoad);
			    Assert.assertTrue(status);

			    test.log(LogStatus.PASS, "Response validated suuccessfully.");
			    extentReport.endTest(test);
	}
	
	//Bulk revert back status to "Unexecuted" at test level, by keeping status at step level execution
	@Test(priority = 18,enabled=testEnabled)
	public void updateBulkStatus18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
	//create test steps for issue1
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
		
	//create test steps for issue2
		Teststep teststepJson1 = new Teststep();
		teststepJson1.setStep("stepValue");
		teststepJson1.setData("dataValue");
		teststepJson1.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson1.toString());
		Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
		Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
	//update
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		
//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
    System.out.println(payLoad);
    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response.getBody().asString());
    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
    Assert.assertNotNull(response, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status = zapiService.validateJobProgress(response,payLoad);
    Assert.assertTrue(status);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
    
    //revert back to unexecuted status
    String payLoad1 = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":-1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
    System.out.println(payLoad1);
    Response response1 = zapiService.updateBulkStatus(jwtGenerator, payLoad1);
    Assert.assertNotNull(response1, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response1.getBody().asString());
    response1 = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
    Assert.assertNotNull(response1, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response1.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status1 = zapiService.validateJobProgress(response1,payLoad1);
    Assert.assertTrue(status1);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
	}
	
	//Bulk revert back status to "Unexecuted" at step level, by keeping status at Test level execution
	@Test(priority = 19,enabled=testEnabled)
	public void updateBulkStatus19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
	//create test steps for issue1
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
		
	//create test steps for issue2
		Teststep teststepJson1 = new Teststep();
		teststepJson1.setStep("stepValue");
		teststepJson1.setData("dataValue");
		teststepJson1.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson1.toString());
		Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
		Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
	//update
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		
//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
    System.out.println(payLoad);
    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response.getBody().asString());
    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
    Assert.assertNotNull(response, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status = zapiService.validateJobProgress(response,payLoad);
    Assert.assertTrue(status);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
    
    //revert back to unexecuted status
    String payLoad1 = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
    System.out.println(payLoad1);
    Response response1 = zapiService.updateBulkStatus(jwtGenerator, payLoad1);
    Assert.assertNotNull(response1, "Bulk update Execution Api Response is null.");
    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
    System.out.println(response1.getBody().asString());
    response1 = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
    Assert.assertNotNull(response1, "Job progress Api Response is null.");
    System.out.println("Response aftre jobProgress Handler: "+response1.getBody().asString());

    System.out.println("Bulk  Update executions statuses Sucessfully");
    boolean status1 = zapiService.validateJobProgress(response1,payLoad1);
    Assert.assertTrue(status1);

    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    extentReport.endTest(test);
	}
	//Bulk change status if tests scheduled in same cycle
	@Test(priority = 20,enabled=testEnabled)
	public void updateBulkStatus20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
        Long projectId = Long.parseLong(Config.getValue("projectId"));

			//create issues
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
			Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(createIssueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			Long issueId = issueIds.get(0);
			System.out.println(issueId);
			Long issueId1= issueIds.get(1);
			
		//create test steps for issue1
			Teststep teststepJson = new Teststep();
			teststepJson.setStep("stepValue");
			teststepJson.setData("dataValue");
			teststepJson.setResult("resultValue");
			System.out.println("payload-->"+ teststepJson.toString());
			Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
			
		//create test steps for issue2
			Teststep teststepJson1 = new Teststep();
			teststepJson1.setStep("stepValue");
			teststepJson1.setData("dataValue");
			teststepJson1.setResult("resultValue");
			System.out.println("payload-->"+ teststepJson1.toString());
			Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
			Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
			
			// Create cycle
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(-1l);
			cycleJson.setName("export execution"+System.currentTimeMillis());
			cycleJson.setDescription("Get execution by cycle");
			
			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status2 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status2, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
	String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
	System.out.println(CycleName);
	
	//2 executions
			Execution executionJson11 = new Execution();
			executionJson11.setStatusId(-1l);
			executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
			executionJson11.setVersionId(-1l);
			executionJson11.setNoOfExecutions(2);
			executionJson11.setCycleId(cycleId);

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			
		//update
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId11 = issueIds.get(j);
				executionJson11.setIssueId(issueId11);
				System.out.println(issueId11);
			//	executionJson11.setStatusId(1l);
				executionJson11.setExecutionId(exeid);
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
			//String	ex1=jsarray2.getString(0).toString();
			String	ex1=exeIds.get(0).toString();
			System.err.println("executionid1:"+ex1);
//		String ex2=jsarray2.getString(1).toString();
			String	ex2=exeIds.get(1).toString();
			System.err.println("executionid2:"+ex2);
			
	//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
	    String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
	    System.out.println(payLoad);
	    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
	    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
	    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	    System.out.println(response.getBody().asString());
	    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
	    Assert.assertNotNull(response, "Job progress Api Response is null.");
	    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

	    System.out.println("Bulk  Update executions statuses Sucessfully");
	    boolean status = zapiService.validateJobProgress(response,payLoad);
	    Assert.assertTrue(status);

	    test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    extentReport.endTest(test);
	    
	    }
	//Change status in bulk if tests scheduled in different cycles
	@Test(priority = 21,enabled=testEnabled)
	public void updateBulkStatus21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));

			//create issues
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
			Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(createIssueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			Long issueId = issueIds.get(0);
			System.out.println(issueId);
			Long issueId1= issueIds.get(1);
			
		//create test steps for issue1
			Teststep teststepJson = new Teststep();
			teststepJson.setStep("stepValue");
			teststepJson.setData("dataValue");
			teststepJson.setResult("resultValue");
			System.out.println("payload-->"+ teststepJson.toString());
			Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
			
		//create test steps for issue2
			Teststep teststepJson1 = new Teststep();
			teststepJson1.setStep("stepValue");
			teststepJson1.setData("dataValue");
			teststepJson1.setResult("resultValue");
			System.out.println("payload-->"+ teststepJson1.toString());
			Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
			Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
			
			// Create cycle1
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(projectId);
			cycleJson.setVersionId(-1l);
			cycleJson.setName("export execution"+System.currentTimeMillis());
			cycleJson.setDescription("Get execution by cycle");
			
			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status2 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status2, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
	        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
	        System.out.println(CycleName);
	        
	     // Create cycle2
 			Cycle cycleJson1 = new Cycle();
 			cycleJson1.setProjectId(projectId);
 			cycleJson1.setVersionId(-1l);
 			cycleJson1.setName("export execution"+System.currentTimeMillis());
 			cycleJson1.setDescription("Get execution by cycle");
 			
 			Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
 			Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
 			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
 			boolean status21 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
 			Assert.assertTrue(status21, "Response Validation Failed.");
 			test.log(LogStatus.PASS, "Response validated successfully.");
 			String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
 	        String CycleName1 = new JSONObject(cycleResponse1.body().asString()).get("name").toString();	
 	        System.out.println(CycleName);
	        
	        //create execution 1 cycle
	        Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setIssueId(issueId);
			executionJson.setCycleId(cycleId1);
		   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		    executionJson.setVersionId(-1l);
			Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response2, "Create Execution Api Response is null.");
			System.out.println("Execution"+response2.getBody().asString());
			JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
			System.out.println(jsonResponse.toString());
			System.out.println(jsonResponse.get("execution").toString());
			String executionId= jsonResponse.getJSONObject("execution").getString("id");
			
			//create execution2 in another cycle
			 Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId);
			   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			    executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");

				 String payLoad = "{\"executions\":[\""+executionId+"\",\""+executionId1+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
				    System.out.println(payLoad);
				    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
				    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
				    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
				    System.out.println(response.getBody().asString());
				    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
				    Assert.assertNotNull(response, "Job progress Api Response is null.");
				    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

				    System.out.println("Bulk  Update executions statuses Sucessfully");
				    boolean status = zapiService.validateJobProgress(response,payLoad);
				    Assert.assertTrue(status);

				    test.log(LogStatus.PASS, "Response validated suuccessfully.");
				    extentReport.endTest(test);
				    
	}
	//Bulk change status if tests scheduled in different Projects
	@Test(priority = 22,enabled=testEnabled)
	public void updateBulkStatus22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		//creating issueid1 in projectId
			Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad1.setSummary("test");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad1.toString());
			Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
			Assert.assertNotNull(response1, "Create Issue Api Response is null.");
			boolean status1 = jiraService.validateCreateIssueApi(response1);
			Assert.assertTrue(status1, "Response Validation Failed.");
			issueId1 = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
			String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
			
			//creating issueid2 in projectId1
			Issue issuePayLoad11 = new Issue();
			issuePayLoad11.setProject(Config.getValue("projectId1"));
			issuePayLoad11.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad11.setSummary("test");
			issuePayLoad11.setPriority("1");
			issuePayLoad11.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad11.toString());
			Response response11 = jiraService.createIssue(basicAuth, issuePayLoad11.toString());
			Assert.assertNotNull(response11, "Create Issue Api Response is null.");
			boolean status2 = jiraService.validateCreateIssueApi(response11);
			Assert.assertTrue(status2, "Response Validation Failed.");
			issueId2 = Long.parseLong(new JSONObject(response11.body().asString()).getString("id"));
			String issueKey2 = new JSONObject(response11.body().asString()).getString("key");
			
			//create execution1
			Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson1.setIssueId(issueId1);
			executionJson1.setCycleId("-1");
		   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		    executionJson1.setVersionId(-1l);
			Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
			Assert.assertNotNull(response21, "Create Execution Api Response is null.");
			System.out.println("Execution"+response21.getBody().asString());
			JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
			System.out.println(jsonResponse1.toString());
			System.out.println(jsonResponse1.get("execution").toString());
			String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
			
			//create execution2
			Execution executionJson11 = new Execution();
			executionJson11.setStatusId(-1l);
			executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
			executionJson11.setIssueId(issueId2);
			executionJson11.setCycleId("-1");
		   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		    executionJson11.setVersionId(-1l);
			Response response211 = zapiService.createExecution(jwtGenerator, executionJson11.toString());
			Assert.assertNotNull(response211, "Create Execution Api Response is null.");
			System.out.println("Execution"+response211.getBody().asString());
			JSONObject jsonResponse11 = new JSONObject(response211.getBody().asString());
			System.out.println(jsonResponse11.toString());
			System.out.println(jsonResponse11.get("execution").toString());
			String executionId2= jsonResponse11.getJSONObject("execution").getString("id");
			
			String payLoad = "{\"executions\":[\""+executionId1+"\",\""+executionId2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
		    System.out.println(payLoad);
		    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		    System.out.println(response.getBody().asString());
		    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		    Assert.assertNotNull(response, "Job progress Api Response is null.");
		    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

		    System.out.println("Bulk  Update executions statuses Sucessfully");
		    boolean status = zapiService.validateJobProgress(response,payLoad);
		    Assert.assertTrue(status);
            test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    extentReport.endTest(test);
	}
	
	//Bulk change status on test schedules if tests scheduled in Adhoc
	@Test(priority = 23,enabled=testEnabled)
	public void updateBulkStatus23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);

       String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
       System.out.println(payLoad);
       Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
       Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
       test.log(LogStatus.PASS, "Bulk update status executed successfully.");
       System.out.println(response.getBody().asString());

       response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
       Assert.assertNotNull(response, "Job progress Api Response is null.");
       System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

       System.out.println("Bulk  Update executions statuses Sucessfully");
       boolean status = zapiService.validateJobProgress(response,payLoad);
       Assert.assertTrue(status);
       test.log(LogStatus.PASS, "Response validated suuccessfully.");
      extentReport.endTest(test);
	}
	
	//Bulk change status on test schedules if tests scheduled in both Adhoc and new cycle
	@Test(priority = 24,enabled=testEnabled)
	public void updateBulkStatus24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
	  // Create cycle1
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
        System.out.println(CycleName);
        
     //create execution 1 cycle
        Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	    executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		
		//create execution2 in another cycle
		 Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson1.setIssueId(issueId);
		executionJson1.setCycleId(cycleId);
	   // executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
	    executionJson1.setVersionId(-1l);
		Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		Assert.assertNotNull(response21, "Create Execution Api Response is null.");
		System.out.println("Execution"+response21.getBody().asString());
		JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
		System.out.println(jsonResponse1.toString());
		System.out.println(jsonResponse1.get("execution").toString());
		String executionId1= jsonResponse1.getJSONObject("execution").getString("id");

		String payLoad = "{\"executions\":[\""+executionId+"\",\""+executionId1+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
	    System.out.println(payLoad);
	    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
	    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
	    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	    System.out.println(response.getBody().asString());
	    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
	    Assert.assertNotNull(response, "Job progress Api Response is null.");
	    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

	    System.out.println("Bulk  Update executions statuses Sucessfully");
	    boolean status = zapiService.validateJobProgress(response,payLoad);
	    Assert.assertTrue(status);

	    test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    extentReport.endTest(test);
	}
	
	//Bulk change status on test schedules if tests scheduled in different versions of same project with linked defects and comments
	@Test(priority = 25,enabled=testEnabled)
	public void updateBulkStatus25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
			Execution executionJson1 = new Execution();
			executionJson1.setStatusId(-1l);
			executionJson1.setProjectId(projectId);
			executionJson1.setIssueId(issueId1);
			executionJson1.setCycleId("-1");
		   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
			Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
			Assert.assertNotNull(response21, "Create Execution Api Response is null.");
			System.out.println("Execution"+response21.getBody().asString());
			JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
			System.out.println(jsonResponse1.toString());
			System.out.println(jsonResponse1.get("execution").toString());
			String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
			System.out.println("executionid2: "+executionId1+"");
			
			//create defect to link		
			issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			
			Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response1, "Create Issue Api Response is null.");
			
			boolean issueStatus = jiraService.validateCreateIssueApi(response1);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
			List<Long> defectsList = new ArrayList<>();
			defectsList.add(bugId);	    

			//update 
			List<String> exeIds1 = new ArrayList<>() ;
			/*JSONArray jsarray21 = new JSONArray(response21.toString());
			System.out.println("length="+jsarray21.length());
			for (int j=0;j<jsarray21.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
				//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds1.add(executionId);
				//Long issueId = issueIds.get(j);
				executionJson1.setIssueId(issueId);
				executionJson1.setDefects(defectsList);
				executionJson1.setComment("Comment added to executions");
				System.out.println(issueId);
				executionJson1.setStatusId(2l);
				executionJson1.setExecutionId(executionId);
				
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
						executionJson1.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
				
				String payLoad = "{\"executions\":[\""+executionId+"\",\""+executionId1+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
			    System.out.println(payLoad);
			    Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
			    Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
			    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
			    System.out.println(response.getBody().asString());
			    response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
			    Assert.assertNotNull(response, "Job progress Api Response is null.");
			    System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

			    System.out.println("Bulk  Update executions statuses Sucessfully");
			    boolean status = zapiService.validateJobProgress(response,payLoad);
			    Assert.assertTrue(status);

			    test.log(LogStatus.PASS, "Response validated suuccessfully.");
			    extentReport.endTest(test);
						
	}

	//Bulk change status on test schedules if tests scheduled in same versions of same project with linked defects and comments
	@Test(priority = 26,enabled=testEnabled)
	public void updateBulkStatus26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	

				//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId11 = issueIds.get(j);
				executionJson11.setIssueId(issueId11);
				System.out.println(issueId11);
			//	executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for Executions");
				executionJson11.setDefects(defectsList);
				executionJson11.setExecutionId(exeid);
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);


	       String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
	       System.out.println(payLoad);
	       Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
	       Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	       System.out.println(response.getBody().asString());

	       response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
	       Assert.assertNotNull(response, "Job progress Api Response is null.");
	       System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

	       System.out.println("Bulk  Update executions statuses Sucessfully");
	       boolean status = zapiService.validateJobProgress(response,payLoad);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	}
	//Bulk change status on test schedule if same test is scheduled multiple times in Adhoc
	@Test(priority = 27,enabled=testEnabled)
	public void updateBulkStatus27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId1+"");

       //String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		String payLoad = "{\"executions\":[\""+executionId+"\",\""+executionId1+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		System.out.println(response.getBody().asString());
		
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk  Update executions statuses Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//<Performance>Bulk change status on test schedule if same test is scheduled in multiple cycles in multiple versions (5 versions, 5 cycles each version)

	//Attempt to bulk update executions if status id is invalid
	@Test(priority = 28,enabled=testEnabled)
	public void updateBulkStatus28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//create test steps for issue1
						Teststep teststepJson = new Teststep();
						teststepJson.setStep("stepValue");
						teststepJson.setData("dataValue");
						teststepJson.setResult("resultValue");
						System.out.println("payload-->"+ teststepJson.toString());
						Response stepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
						Assert.assertNotNull(stepresponse, "Create Test Step Api Response is null.");
						
						//create test steps for issue2
						Teststep teststepJson1 = new Teststep();
						teststepJson1.setStep("stepValue");
						teststepJson1.setData("dataValue");
						teststepJson1.setResult("resultValue");
						System.out.println("payload-->"+ teststepJson1.toString());
						Response stepresponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1, teststepJson1.toString());
						Assert.assertNotNull(stepresponse1, "Create Test Step Api Response is null.");
		//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				//String	ex1=jsarray2.getString(0).toString();
				   String ex1=exeIds.get(0).toString();
				   System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				  String ex2=exeIds.get(1).toString();
				  System.err.println("executionid2:"+ex2);

		//String payLoad = "{\"executions\":[\"0001479882304824-242ac111f-0001\",\"0001479882305970-242ac111f-0001\"],\"status\":4,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1000}";
		     String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":444441,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":1}";
		     System.out.println(payLoad);
		     Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		     Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
		     test.log(LogStatus.PASS, "Bulk update status executed successfully.");
		     System.out.println(response.getBody().asString());
		     System.out.println("Bulk update executions statuses Sucessfully");
			 boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
			 Assert.assertTrue(status);
			 test.log(LogStatus.PASS, "Response validated suuccessfully.");
			 extentReport.endTest(test);
	}
	//Attempt to bulk update status of executions if invalid execution id is passed
	//ZFJCLOUD-4931
	@Test(priority = 29,enabled=testEnabled)
	public void updateBulkStatus29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
   String exeId="00014798000000-242ac111f-0001";
		String payLoad = "{\"executions\":[\""+exeId+"\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":2}";
		System.out.println(payLoad);
		 Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
	     Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
	     test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	     System.out.println(response.getBody().asString());
	     System.out.println("Bulk update executions statuses Sucessfully");
		 boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		 Assert.assertTrue(status);
		 test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
	}
	//Bulk change status for executions with pagination (about 40-60 executions)
	@Test(priority = 30,enabled=false)
	public void updateBulkStatus30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 50);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(50);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
	//update
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);


       String payLoad = "{\"executions\":[\""+ex1+"\",\""+ex2+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":null}";
       System.out.println(payLoad);
       Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
       Assert.assertNotNull(response, "Bulk update Execution Api Response is null.");
       test.log(LogStatus.PASS, "Bulk update status executed successfully.");
       System.out.println(response.getBody().asString());

       response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
       Assert.assertNotNull(response, "Job progress Api Response is null.");
       System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());

       System.out.println("Bulk  Update executions statuses Sucessfully");
       boolean status = zapiService.validateJobProgress(response,payLoad);
       Assert.assertTrue(status);
       test.log(LogStatus.PASS, "Response validated suuccessfully.");
       extentReport.endTest(test);
	}
	//Manual - Attempt to do bulk change status with invalid authentication
	//@Test(priority = 2)
	public void updateBulkStatus31(){
	}
}

