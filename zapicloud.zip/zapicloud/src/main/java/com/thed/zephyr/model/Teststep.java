/**
 * Created by manoj.behera on 15-Nov-2016.
 */
package com.thed.zephyr.model;

import java.util.List;

import org.json.JSONObject;

/**
 * @author manoj.behera 15-Nov-2016
 *
 */
public class Teststep {
	private String id;
	private Long orderId;
	private Long projectId;
	private Long issueId;
	private String step;
	private List<String> stepList;
	private String data;
	private List<String> dataList;
	private String result;
	private List<String> resultList;
	private String createdBy;
	private String createdOn;
	private int noOfTeststeps;
	private String position;
	/**
	 * @return the id
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getClone_position_Id() {
		return position;
	}
	/**
	 * @return the id
	 * sample - -1 - clone after , 0 - before, -2 - last step, position - position need to give
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public void setClone_position_Id(String clonepositionid) {
		this.position=clonepositionid;
		
	}
	
	
	/**
	 * @return the id
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getId() {
		return id;
	}


	/**
	 * @param id the id to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setId(String id) {
		this.id = id;
	}


	/**
	 * @return the orderId
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public Long getOrderId() {
		return orderId;
	}


	/**
	 * @param orderId the orderId to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}


	/**
	 * @return the projectId
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public Long getProjectId() {
		return projectId;
	}


	/**
	 * @param projectId the projectId to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}


	/**
	 * @return the issueId
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public Long getIssueId() {
		return issueId;
	}


	/**
	 * @param issueId the issueId to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setIssueId(Long issueId) {
		this.issueId = issueId;
	}


	/**
	 * @return the step
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getStep() {
		return step;
	}


	/**
	 * @param step the step to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setStep(String step) {
		this.step = step;
	}


	/**
	 * @return the data
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getData() {
		return data;
	}


	/**
	 * @param data the data to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setData(String data) {
		this.data = data;
	}


	/**
	 * @return the result
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getResult() {
		return result;
	}


	/**
	 * @param result the result to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setResult(String result) {
		this.result = result;
	}


	/**
	 * @return the createdBy
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getCreatedBy() {
		return createdBy;
	}


	/**
	 * @param createdBy the createdBy to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	/**
	 * @return the createdOn
	 * Created by manoj.behera on 15-Nov-2016.
	 */
	public String getCreatedOn() {
		return createdOn;
	}


	/**
	 * @param stepList the stepList to set
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	public void setStepList(List<String> stepList) {
		this.stepList = stepList;
	}


	/**
	 * @param dataList the dataList to set
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	public void setDataList(List<String> dataList) {
		this.dataList = dataList;
	}


	/**
	 * @param resultList the resultList to set
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	public void setResultList(List<String> resultList) {
		this.resultList = resultList;
	}


	/**
	 * @param noOfTeststeps the noOfTeststeps to set
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	public void setNoOfTeststeps(int noOfTeststeps) {
		this.noOfTeststeps = noOfTeststeps;
	}


	/**
	 * @param createdOn the createdOn to set
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}


	@Override
	 public String toString() {
	  JSONObject teststepJson = new JSONObject();
	  if(this.id != null){
	   teststepJson.put("id", this.id);
	  }
	  if(this.noOfTeststeps != 0){
		   teststepJson.put("noOfTeststeps", this.noOfTeststeps);
	  }
	  if(this.projectId != null){
	   teststepJson.put("projectId", this.projectId);
	  }
	  if(this.orderId != null){
	   teststepJson.put("orderId", this.orderId);
	  }
	  if(this.issueId != null){
	   teststepJson.put("issueId", this.issueId);
	  }
	  if(this.step != null){
	   teststepJson.put("step", this.step);
	  }
	  if(this.stepList != null ){
		   teststepJson.put("stepList", this.stepList);
	  }
	  if(this.data != null){
	   teststepJson.put("data", this.data);
	  }
	  if(this.dataList != null ){
		   teststepJson.put("dataList", this.dataList);
	  }
	  if(this.result != null){
	   teststepJson.put("result", this.result);
	  }
	  if(this.resultList != null){
		   teststepJson.put("resultList", this.resultList);
	  }
	  if(this.createdBy != null){
	   teststepJson.put("createdBy", this.createdBy);
	  }
	  if(this.position !=null)
	  {
		  teststepJson.put("position", this.position);
	  }
	  
	  return teststepJson.toString();
	 }
	
}
