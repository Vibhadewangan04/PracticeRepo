package com.thed.zephyr.regression.attachment;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.cloud.rest.model.StepResult;
import com.thed.zephyr.cloud.rest.util.json.StepResultJsonParser;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class GetExecutionAttachmentsList extends BaseTest{
	
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution for one attachment in the execution
	 */
	
	//@Test(priority = 1)
	public void getExecutionAttachmentsList_test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "null";
		String issueId = "null";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution for 10 attachment in the execution
	 */
	
	//@Test(priority = 2)
	public void getExecutionAttachmentsList_test2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution for 100 attachments in the execution
	 */
	
	//@Test(priority = 3)
	public void getExecutionAttachmentsList_test3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String entityName = "execution";
		String entityId = "0001479980871526-242ac1122-0001";
		Long projectId = 10200l;
		Long issueId = 10544l;
		String cycleId = "0001479980766013-242ac1122-0001";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "1456.tif";
		
		for(int i=0; i<=100; i++){
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		}

		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution in adhoc unscheduled version
	 */
	
	//@Test(priority = 4)
	public void getExecutionAttachmentsList_test4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution in cycle of unscheduled
	 */
	
	//@Test(priority = 5)
	public void getExecutionAttachmentsList_test5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution in adhoc scheduled version
	 */
	
	//@Test(priority = 6)
	public void getExecutionAttachmentsList_test6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution in cycle scheduled version
	 */
	
	//@Test(priority = 7)
	public void getExecutionAttachmentsList_test7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Get attachment list execution for for different types of execution
	 */
	
	//@Test(priority = 8)
	public void getExecutionAttachmentsList_test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Attempt to Get attachment list execution for no attachment in execution
	 */
	
	//@Test(priority = 9)
	public void getExecutionAttachmentsList_test9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "0001480513561057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateGetAttachment(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 28-Nov-2016
	 * Attempt to Get attachment list for invalid entityId
	 */
	
	//@Test(priority = 10)
	public void getExecutionAttachmentsList_test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityId = "000057-242ac1124-0001";
		String projectId = "10200";
		String issueId = "10201";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		Boolean status = zapiService.validateAddedAttachmentInvalidValues(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
