package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.FolderApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

@Service("folderApi")
public class FolderApiimpl implements FolderApi {

	@Override
	public Response createfolder(JwtGenerator jwtGenerator, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/folder";
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
//		headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		 System.out.println(payLoad);
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	
	@Override
	public Response Getfolderbyid(JwtGenerator jwtGenerator, String payLoad,String Folderid) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/folder/"+Folderid;
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
//		headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		 System.out.println(payLoad);
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	
	@Override
	public Response getFolders(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/folders";
		URI uri = null;
		if(projectId == null){
			uri = UriBuilder.fromUri(uriStr).queryParam("versionId", versionId).build();
		}else if (versionId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}else if (cycleId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("cycleId", cycleId).build();
		}else{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("cycleId",cycleId).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).get(uri);
	}
	

}
