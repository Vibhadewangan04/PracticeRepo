/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URL;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriBuilderException;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.ZqlFilterApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;


import static com.jayway.restassured.RestAssured.given;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("zqlFilterApi")
public class ZqlFilterApiImpl implements ZqlFilterApi {

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ZqlFilterApi#createZQLFilter(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createZQLFilter(JwtGenerator jwtGenerator, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filter";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ZqlFilterApi#getZQLFilter(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getZQLFilter(JwtGenerator jwtGenerator, String zqlFilterId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filter/"+zqlFilterId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ZqlFilterApi#searchZQLFilter(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response searchZQLFilters(JwtGenerator jwtGenerator, String zqlFilter) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters/search";
//		String zqlJson = null;
		JSONObject json = new JSONObject(zqlFilter);
		URI uri = null;
		UriBuilder s = UriBuilder.fromUri(uriStr);
		if(json.has("name")){
			s.queryParam("name", json.getString("name"));
//			uri = UriBuilder.fromUri(uriStr).queryParam("name", zqlFilter.getName()).build();
		}
		if(json.has("owner")){
			s.queryParam("owner", json.getString("owner"));
//			uri = UriBuilder.fromUri(uriStr).queryParam("owner", zqlFilter.getOwner()).build();
		}
		if(json.has("sharePerm")){
			s.queryParam("sharePerm", json.getString("sharePerm"));
//			uri = UriBuilder.fromUri(uriStr).queryParam("sharePerm", zqlFilter.getSharePerm()).build();
		}
		if(json.has("offset")){
			s.queryParam("offset", json.getInt("offset"));
			//			uri = UriBuilder.fromUri(uriStr).queryParam("sharePerm", zqlFilter.getSharePerm()).build();
		}
		if(json.has("size")){
			s.queryParam("size", json.getInt("size"));
			//			uri = UriBuilder.fromUri(uriStr).queryParam("sharePerm", zqlFilter.getSharePerm()).build();
		}
		uri = s.build();
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("name", name).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
//	public Response searchZQLFilter(JwtGenerator jwtGenerator, String name, String owner, String sharePerm) {
//		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters/search";
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("name", name).queryParam("owner", owner).queryParam("sharePerm", sharePerm).build();
//		int expirationInSec = 3600;
//		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
//		System.out.println(jwt);
//		Map<String, String> headers = new HashMap<String, String>();
////		headers.put("Content-Type", "application/json");
//		headers.put("Authorization", jwt);
//		headers.put("zapiAccessKey", Config.getValue("accessKey"));
//		 System.out.println(uri.toString());
//		return given().headers(headers).when().get(uri);
//	}
	@Override
	public Response quickSearchZQLFilter(JwtGenerator jwtGenerator, String zqlFilterName) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters/quicksearch";
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("query", zqlFilterName.replace(" ", "%2520")).build();
		URI uri = UriBuilder.fromUri(uriStr).queryParam("query", zqlFilterName).build();
//		uri.toASCIIString(uri);
//		URL url = new URL();
		int expirationInSec = 3600;
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ZqlFilterApi#getZQLFilters(com.thed.zephyr.cloud.rest.client.JwtGenerator)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getFavouriteZQLFilters(JwtGenerator jwtGenerator, boolean byUser, boolean fav, int offset, int maxRecords) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters";
		
		URI uri = UriBuilder.fromUri(uriStr).queryParam("byUser", byUser).queryParam("fav", fav).queryParam("offset", offset).queryParam("maxRecords", maxRecords).build();
//		UriBuilder s = UriBuilder.fromUri(uriStr);
//		s.queryParam("", "");
//		s.build();
//		uriBuilder = uriBuilder.queryParam("byUser", byUser).queryParam("fav", fav).queryParam("offset", offset).queryParam("maxRecords", maxRecords);
//		if(zqlFilter.getOwner() != null){
//			uriBuilder = uriBuilder.queryParam("owner", zqlFilter.getOwner());
//		}
//		if(zqlFilter.getSharePerm() != null){
//			uriBuilder = uriBuilder.q	ueryParam("sharePerm", zqlFilter.getSharePerm());
//		}
//		URI uri = uriBuilder.build();
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("byUser", true).queryParam("fav", true).queryParam("offset", 0).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getMyZQLFilters(JwtGenerator jwtGenerator, boolean byUser, int offset, int maxRecords) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters";
		
		URI uri = UriBuilder.fromUri(uriStr).queryParam("byUser", byUser).queryParam("offset", offset).queryParam("maxRecords", maxRecords).build();
//		UriBuilder s = UriBuilder.fromUri(uriStr);
//		s.queryParam("", "");
//		s.build();
//		uriBuilder = uriBuilder.queryParam("byUser", byUser).queryParam("fav", fav).queryParam("offset", offset).queryParam("maxRecords", maxRecords);
//		if(zqlFilter.getOwner() != null){
//			uriBuilder = uriBuilder.queryParam("owner", zqlFilter.getOwner());
//		}
//		if(zqlFilter.getSharePerm() != null){
//			uriBuilder = uriBuilder.q	ueryParam("sharePerm", zqlFilter.getSharePerm());
//		}
//		URI uri = uriBuilder.build();
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("byUser", true).queryParam("fav", true).queryParam("offset", 0).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getPapularZQLFilters(JwtGenerator jwtGenerator, boolean fav, int offset, int maxRecords) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters";
		
		URI uri = UriBuilder.fromUri(uriStr).queryParam("fav", fav).queryParam("offset", offset).queryParam("maxRecords", maxRecords).build();
//		UriBuilder s = UriBuilder.fromUri(uriStr);
//		s.queryParam("", "");
//		s.build();
//		uriBuilder = uriBuilder.queryParam("byUser", byUser).queryParam("fav", fav).queryParam("offset", offset).queryParam("maxRecords", maxRecords);
//		if(zqlFilter.getOwner() != null){
//			uriBuilder = uriBuilder.queryParam("owner", zqlFilter.getOwner());
//		}
//		if(zqlFilter.getSharePerm() != null){
//			uriBuilder = uriBuilder.q	ueryParam("sharePerm", zqlFilter.getSharePerm());
//		}
//		URI uri = uriBuilder.build();
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("byUser", true).queryParam("fav", true).queryParam("offset", 0).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		
		return given().headers(headers).when().get(uri);
	}

//	/* (non-Javadoc)
//	 * @see com.thed.zephyr.api.ZqlFilterApi#searchZQLFilter(com.thed.zephyr.cloud.rest.client.JwtGenerator)
//	 * @author Created by manoj.behera on 14-Nov-2016.
//	 */
//	@Override
//	public Response searchZQLFilter(JwtGenerator jwtGenerator) {
//		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filters/search";
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("sharePerm", "global").build();
//		int expirationInSec = 3600;
//		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
//		System.out.println(jwt);
//		Map<String, String> headers = new HashMap<String, String>();
////		headers.put("Content-Type", "application/json");
//		headers.put("Authorization", jwt);
//		headers.put("zapiAccessKey", Config.getValue("accessKey"));
//		 System.out.println(uri.toString());
//		return given().headers(headers).when().get(uri);
//	}
	@Override
	public Response copyFilter(JwtGenerator jwtGenerator, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filter/copy";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri);
		 
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	@Override
	public Response updateFilter(JwtGenerator jwtGenerator, String filterId, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filter/"+filterId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri);
		 
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	@Override
	public Response deleteFilter(JwtGenerator jwtGenerator, String filterId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filter/"+filterId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("DELETE", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri);
		 
		return given().headers(headers).when().delete(uri);
	}
	@Override
	public Response toggleFavorite(JwtGenerator jwtGenerator, String filterId, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/zql/filter/"+filterId+"/favorite";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri);
		 
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	@Override
	public Response pingJob(JwtGenerator jwtGenerator) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/private/rest/api/1.0/backup/ping/home";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri);
		 
		return given().headers(headers).when().get(uri);
	}

	@Override
	public Response createIssueZQLFilter(JwtGenerator jwtGenerator, String payLoad) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
