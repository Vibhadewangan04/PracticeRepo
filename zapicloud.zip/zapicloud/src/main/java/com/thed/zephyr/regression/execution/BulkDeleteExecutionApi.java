/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class BulkDeleteExecutionApi extends BaseTest{
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	JwtGenerator jwtGeneratorinvalid = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
		jwtGeneratorinvalid = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), "12345", "223225454", "user123");
	}


	//Bulk delete a few selected executions that are not executed
	@Test(priority = 1,enabled=testEnabled)
	public void deleteBulkExecutions1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
	//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);

	//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
		
        String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete ExecutionApi executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete Unexecuted executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//Bulk delete executions that have been executed to PASS/FAIL/WIP/BLOCKED/CUSTOM
	@Test(priority = 2,enabled=testEnabled)
	public void deleteBulkExecutions2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);

			//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
				
		        String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\"]}";
				System.out.println(payLoad);
				Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
				Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
				test.log(LogStatus.PASS, "Bulk Delete Executione Api executed successfully.");
				System.out.println("Response: "+response.getBody().asString());
				response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
				Assert.assertNotNull(response, "Job progress Api Response is null.");
				System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
				
				System.out.println("Bulk delete executed executions Sucessfully");
				boolean status = zapiService.validateJobProgress(response,payLoad);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}
	//Bulk delete 20 executions(5 executions )
	@Test(priority = 3,enabled=testEnabled)
	public void deleteBulkExecutions3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(5);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
					
			//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);
				String	ex3=exeIds.get(2).toString();
				String	ex4=exeIds.get(3).toString();
				String	ex5=exeIds.get(4).toString();
			
			//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
			    String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\",\""+ex3+"\",\""+ex4+"\",\""+ex5+"\"]}";
				System.out.println(payLoad);
				Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
				Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
				test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
				System.out.println("Response: "+response.getBody().asString());
				response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
				Assert.assertNotNull(response, "Job progress Api Response is null.");
				System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
				
				System.out.println("Bulk delete executions Sucessfully");
				boolean status = zapiService.validateJobProgress(response,payLoad);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}

	//Bulk delete 30 executions   - check in qa-bench or qa -cloud
	@Test(priority = 4,enabled=false)
	public void deleteBulkExecutions4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 30);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(30);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		String	ex3=exeIds.get(2).toString();
		String	ex4=exeIds.get(3).toString();
		String	ex5=exeIds.get(4).toString();
		
//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
	    String payLoad	="{\"executions\":[\""+ex1+"\",\""+ex2+"\",\""+ex3+"\",\""+ex4+"\",\""+ex5+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		}
	
	//Bulk delete 60 updated  status executions
	@Test(priority = 5,enabled=false)
	public void deleteBulkExecutions5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 60);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(60);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		String	ex3=exeIds.get(2).toString();
		String	ex4=exeIds.get(3).toString();
		String	ex5=exeIds.get(4).toString();
		
//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
	    String payLoad	="{\"executions\":[\""+ex1+"\",\""+ex2+"\",\""+ex3+"\",\""+ex4+"\",\""+ex5+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Bulk delete 500 executions
	@Test(priority = 6,enabled=false)
	public void deleteBulkExecutions6() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 500);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		Thread.sleep(2000);
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(500);
		executionJson11.setCycleId("-1");
		Thread.sleep(2000);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
  //	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		String	ex3=exeIds.get(2).toString();
		String	ex4=exeIds.get(3).toString();
		String	ex5=exeIds.get(4).toString();
		
  //	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
	    String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\",\""+ex3+"\",\""+ex4+"\",\""+ex5+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Attempt to bulk delete 501 executions
	//@Test(priority = 7,enabled=false)
	public void deleteBulkExecutions7() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 501);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		Thread.sleep(2000);
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
				//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(501);
		executionJson11.setCycleId("-1");
		Thread.sleep(2000);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
				
				
	//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);
		String	ex3=exeIds.get(2).toString();
		String	ex4=exeIds.get(3).toString();
		String	ex5=exeIds.get(4).toString();
		

	//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
	    String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\",\""+ex3+"\",\""+ex4+"\",\""+ex5+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete executions Sucessfully");
		boolean status = zapiService.validateinvalidJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Manual - Attempt to bulk delete executions, with no browse permission to the project
	@Test(priority = 8,enabled=false)
	public void deleteBulkExecutions8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479123858871-242ac1134-0001\",\"0001479123804740-242ac1134-0001\",\"0001479123763535-242ac1134-0001\",\"0001479125359956-242ac1134-0001\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Manual - Bulk delete by selecting individual executions using pagination
	@Test(priority = 9,enabled=false)
	public void deleteBulkExecutions9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
	//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);

	//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
		
        String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete Unexecuted executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Bulk delete executions that have been executed in Adhoc cycles
	@Test(priority = 10,enabled=testEnabled)
	public void deleteBulkExecutions10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
       //create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");
        JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
			executionJson11.setStatusId(2l);
			executionJson11.setExecutionId(exeid);
			
			//update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);

	//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
		String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete Unexecuted executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Bulk delete executions that have been exeuted in Ahoc and non-adhoc cycles
	@Test(priority = 11,enabled=testEnabled)
	public void deleteBulkExecutions11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("delete execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
        String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
        System.out.println(CycleName);

		 //creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson1.setIssueId(issueId1);
		executionJson1.setCycleId(cycleId);
	   executionJson1.setVersionId(-1l);
		Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		Assert.assertNotNull(response21, "Create Execution Api Response is null.");
		System.out.println("Execution"+response21.getBody().asString());
		JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
		System.out.println(jsonResponse1.toString());
		System.out.println(jsonResponse1.get("execution").toString());
		String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
		System.out.println("executionid2: "+executionId1+"");
				
       //update execution1
    List<String> exeIds1 = new ArrayList<>() ;
/*JSONArray jsarray21 = new JSONArray(response21.toString());
System.out.println("length="+jsarray21.length());
for (int j=0;j<jsarray21.length();j++){
	JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
	//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	exeIds1.add(executionId);
	//Long issueId = issueIds.get(j);
	executionJson.setIssueId(issueId);
	
//	executionJson1.setComment("Comment added to executions");
	System.out.println(issueId);
	executionJson.setStatusId(2l);
	executionJson.setExecutionId(executionId);
	
	Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
			executionJson.toString());
	Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	System.out.println(updateExecutionResponse.getBody().asString());
	System.out.println("updated execution");

	//update execution2
	List<String> exeIds11 = new ArrayList<>() ;
	/*JSONArray jsarray21 = new JSONArray(response21.toString());
	System.out.println("length="+jsarray21.length());
	for (int j=0;j<jsarray21.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
		//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds11.add(executionId1);
		//Long issueId = issueIds.get(j);
		executionJson1.setIssueId(issueId1);
		System.out.println(issueId1);
		executionJson1.setStatusId(2l);
		executionJson1.setExecutionId(executionId);
		
		Response updateExecutionResponse1 = zapiService.updateExecution(jwtGenerator, executionId1,
				executionJson1.toString());
		Assert.assertNotNull(updateExecutionResponse1, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse1.getBody().asString());
		System.out.println("updated execution");
	//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
		
        String payLoad	=	"{\"executions\":[\""+executionId+"\",\""+executionId1+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Attempt to bulkdelete executions with excution id as NULL=ZFJCLOUD-4931
	@Test(priority = 12,enabled=testEnabled)
	public void deleteBulkExecutions12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[null]}";
		//String payLoad = null;
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Delete Execution Api Response is null.");
		System.out.println(response.getBody().asString());
		boolean response1 = zapiService.validateDeletedExecutionWithInvalidExecutionId(response);
		Assert.assertNotNull(response1, "Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Delete executions Api executed successfully.");
		System.out.println("Bulk delete executions Sucessfully");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to bulk delete executions with excution id as EMPTY
	@Test(priority = 13,enabled=testEnabled)
	public void deleteBulkExecutions13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Delete Execution Api Response is null.");
		System.out.println(response.getBody().asString());
		boolean response1 = zapiService.validateDeletedExecutionWithInvalidExecutionId(response);
		Assert.assertNotNull(response1, "Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Delete executions Api executed successfully.");
		System.out.println("Bulk delete executions Sucessfully");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Bulk delete executions that have been executed with defects and statuses. 
	@Test(priority = 14,enabled=testEnabled)
	public void deleteBulkExecutions14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId("-1");

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		  //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(j);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
			executionJson11.setDefects(defectsList);
			executionJson11.setStatusId(2l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
	//String	ex1=jsarray2.getString(0).toString();
		String	ex1=exeIds.get(0).toString();
		System.err.println("executionid1:"+ex1);
//	String ex2=jsarray2.getString(1).toString();
		String	ex2=exeIds.get(1).toString();
		System.err.println("executionid2:"+ex2);

	//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
		
        String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
		test.log(LogStatus.PASS, "Bulk Delete Execution Api executed successfully.");
		System.out.println("Response: "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "Job progress Api Response is null.");
		System.out.println("Response aftre jobProgress Handler: "+response.getBody().asString());
		
		System.out.println("Bulk delete Unexecuted executions Sucessfully");
		boolean status = zapiService.validateJobProgress(response,payLoad);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to bulk delete executions with invalid credentials
	@Test(priority = 15,enabled=testEnabled)
	public void deleteBulkExecutions15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId("-1");

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
				//	executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				//String	ex1=jsarray2.getString(0).toString();
				String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
				String	ex2=exeIds.get(1).toString();
				System.err.println("executionid2:"+ex2);

			//	String payLoad = "{\"executions\":[\"0001479422438880-242ac113a-0001\",\"0001479446785198-242ac113a-0001\",\"0001479509424076-242ac111d-0001\",\"0001479769131879-242ac111e-0001\"]}";
				 String payLoad	=	"{\"executions\":[\""+ex1+"\",\""+ex2+"\"]}";
				System.out.println(payLoad);
				Response response = zapiService.deleteBulkExecutions(jwtGeneratorinvalid, payLoad);
				Assert.assertNotNull(response, "Bulk Delete Execution Api Response is null.");
				test.log(LogStatus.PASS, "Bulk Delete Execution executed successfully.");
				System.out.println("Response: "+response.getBody().asString());
				
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
	}

}
