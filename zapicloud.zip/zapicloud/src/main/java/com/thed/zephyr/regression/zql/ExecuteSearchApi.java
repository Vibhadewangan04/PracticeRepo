/**
 *
 */
package com.thed.zephyr.regression.zql;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zql;
import com.thed.zephyr.util.RestUtils;
/**
 * @author Praveenkumar
 *
 */
public class ExecuteSearchApi extends BaseTest {
	JwtGenerator jwtGenerator = null;
	String zqlQuery;
	int offset;
	int maxRecords;
	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	// Execute ZQL search by "Zql":"project " + Config.getValue("projectKey");
	@Test(priority = 1)
	public void test1_SearchZqlFilter_by_project_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project = " + Config.getValue("projectKey");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"project !" + Config.getValue("projectKey");
	@Test(priority = 2)
	public void test2_SearchZqlFilter_by_project_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project != " + Config.getValue("projectKey");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"project is not Empty"
	@Test(priority = 3)
	public void test3_SearchZqlFilter_by_project_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"project is Empty"
	@Test(priority = 4)
	public void test4_SearchZqlFilter_by_project_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"project not in (IE,Rock)"
	@Test(priority = 5)
	public void test5_SearchZqlFilter_by_project_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project not in " + "(" + "\"" + Config.getValue("projectKey") + "," + Config.getValue("projectKey1") + "\"" + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"project in (IE,Rock,RUBY)"
	@Test(priority = 6)
	public void test6_SearchZqlFilter_by_project_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project in " + "(" + "\"" + Config.getValue("projectKey") + "," + Config.getValue("projectKey1") + "\"" + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"priority = Highest"
	@Test(priority = 7)
	public void test7_SearchZqlFilter_by_priority_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "priority = Highest";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"priority != Medium"
	@Test(priority = 8)
	public void test8_SearchZqlFilter_by_priority_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "priority != Medium";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"priority is not Empty"
	@Test(priority = 9)
	public void test9_SearchZqlFilter_by_priority_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "priority is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"priority is Empty"
	@Test(priority = 10)
	public void test10_SearchZqlFilter_by_priority_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "priority is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"priority not in (Low,Lowest,Medium)"
	@Test(priority = 11)
	public void test11_SearchZqlFilter_by_priority_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "priority not in (Low,Lowest,Medium)";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"priority in (Highest,High)"
	@Test(priority = 12)
	public void test12_SearchZqlFilter_by_priority_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "priority in (Highest,High)";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"component = RC10"
	@Test(priority = 13)
	public void test13_SearchZqlFilter_by_component_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "component = "  + Config.getValue("c1");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"component != RC10"
	@Test(priority = 14)
	public void test14_SearchZqlFilter_by_component_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "component != " + Config.getValue("c1");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"component is not Empty"
	@Test(priority = 15)
	public void test15_SearchZqlFilter_by_component_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "component is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"component is Empty"
	@Test(priority = 16)
	public void test16_SearchZqlFilter_by_component_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "component is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"component not in (RC10,RC20)"
	@Test(priority = 17)
	public void test17_SearchZqlFilter_by_component_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "component not in " + "(" + Config.getValue("componentId1") + "," + Config.getValue("componentId2") + ")" ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"component in (RC10,RC20,c1)"
	@Test(priority = 18)
	public void test18_SearchZqlFilter_by_component_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "component in " + "(" + Config.getValue("componentId1") + "," + Config.getValue("componentId2") + ")" ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName = 123"
	@Test(priority = 19)
	public void test19_SearchZqlFilter_by_cycleName_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName = " + Config.getValue("componentId1");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName != 123"
	@Test(priority = 20)
	public void test20_SearchZqlFilter_by_cycleName_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName != " + Config.getValue("componentId1");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName is not Empty"
	@Test(priority = 21)
	public void test21_SearchZqlFilter_by_cycleName_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName is Empty"
	@Test(priority = 22)
	public void test22_SearchZqlFilter_by_cycleName_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName not in (123,50 exe)"
	@Test(priority = 23)
	public void test23_SearchZqlFilter_by_cycleName_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName not in " + "(" + "\"" + Config.getValue("Cyclename") + "\"" + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName in (123,50 exe,Ad hoc)"
	@Test(priority = 24)
	public void test24_SearchZqlFilter_by_cycleName_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName in " + "(" + "\"" + Config.getValue("Cyclename") + "\"" + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName ~ 123"
	@Test(priority = 25)
	public void test25_SearchZqlFilter_by_cycleName_tilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName ~ " + "\"" + Config.getValue("Cyclename") + "\"";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"cycleName !~ 123"
	@Test(priority = 26)
	public void test26_SearchZqlFilter_by_cycleName_NotTilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "cycleName !~ " + "\"" + Config.getValue("Cyclename") + "\"";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": fixVersion = "RUBY#2.0"
	@Test(priority = 27)
	public void test27_SearchZqlFilter_by_fixVersion_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "fixVersion = " + Config.getValue("version");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"fixVersion != RUBY#2.0"
	@Test(priority = 28)
	public void test28_SearchZqlFilter_by_fixVersion_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "fixVersion != " + Config.getValue("version");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"fixVersion is not Empty"
	@Test(priority = 29)
	public void test29_SearchZqlFilter_by_fixVersion_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "fixVersion is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"fixVersion is Empty"
	@Test(priority = 30)
	public void test30_SearchZqlFilter_by_fixVersion_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "fixVersion is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"fixVersion not in (RUBY#2.0,50)"
	@Test(priority = 31)
	public void test31_SearchZqlFilter_by_fixVersion_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "fixVersion not in " + "(" + "\"" + Config.getValue("version") + "\"" + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"fixVersion in (RUBY#2.0,50,Unscheduled)"
	@Test(priority = 32)
	public void test32_SearchZqlFilter_by_fixVersion_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "fixVersion in " + "(" + "\"" + Config.getValue("version") + "\"" + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": "executionStatus = WIP"
	@Test(priority = 33)
	public void test33_SearchZqlFilter_by_executionStatus_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionStatus = WIP";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionStatus != FAIL"
	@Test(priority = 34)
	public void test34_SearchZqlFilter_by_executionStatus_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionStatus != FAIL";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionStatus is not Empty"
	@Test(priority = 35)
	public void test35_SearchZqlFilter_by_executionStatus_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionStatus is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionStatus is Empty"
	@Test(priority = 36)
	public void test36_SearchZqlFilter_by_executionStatus_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionStatus is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionStatus not in (PASSED,WIP)"
	@Test(priority = 37)
	public void test37_SearchZqlFilter_by_executionStatus_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionStatus not in (PASSED,WIP)";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionStatus in
	// (BLOCKED,UNEXECUTED,new!)"
	@Test(priority = 38)
	public void test38_SearchZqlFilter_by_executionStatus_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionStatus in (BLOCKED,UNEXECUTED,\"new!\")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": "executedByAccountId = admin"
	@Test(priority = 39)
	public void test39_SearchZqlFilter_by_executedByAccountId_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executedByAccountId =  " + Config.getValue("accountId");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executedByAccountId != admin"
	@Test(priority = 40)
	public void test40_SearchZqlFilter_by_executedByAccountId_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executedByAccountId != " + Config.getValue("accountId");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executedByAccountId is not Empty"
	@Test(priority = 41)
	public void test41_SearchZqlFilter_by_executedByAccountId_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executedByAccountId is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executedByAccountId is Empty"
	@Test(priority = 42)
	public void test42_SearchZqlFilter_by_executedByAccountId_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executedByAccountId is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executedByAccountId not in (admin,user1)"
	@Test(priority = 43)
	public void test43_SearchZqlFilter_by_executedByAccountId_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executedByAccountId not in " + "(" + Config.getValue("accountId") + "," + Config.getValue("userAccountId") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executedByAccountId in (admin,user2,user3)"
	@Test(priority = 44)
	public void test44_SearchZqlFilter_by_executedByAccountId_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executedByAccountId in " + "(" + Config.getValue("accountId") + "," + Config.getValue("userAccountId") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": "assignee = admin"
	@Test(priority = 45)
	public void test45_SearchZqlFilter_by_assignee_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignedToAccountId = " + Config.getValue("accountId");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"assignee != admin"
	@Test(priority = 46)
	public void test46_SearchZqlFilter_by_assignee_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignedToAccountId != " + Config.getValue("accountId");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"assignee is not Empty"
	@Test(priority = 47)
	public void test47_SearchZqlFilter_by_assignee_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignedToAccountId is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"assignee is Empty"
	@Test(priority = 48)
	public void test48_SearchZqlFilter_by_assignee_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignedToAccountId is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"assignee not in (admin,user1)"
	@Test(priority = 49)
	public void test49_SearchZqlFilter_by_assignee_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignedToAccountId not in " + "(" + Config.getValue("accountId") + "," + Config.getValue("userAccountId") + ")" ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"assignee in (admin,user2,user3)"
	@Test(priority = 50)
	public void test50_SearchZqlFilter_by_assignee_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignedToAccountId in " + "(" + Config.getValue("accountId") + "," + Config.getValue("userAccountId") + ")" ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": "issue = IE-1"
	@Test(priority = 51)
	public void test51_SearchZqlFilter_by_issue_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue = " + Config.getValue("issueKey");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"issue != IE-1"
	@Test(priority = 52)
	public void test52_SearchZqlFilter_by_issue_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue != " + Config.getValue("issueKey");;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"issue <= IE-1"
	@Test(priority = 53)
	public void test53_SearchZqlFilter_by_issue_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue <= " + Config.getValue("issueKey");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"issue >= IE-1"
	@Test(priority = 54)
	public void test54_SearchZqlFilter_by_isuue_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue >= " + Config.getValue("issueKey");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"issue < IE-1"
	@Test(priority = 55)
	public void test55_SearchZqlFilter_by_issue_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue < " + Config.getValue("issueKey");;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"issue > IE-1"
	@Test(priority = 56)
	public void test56_SearchZqlFilter_by_issue_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue > " + Config.getValue("issueKey");;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"issue not in (IE-1,IE-2)"
	@Test(priority = 57)
	public void test57_SearchZqlFilter_by_issue_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "issue not in " + "(" +  Config.getValue("issueKey") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"assignee in (issue1,issue2,issue3)"
	@Test(priority = 58)
	public void test58_SearchZqlFilter_by_issue_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "assignee in "  + "(" +  Config.getValue("issueKey") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": "creationDate = 2016-11-23"
	@Test(priority = 59)
	public void test59_SearchZqlFilter_by_creationDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate = "  + Config.getValue("creationDate") ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate != 2016-11-23"
	@Test(priority = 60)
	public void test60_SearchZqlFilter_by_creationDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate != " + Config.getValue("creationDate") ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate <= 2016-11-23"
	@Test(priority = 61)
	public void test61_SearchZqlFilter_by_creationDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate <= "  + Config.getValue("creationDate") ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate >= 2016-11-23"
	@Test(priority = 62)
	public void test62_SearchZqlFilter_by_creationDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate >= "  + Config.getValue("creationDate") ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate < 2016-11-23"
	@Test(priority = 63)
	public void test63_SearchZqlFilter_by_creationDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate < "  + Config.getValue("creationDate") ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate > 2016-11-23"
	@Test(priority = 64)
	public void test64_SearchZqlFilter_by_creationDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate > "  + Config.getValue("creationDate") ;
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate not in (2016-11-23,2016-11-22)"
	@Test(priority = 65)
	public void test65_SearchZqlFilter_by_creationDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate not in  " + "(" + Config.getValue("creationDate") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate in
	// (2016-11-23,2016-11-22,2016-11-21)"
	@Test(priority = 66)
	public void test66_SearchZqlFilter_by_creationDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate in "  + "(" + Config.getValue("creationDate") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate is not Empty"
	@Test(priority = 67)
	public void test67_SearchZqlFilter_by_creationDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"creationDate is Empty"
	@Test(priority = 68)
	public void test68_SearchZqlFilter_by_creationDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "creationDate is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql": "executionDate = 2016-11-23"
	@Test(priority = 69)
	public void test69_SearchZqlFilter_by_executionDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate = 2016-11-23";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate != 2016-11-23"
	@Test(priority = 70)
	public void test70_SearchZqlFilter_by_executionDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate != 2016-11-23";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate <= 2016-11-23"
	@Test(priority = 71)
	public void test71_SearchZqlFilter_by_executionDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate <= " + Config.getValue("executionDate");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate >= 2016-11-23"
	@Test(priority = 72)
	public void test72_SearchZqlFilter_by_executionDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate >= " + Config.getValue("executionDate");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate < 2016-11-23"
	@Test(priority = 73)
	public void test73_SearchZqlFilter_by_executionDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate < " +Config.getValue("executionDate");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate > 2016-11-23"
	@Test(priority = 74)
	public void test74_SearchZqlFilter_by_executionDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate > " + Config.getValue("executionDate");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate not in
	// (2016-11-23,2016-11-22)"
	@Test(priority = 75)
	public void test75_SearchZqlFilter_by_executionDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate not in " + "(" + Config.getValue("executionDate") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate in
	// (2016-11-23,2016-11-22,2016-11-21)"
	@Test(priority = 76)
	public void test76_SearchZqlFilter_by_executionDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate in " + "(" + Config.getValue("executionDate") + ")";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate is not Empty"
	@Test(priority = 77)
	public void test77_SearchZqlFilter_by_executionDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate is not Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	// Execute ZQL search by "Zql":"executionDate is Empty"
	@Test(priority = 78)
	public void test78_SearchZqlFilter_by_executionDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "executionDate is Empty";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLSearch(payload.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated successfully");
		extentReport.endTest(test);
	}
	//	Attempt to execute ZQL search by passing invalid ZQL
	//TODO
	@Test(priority = 79)
	public void test79_AttemptToExecuteZqlSearchByPassingInvalidZql() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "vyhvytvv";
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateInvalidZQLSearch(payload.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}
	//	Attempt to execute ZQL search without passing ZQL
	//TODO
	@Test(priority = 80)
	public void test80_AttemptToExecuteZqlSearchWithoutPassingZql() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		//zqlQuery = "project = " + Config.getValue("projectKey");
		offset = 0;
		maxRecords = 20;
		Zql payload = new Zql();
		//payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
				boolean status = zapiService.validateZQLSearch(payload.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//	Attempt to get executions, if the maxRecord is set to 51
	//TODO
	@Test(priority = 81)
	public void test81_AttemptToGetExecutionsIfTheMaxrecordIsSetTo51() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project = " + Config.getValue("projectKey");
		offset = 0;
		maxRecords = 51;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
				boolean status = zapiService.validateZQLSearchWithMaxRecordExceed(payload.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}
	//	Attempt to get executions, if the offset is set to an invalid value
	@Test(priority = 82)
	//TODO
	public void test82_AttemptToGetExecutionsIfTheOffsetIsSetToAnInvalidValue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project = " + Config.getValue("projectKey");
		offset = 98999898;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateZQLSearch(payload.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}
	//	Attempt to get executions, if the offset value is greater than maxRecords
	//TODO
	@Test(priority = 83)
	public void test83_AttemptToGetExecutionsIfTheOffsetValueIsGreaterThanMaxrecords() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		zqlQuery = "project = " + Config.getValue("projectKey");
		offset = 30;
		maxRecords = 20;
		Zql payload = new Zql();
		payload.setZqlQuery(zqlQuery);
		payload.setOffset(offset);
		payload.setMaxRecords(maxRecords);
		System.out.println(payload.toString());
		Response response = zapiService.executeZQLSearch(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "Execute ZQL Search Api Response is null");
		test.log(LogStatus.PASS, "Execute ZQL Search Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateZQLSearch(payload.toString(), response);
			Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

}