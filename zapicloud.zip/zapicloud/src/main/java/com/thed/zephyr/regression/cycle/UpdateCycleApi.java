/**
 * Created by Praveenkumar on 14-Nov-2016.
 */
package com.thed.zephyr.regression.cycle;


import java.util.List;
import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar 14-Nov-2016
 *
 */
public class UpdateCycleApi extends BaseTest {

	String cycleId = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	@Test(priority = 1, enabled = testEnabled)
	public void test1_updateCycleIfCycleIsEmpty() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//Crating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Empty Cycle");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		//Validating created cycle
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Thread.sleep(1000);

		//Updating cycle
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Empty Cycle Updated");
		updateCycleJson.setBuild("#12345");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("Cycle desc");
		updateCycleJson.setStartDate("2016-11-14");
		updateCycleJson.setEndDate("2016-11-30");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		//Validating updated cycle
		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2,  enabled = testEnabled)
	public void test2_updateCycleName() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		/*
		 * Creating cycle
		 * Set the required parameters to create cycle
		 */
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update Cycle Name");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		/*
		 * Validating created cycle
		 */
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		
		//Fetching the created cycleId
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Thread.sleep(1000);

		/*
		 * Updating cycle name
		 * Set the updated cycle name
		 */
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle Name");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId,updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 3, enabled = testEnabled)
	public void test3_updateSameCycleName() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update With Same Cycle Name");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		Thread.sleep(1000);
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Update With Same Cycle Name");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		System.out.println(response.body().asString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 4, enabled = testEnabled)
	public void test4_updateCycleDescription() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update Cycle Desc");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));


		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		Thread.sleep(1000);
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Update Cycle Desc");
		updateCycleJson.setDescription("Updated Cycle Desc");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 5, enabled = testEnabled)
	public void test5_updateCycleBuildNumber() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update Cycle Build");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));


		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		Thread.sleep(1000);
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setName("Update Cycle Build");
		updateCycleJson.setId(cycleId);
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 6, enabled = testEnabled)
	public void test6_updateCycleEnvironment() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update Cycle Environment");
		cycleJson.setEnvironment("Linux");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));


		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		Thread.sleep(1000);
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setName("Update Cycle Environment");
		updateCycleJson.setId(cycleId);
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 7, enabled = testEnabled)
	public void test7_updateCycleStartDate() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update Cycle startDate");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Thread.sleep(2000);

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setName("Update Cycle startDate");
		updateCycleJson.setId(cycleId);
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 8, enabled = testEnabled)
	public void test8_updateCycleEndDate() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Update Cycle startDate");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));


		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), res);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		Thread.sleep(1000);
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setName("Update Cycle startDate");
		updateCycleJson.setId(cycleId);
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-25");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Need cycleId of Cycle that has Unexceuted testcases
	@Test(priority = 9, enabled = testEnabled)
	public void test9_updateCycleIfCycleIsFullyUnexecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		//cycleId = Config.getValue("cyleId_CycleIsFullyUnexecuted");
		//code to create cycle with unexecuted tests
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 5;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle with unexecuted testcases");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status1 = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Cycle should have partially exceuted schedules
	@Test(priority = 10, enabled = testEnabled)
	public void test10_updateCycleIfCycleIsPartiallyexecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//cycleId = Config.getValue("cyleId_CycleIsPartiallyexecuted");
		//write code for partial executed cycle
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle " + System.currentTimeMillis());

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle with partially executed testcases");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response1 = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status1 = zapiService.validateCycle(updateCycleJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Need cycleId of cycle which has schedules that are linked to Single/multiple defects
	@Test(priority = 11, enabled = testEnabled)
	public void test11_updateCycleIfSchedulesAreLinkedToDefects(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("clone Cycle with schedules");
		cycleJson.setDescription("Cycle cloned with schedules");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		


		//cycleId = Config.getValue("cyleId_CycleIfSchedulesAreLinkedToDefects");
		

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle which has executions linked to defects");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		

		Response response1 = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status1 = zapiService.validateCycle(updateCycleJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Need cycleId which has 50 schedules
	@Test(priority = 12, enabled = false)
	public void test12_updateCycleIfCycleHas50Schedules(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		cycleId = Config.getValue("cyleId_CycleHas50Schedules");

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		
		updateCycleJson.setName("Updated Cycle which has 50 schedules");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Need cycleId which has 500 schedules
	@Test(priority = 13, enabled = false)
	public void test13_updateCycleIfCycleHas500Schedules(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		cycleId = Config.getValue("cyleId_CycleHas500Schedules");

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle which has 500 schedules");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Need cycleId which has 1000 schedules
	@Test(priority = 14, enabled = false)
	public void test14_updateCycleIfCycleHas1000Schedules(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		cycleId = Config.getValue("cyleId_CycleHas1000Schedules");

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle which has 1000 schedules");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}


	//TODO
	//Need cycleId which has >5000 schedules
	@Test(priority = 15, enabled = false)
	public void test15_updateCycleIfCycleHasMoreThan5000Schedules(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		cycleId = Config.getValue("cyleId_CycleHas6000Schedules");

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle which has >5000 schedules");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Need CycleId of cycle which is Created in UI
	@Test(priority = 16, enabled = testEnabled)
	public void test16_updateCycleIfCycleIsCreatedInUI() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		cycleId = Config.getValue("cycleId2");
		
		Thread.sleep(1000);
		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Updated Cycle which is created in UI");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 17, enabled = testEnabled)
	public void test17_attemptToUpdateCycleWithoutProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Attempt to update without ProjectId");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Attempt to update without ProjectId");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Testcase validation is pending due to bug ZAPICLOUD-156
	@Test(priority = 18, enabled = testEnabled)
	public void test18_attemptToUpdateCycleWithoutVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Attempt to update without VersionId");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		
		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setName("Attempt to update without VersionId");
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 19, enabled = testEnabled)
	public void test19_attemptToUpdateCycleWithoutName(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Cycle cycleJson = new Cycle();
		cycleJson.setName("Attempt to update without VersionId");
		cycleJson.setBuild("#12345");
		cycleJson.setEnvironment("Windows");
		cycleJson.setDescription("Cycle desc");
		cycleJson.setStartDate("2016-11-14");
		cycleJson.setEndDate("2016-11-30");
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));


		Response res = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(res, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		JSONObject obj = new JSONObject(res.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);

		Cycle updateCycleJson = new Cycle();
		updateCycleJson.setId(cycleId);
		updateCycleJson.setBuild("#54321");
		updateCycleJson.setEnvironment("Linux");
		updateCycleJson.setDescription("updated Cycle desc");
		updateCycleJson.setStartDate("2016-11-15");
		updateCycleJson.setEndDate("2016-11-29");
		updateCycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		updateCycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response response = zapiService.updateCycle(jwtGenerator, cycleId, updateCycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(updateCycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
}
