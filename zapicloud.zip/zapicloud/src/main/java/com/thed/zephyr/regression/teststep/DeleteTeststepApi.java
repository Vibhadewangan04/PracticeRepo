package com.thed.zephyr.regression.teststep;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class DeleteTeststepApi extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	private Long projectId = Long.parseLong(Config.getValue("projectId")); 
    private Long issueId;
    Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
    Long issueTypeId2 = Long.parseLong(Config.getValue("issueTypeStoryId"));
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * Delete a test step by passing the issue id and test step id Created by
	 * Poornachandra.k on 18-Nov-2016
	 */

	
	
	
	@Test(priority = 1, enabled = true)
	public void test1_delete_teststep_with_issueid_and_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Delete test step with wiki format");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);
		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("h1. Biggest heading");
		TeststepJson.setData("h1. Biggest heading");
		TeststepJson.setResult("h1. Biggest heading");
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to delete a test step by passing a test step id that does not
	 * belong to the issue id Created by Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 2, enabled = true)
	public void test2_Attempt_delete_teststep_with_invalid_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(
				" Attempt to delete a test step by passing a test step id that does not belong to the issue id");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));    
		//issuePayLoad.setReporter("admin");
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("steps");
		TeststepJson.setData("datas");
		TeststepJson.setResult("results");

		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		stepid = "123";
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		System.out.println("bcoz of invalid step id test step not delete-pass");
	}

	/**
	 * Delete a test step that is cloned Created by Poornachandra.k on
	 * 18-Nov-2016
	 */
	@Test(priority = 3, enabled = true)
	public void test3_delete_teststep_After_clone_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-1");
		Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
	

		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Cloneteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
		

	/**
	 * Attempt to delete a test step by passing an invalid test step id Created
	 * by Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 4, enabled = true)
	public void test4_Attempt_delete_teststep_invalid_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Attempt to delete a test step by passing an invalid test step id");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("steps");
		TeststepJson.setData("datas");
		TeststepJson.setResult("results");

		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		stepid = "123";

		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step that is modified Created by Poornachandra.k on
	 * 18-Nov-2016
	 */
	@Test(priority = 5, enabled = true)
	public void test5_delete_teststep_After_modified_step() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		

		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "modified";
		String updateddataValue = "modified";
		String updatedresultValue = "modified"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);
	
		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = createteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(createteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}

	/**
	 * Delete a test step if the issue has more than 1000 test steps Created by
	 * Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 6, enabled = true)
	public void test6_delete_teststep_test_having_greaterthan_100_by_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "abc";
		String dataValue = "jjj";
		String resultValue = "kkk";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
		
		//for (int i = 0; i < 100; i++) if user wants to create 100 steps
		for (int i = 0; i < 4; i++) {
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		 }
		
		
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
	}

	/**
	 * Delete a test step if the test step contains numbers, special characters,
	 * new line characters, international characters Created by Poornachandra.k
	 * on 18-Nov-20
	 */
	@Test(priority = 7, enabled = true)
	public void test7_delete_teststep_Contain_numbers_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "1234567890";
		String dataValue = "09876543";
		String resultValue = "1234567890";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
	
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	
	
	

	/**
	 * Delete a test step if the test step contains numbers, special characters,
	 * new line characters, international characters Created by Poornachandra.k
	 * on 18-Nov-2016
	 */
	@Test(priority = 8, enabled = true)
	public void test8_delete_teststep_Contain_Specailcharacter_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "~!@#$%^&*())";
		String dataValue = "()*&^%$#@!";
		String resultValue = "@#$%^&*";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
		

			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	

	/**
	 * Delete a test step if the test step contains numbers, special characters,
	 * new line characters, international characters Created by Poornachandra.k
	 * on 18-Nov-2016
	 */
	@Test(priority = 9, enabled = true)
	public void test9_delete_teststep_Contain_newline_character_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "\\n \\n \\n";
		String dataValue = "\\n \\n \\n";
		String resultValue = "\\n \\n \\n";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
	
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}

	/**
	 * Delete a test step if the test step contains numbers, special characters,
	 * new line characters, international characters Created by Poornachandra.k
	 * on 18-Nov-2016
	 */
	@Test(priority = 10, enabled = true)
	public void test10_delete_teststep_Contain_international_character_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Delete a test step if the test step contains international characters");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("wie geht's ");// german characters
		TeststepJson.setData("wie geht's ");
		TeststepJson.setResult("wie geht's ");
		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if there is no step value Created by Poornachandra.k
	 * on 18-Nov-2016
	 */
	@Test(priority = 11, enabled = true)
	public void test11_delete_teststep_Contain_Empty_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Delete a test step if there is no step value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("");// empty test step
		TeststepJson.setData("");
		TeststepJson.setResult("");
		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if there is no step value Created by Poornachandra.k
	 * on 18-Nov-2016
	 */
	@Test(priority = 12, enabled = true)
	public void test12_delete_teststep_Contain_Empty_stepdata_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Delete a test step if there is no step value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		// TeststepJson.setStep("steps");
		TeststepJson.setStep("");// empty test step
		TeststepJson.setData("datas");
		TeststepJson.setResult("results");

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if there is no data value Created by Poornachandra.k
	 * on 18-Nov-2016
	 */
	@Test(priority = 13, enabled = true)
	public void test13_delete_teststep_Contain_Empty_Testdata_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Delete a test step if there is no data value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("steps");
		TeststepJson.setData("");// empty test data
		// TeststepJson.setData("datas");
		TeststepJson.setResult("results");

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if there is no results value Created by
	 * Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 14, enabled = true)
	public void test14_delete_teststep_Contain_Empty_Resultdata_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Delete a test step if there is no results value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("steps");
		TeststepJson.setData("datas");
		TeststepJson.setResult("");// empty result data

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if test step contains only step value Created by
	 * Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 15, enabled = true)
	public void test15_delete_teststep_Contain_only_stepdata_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Delete a test step if test step contains only step value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("steps");
		TeststepJson.setData("");// empty test data
		TeststepJson.setResult("");// empty result data

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if the test step contains only data value Created by
	 * Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 16, enabled = true)
	public void test16_delete_teststep_Contain_only_testdata_stepid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Delete a test step if the test step contains only data value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("");
		TeststepJson.setData("Test data");// empty test data
		TeststepJson.setResult("");// empty result data

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a test step if the test step contains only result value Created by
	 * Poornachandra.k on 18-Nov-2016
	 */
	@Test(priority = 17, enabled = true)
	public void test17_Delete_teststep_if_the_teststep_contains_only_result_value() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(" Delete a test step if the test step contains only data value");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("");
		TeststepJson.setData("");
		TeststepJson.setResult("Result data");

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		// passing invalid step to test
		// stepid="123";
		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * New cases as soumaya feedback 1. delete the cloned test step(which is
	 * already being cloned) 2. delete test step after clone the step(should try
	 * for every type of cloning the step). need to add atleast 4 test cases for
	 * this as we have 4 types of cloning methods are available. 3. delete test
	 * step after modified the step fully 4. delete test step after modified the
	 * step,when modified only stepData 5. delete test step after modified the
	 * step,when modified only testData 6. delete test step after modified the
	 * step,when modified only expectedResult 7. delete test step after
	 * rearrange the step 8. delete test step when step contains only capital
	 * letter char 9. delete test step when step contains only small letter char
	 * 10.delete test step when step contains only numeric char 11.delete test
	 * step when step contains only alphaNumeric char 12.delete test step when
	 * step contains all type of char with spaces between it. 13.delete test
	 * step when step contains wiki formatted text. (write test cases for all
	 * wiki fomat text) 14.attempt to delete teststep when stepId is 'null' or
	 * empty like "" 15.attempt to delete teststep when issueId and projectId is
	 * mismatched (pass valid id's , but mismatched) 16.attempt to delete
	 * teststep when issueId and stepId is mismatched (pass valid id's , but
	 * mismatched) 17.attempt to delete teststep when stepId and projectId is
	 * mismatched (pass valid id's , but mismatched) 18.attempt to delete test
	 * step by passing issueId of other issue type.
	 * 
	 **/
	
	
	
	
	//18.attempt to delete test step by passing issueId of other issue type	
	@Test(priority = 18, enabled = true)
	public void test18_Attempt_Todelete_teststep_byPassing_issueId_of_OtherIssueType() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId)); 
		

		issuePayLoad.setSummary("Attempt to Delete a test step");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("step1");
		TeststepJson.setData("data1");
		TeststepJson.setResult("Result data");

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		//passing other issue type id in below
			//	issuePayLoad.setIssuetype(String.valueOf(issueTypeId2));
				Long issueId2 = 990000l;

		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId2, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("passed-TestStep not deleted bcoz of wrong issueid");	

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	


	// 1.delete the cloned test step(which is already being cloned)

	@Test(priority = 19, enabled = true)
	public void test19_delete_the_cloned_test_step() {
	
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "A";
	String dataValue = "B";
	String resultValue = "C"; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);
	System.out.println("payload-->"+ teststepJson.toString());
	Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
	test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	System.out.println(createteststepresponse.getBody().asString());
	
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);		
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	teststepJson.setClone_position_Id("-1");
	Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
	
	System.out.println(Cloneteststepresponse.asString());
	String responseData = Cloneteststepresponse.getBody().asString();
	System.out.println(responseData);
	JSONArray responseJson = new JSONArray(responseData);
	JSONObject json = new JSONObject(responseJson.get(1).toString());
		
	String stepid2= json.get("id").toString();

	Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid2);
	System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

	test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
	// System.out.println(response.getBody().asString());
	String S = Cloneteststepresponse.getStatusLine();
	System.err.println(S);
	status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
	Assert.assertTrue(status);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test); 
	
}
	
	
	/*{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Long issueId = 10000l;
		String stepId = "0001478812190393-242ac1131-0001";

		// implement update Test step and delete the test Step After clone by
		// passing cloned test stepid
		Response response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepId);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		boolean status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepId);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}*/

	// 2. delete test step after clone the step(should try for every type of
		// cloning the step).
		// need to add atleast 4 test cases for this as we have 4 types of cloning
		// methods are available.
		// before test step (cloning in 4 types in single case did in testcase37)

	@Test(priority = 20, enabled = true)
	public void test20_cloned_multiple_steps_then_delete_teststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "!@#$%^&*()";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);	
		Response createteststepresponse=null;
		
		for (int i = 0; i < 3; i++) {
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		 }
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-1");
		Response Cloneteststepresponse=null;
		for (int i = 0; i < 5; i++) {
	 Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
		}
		
		System.out.println(Cloneteststepresponse.asString());
		String responseData = Cloneteststepresponse.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);
		JSONObject json = new JSONObject(responseJson.get(3).toString());
	
		String stepid2= json.get("id").toString();
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid2);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Cloneteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	
	
	// clone after test step
	@Test(priority = 21, enabled = true)
	public void test21_clone_after_teststep_then_delete_teststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "!@#$%^&*()";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);	
		Response createteststepresponse=null;
		
		for (int i = 0; i < 3; i++) {
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		 }
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-1");
		Response Cloneteststepresponse=null;
	
	 Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
		
		System.out.println(Cloneteststepresponse.asString());
		String responseData = Cloneteststepresponse.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);
		JSONObject json = new JSONObject(responseJson.get(3).toString());
	
		String stepid2= json.get("id").toString();
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid2);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Cloneteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}

	
	
	
	// clone with before test step
	@Test(priority = 22, enabled = true)
	public void test22_clone_before_teststep_then_delete_teststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "!@#$%^&*()";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);	
		Response createteststepresponse=null;
		
		for (int i = 0; i < 3; i++) {
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		 }
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("0");
		Response Cloneteststepresponse=null;
	
	 Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
		
		System.out.println(Cloneteststepresponse.asString());
		String responseData = Cloneteststepresponse.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);
		JSONObject json = new JSONObject(responseJson.get(3).toString());
	
		String stepid2= json.get("id").toString();
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid2);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Cloneteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}

	// clone with last test step
	@Test(priority = 23, enabled = true)
	public void test23_clone_with_last_teststep_then_delete_teststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "!@#$%^&*()";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);	
		Response createteststepresponse=null;
		
		for (int i = 0; i < 3; i++) {
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		 }
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		teststepJson.setStep("Clone"+stepValue);
		teststepJson.setClone_position_Id("-2");
		Response Cloneteststepresponse=null;
	
	 Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
		System.out.println(Cloneteststepresponse.getBody().asString());		
		
		boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
		Assert.assertTrue(Clonestatus);
		test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
		extentReport.endTest(test);
		
		System.out.println(Cloneteststepresponse.asString());
		String responseData = Cloneteststepresponse.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);
		JSONObject json = new JSONObject(responseJson.get(3).toString());
	
		String stepid2= json.get("id").toString();
		
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid2);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Cloneteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}

	/*
	 * 4. delete test step after modified the step,when modified only stepData
	 * 5. delete test step after modified the step,when modified only testData
	 * 6. delete test step after modified the step,when modified only
	 * expectedResult
	 */

	// 4. delete test step after modified the step,when modified only stepData
	@Test(priority = 24)
	public void test24_delete_teststep_when_modified_only_teststep(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "modified";
		String updateddataValue = "b";
		String updatedresultValue = "c"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);
	
		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = createteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(createteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	
	


	// 5. delete test step after modified the step,when modified only testData
	@Test(priority = 25, enabled = true)
	public void test25_delete_teststep_when_modified_only_testdata() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		

		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "A";
		String updateddataValue = "modified";
		String updatedresultValue = "C"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);
	

		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = createteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(createteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
	}

	// 6. delete test step after modified the step,when modified only
	// expectedResult
	@Test(priority = 26, enabled = true)
	public void test26_delete_teststep_when_modified_only_testresult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "A";
		String dataValue = "B";
		String resultValue = "C"; 		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		System.out.println("payload-->"+ teststepJson.toString());
		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Test Step Api Response is null.");
		test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);	
		

		String stepId = new JSONObject(createteststepresponse.getBody().asString()).get("id").toString();
		System.out.println("The step id" + stepId);
		
		String updatedstepValue = "A";
		String updateddataValue = "B";
		String updatedresultValue = "modified"; 	
		teststepJson.setStep(updatedstepValue);
		teststepJson.setData(updateddataValue);
		teststepJson.setResult(updatedresultValue);
		teststepJson.setId(stepId);
	
		createteststepresponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = createteststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(createteststepresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}

	/*
	 * 7. delete test step after rearrange the step 8. delete test step when
	 * step contains only capital letter char 9. delete test step when step
	 * contains only small letter char
	 * 
	 * 11.delete test step when step contains only alphaNumeric char 12.delete
	 * test step when step contains all type of char with spaces between it.
	 * 13.delete test step when step contains wiki formatted text. (write test
	 * cases for all wiki fomat text)
	 * 
	 * 15.attempt to delete teststep when issueId and projectId is mismatched
	 * (pass valid id's , but mismatched) 16.attempt to delete teststep when
	 * issueId and stepId is mismatched (pass valid id's , but mismatched)
	 * 17.attempt to delete teststep when stepId and projectId is mismatched
	 * (pass valid id's , but mismatched) 18.attempt to delete test step by
	 * passing issueId of other issue type.
	 */

	// 7. delete test step after rearrange the step
	@Test(priority = 27, enabled = true)
	public void test27_delete_teststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueTypeTestId = Long.parseLong(Config.getValue("issueTypeTestId"));
		String issueKey = null;

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeTestId));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("id").toString();
		// System.out.println("this is the issue key "+ issueKey);
		issueId = Long.parseLong(issueKey);
		test.log(LogStatus.PASS, "Response validated successfully.");

		List<String> step = new ArrayList<>();
		step.add("step1");
		step.add("step2 &*()(*&^%$()+_)(*&^%$#@");
		step.add("step3");
		step.add("step4 tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		step.add("step5 Nuevo status de ejecución para coincidir con ejecuciones");

		List<String> stepData = new ArrayList<>();
		stepData.add("data1 hsgytd87yhjuy89iu");
		stepData.add("data2 +_)(*&^%$");
		stepData.add("data3");
		stepData.add("data4 tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepData.add("data5 Zugangserlaubnis zu Zephyr für Jira Cloud bezüglich HipChat gewährt.");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("~!@#$%");
		stepRes.add("Supprimer cette étape de statut d'exécution");
		stepRes.add("");
		stepRes.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepRes.add("result");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		System.out.println("Response:--> " + getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);

		JSONArray jsarray = new JSONArray(getResponse.getBody().asString());

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(0);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response moveTeststepresponse = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(moveTeststepresponse, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status1 = zapiService.validateMoveStep(srcStep, destStep, payLoad, moveTeststepresponse);
		Assert.assertTrue(status1);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		System.out.println(moveTeststepresponse.asString());
		String responseData = moveTeststepresponse.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);
		JSONObject json = new JSONObject(responseJson.get(1).toString());
			
		String stepId2= json.get("id").toString();
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepId2);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(moveTeststepresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = moveTeststepresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(moveTeststepresponse, projectId, issueId, stepId2);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
	}
	

	// 8. delete test step when step contains only capital letter char
	@Test(priority = 28, enabled = true)
	public void test28_delete_teststep_whensteps_contains_only_capitalLetter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "CAPITAL LETTER";
		String dataValue = "QWERT";
		String resultValue = "HELLO";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
	
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);
		
		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	

	// 9. delete test step when step contains only small letter char
	@Test(priority = 29, enabled = true)
	public void test29_delete_teststep_when_steps_contains_only_SmallLetter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "hello";
		String dataValue = "small letter";
		String resultValue = "byee";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
	
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);

		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	

	// 11.delete test step when step contains only alphaNumeric char
	@Test(priority = 30, enabled = true)
	public void test30_delete_teststep_when_steps_contains_only_alphaNumeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "alpha numeric 1234567890";
		String dataValue = "hello09876543";
		String resultValue = "BYE1234567890";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);

		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	

	// 12.delete test step when step contains all type of char with spaces
	// between it.

	@Test(priority = 31, enabled = true)
	public void test31_delete_teststep_when_steps_contains_allTypeOf_char() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		//Step values
		String stepValue = "hello ALL CHAR WITH NUMBER and special char ~!@#$%^&*() 1234567890";
		String dataValue = "русский (Россия)español";
		String resultValue = "русский (Россия)español";
		
		Teststep teststepJson = new Teststep();		
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);
		Response createteststepresponse=null;
			createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createteststepresponse.getBody().asString());
			System.out.println("payload-->"+ teststepJson.toString());
		boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
		Assert.assertTrue(Createteststepstatus);
		
		String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
		System.out.println("Step id "+ stepid);	
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
		System.out.println(payLoad);

		Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid);
		System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
		Assert.assertNotNull(Createtestresponse, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = Createtestresponse.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(Createtestresponse, projectId, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
		
	}
	
	// 15.attempt to delete teststep when issueId and projectId is mismatched
	// (pass valid id's , but mismatched)
	@Test(priority = 32, enabled = true)
	public void test32_Attempt_to_delete_teststep_when_issueIdAndProjectId_mismatched(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");

			Long ProjectID = Long.parseLong(Config.getValue("projectId"));

			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
			issuePayLoad.setSummary(
					" Attempt to delete a test step by passing stepId and projectId is mismatched");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));    
			//issuePayLoad.setReporter("admin");
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			// System.err.println(response.getBody().asString());

			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
			boolean status = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			issueKey = new JSONObject(response.body().asString()).get("key").toString();
			String issue = new JSONObject(response.body().asString()).get("id").toString();
			System.err.println(issue);

			Long issueId = Long.parseLong(issue);
			Teststep TeststepJson = new Teststep();
			TeststepJson.setProjectId(ProjectID);
			// TeststepJson.setIssueId(issueId);
			TeststepJson.setStep("steps");
			TeststepJson.setData("datas");
			TeststepJson.setResult("results");

			response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
			System.err.println("Step Api Response" + response.getBody().asString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			// System.out.println(response.getBody().asString());
			String stepid = new JSONObject(response.body().asString()).get("id").toString();
			status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");

			// String projectId = "10000";
			// String issueId = "10000";
			// String stepId = "0001478812190393-242ac1131-0001";
			// ProjectID=null;
			//stepid = "123"; 
			ProjectID = 10000l;
			issueId = 10001l;  
			response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
			System.err.println("Delete test step Response" + response.getBody().asString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");

			test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
			// System.out.println(response.getBody().asString());
			String S = response.getStatusLine();
			System.err.println(S);
			status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			System.out.println("bcoz of mismatch stepId and projectId test step not deleted-pass");
		}

	
	// 16.attempt to delete teststep when issueId and stepId is mismatched (pass
	// valid id's , but mismatched)
	@Test(priority = 33, enabled = true)
	public void test33_Attempt_to_delete_teststep_when_issueIdAndProjectId_mismatched() {
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");

			Long ProjectID = Long.parseLong(Config.getValue("projectId"));

			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
			issuePayLoad.setSummary(
					" Attempt to delete a test step by passing stepId and projectId is mismatched");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));    
			//issuePayLoad.setReporter("admin");
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			// System.err.println(response.getBody().asString());

			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
			boolean status = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			issueKey = new JSONObject(response.body().asString()).get("key").toString();
			String issue = new JSONObject(response.body().asString()).get("id").toString();
			System.err.println(issue);

			Long issueId = Long.parseLong(issue);
			Teststep TeststepJson = new Teststep();
			TeststepJson.setProjectId(ProjectID);
			// TeststepJson.setIssueId(issueId);
			TeststepJson.setStep("steps");
			TeststepJson.setData("datas");
			TeststepJson.setResult("results");

			response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
			System.err.println("Step Api Response" + response.getBody().asString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			// System.out.println(response.getBody().asString());
			String stepid = new JSONObject(response.body().asString()).get("id").toString();
			status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");

			// String projectId = "10000";
			// String issueId = "10000";
			// String stepId = "0001478812190393-242ac1131-0001";
			// ProjectID=null;
			stepid = "10000"; 
			//ProjectID = 10000l;
			issueId = 10001l;  
			response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
			System.err.println("Delete test step Response" + response.getBody().asString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");

			test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
			// System.out.println(response.getBody().asString());
			String S = response.getStatusLine();
			System.err.println(S);
			status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			System.out.println("bcoz of mismatch stepId and projectId test step not deleted-pass");
		}


	// 17.attempt to delete teststep when stepId and projectId is mismatched
	// (pass valid id's , but mismatched)
	@Test(priority = 34, enabled = true)
	public void test34_Attempt_to_delete_teststep_when_stepIdAndProjectId_mismatched() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary(
				" Attempt to delete a test step by passing stepId and projectId is mismatched");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));    
		//issuePayLoad.setReporter("admin");
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("steps");
		TeststepJson.setData("datas");
		TeststepJson.setResult("results");

		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		stepid = "14444"; 
		ProjectID = 10000l;
		//issueId = 10001l;  
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		System.out.println("bcoz of mismatch stepId and projectId test step not deleted-pass");
	}

	// 18.attempt to delete test step by passing issueId of other issue type.

	@Test(priority = 35, enabled = true)
	public void test35_Attempt_to_delete_teststep_when_issueId_of_otherIssueType() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("attempt to delete test step by passing issueId of other issue type.");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));    
		//issuePayLoad.setReporter("admin");
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);
		TeststepJson.setStep("steps");
		TeststepJson.setData("datas");
		TeststepJson.setResult("results");

		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		// String projectId = "10000";
		// String issueId = "10000";
		// String stepId = "0001478812190393-242ac1131-0001";
		// ProjectID=null;
		//stepid = "123"; 
		issueId = 10001l;  
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		System.out.println("bcoz of passing issueId of other issue type, test step not deleted- TC pass");
	}

	// 19.Delete all wiki formats text(add each and every test step manually )
	// provide all wiki format test step ids.

	@Test(priority = 36, enabled = true)
	public void test36_delete_teststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId)); 
		

		issuePayLoad.setSummary("Delete all wiki formats text test step");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));   
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		// System.err.println(response.getBody().asString());

		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();
		String issue = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println(issue);

		Long issueId = Long.parseLong(issue);
		Teststep TeststepJson = new Teststep();
		TeststepJson.setProjectId(ProjectID);
		// TeststepJson.setIssueId(issueId);

		TeststepJson.setStep("_emphasis_");
		TeststepJson.setData("*strong*");
		TeststepJson.setResult("_emphasis_");

		// implement create 10001 Test step code and delete the test Step by
		// passing one of the valid test stepid
		response = zapiService.createTeststep(jwtGenerator, ProjectID, issueId, TeststepJson.toString());
		System.err.println("Step Api Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String stepid = new JSONObject(response.body().asString()).get("id").toString();
		status = zapiService.validateTeststep(ProjectID, issueId, TeststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		response = zapiService.deleteTeststep(jwtGenerator, ProjectID, issueId, stepid);
		System.err.println("Delete test step Response" + response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println("passed-TestStep not deleted bcoz of wrong issueid");	

		test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
		// System.out.println(response.getBody().asString());
		String S = response.getStatusLine();
		System.err.println(S);
		status = zapiService.validateDeleteTeststep(response, ProjectID, issueId, stepid);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
	}
	



//2. delete test step after clone the step(should try for every type of
	// cloning the step).
	// need to add atleast 4 test cases for this as we have 4 types of cloning
	// methods are available.
	// before test step  similar as testcase20,  implement cloning steps in all position in this case, then deleted steps

@Test(priority = 37, enabled = true)
public void test22_delete_teststep() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	// creating issue - Test
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
	Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
	
	//Step values
	String stepValue = "!@#$%^&*()";
	String dataValue = "B";
	String resultValue = "C"; 		
	Teststep teststepJson = new Teststep();
	teststepJson.setStep(stepValue);
	teststepJson.setData(dataValue);
	teststepJson.setResult(resultValue);	
	Response createteststepresponse=null;
	
	for (int i = 0; i < 3; i++) {
		createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(createteststepresponse.getBody().asString());
		System.out.println("payload-->"+ teststepJson.toString());
	boolean Createteststepstatus = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), createteststepresponse);
	Assert.assertTrue(Createteststepstatus);
	 }
	
	String stepid= new JSONObject(createteststepresponse.body().asString()).get("id").toString();
	System.out.println("Step id "+ stepid);	
	String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
	System.out.println(payLoad);
	teststepJson.setStep("Clone"+stepValue);
	for (int i = -1; i < 2; i++) {
		
	//teststepJson.setClone_position_Id("-1");
		String s = Integer.toString(i);
	teststepJson.setClone_position_Id(s);

	
	}
	Response Cloneteststepresponse=null;
	for (int i = 0; i < 5; i++) {
 Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
	System.out.println(Cloneteststepresponse.getBody().asString());		
	
	boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, teststepJson.toString(), Cloneteststepresponse);
	Assert.assertTrue(Clonestatus);
	test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	System.out.println(Cloneteststepresponse.asString());
	String responseData = Cloneteststepresponse.getBody().asString();
	System.out.println(responseData);
	JSONArray responseJson = new JSONArray(responseData);
	JSONObject json = new JSONObject(responseJson.get(3).toString());

	String stepid2= json.get("id").toString();
	
	
	Response deleteTeststeppresponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepid2);
	System.err.println("Delete test step Response" + deleteTeststeppresponse.getBody().asString());
	Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");

	test.log(LogStatus.PASS, "Delete test step Api executed successfully.");
	// System.out.println(response.getBody().asString());
	String S = Cloneteststepresponse.getStatusLine();
	System.err.println(S);
	status = zapiService.validateDeleteTeststep(Cloneteststepresponse, projectId, issueId, stepid);
	Assert.assertTrue(status);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test); 
	
}
}