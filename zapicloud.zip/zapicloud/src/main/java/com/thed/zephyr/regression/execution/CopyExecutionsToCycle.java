/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.CopyMoveExecutions;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class CopyExecutionsToCycle extends BaseTest {

	JwtGenerator jwtGenerator = null;
	Long versionId = null;
	Long projectId = null;
	String cycleId = null;
	boolean clearDefectMappingFlag;
	boolean clearStatusFlag;
	private boolean clearAssignmentsFlag;
	private boolean clearCustomFieldsFlag;
	private String cycleName;
	private String folderName;
	private boolean clearDefectMappingFlag1;
	private boolean clearStatusFlag1;
	private Execution executionJson1;
	private String executionId;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//	Bulk copy test executions with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 1, enabled = testEnabled)
	public void test1_BulkCopyTestExecutionsWithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331535002-242ac1139-0001","0001479716399433-242ac111e-0001","0001479898038015-242ac1121-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
//cycleId ="0001478784170652-242ac1131-0001";
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for copy");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId( Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId( Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects
	//TODO
	@Test(priority = 2, enabled = testEnabled)
	public void test2_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefects(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry statuses
	//TODO
	@Test(priority = 3, enabled = testEnabled)
	public void test3_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStatuses(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried
	//TODO
	@Test(priority = 4, enabled = testEnabled)
	public void test4_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 5, enabled = testEnabled)
	public void test5_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId( versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 6, enabled = testEnabled)
	public void test6_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId( versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry stasuses from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 7,enabled = testEnabled)
	public void test7_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId( versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from Adhoc to new cycle in unscheduled version
	//TODO
	@Test(priority = 8, enabled = testEnabled)
	public void test8_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromAdhocToNewCycleInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId( versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 9, enabled = testEnabled)
	public void test9_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId ="-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 10, enabled = testEnabled)
	public void test10_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId ="-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry stasuses from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 11, enabled = testEnabled)
	public void test11_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId ="-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from Adhoc Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 12, enabled=testEnabled)
	public void test12_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromAdhocUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId ="-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 13, enabled = testEnabled)
	public void test13_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 14, enabled = testEnabled)
	public void test14_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry statuses from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 15, enabled = testEnabled)
	public void test15_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStatusesFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from new cycle Unscheduled to Adhoc Unscheduled version
	//TODO
	@Test(priority = 16, enabled = testEnabled)
	public void test16_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromNewCycleUnscheduledToAdhocUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 17, enabled = testEnabled)
	public void test17_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
		

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 18, enabled = testEnabled)
	public void test18_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry stasuses from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 19, enabled = testEnabled)
	public void test19_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from new cycle Unscheduled to Adhoc Scheduled version
	//TODO
	@Test(priority = 20, enabled = testEnabled)
	public void test20_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromNewCycleUnscheduledToAdhocScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(-1l);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(-1l);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 21, enabled = testEnabled)
	public void test21_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 22, enabled = testEnabled)
	public void test22_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry stasuses from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 23, enabled = testEnabled)
	public void test23_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from Adhoc Scheduled to new cycle Scheduled version
	//TODO
	@Test(priority = 24, enabled = testEnabled)
	public void test24_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromAdhocScheduledToNewCycleScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copy execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(versionId);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId("-1");
					   executionJson1.setVersionId(versionId);
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from one cycle scheduled version to another cycle to other version
	//TODO
	@Test(priority = 25, enabled = testEnabled)
	public void test25_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromOneCycleScheduledVersionToAnotherCycleToOtherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from one cycle scheduled version to another version
	//TODO
	@Test(priority = 26, enabled = testEnabled)
	public void test26_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromOneCycleScheduledVersionToAnotherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry stasuses from one cycle scheduled version to another version
	//TODO
	@Test(priority = 27, enabled = testEnabled)
	public void test27_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromOneCycleScheduledVersionToAnotherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from one cycle scheduled version to another cycle to other version
	//TODO
	@Test(priority = 28, enabled = testEnabled)
	public void test28_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromOneCycleScheduledVersionToAnotherCycleToOtherVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 29, enabled = testEnabled)
	public void test29_BulkCopyTestExecutionsWithDefectsAndStatusCarriedFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing statuses and carry defects from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 30, enabled = testEnabled)
	public void test30_BulkCopyTestExecutionsToADifferentCycleByClearingStatusesAndCarryDefectsFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions to a different Cycle - by clearing defects and carry stasuses from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 31, enabled = testEnabled)
	public void test31_BulkCopyTestExecutionsToADifferentCycleByClearingDefectsAndCarryStasusesFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried from cycle to cycle in Scheduled version
	//TODO
	@Test(priority = 32, enabled = testEnabled)
	public void test32_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedFromCycleToCycleInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for copy");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating cycle to move
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(projectId);
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Copied execution to cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating cycle
				Cycle cycleJson1 = new Cycle();
				cycleJson1.setProjectId(projectId);
				cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				cycleJson1.setName("Copy execution to cycle");
				cycleJson1.setDescription("Get execution by cycle");
				
				Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
				Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status11 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId1= new JSONObject(cycleResponse1.body().asString()).get("id").toString();
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId1);
			   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				
				//creating execution2
						Execution executionJson1 = new Execution();
						executionJson1.setStatusId(-1l);
						executionJson1.setProjectId(projectId);
						executionJson1.setIssueId(issueId1);
						executionJson1.setCycleId(cycleId1);
					   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
						Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
						Assert.assertNotNull(response21, "Create Execution Api Response is null.");
						System.out.println("Execution"+response21.getBody().asString());
						JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
						System.out.println(jsonResponse1.toString());
						System.out.println(jsonResponse1.get("execution").toString());
						String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
						System.out.println("executionid2: "+executionId1+"");
						
		      //create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds1 = new ArrayList<>() ;
				/*JSONArray jsarray21 = new JSONArray(response21.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
					//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds1.add(executionId);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		        
				String[] executions = {executionId,executionId1};
	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status carried in Unscheduled version, then Bulk copy back to previous cycle with both defects and status not carried
	//TODO
	@Test(priority = 33, enabled = testEnabled)
	public void test33_BulkCopyTestExecutionsWithDefectsAndStatusCarriedInUnscheduledVersionThenBulkCopyBackToPreviousCycleWithBothDefectsAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
				projectId = Long.parseLong(Config.getValue("projectId"));
				versionId = Long.parseLong(Config.getValue("versionTwoId"));
				//cycleId = "-1";
				clearDefectMappingFlag1 = true;
				clearStatusFlag1 = true;
				clearAssignmentsFlag= false;
				clearCustomFieldsFlag= false;
				cycleName="";
				folderName="";
				
				Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
				System.out.println("jobProgressId : "+response11.getBody().asString());
				response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
				Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
				test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
				boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects and status not carried in Unscheduled version, then Bulk copy back to previous cycle with defects not carried and status carried
	//TODO
	@Test(priority = 34, enabled = testEnabled)
	public void test34_BulkCopyTestExecutionsWithDefectsAndStatusNotCarriedInUnscheduledVersionThenBulkCopyBackToPreviousCycleWithDefectsNotCarriedAndStatusCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
				projectId = Long.parseLong(Config.getValue("projectId"));
				versionId = Long.parseLong(Config.getValue("versionTwoId"));
				//cycleId = "-1";
				clearDefectMappingFlag1 = true;
				clearStatusFlag1 = false;
				clearAssignmentsFlag= false;
				clearCustomFieldsFlag= false;
				cycleName="";
				folderName="";
				
				Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
				System.out.println("jobProgressId : "+response11.getBody().asString());
				response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
				Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
				test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
				boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
	}

	//	Bulk copy test executions with defects not carried and status carried in Unscheduled version, then Bulk copy back to previous cycle with defects carried and status not carried
	//TODO
	@Test(priority = 35, enabled = testEnabled)
	public void test35_BulkCopyTestExecutionsWithDefectsNotCarriedAndStatusCarriedInUnscheduledVersionThenBulkCopyBackToPreviousCycleWithDefectsCarriedAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
    	projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
				projectId = Long.parseLong(Config.getValue("projectId"));
				versionId = Long.parseLong(Config.getValue("versionTwoId"));
				//cycleId = "-1";
				clearDefectMappingFlag1 = false;
				clearStatusFlag1 = true;
				clearAssignmentsFlag= false;
				clearCustomFieldsFlag= false;
				cycleName="";
				folderName="";
				
				Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
				System.out.println("jobProgressId : "+response11.getBody().asString());
				response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
				Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
				test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
				boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
	}

	//	Bulk copy test executions with both defects and status not carried in Unscheduled version, then Bulk copy back to previous cycle with defects carried and status not carried
	//TODO
	@Test(priority = 36, enabled = testEnabled)
	public void test36_BulkCopyTestExecutionsWithBothDefectsAndStatusNotCarriedInUnscheduledVersionThenBulkCopyBackToPreviousCycleWithDefectsCarriedAndStatusNotCarried(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		
    	projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//move back to cycle
				projectId = Long.parseLong(Config.getValue("projectId"));
				versionId = Long.parseLong(Config.getValue("versionTwoId"));
				//cycleId = "-1";
				clearDefectMappingFlag1 = false;
				clearStatusFlag1 = true;
				clearAssignmentsFlag= false;
				clearCustomFieldsFlag= false;
				cycleName="";
				folderName="";
				
				Response response11 = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId1, payload.toString());
				System.out.println("jobProgressId : "+response11.getBody().asString());
				response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
				Assert.assertNotNull(response11, "MoveExecutionsToCycle Api Response is null.");
				test.log(LogStatus.PASS, "MoveExecutionsToCycle Api executed successfully.");
				boolean status11 = zapiService.validateMoveExecutionsToCycle(response11);
				Assert.assertTrue(status11, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
	}

	//	Attempt to bulk copy by providing the wrong project id
	//TODO
	@Test(priority = 37, enabled = testEnabled)
	public void test37_AttemptToBulkCopyByProvidingTheWrongProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = 987654l;
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyExecutionsToCycleWithInvalidProjectId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk copy by not providing the project id
	//TODO
	@Test(priority = 38, enabled = testEnabled)
	public void test38_AttemptToBulkCopyByNotProvidingTheProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
//payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyExecutionsToCycleWithInvalidProjectId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk copy by providing the wrong version id
	//TODO
	@Test(priority = 39, enabled = testEnabled)
	public void test39_AttemptToBulkCopyByProvidingTheWrongVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = 987654321l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk move to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyExecutionsToCycleWithInvalidVersionId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk copy by not providing version id
	//TODO
	@Test(priority = 40, enabled = testEnabled)
	public void test40_AttemptToBulkCopyByNotProvidingVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
//payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyExecutionsToCycleWithInvalidVersionId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to bulk copy by not providing the Issuetype id
	//	Attempt to bulk copy by not providing the defect id

	//	Attempt to Bulk copy by providing wrong cycle id
	//TODO
	@Test(priority = 43, enabled = testEnabled)
	public void test43_AttemptToBulkCopyByProvidingWrongCycleId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		cycleId = "987654321";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyExecutionsToCycleWithInvalidCycleId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to Bulk copy by providing blank cycle id
	//TODO
	@Test(priority = 44, enabled = testEnabled)
	public void test44_AttemptToBulkCopyByProvidingBlankCycleId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyExecutionsToCycleWithInvalidCycleId(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Attempt to Bulk copy by not providing execution ids
	//TODO
	@Test(priority = 45, enabled = testEnabled)
	public void test45_AttemptToBulkCopyByNotProvidingExecutionIds(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test for move");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				Long issueId1= issueIds.get(1);
				
				//creating execution1
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(projectId);
				executionJson.setIssueId(issueId);
				executionJson.setCycleId("-1");
			   executionJson.setVersionId(-1l);
				Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				System.out.println("Execution"+response2.getBody().asString());
				JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
				System.out.println(jsonResponse.toString());
				System.out.println(jsonResponse.get("execution").toString());
				String executionId= jsonResponse.getJSONObject("execution").getString("id");
				System.out.println("executionid1: "+executionId+"");
				

		CopyMoveExecutions payload = new CopyMoveExecutions();
		//payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyInvalidExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	//	Attempt to Bulk copy by providing wrong execution ids bug id= ZFJCLOUD-4931
	//TODO
	@Test(priority = 46, enabled = testEnabled)
	public void test46_AttemptToBulkCopyByProvidingWrongExecutionIds(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] executions = {"12345","67890"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId ="0001478783642660-242ac1131-0001";
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;

		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCopyInvalidExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	// Bulk copy by not providing clearDefectMappingFlag flag
	//TODO
	@Test(priority = 47, enabled = testEnabled)
	public void test47_BulkCopyByNotProvidingClearDefectmappingflagFlag(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
//payload.setClearDefectMappingFlag(clearDefectMappingFlag);
payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	// Bulk copy by not providing clearStatusFlag flag
	//TODO
	@Test(priority = 48, enabled = testEnabled)
	public void test48_BulkCopyByNotProvidingClearStatusFlag(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test for move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(-1l);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId("-1");
			   executionJson1.setVersionId(-1l);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
CopyMoveExecutions payload = new CopyMoveExecutions();
payload.setExecutions(executions);
payload.setProjectId(projectId);
payload.setVersionId(versionId);
payload.setClearDefectMappingFlag(clearDefectMappingFlag);
 //payload.setClearStatusFlag(clearStatusFlag);
System.err.println("status");
System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with different tests with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 49, enabled = testEnabled)
	public void test49_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithDifferentTestsWithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with different tests with defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 50, enabled = testEnabled)
	public void test50_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithDifferentTestsWithDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with different tests defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 51, enabled = testEnabled)
	public void test51_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithDifferentTestsDefectsNotCarriedAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with different tests with both defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 52, enabled = testEnabled)
	public void test52_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithDifferentTestsWithBothDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with some same tests with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 53, enabled = testEnabled)
	public void test53_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithSomeSameTestsWithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with some same tests with defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 54, enabled = testEnabled)
	public void test54_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithSomeSameTestsWithDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with some same tests defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 55, enabled = testEnabled)
	public void test55_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithSomeSameTestsDefectsNotCarriedAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle to 1 cycle with some same tests with both defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 56, enabled = testEnabled)
	public void test56_BulkCopyTestExecutionsFromMultipleCycleTo1CycleWithSomeSameTestsWithBothDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId2);
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle with different tests with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 57, enabled = testEnabled)
	public void test57_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithDifferentTestsWithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId1);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle.with different tests with defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 58, enabled = testEnabled)
	public void test58_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithDifferentTestsWithDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId1);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle with different tests with defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 59, enabled = testEnabled)
	public void test59_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithDifferentTestsWithDefectsNotCarriedAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId1);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle with different tests both defects and status not carried in Unscheduled version
	//TODO  
	@Test(priority = 60,  enabled = testEnabled)
	public void test60_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithDifferentTestsBothDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId1);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle with some same tests with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 61, enabled = testEnabled)
	public void test61_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithSomeSameTestsWithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle.with some same tests with defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 62, enabled = testEnabled)
	public void test62_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithSomeSameTestsWithDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle with some same tests with defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 63, enabled = testEnabled)
	public void test63_Bulkcopytestexecutionsfrommultiplecycleincludingadhocto1Cyclewithsomesametestswithdefectsnotcarriedandstatuscarriedinunscheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk Copy test executions with 500 tests with defects and status carried in Unscheduled version
	//TODO
	//Making false for large executions
	@Test(priority = 64,enabled = false)
	public void test64_BulkCopyTestExecutionsWith500TestsWithDefectsAndStatusCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response1 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response1.getBody().asString());
		response1 = zapiService.jobProgressHandler(jwtGenerator, response1.getBody().asString());
		Assert.assertNotNull(response1, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}

	//	Bulk copy test executions from multiple cycle including adhoc to 1 cycle with some same tests both defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 65, enabled = testEnabled)
	public void test65_BulkCopyTestExecutionsFromMultipleCycleIncludingAdhocTo1CycleWithSomeSameTestsBothDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to move");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson1.setName("Move execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
	   executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk Copy test executions with 500 tests with defects and status not carried in Unscheduled version
	//TODO
	//Making false  for large execution
	@Test(priority = 66, enabled = false)
	public void test66_BulkCopyTestExecutionsWith500TestsWithDefectsAndStatusNotCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);


		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}

	//	Bulk Copy test executions with 500 tests with defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 67, enabled = false)
	public void test67_BulkCopyTestExecutionsWith500TestsWithDefectsNotCarriedAndStatusCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}

	//	Bulk Copy test executions with 500 tests with both defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 68,enabled=false)
	public void test68_BulkCopyTestExecutionsWith500TestsWithBothDefectsAndStatusNotCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}

	//	Attempt to Bulk Copy test executions with more than 500 tests with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 69,enabled=false)
	public void test69_AttemptToBulkCopyTestExecutionsWithMoreThan500TestsWithDefectsAndStatusCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//	String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	//	Attempt to Bulk Copy test executions with more than 500 tests with defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 70,enabled=false)
	public void test70_AttemptToBulkCopyTestExecutionsWithMoreThan500TestsWithDefectsAndStatusNotCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
				boolean status = zapiService.validateCopyInvalidExecutionsToCycle(response);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
	}
	}
	//	Attempt to Bulk Copy test executions with more than 500 tests with defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 71,enabled=false)
	public void test71_AttemptToBulkCopyTestExecutionsWithMoreThan500TestsWithDefectsNotCarriedAndStatusCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateCopyInvalidExecutionsToCycle(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				}
	}

	//	Attempt to Bulk Copy test executions with more than 500 tests with both defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 72,enabled=false)
	public void test72_AttemptToBulkCopyTestExecutionsWithMoreThan500TestsWithBothDefectsAndStatusNotCarriedInUnscheduledVersion() throws InterruptedException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to move";
		folderName="";
//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test move");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		
		// Creating defect
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("User defined Summary " + System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				List<String> response2 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 50);
				Thread.sleep(200);
				Assert.assertNotNull(response2, "Create Issue Api Response is null.");
				List<Long> defectsList = CommonUtils.getListAsLong(response2, "id");
//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		executionJson.setCycleId("-1");
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		
		Thread.sleep(2000);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
	    // String executionId= executionJson.getJSONObject("execution").getString("id");
	      
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
		}
		System.out.println("exeIDs are ------>"+exeIds);
//update
		
			List<String> exeIds1 = new ArrayList<>() ;
				JSONArray jsarray21 = new JSONArray(response2.toString());
				System.out.println("length="+jsarray21.length());
				for (int j=0;j<jsarray21.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					//exeIds1.add(exeIds);
					//Long issueId = issueIds.get(j);
					executionJson1.setIssueId(issueId);
					executionJson1.setDefects(defectsList);
					executionJson1.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson1.setStatusId(2l);
					executionJson1.setExecutionId(executionId);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
							executionJson1.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
		//String[] array = (String[]) exeIds.toArray();
		
		String[] executions = {"exeIds"};
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateCopyInvalidExecutionsToCycle(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
				}
	}

	//	Bulk copy test executions from cycle 1 to cycle 2, then bulk copy from cycle 2 to cycle 3 with defects and status carried in Unscheduled version
	//TODO
	@Test(priority = 73, enabled=testEnabled)
	public void test73_BulkCopyTestExecutionsFromCycle1ToCycle2ThenBulkCopyFromCycle2ToCycle3WithDefectsAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = false;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to copy";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to move
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to copy");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Copy execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//copy to 3rd cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		//versionId = Long.parseLong(Config.getValue("versionTwoId"));
		clearDefectMappingFlag1 = false;
		clearStatusFlag1 = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		//copy to 3rd cycle
		
		Response response11 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId2, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status111 = zapiService.validateCopyExecutionsToCycle(response11);
		Assert.assertTrue(status111, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from cycle 1 to cycle 2, then bulk copy from cycle 2 to cycle 3 with defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 74,  enabled = testEnabled)
	public void test74_BulkCopyTestExecutionsFromCycle1ToCycle2ThenBulkCopyFromCycle2ToCycle3WithDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to copy";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to copy
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to copy");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("Copy execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
       	String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//copy to 3rd cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		//versionId = Long.parseLong(Config.getValue(""));
		clearDefectMappingFlag1 = true;
		clearStatusFlag1 = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//copy to 3rd cycle
		Response response11 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId2, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status111 = zapiService.validateCopyExecutionsToCycle(response11);
		Assert.assertTrue(status111, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from cycle 1 to cycle 2, then bulk copy from cycle 2 to cycle 3 with defects not carried and status carried in Unscheduled version
	//TODO
	@Test(priority = 75, enabled = testEnabled)
	public void test75_BulkCopyTestExecutionsFromCycle1ToCycle2ThenBulkCopyFromCycle2ToCycle3WithDefectsNotCarriedAndStatusCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//String[] executions = {"0001479331595772-242ac1139-0001"};
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to copy";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to copy
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to copy");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("copy execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//copy to 3rd cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		//versionId = Long.parseLong(Config.getValue(""));
		clearDefectMappingFlag1 = true;
		clearStatusFlag1 = false;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//copy to 3rd cycle
		Response response11 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId2, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status111 = zapiService.validateCopyExecutionsToCycle(response11);
		Assert.assertTrue(status111, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//	Bulk copy test executions from cycle 1 to cycle 2, then bulk copy from cycle 2 to cycle 3 with both defects and status not carried in Unscheduled version
	//TODO
	@Test(priority = 76, enabled = testEnabled)
	public void test76_BulkCopyTestExecutionsFromCycle1ToCycle2ThenBulkCopyFromCycle2ToCycle3WithBothDefectsAndStatusNotCarriedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		clearDefectMappingFlag = true;
		clearStatusFlag = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="cycle to copy";
		folderName="";

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		
		//creating cycle to copy
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle to copy");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId1 = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating cycle
		Cycle cycleJson1 = new Cycle();
		cycleJson1.setProjectId(projectId);
		cycleJson1.setVersionId(versionId);
		cycleJson1.setName("copy execution cycle");
		cycleJson1.setDescription("Get execution by cycle");
		
		Response cycleResponse1 = zapiService.createCycle(jwtGenerator, cycleJson1.toString());
		Assert.assertNotNull(cycleResponse1, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status2 = zapiService.validateCycle(cycleJson1.toString(), cycleResponse1);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(cycleResponse1.body().asString()).get("id").toString();
		
		//creating execution1
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleId1);
	   executionJson.setVersionId(versionId);
		Response response2 = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		System.out.println("Execution"+response2.getBody().asString());
		JSONObject jsonResponse = new JSONObject(response2.getBody().asString());
		System.out.println(jsonResponse.toString());
		System.out.println(jsonResponse.get("execution").toString());
		String executionId= jsonResponse.getJSONObject("execution").getString("id");
		System.out.println("executionid1: "+executionId+"");
		
		//creating execution2
				Execution executionJson1 = new Execution();
				executionJson1.setStatusId(-1l);
				executionJson1.setProjectId(projectId);
				executionJson1.setIssueId(issueId1);
				executionJson1.setCycleId(cycleId1);
			   executionJson1.setVersionId(versionId);
				Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
				Assert.assertNotNull(response21, "Create Execution Api Response is null.");
				System.out.println("Execution"+response21.getBody().asString());
				JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
				System.out.println(jsonResponse1.toString());
				System.out.println(jsonResponse1.get("execution").toString());
				String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
				System.out.println("executionid2: "+executionId1+"");
				
      //create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean issueStatus = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);	    

		//update 
		List<String> exeIds1 = new ArrayList<>() ;
		/*JSONArray jsarray21 = new JSONArray(response21.toString());
		System.out.println("length="+jsarray21.length());
		for (int j=0;j<jsarray21.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));*/
			//String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds1.add(executionId);
			//Long issueId = issueIds.get(j);
			executionJson1.setIssueId(issueId);
			executionJson1.setDefects(defectsList);
			executionJson1.setComment("Comment added to executions");
			System.out.println(issueId);
			executionJson1.setStatusId(2l);
			executionJson1.setExecutionId(executionId);
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
        
		String[] executions = {executionId,executionId1};	
		CopyMoveExecutions payload = new CopyMoveExecutions();
		payload.setExecutions(executions);
		payload.setProjectId(projectId);
		payload.setVersionId(versionId);
		payload.setClearDefectMappingFlag(clearDefectMappingFlag);
		payload.setClearStatusFlag(clearStatusFlag);
		System.err.println("status");
		System.err.println("payload of bulk copy to cycle"+payload);

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payload.toString());
		System.out.println("jobProgressId : "+response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		Assert.assertNotNull(response, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
		
		//copy to 3rd cycle
		projectId = Long.parseLong(Config.getValue("projectId"));
		//versionId = Long.parseLong(Config.getValue(""));
		clearDefectMappingFlag1 = true;
		clearStatusFlag1 = true;
		clearAssignmentsFlag= false;
		clearCustomFieldsFlag= false;
		cycleName="";
		folderName="";
		
		//copy to 3rd cycle
		Response response11 = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId2, payload.toString());
		System.out.println("jobProgressId : "+response11.getBody().asString());
		response11 = zapiService.jobProgressHandler(jwtGenerator, response11.getBody().asString());
		Assert.assertNotNull(response11, "CopyExecutionsToCycle Api Response is null.");
		test.log(LogStatus.PASS, "CopyExecutionsToCycle Api executed successfully.");
		boolean status111 = zapiService.validateCopyExecutionsToCycle(response11);
		Assert.assertTrue(status111, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

}
