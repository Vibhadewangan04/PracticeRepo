/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;

import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class getExecutionSummariesBySprintAndIssue extends BaseTest{
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	private JSONObject teststepObj;
	private Object response;
	Long Sprintid = null;
	String Sprintname=null;
	private String stepId;
	private String ex1;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
		 String projectId=Config.getValue("projectId");
	        Response s =jiraService.getProjectBoard(basicAuth, projectId);
	        System.out.println(s.getBody().asString());
	        JSONObject jsobj = new JSONObject(s.getBody().asString());
	        String views = jsobj.get("views").toString();
	        System.out.println(views);
	        JSONArray jsarray = new org.json.JSONArray(jsobj.get("views").toString());
	        Long Boardid = null;
	        for (int i = 0; i < jsarray.length(); i++) {        	
	        	
	        	//System.out.println(jsarray.get(i));
	        	JSONObject ns = new JSONObject(jsarray.get(i).toString());
	        	String parentProjectId=ns.get("parentProjectId").toString();
	        
	        	if(projectId.equals(parentProjectId))
	        	{
	        		Boardid=Long.parseLong(ns.get("id").toString());
	        	}
			}
	        System.out.println(Boardid);
	        //create sprint
	         Sprintname="Sprint"+System.currentTimeMillis();
	        String CreateSprintpayload="{\"name\": \""+Sprintname+"\",\"originBoardId\":"+Boardid+"}";
	        Response sprintresponse =jiraService.createSprint(basicAuth, CreateSprintpayload);
	        System.out.println(sprintresponse.getBody().asString());
	        JSONObject sprint=new JSONObject(sprintresponse.getBody().asString());
	         Sprintid =sprint.getLong("id");
	        System.out.println("Sprintid"+Sprintid);
	}

	//Attempt to getExecutionSummaryBySprint  without browse permission
	//Attempt to getExecutionSummaryBySprint and issue id with invalid credentials

	//Attempt to getExecutionSummaryBySprint if sprint is empty
	@Test(priority = 1,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
		//String issueIdorKeys = Config.getValue("issueIdOrKeys");
		Long sprintId1 =  null;
		//create bug
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId1"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad.setSummary("bug");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
			Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(createIssueResponse);
			for(int i= 0;i<jsarray.length();i++){
		        JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			Long issueId = issueIds.get(0);
			System.out.println(issueId);
			//convert long to string
		    String issue1=	Long.toString(issueId);
		    //create test
		    Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId1"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad1.setSummary("test");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
			Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
		
			List<Long> issueIds1 = new ArrayList<>() ;
			JSONArray jsarray1 = new JSONArray(createIssueResponse1);
			for(int i= 0;i<jsarray1.length();i++){
		        JSONObject jsobj = new JSONObject(jsarray1.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds1.add(l);
			}
			System.out.println("*****"+issueIds1);
			Long issueId2 = issueIds1.get(0);
			System.out.println(issueId2);
			//convert long to string
		    String issue2=	Long.toString(issueId2);
			    
			    //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());
            JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create execution successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId1, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetinvalidExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getExecutionSummaryBySprint invalid sprint id 
	@Test(priority = 2,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		//String issueIdorKeys = Config.getValue("issueIdOrKeys");
		Long sprintId = 10l;
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	        JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	    List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	        JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	    //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());
            JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionSummaryBySprint using valid issueId and sprintId is initailized to null
	@Test(priority = 3,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		//String issueIdorKeys = Config.getValue("issueIdOrKeys");
		Long sprintId = null;
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	        JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	    List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	        JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	    //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());
            JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create  executions successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetinvalidExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionSummaryBySprint using sprintId =0
	@Test(priority = 4,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		//String issueIdorKeys = Config.getValue("issueIdOrKeys");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		Long sprintId = 0l;
		//create bug
	Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(Config.getValue("projectId1"));
	issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
	issuePayLoad.setSummary("bug");
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter(Config.getValue("adminUserName"));
	List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
	Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	List<Long> issueIds = new ArrayList<>() ;
	JSONArray jsarray = new JSONArray(createIssueResponse);
	for(int i= 0;i<jsarray.length();i++){
        JSONObject jsobj = new JSONObject(jsarray.getString(i));
		Long l= Long.parseLong(jsobj.get("id").toString());
		issueIds.add(l);
	}
	System.out.println("*****"+issueIds);
	Long issueId = issueIds.get(0);
	System.out.println(issueId);
	//convert long to string
    String issue1=	Long.toString(issueId);
    
    //create test
    Issue issuePayLoad1 = new Issue();
	issuePayLoad1.setProject(Config.getValue("projectId1"));
	issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
	issuePayLoad1.setSummary("test");
	issuePayLoad1.setPriority("1");
	issuePayLoad1.setReporter(Config.getValue("adminUserName"));
	List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
	Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
    List<Long> issueIds1 = new ArrayList<>() ;
	JSONArray jsarray1 = new JSONArray(createIssueResponse1);
	for(int i= 0;i<jsarray1.length();i++){
        JSONObject jsobj = new JSONObject(jsarray1.getString(i));
		Long l= Long.parseLong(jsobj.get("id").toString());
		issueIds1.add(l);
	}
	System.out.println("*****"+issueIds1);
	Long issueId2 = issueIds1.get(0);
	System.out.println(issueId2);
	//convert long to string
    String issue2=	Long.toString(issueId2);
    
    //create executions
  		Execution executionJson = new Execution();
  		executionJson.setStatusId(-1l);
  		executionJson.setProjectId(ProjectID);
  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
  		executionJson.setVersionId(-1l);
  		executionJson.setNoOfExecutions(1);
  		executionJson.setCycleId("-1");
  		System.out.println(executionJson.toString());
        JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
  		test.log(LogStatus.PASS,
  				"Create  executions successfully.");
  		
  		List<String> exeIds = new ArrayList<>() ;
  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
  		System.out.println("length="+jsarray2.length());
  		for (int j=0;j<jsarray2.length();j++){
  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
  			exeIds.add(exeid);
  			Long issueId11 = issueIds1.get(j);
  			executionJson.setIssueId(issueId11);
  			System.out.println(issueId11);
  			executionJson.setStatusId(2l);
  			//executionJson.setDefect(issueKey);
  			executionJson.setDefects(issueIds);
  			executionJson.setExecutionId(exeid);
  			//update executions
  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
  					executionJson.toString());
  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
  			System.out.println(updateExecutionResponse.getBody().asString());
  			System.out.println("updated execution");
  		}
  		 //add issue to sprint
       
          String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
          System.out.println(addissuesprintpayload);
          Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
          System.out.println(addsprintresponse.getBody().asString());
          System.out.println(addsprintresponse.getStatusCode());
			          
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionSummaryBySprint if its linked tests are deleted from cycle
	@Test(priority = 5,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
	    Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		//create bug
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId1"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad.setSummary("bug");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
			Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		    List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(createIssueResponse);
			for(int i= 0;i<jsarray.length();i++){
		        JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			Long issueId = issueIds.get(0);
			System.out.println(issueId);
			//convert long to string
		    String issue1=	Long.toString(issueId);
		 //create test
		    Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId1"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad1.setSummary("test");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
			Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
		
			List<Long> issueIds1 = new ArrayList<>() ;
			JSONArray jsarray1 = new JSONArray(createIssueResponse1);
			for(int i= 0;i<jsarray1.length();i++){
		        JSONObject jsobj = new JSONObject(jsarray1.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds1.add(l);
			}
			System.out.println("*****"+issueIds1);
			Long issueId2 = issueIds1.get(0);
			System.out.println(issueId2);
			//convert long to string
		    String issue2=	Long.toString(issueId2);
		    
		    //create executions
		  		Execution executionJson = new Execution();
		  		executionJson.setStatusId(-1l);
		  		executionJson.setProjectId(ProjectID);
		  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
		  		executionJson.setVersionId(-1l);
		  		executionJson.setNoOfExecutions(1);
		  		executionJson.setCycleId("-1");
		  		System.out.println(executionJson.toString());
               JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		  		test.log(LogStatus.PASS,
		  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		  		
		  		List<String> exeIds = new ArrayList<>() ;
		  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		  		System.out.println("length="+jsarray2.length());
		  		for (int j=0;j<jsarray2.length();j++){
		  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		  			
		  			System.out.println(issueKey);
		  			exeIds.add(exeid);
		  			Long issueId11 = issueIds1.get(j);
		  			executionJson.setIssueId(issueId11);
		  			System.out.println(issueId11);
		  			executionJson.setStatusId(2l);
		  			//executionJson.setDefect(issueKey);
		  			executionJson.setDefects(issueIds);
		  			executionJson.setExecutionId(exeid);
		  			
		  			//update executions
		  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
		  					executionJson.toString());
		  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		  			System.out.println(updateExecutionResponse.getBody().asString());
		  			System.out.println("updated execution");
		  		}
		  		String	ex1=exeIds.get(0).toString();
				System.err.println("executionid1:"+ex1);
				
			 //add issue to sprint
	        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
			
			//	IssueId to be deleted		
			response = zapiService.deleteExecution(jwtGenerator,issueId2, ex1);
			Assert.assertNotNull(response, "Delete Execution Api Response is null.");
			test.log(LogStatus.PASS, "Delete Execution Api executed successfully.");
			extentReport.endTest(test);
			System.out.println("IssueId deleted ");
			
			Response response1 = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
			Assert.assertNotNull(response1, "getExecutionSummariesBySprintAndIssue Api Response is null.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
			System.out.println(response1.getBody().asString());
	        test.log(LogStatus.PASS, "Response validated suuccessfully.");
	        
	        boolean status1 = zapiService.validategetExecutionSummariesBySprintAndIssue(response1);
			Assert.assertTrue(status1, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	
	//Attempt to getExecutionSummaryBySprint if the cycle of its linked test is deleted
	//@Test(priority = 6)(repeated of 5th case)
	public void getExecutionSummariesBySprintAndIssue6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		String issueIdorKeys = "10000";
		Long sprintId = 3l;
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId, issueIdorKeys);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionSummaryBySprint of  any issue type[Bug,Story,Task] if its linked tests are not scheduled using sprint and issue id
	@Test(priority = 7,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
	    Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	  //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	   List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);

	  //create executions
  		Execution executionJson = new Execution();
  		executionJson.setStatusId(-1l);
  		executionJson.setProjectId(ProjectID);
  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
  		executionJson.setVersionId(-1l);
  		executionJson.setNoOfExecutions(1);
  		executionJson.setCycleId("-1");
  		System.out.println(executionJson.toString());

  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
  		test.log(LogStatus.PASS,
  				"Create  executions  successfully.");
  		
  		List<String> exeIds = new ArrayList<>() ;
  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
  		System.out.println("length="+jsarray2.length());
  		for (int j=0;j<jsarray2.length();j++){
  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
  			
  			System.out.println(issueKey);
  			exeIds.add(exeid);
  			Long issueId11 = issueIds1.get(j);
  			executionJson.setIssueId(issueId11);
  			System.out.println(issueId11);
  			executionJson.setStatusId(2l);
  			//executionJson.setDefect(issueKey);
  			executionJson.setDefects(issueIds);
  			executionJson.setExecutionId(exeid);
  			
  			//update executions
  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
  					executionJson.toString());
  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
  			System.out.println(updateExecutionResponse.getBody().asString());
  			System.out.println("updated execution");
		
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	}
	//getExectionSummaryBySprint by passing only sprint id and issueId as null   -N/A
	//Attempt to getExecutionSummaryBySprint by passing sprint id and issue id if that issue is not in that sprint   -N/A

	//getExecutionSummaryBySprint of  any issue type[Bug,Story,Task]  by sprint id if its linked tests are executed and associated to defects at test level then view execution and defect count
	@Test(priority = 8,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
	    Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
	  //create bug
	  		Issue issuePayLoad = new Issue();
	  		issuePayLoad.setProject(Config.getValue("projectId1"));
	  		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
	  		issuePayLoad.setSummary("bug");
	  		issuePayLoad.setPriority("1");
	  		issuePayLoad.setReporter(Config.getValue("adminUserName"));
	  		
	  		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
	  		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	  	
	  		List<Long> issueIds = new ArrayList<>() ;
	  		JSONArray jsarray = new JSONArray(createIssueResponse);
	  		for(int i= 0;i<jsarray.length();i++){
	  	
	  			JSONObject jsobj = new JSONObject(jsarray.getString(i));
	  			Long l= Long.parseLong(jsobj.get("id").toString());
	  			issueIds.add(l);
	  		}
	  		System.out.println("*****"+issueIds);
	  		Long issueId = issueIds.get(0);
	  		System.out.println(issueId);
	  		//convert long to string
	  	    String issue1=	Long.toString(issueId);
	  	    
	  	    //create test
	  	    Issue issuePayLoad1 = new Issue();
	  		issuePayLoad1.setProject(Config.getValue("projectId1"));
	  		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
	  		issuePayLoad1.setSummary("test");
	  		issuePayLoad1.setPriority("1");
	  		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
	  		
	  		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
	  		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	  	
	  		List<Long> issueIds1 = new ArrayList<>() ;
	  		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
	  		for(int i= 0;i<jsarray1.length();i++){
	  	
	  			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
	  			Long l= Long.parseLong(jsobj.get("id").toString());
	  			issueIds1.add(l);
	  		}
	  		System.out.println("*****"+issueIds1);
	  		Long issueId2 = issueIds1.get(0);
	  		System.out.println(issueId2);
	  		//convert long to string
	  	    String issue2=	Long.toString(issueId2);
	  	    
	  	    //create executions
	  	  		Execution executionJson = new Execution();
	  	  		executionJson.setStatusId(-1l);
	  	  		executionJson.setProjectId(ProjectID);
	  	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  	  		executionJson.setVersionId(-1l);
	  	  		executionJson.setNoOfExecutions(1);
	  	  		executionJson.setCycleId("-1");
	  	  		System.out.println(executionJson.toString());

	  	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  	  		test.log(LogStatus.PASS,
	  	  				"Create executions  successfully.");
	  	  		
	  	  		List<String> exeIds = new ArrayList<>() ;
	  	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  	  		System.out.println("length="+jsarray2.length());
	  	  		for (int j=0;j<jsarray2.length();j++){
	  	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  	  			
	  	  			System.out.println(issueKey);
	  	  			exeIds.add(exeid);
	  	  			Long issueId11 = issueIds1.get(j);
	  	  			executionJson.setIssueId(issueId11);
	  	  			System.out.println(issueId11);
	  	  			executionJson.setStatusId(1l);
	  	  			//executionJson.setDefect(issueKey);
	  	  			executionJson.setDefects(issueIds);
	  	  			executionJson.setExecutionId(exeid);
	  	  			
	  	  			//update executions
	  	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  	  					executionJson.toString());
	  	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  	  			System.out.println(updateExecutionResponse.getBody().asString());
	  	  			System.out.println("updated execution");
	  	  		}
	  		
	  		 //add issue to sprint
	        //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
	          String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	          System.out.println(addissuesprintpayload);
	          Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	          System.out.println(addsprintresponse.getBody().asString());
	          System.out.println(addsprintresponse.getStatusCode());
	          
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint of multiple issue types[bug,story,task] by sprint id 
	@Test(priority = 9,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	    Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
	  //create bug
	  		Issue issuePayLoad = new Issue();
	  		issuePayLoad.setProject(Config.getValue("projectId1"));
	  		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
	  		issuePayLoad.setSummary("bug");
	  		issuePayLoad.setPriority("1");
	  		issuePayLoad.setReporter(Config.getValue("adminUserName"));
	  		
	  		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
	  		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	  	
	  		List<Long> issueIds = new ArrayList<>() ;
	  		JSONArray jsarray = new JSONArray(createIssueResponse);
	  		for(int i= 0;i<jsarray.length();i++){
	  	
	  			JSONObject jsobj = new JSONObject(jsarray.getString(i));
	  			Long l= Long.parseLong(jsobj.get("id").toString());
	  			issueIds.add(l);
	  		}
	  		System.out.println("*****"+issueIds);
	  		Long issueId = issueIds.get(0);
	  		System.out.println(issueId);
	  		//convert long to string
	  	    String issue1=	Long.toString(issueId);
	  	    
	  	//create task
	  		Issue issuePayLoad2 = new Issue();
	  		issuePayLoad2.setProject(Config.getValue("projectId1"));
	  		issuePayLoad2.setIssuetype(Config.getValue("issueTypeTaskId"));
	  		issuePayLoad2.setSummary("bug");
	  		issuePayLoad2.setPriority("1");
	  		issuePayLoad2.setReporter(Config.getValue("adminUserName"));
	  		
	  		List<String> createIssueResponse2 = jiraService.createIssues(basicAuth, issuePayLoad2.toString(), 1);
	  		Assert.assertNotNull(createIssueResponse2, "Create issues Api Response is null.");
	  	
	  		List<Long> issueIds2 = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(createIssueResponse2);
	  		for(int i= 0;i<jsarray2.length();i++){
	  	
	  			JSONObject jsobj = new JSONObject(jsarray2.getString(i));
	  			Long l= Long.parseLong(jsobj.get("id").toString());
	  			issueIds2.add(l);
	  		}
	  		System.out.println("*****"+issueIds2);
	  		Long issueId1 = issueIds2.get(0);
	  		System.out.println(issueId1);
	  		//convert long to string
	  	    String issue11=	Long.toString(issueId1);
	  	    
	  	    //create test
	  	    Issue issuePayLoad1 = new Issue();
	  		issuePayLoad1.setProject(Config.getValue("projectId1"));
	  		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
	  		issuePayLoad1.setSummary("test");
	  		issuePayLoad1.setPriority("1");
	  		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
	  		
	  		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
	  		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	  	
	  		List<Long> issueIds1 = new ArrayList<>() ;
	  		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
	  		for(int i= 0;i<jsarray1.length();i++){
	  	
	  			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
	  			Long l= Long.parseLong(jsobj.get("id").toString());
	  			issueIds1.add(l);
	  		}
	  		System.out.println("*****"+issueIds1);
	  		Long issueId2 = issueIds1.get(0);
	  		System.out.println(issueId2);
	  		//convert long to string
	  	    String issue2=	Long.toString(issueId2);
	  	    
	  	    Long issueId3 = issueIds1.get(0);
	  		System.out.println(issueId3);
	  		//convert long to string
	  	    String issue3=	Long.toString(issueId3);
	  	   
	  	  //create executions
	  	  		Execution executionJson = new Execution();
	  	  		executionJson.setStatusId(-1l);
	  	  		executionJson.setProjectId(ProjectID);
	  	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  	  		executionJson.setVersionId(-1l);
	  	  		executionJson.setNoOfExecutions(1);
	  	  		executionJson.setCycleId("-1");
	  	  		System.out.println(executionJson.toString());

	  	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  	  		test.log(LogStatus.PASS,
	  	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  	  		
	  	  		List<String> exeIds = new ArrayList<>() ;
	  	  		JSONArray jsarray21 = new JSONArray(executionResponse.toString());
	  	  		System.out.println("length="+jsarray21.length());
	  	  		for (int j=0;j<jsarray21.length();j++){
	  	  			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
	  	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  	  			exeIds.add(exeid);
	  	  			Long issueId11 = issueIds1.get(j);
	  	  			executionJson.setIssueId(issueId11);
	  	  			System.out.println(issueId11);
	  	  			executionJson.setStatusId(2l);
	  	  			//executionJson.setDefect(issueKey);
	  	  			executionJson.setDefects(issueIds);
	  	  			executionJson.setExecutionId(exeid);
	  	  			
	  	  			//update executions
	  	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  	  					executionJson.toString());
	  	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  	  			System.out.println(updateExecutionResponse.getBody().asString());
	  	  			System.out.println("updated execution");
	  	  		}
	  		
	  		 //add issue to sprint
	        //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
	          String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	          System.out.println(addissuesprintpayload);
	          Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	          System.out.println(addsprintresponse.getBody().asString());
	          System.out.println(addsprintresponse.getStatusCode());
	          
	          //add task to sprint
	          String addissuesprintpayload1= "{\"issues\":["+issue11+"]}";
	          System.out.println(addissuesprintpayload1);
	          Response addsprintresponse1 =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload1);
	          System.out.println(addsprintresponse1.getBody().asString());
	          System.out.println(addsprintresponse1.getStatusCode());
	          
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if issue is linked  to single scheduled test and view execution count using sprintId
	@Test(priority = 10,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
      //create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	  //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create  executions  successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		//add issue to sprint
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
        
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getExecutionSummaryBySprint if its linked tests are executed to PASS and not associated with any defects then view execution and defect count using sprintId
	@Test(priority = 11,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("bug");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				//convert long to string
			    String issue1=	Long.toString(issueId);
			    
			    //create test
			    Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId1"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
				Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
			
				List<Long> issueIds1 = new ArrayList<>() ;
				JSONArray jsarray1 = new JSONArray(createIssueResponse1);
				for(int i= 0;i<jsarray1.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray1.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds1.add(l);
				}
				System.out.println("*****"+issueIds1);
				Long issueId2 = issueIds1.get(0);
				System.out.println(issueId2);
				//convert long to string
			    String issue2=	Long.toString(issueId2);
			    
			   //create executions
			  		Execution executionJson = new Execution();
			  		executionJson.setStatusId(-1l);
			  		executionJson.setProjectId(ProjectID);
			  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
			  		executionJson.setVersionId(-1l);
			  		executionJson.setNoOfExecutions(1);
			  		executionJson.setCycleId("-1");
			  		System.out.println(executionJson.toString());

			  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			  		test.log(LogStatus.PASS,
			  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			  		
			  		List<String> exeIds = new ArrayList<>() ;
			  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			  		System.out.println("length="+jsarray2.length());
			  		for (int j=0;j<jsarray2.length();j++){
			  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			  			
			  			exeIds.add(exeid);
			  			Long issueId11 = issueIds1.get(j);
			  			executionJson.setIssueId(issueId11);
			  			System.out.println(issueId11);
			  			executionJson.setStatusId(1l);
			  			//executionJson.setDefects(issueIds);
			  			executionJson.setExecutionId(exeid);
			  			
			  			//update executions
			  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			  					executionJson.toString());
			  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			  			System.out.println(updateExecutionResponse.getBody().asString());
			  			System.out.println("updated execution");
			  		}
				
				 //add issue to sprint
		      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
		        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
		        System.out.println(addissuesprintpayload);
		        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
		        System.out.println(addsprintresponse.getBody().asString());
		        System.out.println(addsprintresponse.getStatusCode());
		        
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
}
	
	
	//getExeutionSummaryBySprint if its linked tests are executed to FAIL associated with single defect then view execution and defect count using sprint and issue id
	@Test(priority = 12,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	   //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
				
			 //add issue to sprint
	        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
		        
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if its linked tests are executed to WIP and  associated with multiple defects then view execution and defect count using sprint and issue id
	@Test(priority = 13,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
       //create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	   
	  //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			System.out.println(issueKey);
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(3l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		
		 //add issue to sprint
      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if its linked tests are executed to BLOCKED then view execution and defect count using sprint and issue id
	@Test(priority = 14,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	  //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			System.out.println(issueKey);
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(4l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
				
			 //add issue to sprint
	        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
		        
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if its linked tests are executed to "CUSTOM" status then view execution and defect count using sprint and issue id
	@Test(priority = 15,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	  //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			System.out.println(issueKey);
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(5l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
				
			 //add issue to sprint
	        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
		        
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if its linked tests are executed from one  status to another then view execution  count using sprint and issue id
	@Test(priority = 16,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId1"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("bug");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
				Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
			
				List<Long> issueIds1 = new ArrayList<>() ;
				JSONArray jsarray1 = new JSONArray(createIssueResponse1);
				for(int i= 0;i<jsarray1.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray1.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds1.add(l);
				}
				System.out.println("*****"+issueIds1);
				Long bugId = issueIds1.get(0);
				System.out.println(bugId);
				//convert long to string
			    String issue1=	Long.toString(bugId);
			    
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//Long issueId1= issueIds.get(1);
		
		//create executions
			Execution executionJson11 = new Execution();
			executionJson11.setStatusId(-1l);
			executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
			executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
			executionJson11.setVersionId(-1l);
			executionJson11.setNoOfExecutions(1);
			executionJson11.setCycleId("-1");

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			
		//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId11 = issueIds.get(j);
				executionJson11.setIssueId(issueId11);
				System.out.println(issueId11);
			//	executionJson11.setStatusId(1l);
				executionJson11.setDefects(issueIds1);
				executionJson11.setExecutionId(exeid);
				
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
			
			String	ex1=exeIds.get(0).toString();
			System.err.println("executionid1:"+ex1);
			
		String payLoad = "{\"executions\":[\""+ex1+"\"],\"status\":1,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
	    System.out.println(payLoad);
	    Response response2= zapiService.updateBulkStatus(jwtGenerator, payLoad);
	    Assert.assertNotNull(response2, "Bulk update Execution Api Response is null.");
	    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	    test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    extentReport.endTest(test);
	    
	    //revert back to unexecuted status
	    String payLoad1 = "{\"executions\":[\""+ex1+"\"],\"status\":2,\"clearDefectMapping\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
	    System.out.println(payLoad1);
	    Response response1 = zapiService.updateBulkStatus(jwtGenerator, payLoad1);
	    Assert.assertNotNull(response1, "Bulk update Execution Api Response is null.");
	    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	    System.out.println(response1.getBody().asString());
	   test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    extentReport.endTest(test);
	    
	    //add issue to sprint
	      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
	        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
	    
	    Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
		    
	}
	//getExecutionSummaryBySprint if its linked tests are executed and associated with multiple defects both in test & step level then view execution and defect count using sprint and issue id
	@Test(priority = 17,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		//create bug
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId1"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("bug");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 2);
				Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
			
				List<Long> issueIds1 = new ArrayList<>() ;
				JSONArray jsarray1 = new JSONArray(createIssueResponse1);
				for(int i= 0;i<jsarray1.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray1.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds1.add(l);
				}
				System.out.println("*****"+issueIds1);
				Long bugId = issueIds1.get(0);
				System.out.println(bugId);
				//convert long to string
			    String issue1=	Long.toString(bugId);
			    
		//create issues
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId1"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
			Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		    List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(createIssueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			Long issueId = issueIds.get(0);
			System.out.println(issueId);
			Long issueId1= issueIds.get(1);
					
			//create test steps
			Teststep teststepJson = new Teststep();
			teststepJson.setStep("step");
			teststepJson.setData("data");
			teststepJson.setResult("result");

    Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
		teststepJson.toString());
    Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
    test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
    System.out.println(createTeststepResponse.getBody().asString());

    boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
    Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
    test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");
    teststepObj = new JSONObject(createTeststepResponse.body().asString());
    Long issueId11 = teststepObj.getLong("issueId");
    String stepId = teststepObj.getString("id");

//1 executions
    Execution executionJson11 = new Execution();
    executionJson11.setStatusId(-1l);
    executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
    executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
    executionJson11.setVersionId(-1l);
    executionJson11.setNoOfExecutions(1);
    executionJson11.setCycleId("-1");
    JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
    Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
    
  
 //update execution
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId111 = issueIds.get(j);
		executionJson11.setIssueId(issueId111);
		System.out.println(issueId111);
		executionJson11.setStatusId(1l);
		executionJson11.setDefects(issueIds1);
		executionJson11.setExecutionId(exeid);
		//update executions
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
				executionJson11.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());
		System.out.println("updated execution");
	}					
			String	ex1=exeIds.get(0).toString();
		
		//execute test step
		Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
	    System.out.println(StepResultsresponse.getBody().asString());
		JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
		JSONArray value = js1.getJSONArray("stepResults");
		JSONObject stepResult = value.getJSONObject(0);
		String stepresultid = stepResult.get("id").toString();
		stepId= stepResult.get("stepId").toString();
		ex1 =stepResult.get("executionId").toString();
		issueId =Long.parseLong(stepResult.get("issueId").toString());
		System.err.println(stepresultid);
		String payLoad="{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +" ,\"defects\":["+ issueIds1 +"]}";
	  //  String payLoad = "{\"executionId\":\""+ex1+"\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 +"\",\"status\":{\"id\":\"1\"}}";
		System.err.println(payLoad);
        Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
		Assert.assertNotNull(response2, "Update step result Api Response is null.");
		test.log(LogStatus.PASS, "Update step result  Api executed successfully.");
		
		//add issue to sprint
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
		
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
        test.log(LogStatus.PASS, "Response validated suuccessfully.");
        
        boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	//getExecutionSummaryBySprint if associated defect of its linked tests are deleted at test level then view execution and defect count using sprint and issue id
	@Test(priority = 18,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
			Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId1"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad1.setSummary("bug");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 2);
			Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
		
			List<Long> issueIds1 = new ArrayList<>() ;
			JSONArray jsarray1 = new JSONArray(createIssueResponse1);
			for(int i= 0;i<jsarray1.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray1.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds1.add(l);
			}
			System.out.println("*****"+issueIds1);
			Long issueId1 = issueIds1.get(0);
			System.out.println(issueId1);
			//convert long to string
		    String issue1=	Long.toString(issueId1);
		    
		    Long issueId2 = issueIds1.get(0);
			System.out.println(issueId2);
			//convert long to string
		    String issue2=	Long.toString(issueId2);
			    
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue3=	Long.toString(issueId);
		
		
//create execution
		Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(ProjectID);
		executionJson1.setIssueId(issueId);
		executionJson1.setCycleId("-1");
	   executionJson1.setVersionId(-1l);
		Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		Assert.assertNotNull(response21, "Create Execution Api Response is null.");
		System.out.println("Execution"+response21.getBody().asString());
		JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
		System.out.println(jsonResponse1.toString());
		System.out.println(jsonResponse1.get("execution").toString());
		String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
		System.out.println("executionid: "+executionId1+"");
        
		List<String> exeIds = new ArrayList<>() ;
		System.out.println(issueKey);
		exeIds.add(executionId1);
		//Long issueId11 = issueIds.get(j);
		executionJson1.setIssueId(issueId);
		System.out.println(issueId);
		executionJson1.setStatusId(2l);
		executionJson1.setDefects(issueIds1);
		executionJson1.setExecutionId(executionId1);
			
			//update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId1,
					executionJson1.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
			
			//	IssueId to be deleted		
			response = jiraService.deleteIssue(basicAuth, issue2);
			Assert.assertNotNull(response, "delete test Api Response is null.");
			test.log(LogStatus.PASS, "delete test Api executed successfully.");
			extentReport.endTest(test);
			System.out.println("IssueId deleted ");
			
			 //add issue to sprint
		     String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
		     System.out.println(addissuesprintpayload);
		     Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
		     System.out.println(addsprintresponse.getBody().asString());
		     System.out.println(addsprintresponse.getStatusCode());
			
			Response response1 = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
			Assert.assertNotNull(response1, "getExecutionSummariesBySprintAndIssue Api Response is null.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
			System.out.println(response1.getBody().asString());
	        test.log(LogStatus.PASS, "Response validated suuccessfully.");
	        
	        boolean status1 = zapiService.validategetExecutionSummariesBySprintAndIssue(response1);
			Assert.assertTrue(status1, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
			extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if  more defects are associated to its linked tests at test level then view defect count using sprint and issue id
	@Test(priority = 19,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		
		//create bug
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("bug");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				//convert long to string
			    String issue1=	Long.toString(issueId);
			    Long issueId1=issueIds.get(1);
			    System.out.println(issueId1);
				//convert long to string
			    String issue2=	Long.toString(issueId1);
			    
			    //create test
			    Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId1"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad1.setSummary("test");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
				Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
			
				List<Long> issueIds1 = new ArrayList<>() ;
				JSONArray jsarray1 = new JSONArray(createIssueResponse1);
				for(int i= 0;i<jsarray1.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray1.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds1.add(l);
				}
				System.out.println("*****"+issueIds1);
				Long issueId2 = issueIds1.get(0);
				System.out.println(issueId2);
				//convert long to string
			    String issue3=	Long.toString(issueId2);
			   
			   //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			System.out.println(issueKey);
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
				
				 //add issue to sprint
	        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
		    
			Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
			Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
			System.out.println(response.getBody().asString());
		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    
		    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
			Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
			extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint if associated defects of its linked tests are resolved to "DONE" at test/step level then view open and total defect count 
	@Test(priority = 20,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	    List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	  //get transitions
        
	       Response getresponse=jiraService.getTransitions(basicAuth, issue1);
	       System.out.println(getresponse.getBody().asString()); 
	       JSONObject jsobj1 = new JSONObject(getresponse.getBody().asString());
	   
	       System.out.println(jsobj1.get("transitions").toString());
	       JSONArray js = new JSONArray(jsobj1.get("transitions").toString());
	       System.out.println("array" + js.getJSONObject(0));
	     //getting transition for done so passing index as 2,for To do =0,inprogress=1
	       JSONObject transition = new JSONObject(js.getJSONObject(2).toString());
	       System.out.println("transition: " + js.getJSONObject(0).toString());
	       String id=  transition.get("id").toString();
	       System.out.println(transition.get("id").toString());
	       System.out.println(getresponse.getStatusCode());
	       
	     //edit issue
	       String editissuepayload="{\"transition\":{\"id\":\""+id+"\"}}";
	       System.out.println(editissuepayload);
	       Response editresponse =jiraService.editissue(basicAuth, issue1, editissuepayload);
	       System.out.println(editresponse.getBody().asString());
	       System.out.println("edit issue res"+editresponse.getStatusCode());
	        
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("bug");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	    List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	  //create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

      Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, ProjectID, issueId2,
	   teststepJson.toString());
      Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
      test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
      System.out.println(createTeststepResponse.getBody().asString());

 //create execution
        Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(ProjectID);
		executionJson1.setIssueId(issueId2);
		executionJson1.setCycleId("-1");
	   executionJson1.setVersionId(-1l);
		Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		Assert.assertNotNull(response21, "Create Execution Api Response is null.");
		System.out.println("Execution"+response21.getBody().asString());
		JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
		System.out.println(jsonResponse1.toString());
	
		String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
		System.out.println("executionid: "+executionId1+"");
        
		List<String> exeIds = new ArrayList<>() ;
		System.out.println(issueKey);
		exeIds.add(executionId1);
		//Long issueId11 = issueIds.get(j);
		executionJson1.setIssueId(issueId2);
		executionJson1.setStatusId(2l);
		//executionJson.setDefect(issueKey);
		executionJson1.setDefects(issueIds);
		executionJson1.setExecutionId(executionId1);
			
		//update executions
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId1,
				executionJson1.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());
		System.out.println("updated execution");
	
	//execute test step
		Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId2, executionId1);
	    System.out.println(StepResultsresponse.getBody().asString());
		JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
		JSONArray value = js1.getJSONArray("stepResults");
		JSONObject stepResult = value.getJSONObject(0);
		String stepresultid = stepResult.get("id").toString();
		stepId= stepResult.get("stepId").toString();
		ex1 =stepResult.get("executionId").toString();
		issueId =Long.parseLong(stepResult.get("issueId").toString());
		System.err.println(stepresultid);
		String payLoad="{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +" ,\"defects\":["+ issueIds +"]}";
	  //  String payLoad = "{\"executionId\":\""+ex1+"\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 +"\",\"status\":{\"id\":\"1\"}}";
		System.err.println(payLoad);
        Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
		Assert.assertNotNull(response2, "Update step result Api Response is null.");
		test.log(LogStatus.PASS, "Update step result  Api executed successfully.");
		
		 //add issue to sprint
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//getExecutionSummaryBySprint if few associated defects of its linked tests are resolved and few are unresolved at test/step level then view open and total defect count 
	@Test(priority = 21,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	    List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	  //get transitions
        
	       Response getresponse=jiraService.getTransitions(basicAuth, issue1);
	       System.out.println(getresponse.getBody().asString()); 
	       JSONObject jsobj1 = new JSONObject(getresponse.getBody().asString());
	       System.out.println(jsobj1.get("transitions").toString());
	       
	       JSONArray js = new JSONArray(jsobj1.get("transitions").toString());
	       System.out.println("array" + js.getJSONObject(0));
	     //getting transition for done so passing index as 2,for To do =0,inprogress=1
	       JSONObject transition = new JSONObject(js.getJSONObject(2).toString());
	       System.out.println("transition: " + js.getJSONObject(0).toString());
	       String id=  transition.get("id").toString();
	       System.out.println(transition.get("id").toString());
	       System.out.println(getresponse.getStatusCode());
	       
	     //edit issue
	       String editissuepayload="{\"transition\":{\"id\":\""+id+"\"}}";
	       System.out.println(editissuepayload);
	       Response editresponse =jiraService.editissue(basicAuth, issue1, editissuepayload);
	       System.out.println(editresponse.getBody().asString());
	       System.out.println("edit issue res"+editresponse.getStatusCode());
	        
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("bug");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	    List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	  //create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

      Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, ProjectID, issueId2,
	   teststepJson.toString());
      Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
      test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
      System.out.println(createTeststepResponse.getBody().asString());

 //create execution
        Execution executionJson1 = new Execution();
		executionJson1.setStatusId(-1l);
		executionJson1.setProjectId(ProjectID);
		executionJson1.setIssueId(issueId2);
		executionJson1.setCycleId("-1");
	   executionJson1.setVersionId(-1l);
		Response response21 = zapiService.createExecution(jwtGenerator, executionJson1.toString());
		Assert.assertNotNull(response21, "Create Execution Api Response is null.");
		System.out.println("Execution"+response21.getBody().asString());
		JSONObject jsonResponse1 = new JSONObject(response21.getBody().asString());
		System.out.println(jsonResponse1.toString());
	
		String executionId1= jsonResponse1.getJSONObject("execution").getString("id");
		System.out.println("executionid: "+executionId1+"");
        
		List<String> exeIds = new ArrayList<>() ;
		System.out.println(issueKey);
		exeIds.add(executionId1);
		//Long issueId11 = issueIds.get(j);
		executionJson1.setIssueId(issueId2);
		executionJson1.setStatusId(2l);
		//executionJson.setDefect(issueKey);
		executionJson1.setDefects(issueIds);
		executionJson1.setExecutionId(executionId1);
			
		//update executions
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId1,
				executionJson1.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());
		System.out.println("updated execution");
	
	//execute test step
		Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId2, executionId1);
	    System.out.println(StepResultsresponse.getBody().asString());
		JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
		JSONArray value = js1.getJSONArray("stepResults");
		JSONObject stepResult = value.getJSONObject(0);
		String stepresultid = stepResult.get("id").toString();
		stepId= stepResult.get("stepId").toString();
		ex1 =stepResult.get("executionId").toString();
		issueId =Long.parseLong(stepResult.get("issueId").toString());
		System.err.println(stepresultid);
		String payLoad="{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +" ,\"defects\":["+ issueIds +"]}";
	  //  String payLoad = "{\"executionId\":\""+ex1+"\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 +"\",\"status\":{\"id\":\"1\"}}";
		System.err.println(payLoad);
        Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
		Assert.assertNotNull(response2, "Update step result Api Response is null.");
		test.log(LogStatus.PASS, "Update step result  Api executed successfully.");
		
		 //add issue to sprint
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//getExecutionSummaryBySprint if more scheduled tests are linked to issue then view execution count 
	@Test(priority = 22,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
		
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 2);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	    Long issueId3 = issueIds1.get(0);
		System.out.println(issueId3);
		//convert long to string
	    String issue3=	Long.toString(issueId3);
	   
	  //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(2);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			System.out.println(issueKey);
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		
//add issue to sprint
    String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
    System.out.println(addissuesprintpayload);
    Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
    System.out.println(addsprintresponse.getBody().asString());
    System.out.println(addsprintresponse.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//getExecutionSummaryBySprint if tests are de-linked from issue then view execution count 
	@Test(priority = 23,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	     //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  			}
	  	//String	ex1=jsarray2.getString(0).toString();
			String	ex1=exeIds.get(0).toString();
			System.err.println("executionid1:"+ex1);
//			String ex2=jsarray2.getString(1).toString();
			//delinked issues
		String payLoad = "{\"executions\":[\""+ex1+"\"],\"status\":1,\"clearDefectMapping\":true,\"testStepStatusChangeFlag\":true,\"stepStatus\":-1}";
	    System.out.println(payLoad);
	    Response response2= zapiService.updateBulkStatus(jwtGenerator, payLoad);
	    Assert.assertNotNull(response2, "Bulk update Execution Api Response is null.");
	    test.log(LogStatus.PASS, "Bulk update status executed successfully.");
	    test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    extentReport.endTest(test);
		
		 //add issue to sprint
      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//getExecutionSummaryBySprint if sprint is active
	@Test(priority = 24,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	//create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create  executions  successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
  			System.out.println(issueKey);
  			exeIds.add(exeid);
  			Long issueId11 = issueIds1.get(j);
  			executionJson.setIssueId(issueId11);
  			System.out.println(issueId11);
  			executionJson.setStatusId(2l);
  			//executionJson.setDefect(issueKey);
  			executionJson.setDefects(issueIds);
  			executionJson.setExecutionId(exeid);
  			
  			//update executions
  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
  					executionJson.toString());
  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
  			System.out.println(updateExecutionResponse.getBody().asString());
  			System.out.println("updated execution");
  		}
	//make sprint active
  		
  		 String updatesprintpayload="{\"state\":\"active\",\"name\":\""+Sprintname+"\",\"startDate\":\"2015-04-11T15:22:00.000+10:00\",\"endDate\":\"2015-04-20T01:22:00.000+10:00\"}";
         System.out.println(updatesprintpayload);
         Response updatesprintresponse= jiraService.updatesprint(basicAuth, Sprintid, updatesprintpayload);
         System.out.println(updatesprintresponse.getBody().asString());
         System.out.println(updatesprintresponse.getStatusCode());
	         
		 //add issue to sprint
      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//getExecutionSummaryBySprint sprint is completed   
	@Test(priority = 25,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	//create executions
  		Execution executionJson = new Execution();
  		executionJson.setStatusId(-1l);
  		executionJson.setProjectId(ProjectID);
  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
  		executionJson.setVersionId(-1l);
  		executionJson.setNoOfExecutions(1);
  		executionJson.setCycleId("-1");
  		System.out.println(executionJson.toString());

  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
  		test.log(LogStatus.PASS,
  				"Create  executions  successfully.");
  		
  		List<String> exeIds = new ArrayList<>() ;
  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
  		System.out.println("length="+jsarray2.length());
  		for (int j=0;j<jsarray2.length();j++){
  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
  			
		System.out.println(issueKey);
		exeIds.add(exeid);
		Long issueId11 = issueIds1.get(j);
		executionJson.setIssueId(issueId11);
		System.out.println(issueId11);
		executionJson.setStatusId(2l);
		//executionJson.setDefect(issueKey);
		executionJson.setDefects(issueIds);
		executionJson.setExecutionId(exeid);
		
		//update executions
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());
		System.out.println("updated execution");
	}
         
  	//make sprint active
  		String updatesprintpayload="{\"state\":\"active\",\"name\":\""+Sprintname+"\",\"startDate\":\"2015-04-11T15:22:00.000+10:00\",\"endDate\":\"2015-04-20T01:22:00.000+10:00\"}";
        System.out.println(updatesprintpayload);
        Response updatesprintresponse= jiraService.updatesprint(basicAuth, Sprintid, updatesprintpayload);
        System.out.println(updatesprintresponse.getBody().asString());
        System.out.println(updatesprintresponse.getStatusCode());
        
		 //add issue to sprint
      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
        
      //make sprint complete
  		String updatesprintpayload1="{\"state\":\"closed\",\"name\":\""+Sprintname+"\",\"startDate\":\"2015-04-11T15:22:00.000+10:00\",\"endDate\":\"2015-04-20T01:22:00.000+10:00\"}";
        System.out.println(updatesprintpayload1);
        Response updatesprintresponse1= jiraService.updatesprint(basicAuth, Sprintid, updatesprintpayload1);
        System.out.println(updatesprintresponse1.getBody().asString());
        System.out.println(updatesprintresponse1.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//Attempt to getExecutionSummaryBySprint in the sprint is deleted
	@Test(priority = 26,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	    Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	   //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create executions successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			System.out.println(issueKey);
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		 //add issue to sprint
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
        
        //delete sprint
       
      Response del=  jiraService.deletesprint(basicAuth, Sprintid);
      System.out.println(del.getBody().asString()); 
      System.out.println(del.getStatusCode());
      System.out.println("deleted ");
      
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}
	
	//Attempt to getExectionSummaryBySprint if issue is moved from one project to another and using sprint id by the user who doesn't have browse permission to either of the projects
	@Test(priority = 27,enabled=false)
	public void getExecutionSummariesBySprintAndIssue27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		String issueIdorKeys = "{\"issueIdOrKeys\":\"RUBY-23\"}";
		Long sprintId = 4l;
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId,issueIdorKeys );
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint when its linked tests are moved from one project to another project by the user who has browse permission to both the projects
	@Test(priority = 28,enabled=false)
	public void getExecutionSummariesBySprintAndIssue28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		//String issueIdorKeys = "{\"issueIdOrKeys\":\"RUBY-14\"}";
		String issueIdorKeys ="{\"issueIdOrKeys\":\"RUBY-25\", \"issueIdOrKeys\":\"BC-501\"}";
		Long sprintId = 8l;
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId,issueIdorKeys );
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionSummaryBySprint when its linked tests are moved from one project to another project by the user who has browse permission to one of the projects
	@Test(priority = 29,enabled=false)
	public void getExecutionSummariesBySprintAndIssue29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		String issueIdorKeys = "{\"issueIdOrKeys\":\"RUBY-15\"}";
		Long sprintId = 6l;
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, sprintId,issueIdorKeys );
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionSummaryBySprint by passing only sprint id ,if issues in the sprint are created in different projects .
	@Test(priority = 30,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		//create bug
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("bug");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				//convert long to string
			    String issue1=	Long.toString(issueId);
			    
			  //create bug in another project
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad1.setSummary("bug");
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
				Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
			
				List<Long> issueIds1 = new ArrayList<>() ;
				JSONArray jsarray1 = new JSONArray(createIssueResponse1);
				for(int i= 0;i<jsarray1.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray1.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds1.add(l);
				}
				System.out.println("*****"+issueIds1);
				Long issueId1= issueIds1.get(0);
				System.out.println(issueId1);
				//convert long to string
			    String issue2=	Long.toString(issueId1);
			    
			  //create test
			    Issue issuePayLoad2 = new Issue();
			    issuePayLoad2.setProject(Config.getValue("projectId1"));
			    issuePayLoad2.setIssuetype(Config.getValue("issueTypeTestId"));
			    issuePayLoad2.setSummary("test");
			    issuePayLoad2.setPriority("1");
			    issuePayLoad2.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse2 = jiraService.createIssues(basicAuth, issuePayLoad2.toString(), 1);
				Assert.assertNotNull(createIssueResponse2, "Create issues Api Response is null.");
			
				List<Long> issueIds2= new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createIssueResponse2);
				for(int i= 0;i<jsarray2.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray2.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds2.add(l);
				}
				System.out.println("*****"+issueIds2);
				Long issueId2 = issueIds2.get(0);
				System.out.println(issueId2);
				//convert long to string
			    String issue3=	Long.toString(issueId2);
			    
			   //create executions
			  		Execution executionJson = new Execution();
			  		executionJson.setStatusId(-1l);
			  		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
			  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse2, "id"));
			  		executionJson.setVersionId(-1l);
			  		executionJson.setNoOfExecutions(1);
			  		executionJson.setCycleId("-1");
			  		System.out.println(executionJson.toString());

			  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			  		test.log(LogStatus.PASS,
			  				"Create  executions  successfully.");
			  		
			  		List<String> exeIds = new ArrayList<>() ;
			  		JSONArray jsarray21 = new JSONArray(executionResponse.toString());
			  		System.out.println("length="+jsarray21.length());
			  		for (int j=0;j<jsarray21.length();j++){
			  			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
			  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			  			
			  			exeIds.add(exeid);
			  			Long issueId11 = issueIds2.get(j);
			  			executionJson.setIssueId(issueId11);
			  			System.out.println(issueId11);
			  			executionJson.setStatusId(2l);
			  			//executionJson.setDefect(issueKey);
			  			executionJson.setDefects(issueIds);
			  			executionJson.setExecutionId(exeid);
			  			
			  			//update executions
			  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
			  					executionJson.toString());
			  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			  			System.out.println(updateExecutionResponse.getBody().asString());
			  			System.out.println("updated execution");
			  		}
				
				 //add issue to sprint
		      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
		        String addissuesprintpayload= "{\"issues\":[\""+issue1+"\",\""+issue2+"\"]}";
		        System.out.println(addissuesprintpayload);
		        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
		        System.out.println(addsprintresponse.getBody().asString());
		        System.out.println(addsprintresponse.getStatusCode());
		    
			Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
			Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
			System.out.println(response.getBody().asString());
		    test.log(LogStatus.PASS, "Response validated suuccessfully.");
		    
		    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
			Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
			test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
			extentReport.endTest(test);  
			   
	}
	//getExecutionSummaryBySprint with only sprint id of a sprint when we have multiple boards with many sprints to the project.
	@Test(priority = 31,enabled=testEnabled)
	public void getExecutionSummariesBySprintAndIssue31(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		Long ProjectID = Long.parseLong(Config.getValue("projectId1"));
		test.assignAuthor("Roopa");
	
		//create bug
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("bug");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//convert long to string
	    String issue1=	Long.toString(issueId);
	    
	    //create test
	    Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId1"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
		Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
	
		List<Long> issueIds1 = new ArrayList<>() ;
		JSONArray jsarray1 = new JSONArray(createIssueResponse1);
		for(int i= 0;i<jsarray1.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray1.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds1.add(l);
		}
		System.out.println("*****"+issueIds1);
		Long issueId2 = issueIds1.get(0);
		System.out.println(issueId2);
		//convert long to string
	    String issue2=	Long.toString(issueId2);
	    
	  
	  //create executions
	  		Execution executionJson = new Execution();
	  		executionJson.setStatusId(-1l);
	  		executionJson.setProjectId(ProjectID);
	  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse1, "id"));
	  		executionJson.setVersionId(-1l);
	  		executionJson.setNoOfExecutions(1);
	  		executionJson.setCycleId("-1");
	  		System.out.println(executionJson.toString());

	  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	  		test.log(LogStatus.PASS,
	  				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	  		
	  		List<String> exeIds = new ArrayList<>() ;
	  		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	  		System.out.println("length="+jsarray2.length());
	  		for (int j=0;j<jsarray2.length();j++){
	  			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
	  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
	  			
	  			exeIds.add(exeid);
	  			Long issueId11 = issueIds1.get(j);
	  			executionJson.setIssueId(issueId11);
	  			System.out.println(issueId11);
	  			executionJson.setStatusId(2l);
	  			//executionJson.setDefect(issueKey);
	  			executionJson.setDefects(issueIds);
	  			executionJson.setExecutionId(exeid);
	  			
	  			//update executions
	  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
	  					executionJson.toString());
	  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
	  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
	  			System.out.println(updateExecutionResponse.getBody().asString());
	  			System.out.println("updated execution");
	  		}
		
		 //add issue to sprint
        String addissuesprintpayload= "{\"issues\":["+issue1+"]}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
    
	Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
	Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
	System.out.println(response.getBody().asString());
    test.log(LogStatus.PASS, "Response validated suuccessfully.");
    
    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
	Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
	test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
	extentReport.endTest(test);
	}

	//getExecutionSummaryBySprint with sprint id and mulitple issueIdOrKeys of of a sprint when we have multiple boards with many sprints to the project.
	// Create a sprint with multiple issues from different projects. Select only a few issues from the sprint and make the call
		@Test(priority = 32,enabled=testEnabled)
		public void getExecutionSummariesBySprintAndIssue32(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			//create bug
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId1"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad.setSummary("bug");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
			Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(createIssueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			Long issueId = issueIds.get(0);
			System.out.println(issueId);
			//convert long to string
		    String issue1=	Long.toString(issueId);
		    
		    Long issueId3 = issueIds.get(0);
			System.out.println(issueId3);
			//convert long to string
		    String issue4=	Long.toString(issueId3);
		    
		  //create bug in another project
			Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad1.setSummary("bug");
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad1.toString(), 1);
			Assert.assertNotNull(createIssueResponse1, "Create issues Api Response is null.");
		
			List<Long> issueIds1 = new ArrayList<>() ;
			JSONArray jsarray1 = new JSONArray(createIssueResponse1);
			for(int i= 0;i<jsarray1.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray1.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds1.add(l);
			}
			System.out.println("*****"+issueIds1);
			Long issueId1= issueIds1.get(0);
			System.out.println(issueId1);
			//convert long to string
		    String issue2=	Long.toString(issueId1);
		    
		  //create test
		    Issue issuePayLoad2 = new Issue();
		    issuePayLoad2.setProject(Config.getValue("projectId1"));
		    issuePayLoad2.setIssuetype(Config.getValue("issueTypeTestId"));
		    issuePayLoad2.setSummary("test");
		    issuePayLoad2.setPriority("1");
		    issuePayLoad2.setReporter(Config.getValue("adminUserName"));
			
			List<String> createIssueResponse2 = jiraService.createIssues(basicAuth, issuePayLoad2.toString(), 1);
			Assert.assertNotNull(createIssueResponse2, "Create issues Api Response is null.");
		
			List<Long> issueIds2= new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(createIssueResponse2);
			for(int i= 0;i<jsarray2.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray2.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds2.add(l);
			}
			System.out.println("*****"+issueIds2);
			Long issueId2 = issueIds2.get(0);
			System.out.println(issueId2);
			//convert long to string
		    String issue3=	Long.toString(issueId2);
		    
		   //create executions
		  		Execution executionJson = new Execution();
		  		executionJson.setStatusId(-1l);
		  		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		  		executionJson.setIssueIds(CommonUtils.getListAsLong(createIssueResponse2, "id"));
		  		executionJson.setVersionId(-1l);
		  		executionJson.setNoOfExecutions(1);
		  		executionJson.setCycleId("-1");
		  		System.out.println(executionJson.toString());

		  		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		  		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		  		test.log(LogStatus.PASS,
		  				"Create  executions  successfully.");
		  		
		  		List<String> exeIds = new ArrayList<>() ;
		  		JSONArray jsarray21 = new JSONArray(executionResponse.toString());
		  		System.out.println("length="+jsarray21.length());
		  		for (int j=0;j<jsarray21.length();j++){
		  			JSONObject jsobj2 = new JSONObject(jsarray21.getString(j));
		  			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		  			
		  			exeIds.add(exeid);
		  			Long issueId11 = issueIds2.get(j);
		  			executionJson.setIssueId(issueId11);
		  			System.out.println(issueId11);
		  			executionJson.setStatusId(2l);
		  			//executionJson.setDefect(issueKey);
		  			executionJson.setDefects(issueIds);
		  			executionJson.setExecutionId(exeid);
		  			
		  			//update executions
		  			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
		  					executionJson.toString());
		  			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		  			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		  			System.out.println(updateExecutionResponse.getBody().asString());
		  			System.out.println("updated execution");
		  		}
			
			 //add issue to sprint
	      //  String issueIdorKeys = Config.getValue("issueIdOrKeys");
	        String addissuesprintpayload= "{\"issues\":[\""+issue1+"\",\""+issue2+"\",\""+issue4+"\"]}";
	        System.out.println(addissuesprintpayload);
	        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
	        System.out.println(addsprintresponse.getBody().asString());
	        System.out.println(addsprintresponse.getStatusCode());
	    
		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, Sprintid, issue1);
		Assert.assertNotNull(response, "getExecutionSummariesBySprintAndIssue Api Response is null.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api executed successfully.");
		System.out.println(response.getBody().asString());
	    test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    
	    boolean status = zapiService.validategetExecutionSummariesBySprintAndIssue(response);
		Assert.assertTrue(status, "getExecutionSummariesBySprintAndIssue Api Response Validation Failed.");
		test.log(LogStatus.PASS, "getExecutionSummariesBySprintAndIssue Api Response validated suuccessfully.");
		extentReport.endTest(test);  
		}

























































}
