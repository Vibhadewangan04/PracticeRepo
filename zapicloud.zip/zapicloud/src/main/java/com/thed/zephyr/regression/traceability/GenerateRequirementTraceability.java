package com.thed.zephyr.regression.traceability;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class GenerateRequirementTraceability extends BaseTest {
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect for selected version and selected requirement 
 */	
//@Test(priority = 1)
	public void Test1_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		requirementIdOrKeyList.add(10240l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Attempt to Generate Requirement to defect  for selected version and selected invalid requirement id
 * response-400
 */	
@Test(priority = 2)
	public void Test2_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		//requirementIdOrKeyList.add(12345l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for invalid version and selected valid requirement id
 * Hence version id is not mandatory field we are getting 200 response.
 * 200 response
 */	
//@Test(priority = 3)
	public void Test3_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 1234l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10240l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchTestsByRequirement
 * Attempt to Generate Requirement to defect  for invalid version and invalid requirement id
 * 400 response
 */	
//@Test(priority = 4)
	public void Test4_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 1234l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(1234l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and requirement id where requirement is TODO
 * statusId":10000
 * 200 response
 */	
//@Test(priority = 5)
	public void Test5_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10324l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and requirement id where requirement is IN PROGRESS
 * statusId":3
 * 200 response
 */	
//@Test(priority = 6)
	public void Test6_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10325l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and requirement id where requirement is Done
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 7)
	public void Test7_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10329l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Attempt to Generate Requirement to defect  for selected version id  and requirement id where requirement  is deleted 
 * statusId":10001
 * 200 response/[{}]
 */	
//@Test(priority = 8)
	public void Test8_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10333l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
//10334
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and requirement linked test has no defects Associated 
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 9)
	public void Test9_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10339l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and requirement linked test has 50 defects Associated 
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 10)
	public void Test10_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10339l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and requirement linked 5 test has no defects Associated 
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 11)
	public void Test11_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10345l);
		//requirementIdOrKeyList.add(10017l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and having multiple requirements 
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 12)
	public void Test12_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10345l);
		requirementIdOrKeyList.add(10324l);
		requirementIdOrKeyList.add(10325l);
		requirementIdOrKeyList.add(10329l);	
		requirementIdOrKeyList.add(10240l);
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if requirement associated test is deleted 
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 13)
	public void Test13_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10362l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test is TODO 
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 14)
	public void Test14_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10366l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test is In progress
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 15)
	public void Test15_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10367l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test is Done
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 16)
	public void Test16_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10368l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test has Todo defect
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 17)
	public void Test17_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10240l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test has inprogress defect
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 18)
	public void Test18_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10240l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test has done defect
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 19)
	public void Test19_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10240l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchTestsByRequirement
 * Generate Requirement to defect  for selected version id  and  requirements id if linked test has  deleted defect
 * statusId":10001
 * 200 response
 */	
//@Test(priority = 20)
	public void Test20_generateRequirementTraceability() throws UnsupportedEncodingException{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");		
		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		//update invalid id below
		requirementIdOrKeyList.add(10240l);
		
		
		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		System.out.println("response:"+response.getStatusLine());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


}
