// get multipleSteps


package com.thed.zephyr.regression.teststep;

import org.testng.Assert;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class GetMultipleTestSteps extends BaseTest {


//	JwtGenerator jwtGenerator = null;
	Long projectId = Long.parseLong(Config.getValue("projectId"));
	Long issueTypeTestId = Long.parseLong(Config.getValue("issueTypeTestId"));
	Long issueId = null;
	String issueKey = null;
	
	/*// Long projectId2 = 0l;
	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}*/

	//creating 1 issue 
	 @BeforeMethod
	 public void beforeMethod(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Soumyaranjan");
			 
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(String.valueOf(issueTypeTestId));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");
			
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
			
			boolean status = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(status, "Response Validation Failed.");
			issueKey = new JSONObject(response.body().asString()).get("id").toString();
//			System.out.println("this is the issue key "+ issueKey);
			issueId = Long.parseLong(issueKey);
			test.log(LogStatus.PASS, "Response validated successfully.");
			
	 }

	 @Test(priority = 1, enabled = true)
	public void test1_getTeststeps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		List<String> step = new ArrayList<>();
		step.add("step 1");
		step.add("step 2");
		step.add("step 3");
		List<String> stepData = new ArrayList<>();
		stepData.add("stepData 1");
		stepData.add("stepData 2");
		stepData.add("stepData 3");
		List<String> stepRes = new ArrayList<>();
		stepRes.add("stepRes 1");
		stepRes.add("stepRes 2");
		stepRes.add("stepRes 3");
		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having wiki format heading and Get Teststeps
	 @Test(priority = 2, enabled = true)
	public void test2_getTeststeps_havingWikiHeading() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("h1. Biggest heading");
		step.add("h2. Bigger heading");
		step.add("h3. Big heading");
		step.add("h4. Normal heading");
		step.add("h5. Small heading");
		step.add("h6. Smallest heading");

		List<String> stepData = new ArrayList<>();
		stepData.add("h1. Biggest heading");
		stepData.add("h2. Bigger heading");
		stepData.add("h3. Big heading");
		stepData.add("h4. Hello world");
		stepData.add("h5. Good morning");
		stepData.add("h6. bye everybody");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("h1. Biggest heading");
		stepRes.add("h2. Bigger heading");
		stepRes.add("h3. Big heading");
		stepRes.add("h4. Hi Everyone");
		stepRes.add("h5. how are u");
		stepRes.add("h6. Good Night");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		 System.out.println("GetResponse is : " +getResponse.getBody().asString());
		 System.out.println(getResponse.statusLine());
		
		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having wiki format Text and Get Teststeps :
	// strong,citation,emphasis
	 @Test(priority = 3, enabled = true)
	public void test3_getTeststeps_havingWikiFormatedText1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("*strong*");
		step.add("*strong*");
		step.add("_emphasis_");
		step.add("??citation??");
		step.add("_emphasis_");
		step.add("??citation??");

		List<String> stepData = new ArrayList<>();
		stepData.add("*alphabet in strong case*");
		stepData.add("*alphabet in strong case*");
		stepData.add("_Java programmimg_");
		stepData.add("??Zapi technology??");
		stepData.add("_PHP,Pythan programmimg_");
		stepData.add("??Zapi technology??");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("*Hehehe*");
		stepRes.add("*Hi 2345 #$%^& All*");
		stepRes.add("_c++ programmimg_");
		stepRes.add("??INdia@bangalore??");
		stepRes.add("_c programmimg_");
		stepRes.add("??zephyr,bangalore??");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having wiki format Text and Get Test steps:
	// deleted,inserted,superscript,subscript,quoted block
	 @Test(priority = 4, enabled = true)
	public void test4_getTeststeps_havingWikiFormatedText2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("-deleted-");
		step.add("+inserted+");
		step.add("^2^ 3");
		step.add("~2~ 3");
		step.add("bq. test step");
		step.add("{quote}here is quotable content to be quoted {quote}");

		List<String> stepData = new ArrayList<>();
		stepData.add("-test cases to delete-");
		stepData.add("+underline the points+");
		stepData.add("10 ^2^");
		stepData.add("10 ~2~");
		stepData.add("bq. test data");
		stepData.add("{quote}here is quotable content to be quoted {quote}");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("-facebook-");
		stepRes.add("+important notes+");
		stepRes.add("7 ^3^ 4");
		stepRes.add("7 ~3~ 4");
		stepRes.add("bq. step result");
		stepRes.add("{quote}here is quotable content to be quoted {quote}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having wiki format Text and Get Teststeps: hifen symbol,
	// horizontal line , color text
	 @Test(priority = 5, enabled = true)
	public void test5_getTeststeps_havingWikiFormatedText3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("{color:red}look ma, red text!{color}");
		step.add("----creates a horizontal line");
		step.add("---produces hifen symbol");

		List<String> stepData = new ArrayList<>();
		stepData.add("{color:yellow}yellow text!{color}");
		stepData.add("----creates a horizontal line");
		stepData.add("---produces hifen symbol");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("{color:blue}look ma, blue text!{color}");
		stepRes.add("----creates a horizontal line");
		stepRes.add("---produces hifen symbol");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having wiki format Text and Get Teststeps: Link , bullet
	// points, number list, escape char, empty line,line break
	 @Test(priority = 6, enabled = true)
	public void test6_getTeststeps_havingWikiFormatedText4() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		step.add("* some\n* bullet\n* points");
		step.add("# a\n# numbered\n# list");
		step.add("Hello\\\\good morning");
		step.add("paragraph1\n\nparagraph2");
		step.add("\\* a\n\\* b");

		List<String> stepData = new ArrayList<>();
		stepData.add("[Atlassian|http://atlassian.com]");
		stepData.add("* Whatsup app\n* facebook\n* Twitter");
		stepData.add("# Zapi\n# Zapi Technology,banglore\n# Vlcc building");
		stepData.add("Hi\\\\everyone");
		stepData.add("paragraph1\n\nparagraph2");
		stepData.add("\\* a\n\\* b");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepRes.add("* java programming language\n* c++\n* Ruby and Pythan");
		stepRes.add("# Zephyr\n# Zfjcloud\n# Zee and Zfj");
		stepRes.add("Hello\\\\world");
		stepRes.add("paragraph1\n\nparagraph2");
		stepRes.add("\\* a\n\\* b");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having wiki format Text and Get Teststeps: image, email
	// link, table
	 @Test(priority = 7, enabled = true)
	public void test7_getTeststeps_havingWikiFormatedText5() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("[mailto:legendaryservice@atlassian.com]");

		List<String> stepData = new ArrayList<>();
		stepData.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		stepData.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepData.add("[mailto:legendaryservice@atlassian.com]");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		stepRes.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepRes.add("[mailto:legendaryservice@atlassian.com]");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having only test step, without test data and test result
	@Test(priority = 8, enabled = true)
	public void test8_getTeststeps_havingOnlyTestStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("[mailto:legendaryservice@atlassian.com]");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("");
		stepRes.add("");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having only test data, without test step and test result
	@Test(priority = 9, enabled = true)
	public void test9_getTeststeps_havingOnlyTestData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("");
		step.add("");
		step.add("");

		List<String> stepData = new ArrayList<>();
		stepData.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		stepData.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepData.add("[mailto:legendaryservice@atlassian.com]");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("");
		stepRes.add("");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps having only test result, without test step and test data
	@Test(priority = 10, enabled = true)
	public void test10_getTeststeps_havingOnlyTestResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("");
		step.add("");
		step.add("");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		stepRes.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepRes.add("[mailto:legendaryservice@atlassian.com]");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps without test result
	@Test(priority = 11, enabled = true)
	public void test11_getTeststeps_withoutTestResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		step.add("h2. Bigger heading");

		List<String> stepData = new ArrayList<>();
		stepData.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepData.add("* some\n* bullet\n* points");
		stepData.add("{color:green}look ma, green text!{color}");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("");
		stepRes.add("");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps without test data
	@Test(priority = 12, enabled = true)
	public void test12_getTeststeps_withoutTestData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		step.add("h2. Bigger heading");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps without test step
	@Test(priority = 13, enabled = true)
	public void test13_getTeststeps_withoutTestStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("");
		step.add("");
		step.add("");

		List<String> stepData = new ArrayList<>();
		stepData.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps with mixing data
	@Test(priority = 14, enabled = true)
	public void test14_getTeststeps_withMixingData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("# a\n# numbered\n# list");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps with mixing data: capital, small, numeric, alphanumeric
	// letter
	@Test(priority = 15, enabled = true)
	public void test15_getTeststeps_withMixingData2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("AAAA");
		step.add("aaa");
		step.add("2134567");
		step.add("8765rtfgjhy89iujhgv");
		step.add("&*()(*&^%$()+_)(*&^%$#@");
		step.add("");
		step.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		step.add(null);

		List<String> stepData = new ArrayList<>();
		stepData.add("BBB");
		stepData.add("bbb");
		stepData.add("098765");
		stepData.add("hsgytd87yhjuy89iu");
		stepData.add("+_)(*&^%$");
		stepData.add("");
		stepData.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepData.add(null);

		List<String> stepRes = new ArrayList<>();
		stepRes.add("CCC");
		stepRes.add("hhh");
		stepRes.add("7655433456d789");
		stepRes.add("dghai789oijhnjuy7890jh8987");
		stepRes.add("~!@#$%");
		stepRes.add("");
		stepRes.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepRes.add(null);

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps with international char data
	@Test(priority = 16, enabled = true)
	public void test16_getTeststeps_withInternationalChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("Supprimer cette ï¿½tape de statut d'exï¿½cution");
		step.add("Zugangserlaubnis zu Zephyr fï¿½r Jira Cloud bezï¿½glich HipChat gewï¿½hrt.");
		step.add("Nuevo status de ejecuciï¿½n para coincidir con ejecuciones");
		step.add("Supprimer cette ï¿½tape de statut d'exï¿½cution");

		List<String> stepData = new ArrayList<>();
		stepData.add("Supprimer cette ï¿½tape de statut d'exï¿½cution");
		stepData.add("Zugangserlaubnis zu Zephyr fï¿½r Jira Cloud bezï¿½glich HipChat gewï¿½hrt.");
		stepData.add("Nuevo status de ejecuciï¿½n para coincidir con ejecuciones");
		stepData.add("Zugangserlaubnis zu Zephyr fï¿½r Jira Cloud bezï¿½glich HipChat gewï¿½hrt.");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("Supprimer cette ï¿½tape de statut d'exï¿½cution");
		stepRes.add("Zugangserlaubnis zu Zephyr fï¿½r Jira Cloud bezï¿½glich HipChat gewï¿½hrt.");
		stepRes.add("Nuevo status de ejecuciï¿½n para coincidir con ejecuciones");
		stepRes.add("Nuevo status de ejecuciï¿½n para coincidir con ejecuciones");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created steps with long character
	@Test(priority = 17, enabled = true)
	public void test17_getTeststeps_withLongChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		List<String> step = new ArrayList<>();
		step.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		step.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		step.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		List<String> stepData = new ArrayList<>();
		stepData.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		stepData.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		stepData.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		List<String> stepRes = new ArrayList<>();
		stepRes.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		stepRes.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		stepRes.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created only one step and Get test steps
	@Test(priority = 18, enabled = true)
	public void test18_getTeststeps_havingOnlyOneStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");

		List<String> stepData = new ArrayList<>();
		stepData.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("[mailto:legendaryservice@atlassian.com]");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created 10 steps and Get test steps
	@Test(priority = 19, enabled = true)
	public void test19_getTeststeps_withTenSteps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("AAAA");
		step.add("aaa");
		step.add("2134567");
		step.add("8765rtfgjhy89iujhgv");
		step.add("&*()(*&^%$()+_)(*&^%$#@");
		step.add("");
		step.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		step.add(null);
		step.add("Nuevo status de ejecuciï¿½n para coincidir con ejecuciones");
		step.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		List<String> stepData = new ArrayList<>();
		stepData.add("BBB");
		stepData.add("bbb");
		stepData.add("098765");
		stepData.add("hsgytd87yhjuy89iu");
		stepData.add("+_)(*&^%$");
		stepData.add("");
		stepData.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepData.add(null);
		stepData.add("Zugangserlaubnis zu Zephyr fï¿½r Jira Cloud bezï¿½glich HipChat gewï¿½hrt.");
		stepData.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("CCC");
		stepRes.add("hhh");
		stepRes.add("7655433456d789");
		stepRes.add("dghai789oijhnjuy7890jh8987");
		stepRes.add("~!@#$%");
		stepRes.add("");
		stepRes.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepRes.add(null);
		stepRes.add("Supprimer cette ï¿½tape de statut d'exï¿½cution");
		stepRes.add(
				"This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		// System.out.println(getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),	getResponse);
		Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// created 0 step and Get test steps
	@Test(priority = 20, enabled = true)
	public void test20_getTeststeps_withZeroSteps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		System.out.println(getResponse.getBody().asString());

		// boolean validateStatus = zapiService.validateTeststepsData(projectId,
		// issueId, teststepJson.toString(), getResponse);
		// Assert.assertTrue(validateStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Attempt to get test steps when issueId is null
	@Test(priority = 21, enabled = true)
	public void test21_getTeststeps_withIssueidNull() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		/*List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("# a\n# numbered\n# list");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");*/

		Long invalidIssueId = null;
		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, invalidIssueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		
		// System.out.println(getResponse.getBody().asString());

		 boolean validateStatus = zapiService.validateInvalidIssueId(invalidIssueId, getResponse);
		 Assert.assertTrue(validateStatus);
		 test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
	}

	// Attempt to get test steps when issueId is invalid
	@Test(priority = 22, enabled = true)
	public void test22_getTeststeps_withIssueidInvalid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		/*List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("# a\n# numbered\n# list");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");*/

		Long invalidIssueId = 11210l;
		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, invalidIssueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		System.out.println("get test steps response: "+ getResponse.getBody().asString());

		 boolean validateStatus = zapiService.validateInvalidIssueIdForStep1(invalidIssueId, getResponse);
		 Assert.assertTrue(validateStatus);
		 test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
	}

	// Attempt to get test steps when projectId is invalid
	@Test(priority = 23, enabled = true)
	public void test23_getTeststeps_withProjectIdInvalid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		/*List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("# a\n# numbered\n# list");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");*/

		Long invalidProjectId = 54679l;
		Response getResponse = zapiService.getTeststeps(jwtGenerator, invalidProjectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		
		// System.out.println(getResponse.getBody().asString());

		 boolean validateStatus = zapiService.validateInvalidProjectId(invalidProjectId, getResponse);
		 Assert.assertTrue(validateStatus);
		 test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
	}

	// Attempt to get test steps when projectId is null
	@Test(priority = 24, enabled = true)
	public void test24_getTeststeps_withProjectIdNull() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("# a\n# numbered\n# list");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Long invalidProjectId = null;
		Response getResponse = zapiService.getTeststeps(jwtGenerator, invalidProjectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		
		// System.out.println(getResponse.getBody().asString());

		 boolean validateStatus = zapiService.validateInvalidProjectId(invalidProjectId, getResponse);
		 Assert.assertTrue(validateStatus);
		 test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
	}

	// Attempt to get test steps when projectId and issueId is mismatch
	@Test(priority = 25, enabled = true)
	public void test25_getTeststeps_with_ProjecIdAndIssueid_Mismatch() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		List<String> step = new ArrayList<>();
		step.add("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
		step.add("");
		step.add("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
		step.add("# a\n# numbered\n# list");

		List<String> stepData = new ArrayList<>();
		stepData.add("");
		stepData.add("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
		stepData.add("h2. Bigger heading");
		stepData.add("");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("");
		stepRes.add("* some\n* bullet\n* points");
		stepRes.add("");
		stepRes.add("{color:green}look ma, green text!{color}");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		
		/*boolean createStepStatus = zapiService.validateTeststepswithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createStepStatus);
		test.log(LogStatus.PASS, "create step Response validated suuccessfully.");*/
				
		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Long invalidProjectId = 10000777l;
		Response getResponse = zapiService.getTeststeps(jwtGenerator, invalidProjectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
			System.out.println(getResponse.getStatusCode());
		// System.out.println(getResponse.getBody().asString());
		 boolean validateStatus = zapiService.validateInvalidProjectId(invalidProjectId, getResponse);
		 Assert.assertTrue(validateStatus);
		 test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
	}

}
