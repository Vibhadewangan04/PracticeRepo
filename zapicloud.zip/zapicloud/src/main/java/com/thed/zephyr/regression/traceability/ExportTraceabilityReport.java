/**
 *
 */
package com.thed.zephyr.regression.traceability;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.ExportTraceability;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class ExportTraceabilityReport extends BaseTest {

	JwtGenerator jwtGenerator = null;
	String exportType = null;
	Long versionId = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//	Export traceability in HTML format with defectList and in unscheduled version
	@Test(priority = 1)
	public void test1_ExportTraceabilityInHtmlFormatWithDefectlistAndInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"11502"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with defectList and in scheduled version
	@Test(priority = 2)
	public void test2_ExportTraceabilityInHtmlFormatWithDefectlistAndInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10443"};
		exportType = "html";
		versionId = 10108l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with requirementList and in unscheduled version
	@Test(priority = 3)
	public void test3_ExportTraceabilityInHtmlFormatWithRequirementlistAndInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with requirementList and in scheduled version
	@Test(priority = 4)
	public void test4_ExportTraceabilityInHtmlFormatWithRequirementlistAndInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "html";
		versionId = 10108l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with 50 defects in defectList
	//TODO
	@Test(priority = 5)
	public void test5_ExportTraceabilityInHtmlFormatWith50DefectsInDefectIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with 100 defects in defectList
	//TODO
	@Test(priority = 6)
	public void test6_ExportTraceabilityInHtmlFormatWith100DefectsInDefectIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//	Export traceability in HTML format with 500 defects in defectList
	//TODO
	@Test(priority = 7)
	public void test7_ExportTraceabilityInHtmlFormatWith500DefectsInDefectIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"11502","11503","11504","11505","11506","11507","11508","11509","11510","11511","11512","11513","11514","11515","11516","11517","11518","11519","11520","11521","11522","11523","11524","11525","11526","11527","11528","11529","11530","11531","11532","11533","11534","11535","11536","11537","11538","11539","11540","11541","11542","11543","11544","11545","11546","11547","11548","11549","11550","11551","11552","11553","11554","11555","11556","11557","11558","11559","11560","11561","11562","11563","11564","11565","11566","11567","11568","11569","11570","11571","11572","11573","11574","11575","11576","11577","11578","11579","11580","11581","11582","11583","11584","11585","11586","11587","11588","11589","11590","11591","11592","11593","11594","11595","11596","11597","11598","11599","11600","11601","11602","11603","11604","11605","11606","11607","11608","11609","11610","11611","11612","11613","11614","11615","11616","11617","11618","11619","11620","11621","11622","11623","11624","11625","11626","11627","11628","11629","11630","11631","11632","11633","11634","11635","11636","11637","11638","11639","11640","11641","11642","11643","11644","11645","11646","11647","11648","11649","11650","11651","11652","11653","11654","11655","11656","11657","11658","11659","11660","11661","11662","11663","11664","11665","11666","11667","11668","11669","11670","11671","11672","11673","11674","11675","11676","11677","11678","11679","11680","11681","11682","11683","11684","11685","11686","11687","11688","11689","11690","11691","11692","11693","11694","11695","11696","11697","11698","11699","11700","11701","11702","11703","11704","11705","11706","11707","11708","11709","11710","11711","11712","11713","11714","11715","11716","11717","11718","11719","11720","11721","11722","11723","11724","11725","11726","11727","11728","11729","11730","11731","11732","11733","11734","11735","11736","11737","11738","11739","11740","11741","11742","11743","11744","11745","11746","11747","11748","11749","11750","11751","11752","11753","11754","11755","11756","11757","11758","11759","11760","11761","11762","11763","11764","11765","11766","11767","11768","11769","11770","11771","11772","11773","11774","11775","11776","11777","11778","11779","11780","11781","11782","11783","11784","11785","11786","11787","11788","11789","11790","11791","11792","11793","11794","11795","11796","11797","11798","11799","11800","11801","11802","11803","11804","11805","11806","11807","11808","11809","11810","11811","11812","11813","11814","11815","11816","11817","11818","11819","11820","11821","11822","11823","11824","11825","11826","11827","11828","11829","11830","11831","11832","11833","11834","11835","11836","11837","11838","11839","11840","11841","11842","11843","11844","11845","11846","11847","11848","11849","11850","11851","11852","11853","11854","11855","11856","11857","11858","11859","11860","11861","11862","11863","11864","11865","11866","11867","11868","11869","11870","11871","11872","11873","11874","11875","11876","11877","11878","11879","11880","11881","11882","11883","11884","11885","11886","11887","11888","11889","11890","11891","11892","11893","11894","11895","11896","11897","11898","11899","11900","11901","11902","11903","11904","11905","11906","11907","11908","11909","11910","11911","11912","11913","11914","11915","11916","11917","11918","11919","11920","11921","11922","11923","11924","11925","11926","11927","11928","11929","11930","11931","11932","11933","11934","11935","11936","11937","11938","11939","11940","11941","11942","11943","11944","11945","11946","11947","11948","11949","11950","11951","11952","11953","11954","11955","11956","11957","11958","11959","11960","11961","11962","11963","11964","11965","11966","11967","11968","11969","11970","11971","11972","11973","11974","11975","11976","11977","11978","11979","11980","11981","11982","11983","11984","11985","11986","11987","11988","11989","11990","11991","11992","11993","11994","11995","11996","11997","11998","11999","12000","12001"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//  Export traceability in HTML format with 50 requirements in requirementIdList
	//TODO
	@Test(priority = 8)
	public void test8_ExportTraceabilityInHtmlFormatWith50RequirementsInRequirementIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with 100 requirements in requirementIdList
	//TODO
	@Test(priority = 9)
	public void test9_ExportTraceabilityInHtmlFormatWith100RequirementsInRequirementIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in HTML format with 500 requirements in requirementIdList
	//TODO
	@Test(priority = 10)
	public void test10_ExportTraceabilityInHtmlFormatWith500RequirementsInRequirementIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Attempt to export traceability in HTML format with defectList and invalid versionId
	@Test(priority = 11)
	public void test11_AttemptToExportTraceabilityInHtmlFormatWithDefectidlistAndInvalidVersionid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "html";
		versionId = 99l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Attempt to export traceability in HTML format with requirementList and invalid versionId
	@Test(priority = 12)
	public void test12_AttemptToExportTraceabilityInHtmlFormatWithRequirementidlistAndInvalidVersionid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "html";
		versionId = 99l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Attempt to export traceability in HTML format with invalid defectList
	@Test(priority = 13)
	public void test13_AttemptToExportTraceabilityInHtmlFormatWithInvalidDefectidlist(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"99","98"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Attempt to export traceability in HTML format with invalid requirementList
	@Test(priority = 14)
	public void test14_AttemptToExportTraceabilityInHtmlFormatWithInvalidRequirementidlist(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"99","98"};
		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with defectList and in unscheduled version
	@Test(priority = 15)
	public void test15_ExportTraceabilityInExcelFormatWithDefectlistAndInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with defectList and in scheduled version
	@Test(priority = 16)
	public void test16_ExportTraceabilityInExcelFormatWithDefectlistAndInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10443"};
		exportType = "excel";
		versionId = 10108l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with requirementList and in unscheduled version
	@Test(priority = 17)
	public void test17_ExportTraceabilityInExcelFormatWithRequirementlistAndInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with requirementList and in scheduled version
	@Test(priority = 18)
	public void test18_ExportTraceabilityInExcelFormatWithRequirementlistAndInScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "excel";
		versionId = 10108l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with 50 defects in defectList
	//TODO
	@Test(priority = 19)
	public void test19_ExportTraceabilityInExcelFormatWith50DefectsInDefectIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with 100 defects in defectList
	//TODO
	@Test(priority = 20)
	public void test20_ExportTraceabilityInExcelFormatWith100DefectsInDefectIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//	Export traceability in EXCEL format with 500 defects in defectList
	//TODO
	@Test(priority = 21)
	public void test21_ExportTraceabilityInExcelFormatWith500DefectsInDefectIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"11502","11503","11504","11505","11506","11507","11508","11509","11510","11511","11512","11513","11514","11515","11516","11517","11518","11519","11520","11521","11522","11523","11524","11525","11526","11527","11528","11529","11530","11531","11532","11533","11534","11535","11536","11537","11538","11539","11540","11541","11542","11543","11544","11545","11546","11547","11548","11549","11550","11551","11552","11553","11554","11555","11556","11557","11558","11559","11560","11561","11562","11563","11564","11565","11566","11567","11568","11569","11570","11571","11572","11573","11574","11575","11576","11577","11578","11579","11580","11581","11582","11583","11584","11585","11586","11587","11588","11589","11590","11591","11592","11593","11594","11595","11596","11597","11598","11599","11600","11601","11602","11603","11604","11605","11606","11607","11608","11609","11610","11611","11612","11613","11614","11615","11616","11617","11618","11619","11620","11621","11622","11623","11624","11625","11626","11627","11628","11629","11630","11631","11632","11633","11634","11635","11636","11637","11638","11639","11640","11641","11642","11643","11644","11645","11646","11647","11648","11649","11650","11651","11652","11653","11654","11655","11656","11657","11658","11659","11660","11661","11662","11663","11664","11665","11666","11667","11668","11669","11670","11671","11672","11673","11674","11675","11676","11677","11678","11679","11680","11681","11682","11683","11684","11685","11686","11687","11688","11689","11690","11691","11692","11693","11694","11695","11696","11697","11698","11699","11700","11701","11702","11703","11704","11705","11706","11707","11708","11709","11710","11711","11712","11713","11714","11715","11716","11717","11718","11719","11720","11721","11722","11723","11724","11725","11726","11727","11728","11729","11730","11731","11732","11733","11734","11735","11736","11737","11738","11739","11740","11741","11742","11743","11744","11745","11746","11747","11748","11749","11750","11751","11752","11753","11754","11755","11756","11757","11758","11759","11760","11761","11762","11763","11764","11765","11766","11767","11768","11769","11770","11771","11772","11773","11774","11775","11776","11777","11778","11779","11780","11781","11782","11783","11784","11785","11786","11787","11788","11789","11790","11791","11792","11793","11794","11795","11796","11797","11798","11799","11800","11801","11802","11803","11804","11805","11806","11807","11808","11809","11810","11811","11812","11813","11814","11815","11816","11817","11818","11819","11820","11821","11822","11823","11824","11825","11826","11827","11828","11829","11830","11831","11832","11833","11834","11835","11836","11837","11838","11839","11840","11841","11842","11843","11844","11845","11846","11847","11848","11849","11850","11851","11852","11853","11854","11855","11856","11857","11858","11859","11860","11861","11862","11863","11864","11865","11866","11867","11868","11869","11870","11871","11872","11873","11874","11875","11876","11877","11878","11879","11880","11881","11882","11883","11884","11885","11886","11887","11888","11889","11890","11891","11892","11893","11894","11895","11896","11897","11898","11899","11900","11901","11902","11903","11904","11905","11906","11907","11908","11909","11910","11911","11912","11913","11914","11915","11916","11917","11918","11919","11920","11921","11922","11923","11924","11925","11926","11927","11928","11929","11930","11931","11932","11933","11934","11935","11936","11937","11938","11939","11940","11941","11942","11943","11944","11945","11946","11947","11948","11949","11950","11951","11952","11953","11954","11955","11956","11957","11958","11959","11960","11961","11962","11963","11964","11965","11966","11967","11968","11969","11970","11971","11972","11973","11974","11975","11976","11977","11978","11979","11980","11981","11982","11983","11984","11985","11986","11987","11988","11989","11990","11991","11992","11993","11994","11995","11996","11997","11998","11999","12000","12001"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//  Export traceability in EXCEL format with 50 requirements in requirementIdList
	//TODO
	@Test(priority = 22)
	public void test22_ExportTraceabilityInExcelFormatWith50RequirementsInRequirementIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with 100 requirements in requirementIdList
	//TODO
	@Test(priority = 23)
	public void test23_ExportTraceabilityInExcelFormatWith100RequirementsInRequirementIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Export traceability in EXCEL format with 500 requirements in requirementIdList
	//TODO
	@Test(priority = 24)
	public void test24_ExportTraceabilityInExcelFormatWith500RequirementsInRequirementIdList(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"11502","11503","11504","11505","11506","11507","11508","11509","11510","11511","11512","11513","11514","11515","11516","11517","11518","11519","11520","11521","11522","11523","11524","11525","11526","11527","11528","11529","11530","11531","11532","11533","11534","11535","11536","11537","11538","11539","11540","11541","11542","11543","11544","11545","11546","11547","11548","11549","11550","11551","11552","11553","11554","11555","11556","11557","11558","11559","11560","11561","11562","11563","11564","11565","11566","11567","11568","11569","11570","11571","11572","11573","11574","11575","11576","11577","11578","11579","11580","11581","11582","11583","11584","11585","11586","11587","11588","11589","11590","11591","11592","11593","11594","11595","11596","11597","11598","11599","11600","11601","11602","11603","11604","11605","11606","11607","11608","11609","11610","11611","11612","11613","11614","11615","11616","11617","11618","11619","11620","11621","11622","11623","11624","11625","11626","11627","11628","11629","11630","11631","11632","11633","11634","11635","11636","11637","11638","11639","11640","11641","11642","11643","11644","11645","11646","11647","11648","11649","11650","11651","11652","11653","11654","11655","11656","11657","11658","11659","11660","11661","11662","11663","11664","11665","11666","11667","11668","11669","11670","11671","11672","11673","11674","11675","11676","11677","11678","11679","11680","11681","11682","11683","11684","11685","11686","11687","11688","11689","11690","11691","11692","11693","11694","11695","11696","11697","11698","11699","11700","11701","11702","11703","11704","11705","11706","11707","11708","11709","11710","11711","11712","11713","11714","11715","11716","11717","11718","11719","11720","11721","11722","11723","11724","11725","11726","11727","11728","11729","11730","11731","11732","11733","11734","11735","11736","11737","11738","11739","11740","11741","11742","11743","11744","11745","11746","11747","11748","11749","11750","11751","11752","11753","11754","11755","11756","11757","11758","11759","11760","11761","11762","11763","11764","11765","11766","11767","11768","11769","11770","11771","11772","11773","11774","11775","11776","11777","11778","11779","11780","11781","11782","11783","11784","11785","11786","11787","11788","11789","11790","11791","11792","11793","11794","11795","11796","11797","11798","11799","11800","11801","11802","11803","11804","11805","11806","11807","11808","11809","11810","11811","11812","11813","11814","11815","11816","11817","11818","11819","11820","11821","11822","11823","11824","11825","11826","11827","11828","11829","11830","11831","11832","11833","11834","11835","11836","11837","11838","11839","11840","11841","11842","11843","11844","11845","11846","11847","11848","11849","11850","11851","11852","11853","11854","11855","11856","11857","11858","11859","11860","11861","11862","11863","11864","11865","11866","11867","11868","11869","11870","11871","11872","11873","11874","11875","11876","11877","11878","11879","11880","11881","11882","11883","11884","11885","11886","11887","11888","11889","11890","11891","11892","11893","11894","11895","11896","11897","11898","11899","11900","11901","11902","11903","11904","11905","11906","11907","11908","11909","11910","11911","11912","11913","11914","11915","11916","11917","11918","11919","11920","11921","11922","11923","11924","11925","11926","11927","11928","11929","11930","11931","11932","11933","11934","11935","11936","11937","11938","11939","11940","11941","11942","11943","11944","11945","11946","11947","11948","11949","11950","11951","11952","11953","11954","11955","11956","11957","11958","11959","11960","11961","11962","11963","11964","11965","11966","11967","11968","11969","11970","11971","11972","11973","11974","11975","11976","11977","11978","11979","11980","11981","11982","11983","11984","11985","11986","11987","11988","11989","11990","11991","11992","11993","11994","11995","11996","11997","11998","11999","12000","12001"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Attempt to export traceability in EXCEL format with defectList and invalid versionId
	@Test(priority = 25)
	public void test25_AttemptToExportTraceabilityInExcelFormatWithDefectidlistAndInvalidVersionid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "excel";
		versionId = 99l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//	Attempt to export traceability in EXCEL format with requirementList and invalid versionId
	@Test(priority = 26)
	public void test26_AttemptToExportTraceabilityInExcelFormatWithRequirementidlistAndInvalidVersionid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"10237"};
		exportType = "excel";
		versionId = 99l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Attempt to export traceability in EXCEL format with invalid defectList
	@Test(priority = 27)
	public void test27_AttemptToExportTraceabilityInExcelFormatWithInvalidDefectidlist(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"99","98"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Attempt to export traceability in EXCEL format with invalid requirementList
	@Test(priority = 28)
	public void test28_AttemptToExportTraceabilityInExcelFormatWithInvalidRequirementidlist(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] requirementIdList = {"99","98"};
		exportType = "excel";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setRequirementIdList(requirementIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//	Attempt to export traceability by passing invalid exportType
	@Test(priority = 29)
	public void test29_AttemptToExportTraceabilityByPassingInvalidExporttype(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "zzzz";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//  Attempt to export traceability without passing exportType
	@Test(priority = 30)
	public void test30_AttemptToExportTraceabilityWithoutPassingExporttype(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setDefectIdList(defectIdList);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//  Attempt to export traceability without passing versionId
	//TODO
	//FIXME
	@Test(priority = 31)
	public void test31_AttemptToExportTraceabilityWithoutPassingVersionid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String[] defectIdList = {"10239"};
		exportType = "html";

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setDefectIdList(defectIdList);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		System.out.println(fileName);
		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

	//  Attempt to export traceability without passing defectIdList and requirementIdList
	//TODO
	//FIXME
	@Test(priority = 32)
	public void test32_AttemptToExportTraceabilityWithoutPassingDefectidlistAndRequirementidlist(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		exportType = "html";
		versionId = 0l;

		ExportTraceability payload = new ExportTraceability();
		payload.setExportType(exportType);
		payload.setVersionId(versionId);
		System.out.println(payload.toString());

		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payload.toString());
		Assert.assertNotNull(response, "ExportTraceability Api Response is null.");
		test.log(LogStatus.PASS, "ExportTraceability Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		//		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();
		//		System.out.println(fileName);
		//		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		//		Assert.assertTrue(status);
		//		boolean status1 = zapiService.validateExportTraceabilityReport(fileName, exportType);
		//		Assert.assertTrue(status1, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		//		extentReport.endTest(test);
	}

}
