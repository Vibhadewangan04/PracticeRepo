package com.thed.zephyr.regression.execution;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseOptions;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class AddTestsToCycleFromCycle extends BaseTest {

	String cycleId = null;
	String issueKey = null;
	Long versionId = null;
	Long componentId1 = null;
	Long componentId2 = null;
	private Long projectId = Long.parseLong(Config.getValue("projectId"));
	private Long projectId1 = Long.parseLong(Config.getValue("projectId1"));
	private Long issueId;
	Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
	Long issueTypeId1 = Long.parseLong(Config.getValue("issueTypeStoryId"));

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add tests to cycle from another
	 * cycle by passing cycle id and version id from the cycle containing the tests
	 * and the cycle id and version id of the cycle to which the tests are added
	 */

	@Test(priority = 1)
	public void addTestsToCycleFromCycle_Test1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status1 = jiraService.validateCreateIssueApi(createIssueresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		// issueId = Long.parseLong(new
		// JSONObject(createIssueresponse.body().asString()).get("id").toString());
		// get test issue id then pass in payload
		String issueid = new JSONObject(createIssueresponse.body().asString()).get("id").toString();
		System.out.println("qqqresponse" + createIssueresponse.toString());

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("AddTestsToCycleFromCycle");

		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse.toString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		String payLoad = "{\"issues\":[" + issueid + "],\"versionId\":" + versionId + ",\"projectId\":" + projectId
				+ ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

		String payLoad2 = "{\"issues\":[" + issueid + "],\"versionId\":" + versionId + ",\"projectId\":" + projectId
				+ ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle, to
	 * Adhoc in unscheduled version
	 */

	@Test(priority = 2)
	public void addTestsToCycleFromCycle_Test2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		System.out.println("issueResponse" + issueResponse.toString());

		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid = json.get("id").toString();

		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2 = json2.get("id").toString();

		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3 = json3.get("id").toString();

		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4 = json4.get("id").toString();

		System.out.println("issueresponse is  " + issueResponse.toString());

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("AddTestsToCycleFromCycle");

		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse.toString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		String payLoad = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		/*
		 * Cycle cycleJson2 = new Cycle();
		 * cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		 * cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		 * cycleJson2.setName("taken test from another cycle");
		 * 
		 * Response createCycleresponse2 = zapiService.createCycle(jwtGenerator,
		 * cycleJson2.toString()); Assert.assertNotNull(createCycleresponse2,
		 * "Create Cycle Api Response is null."); test.log(LogStatus.PASS,
		 * "Create Cycle Api executed successfully.");
		 * 
		 * System.out.println("qqq2response"+ createCycleresponse2.toString());
		 * 
		 * boolean status21 = zapiService.validateCycle(cycleJson2.toString(),
		 * createCycleresponse2); Assert.assertTrue(status21,
		 * "Response Validation Failed."); test.log(LogStatus.PASS,
		 * "Response validated successfully."); String cycleId2 = new
		 * JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		 * System.out.println("cycleIDresponse" + cycleId2);
		 */

		String cycleId2 = "-1";
		String payLoad2 = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad2 = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId +
		// ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another cycle, to
	 * non-adhoc in unscheduled version
	 */
	@Test(priority = 3)
	public void addTestsToCycleFromCycle_Test3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		System.out.println("issueResponse" + issueResponse.toString());

		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid = json.get("id").toString();

		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2 = json2.get("id").toString();

		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3 = json3.get("id").toString();

		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4 = json4.get("id").toString();

		System.out.println("issueresponse is  " + issueResponse.toString());

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("AddTestsToCycleFromCycle");

		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse.toString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		String payLoad = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

		String payLoad2 = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from Adhoc to a
	 * non-adhoc cycle in Unscheduled version
	 */
	@Test(priority = 4)
	public void addTestsToCycleFromCycle_Test4() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		System.out.println("issueResponse" + issueResponse.toString());

		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid = json.get("id").toString();

		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2 = json2.get("id").toString();

		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3 = json3.get("id").toString();

		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4 = json4.get("id").toString();

		System.out.println("issueresponse is  " + issueResponse.toString());

		/*
		 * Cycle cycleJson = new Cycle();
		 * cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		 * cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		 * cycleJson.setName("AddTestsToCycleFromCycle");
		 * 
		 * Response createCycleresponse = zapiService.createCycle(jwtGenerator,
		 * cycleJson.toString()); Assert.assertNotNull(createCycleresponse,
		 * "Create Cycle Api Response is null."); test.log(LogStatus.PASS,
		 * "Create Cycle Api executed successfully.");
		 * 
		 * System.out.println("qqq2response"+ createCycleresponse.toString());
		 * 
		 * boolean status2 = zapiService.validateCycle(cycleJson.toString(),
		 * createCycleresponse); Assert.assertTrue(status2,
		 * "Response Validation Failed."); test.log(LogStatus.PASS,
		 * "Response validated successfully."); String cycleId = new
		 * JSONObject(createCycleresponse.body().asString()).get("id").toString();
		 * System.out.println("cycleIDresponse" + cycleId);
		 */

		String cycleId = "-1";
		String payLoad = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

		String payLoad2 = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle, to
	 * Adhoc in a selected version
	 */
	@Test(priority = 5)
	public void addTestsToCycleFromCycle_Test5() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		System.out.println("issueResponse" + issueResponse.toString());

		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid = json.get("id").toString();

		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2 = json2.get("id").toString();

		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3 = json3.get("id").toString();

		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4 = json4.get("id").toString();

		System.out.println("issueresponse is  " + issueResponse.toString());

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("AddTestsToCycleFromCycle");

		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse.toString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		String payLoad = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		/*
		 * Cycle cycleJson2 = new Cycle();
		 * cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		 * cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		 * cycleJson2.setName("taken test from another cycle");
		 * 
		 * Response createCycleresponse2 = zapiService.createCycle(jwtGenerator,
		 * cycleJson2.toString()); Assert.assertNotNull(createCycleresponse2,
		 * "Create Cycle Api Response is null."); test.log(LogStatus.PASS,
		 * "Create Cycle Api executed successfully.");
		 * 
		 * System.out.println("qqq2response"+ createCycleresponse2.toString());
		 * 
		 * boolean status21 = zapiService.validateCycle(cycleJson2.toString(),
		 * createCycleresponse2); Assert.assertTrue(status21,
		 * "Response Validation Failed."); test.log(LogStatus.PASS,
		 * "Response validated successfully."); String cycleId2 = new
		 * JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		 * System.out.println("cycleIDresponse" + cycleId2);
		 */

		String cycleId2 = "-1";
		String payLoad2 = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another cycle, to
	 * cycle in a scheduled version
	 */
	@Test(priority = 6)
	public void addTestsToCycleFromCycle_Test6() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		System.out.println("issueResponse" + issueResponse.toString());

		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid = json.get("id").toString();

		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2 = json2.get("id").toString();

		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3 = json3.get("id").toString();

		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4 = json4.get("id").toString();

		System.out.println("issueresponse is  " + issueResponse.toString());

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson.setName("AddTestsToCycleFromCycle");

		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse.toString());

		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		String payLoad = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

		String payLoad2 = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from Adhoc to a
	 * non-adhoc cycle in a scheduled version
	 */
	// @Test(priority = 7)
	public void addTestsToCycleFromCycle_Test7() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		System.out.println("issueResponse" + issueResponse.toString());

		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid = json.get("id").toString();

		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2 = json2.get("id").toString();

		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3 = json3.get("id").toString();

		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4 = json4.get("id").toString();

		System.out.println("issueresponse is  " + issueResponse.toString());

		/*
		 * Cycle cycleJson = new Cycle();
		 * cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		 * cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		 * cycleJson.setName("AddTestsToCycleFromCycle");
		 * 
		 * Response createCycleresponse = zapiService.createCycle(jwtGenerator,
		 * cycleJson.toString()); Assert.assertNotNull(createCycleresponse,
		 * "Create Cycle Api Response is null."); test.log(LogStatus.PASS,
		 * "Create Cycle Api executed successfully.");
		 * 
		 * System.out.println("qqq2response"+ createCycleresponse.toString());
		 * 
		 * boolean status2 = zapiService.validateCycle(cycleJson.toString(),
		 * createCycleresponse); Assert.assertTrue(status2,
		 * "Response Validation Failed."); test.log(LogStatus.PASS,
		 * "Response validated successfully."); String cycleId = new
		 * JSONObject(createCycleresponse.body().asString()).get("id").toString();
		 * System.out.println("cycleIDresponse" + cycleId);
		 */

		String cycleId = "-1";
		String payLoad = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

		String payLoad2 = "{\"issues\":[" + issueid + "," + issueid2 + "," + issueid3 + "," + issueid4
				+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		// String payLoad = "{\"issues\":[+
		// issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
		// String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +
		// "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status22 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status22, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle,
	 * Filter by by Version, Cycle and Priority
	 * (Blocker/Critical/Major/Minor/Trivial)
	 */

	@Test(priority = 8)
	public void addTestsToCycleFromCycle_Test8() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		JSONArray fixVersions = new JSONArray();
		fixVersions.put(Config.getValue("versionOneId"));
		fixVersions.put(Config.getValue("versionTwoId"));
		issuePayLoad.setFixVersions(fixVersions);
		/*JSONArray labels = new JSONArray();
			labels.put("label1");
		labels.put("label2");
		labels.put("label3");
		issuePayLoad.setLabels(labels);*/

		int numberOfExecutions = 3;
		System.out.println(issuePayLoad.toString());
		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());

	
	     JSONArray responseJson = new JSONArray(issueResponse); JSONObject json = new
		  JSONObject(issueResponse.get(0).toString()); String issueid=
		  json.get("id").toString();
		 
		  
		  JSONObject json2 = new JSONObject(issueResponse.get(1).toString()); String
		  issueid2= json2.get("id").toString();
		  
		  JSONObject json3 = new JSONObject(responseJson.get(2).toString()); String
		  issueid3= json3.get("id").toString();
		 
	//	 JSONObject json4 = new JSONObject(responseJson.get(3).toString()); String
	//	  issueid4= json4.get("id").toString();
		 
		  System.out.println("issueresponse is  " + issueResponse.toString());
		 
		  Cycle cycleJson = new Cycle();
		  cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		  cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		  cycleJson.setName("AddTestsToCycle1");
		 
		  Response createCycleresponse = zapiService.createCycle(jwtGenerator,
		  cycleJson.toString()); Assert.assertNotNull(createCycleresponse,
		  "Create Cycle Api Response is null."); test.log(LogStatus.PASS,
		  "Create Cycle Api executed successfully.");
		  
		  System.out.println("qqq2response"+ createCycleresponse.toString());
		  
		  boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		  Assert.assertTrue(status2,  "Response Validation Failed."); 
		  test.log(LogStatus.PASS, "Response validated successfully."); 
		  String cycleId1 = new  JSONObject(createCycleresponse.body().asString()).get("id").toString();
		  System.out.println("cycleIDresponse" + cycleId1);

	//	 String priorities = "1,3,4"; 
		 String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\" ,\" Priorities\" : \"1,3,4\"}";
		 
		 // String payLoad =  "{\"issues\":[+ issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}" ; - wrong 
		  // String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +  "],\"versionId\":-1,\"projectId\":10003,\" Priorities\" : "1,3, 4"  \"method\":\"1\"}"; 
		  Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId1, payLoad);
		 Assert.assertNotNull(response, "Create Execution Api Response is null.");
		  test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		  boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		  Assert.assertTrue(status, "Response Validation Failed.");
		  test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
		  
			Cycle cycleJson2 = new Cycle();
			cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson2.setName("taken test from another cycle");

			Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
			Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

			System.out.println("qqq2response" + createCycleresponse2.toString());

			boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
			Assert.assertTrue(status21, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
			System.out.println("cycleIDresponse" + cycleId2);
	
// String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\"}";
	//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
	Assert.assertNotNull(response2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response2.getBody().asString());
	
	boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
	Assert.assertTrue(status22, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);		 
	}
	/**
	 * Created by debadatta.kathar on 25-Nov-2016
	 * Add Tests from another Cycle, Filter by by  Version, Cycle and Execution Status (Pass/Fail/WIP/Blocked)
	 */
	
	
	@Test(priority = 9)
	public void addTestsToCycleFromCycle_Test9(){

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\"}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
}
	
	/**
	 * Created by debadatta.kathar on 25-Nov-2016
	 * Manual - Add Tests from another Cycle, Filter by by  Version, Cycle and Component 
	 */
	@Test(priority = 10)
	public void addTestsToCycleFromCycle_Test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
	//	componentId1
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		JSONArray fixVersions = new JSONArray();
		fixVersions.put(Config.getValue("versionOneId"));
		fixVersions.put(Config.getValue("versionTwoId"));
		issuePayLoad.setFixVersions(fixVersions);
		/*JSONArray labels = new JSONArray();
			labels.put("label1");
		labels.put("label2");
		labels.put("label3");
		issuePayLoad.setLabels(labels);*/
		
		
		int numberOfExecutions = 3;
		System.out.println(issuePayLoad.toString());
		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());

	
	     JSONArray responseJson = new JSONArray(issueResponse); JSONObject json = new
		  JSONObject(issueResponse.get(0).toString()); String issueid=
		  json.get("id").toString();
		 
		  
		  JSONObject json2 = new JSONObject(issueResponse.get(1).toString()); String
		  issueid2= json2.get("id").toString();
		  
		  JSONObject json3 = new JSONObject(responseJson.get(2).toString()); String
		  issueid3= json3.get("id").toString();
		 
	//	 JSONObject json4 = new JSONObject(responseJson.get(3).toString()); String
	//	  issueid4= json4.get("id").toString();
		 
		  System.out.println("issueresponse is  " + issueResponse.toString());
		 
		  Cycle cycleJson = new Cycle();
		  cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		  cycleJson.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		  cycleJson.setName("AddTestsToCycle1");
		 
		  Response createCycleresponse = zapiService.createCycle(jwtGenerator,
		  cycleJson.toString()); Assert.assertNotNull(createCycleresponse,
		  "Create Cycle Api Response is null."); test.log(LogStatus.PASS,
		  "Create Cycle Api executed successfully.");
		  
		  System.out.println("qqq2response"+ createCycleresponse.toString());
		  
		  boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		  Assert.assertTrue(status2,  "Response Validation Failed."); 
		  test.log(LogStatus.PASS, "Response validated successfully."); 
		  String cycleId1 = new  JSONObject(createCycleresponse.body().asString()).get("id").toString();
		  System.out.println("cycleIDresponse" + cycleId1);
	
		  
		  
	//	 String priorities = "1,3,4"; 
		 String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
		 
		 // String payLoad =  "{\"issues\":[+ issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}" ; - wrong 
		  // String payLoad = "{\"issues\":["+ issueid + "," + issueid2 +  "],\"versionId\":-1,\"projectId\":10003,\" Priorities\" : "1,3, 4"  \"method\":\"1\"}"; 
		  Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId1, payLoad);
		 Assert.assertNotNull(response, "Create Execution Api Response is null.");
		  test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		  boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		  Assert.assertTrue(status, "Response Validation Failed.");
		  test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 extentReport.endTest(test);
		  
			Cycle cycleJson2 = new Cycle();
			cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson2.setName("taken test from another cycle");

			Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
			Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

			System.out.println("qqq2response" + createCycleresponse2.toString());

			boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
			Assert.assertTrue(status21, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
			System.out.println("cycleIDresponse" + cycleId2);
	
// String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"components\":" + componentId1 + "}";
	//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
	Assert.assertNotNull(response2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response2.getBody().asString());
	
	boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
	Assert.assertTrue(status22, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test); 
	}
	

	/**
	 * Created by debadatta.kathar on 25-Nov-2016
	 * Add Tests from another Cycle Filter by Version, Cycle and Linked Defects
	 */
	
	 @Test(priority = 11)
	public void addTestsToCycleFromCycle_Test11() {

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long versionId = Long.parseLong(Config.getValue("unscheduleId"));
			// implement cycle with test executed schedules having defect
			// links/comments/component/label
			int numberOfExecutions = 2;

			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(versionId);
			cycleJson.setName("Move Cycle");
			cycleJson.setDescription("Cycle moved");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

			// Creating tests
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(issueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			
			//create defect to link		
			issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			//
			boolean issueStatus = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
			List<Long> defectsList = new ArrayList<>();
			defectsList.add(bugId);
			
		
			//create executions
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
			executionJson.setVersionId(versionId);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);
			System.out.println(executionJson.toString());

			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId = issueIds.get(j);
				executionJson.setIssueId(issueId);
				executionJson.setDefects(defectsList);
				System.out.println(issueId);
				executionJson.setStatusId(2l);
				executionJson.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
			
			Cycle cycleJson2 = new Cycle();
			cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson2.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
			cycleJson2.setName("taken test from another cycle");

			Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
			Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println("qqq2response" + createCycleresponse2.toString());

			boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
			Assert.assertTrue(status21, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
			System.out.println("cycleIDresponse" + cycleId2);

	//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\"hasDefects\":true }";
	//String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\" ,\"hasDefects\":true }";
	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\" ,\"assigneeType\":\"currentUser\" }";
//		String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//		String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
	Assert.assertNotNull(response2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response2.getBody().asString());

	boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
	Assert.assertTrue(status22, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
			
	 }
	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Blocker/Critical/Major/Minor/Trivial) and Execution
	 * Status
	 */
		@Test(priority = 12)
		public void addTestsToCycleFromCycle_Test12(){

			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long versionId = Long.parseLong(Config.getValue("versionFourId"));
			// implement cycle with test executed to different statuses
			int numberOfExecutions = 3;

			/*Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(versionId);
			cycleJson.setName("cycle having partial exec");
			cycleJson.setDescription("Cycle for export");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

			String cycleId = "-1";
			
			List<Long> issueIds = new ArrayList<>() ;
			for(int i=1; i<4;i++)
			{
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			
			String priority = ""+ i ;
			issuePayLoad.setPriority(priority);
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			
			Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
			Assert.assertTrue(statuss, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
			
			issueIds.add(issueId);
			/*//JSONArray jsarray = new JSONArray(Createtestresponse);
			JSONObject js = new JSONObject(Createtestresponse);
			for(int j= 0;j<js.length();j++){
		
		    	Long l= Long.parseLong(js.get("id").toString());
				issueIds.add(l);
			}*/
			
			
			System.out.println("*****"+issueIds);
						
			
			}
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(issueIds);
			executionJson.setVersionId(versionId);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);
			System.out.println(executionJson.toString());
			
			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId = issueIds.get(j);
				executionJson.setIssueId(issueId);
				System.out.println(issueId);
				long StatusId = j+1;
				executionJson.setStatusId(StatusId);
				executionJson.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
						
			Cycle cycleJson2 = new Cycle();
			cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson2.setName("taken test from another cycle");

			Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
			Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println("qqq2response" + createCycleresponse2.toString());

			boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
			Assert.assertTrue(status21, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
			System.out.println("cycleIDresponse" + cycleId2);

	//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\"}";
//		String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//		String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
	Assert.assertNotNull(response2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response2.getBody().asString());

	boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
	Assert.assertTrue(status22, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Blocker/Critical/Major/Minor/Trivial) and Component
	 * 
	 */
	 
	@Test(priority = 13)
	public void addTestsToCycleFromCycle_Test13(){

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		/*Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		String cycleId = "-1";
		
		List<Long> issueIds = new ArrayList<>() ;
		for(int i=1; i<4;i++)
		{
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		
		String priority = ""+ i ;
		issuePayLoad.setPriority(priority);
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		
		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(statuss, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		issueIds.add(issueId);
		System.out.println("*****"+issueIds);
		}
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(issueIds);
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
	
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\"}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
}
 
	

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Blocker/Critical/Major/Minor/Trivial) and Linked Defects
	 * 
	 */
	 @Test(priority = 14)
	public void addTestsToCycleFromCycle_Test14() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
	//	componentId1 = Long.parseLong(Config.getValue("componentId1"));
	//	componentId2 = Long.parseLong(Config.getValue("componentId2"));
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle craeted to take execution form this cycle");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

	//	String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		List<Long> issueIds = new ArrayList<>() ;
		for(int i=1; i<4;i++) //if user wants priority - Highest,High then he can start loop from 1
		{
	//	Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		String priority = ""+ i ;
		issuePayLoad.setPriority(priority);
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		
		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(statuss, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		issueIds.add(issueId);
		System.out.println("*****"+issueIds);
		}	
		
		/*// Creating tests
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(String.valueOf(ProjectID));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));

					List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
					Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
					test.log(LogStatus.PASS, "Issue created successfully.");
					
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(issueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					}
					System.out.println("*****"+issueIds);*/
					
					//create defect to link		
					issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
					issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
							
					Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
					Assert.assertNotNull(response, "Create Issue Api Response is null.");
					//
					boolean issueStatus = jiraService.validateCreateIssueApi(response);
					Assert.assertTrue(issueStatus, "Response Validation Failed.");
					Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
					List<Long> defectsList = new ArrayList<>();
					defectsList.add(bugId);
					
				
					//create executions
					Execution executionJson = new Execution();
					executionJson.setStatusId(-1l);
					executionJson.setProjectId(ProjectID);
					executionJson.setIssueIds(issueIds);
					executionJson.setVersionId(versionId);
					executionJson.setNoOfExecutions(numberOfExecutions);
					executionJson.setCycleId(cycleId);
					System.out.println(executionJson.toString());
					
					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS,
							"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
					
					List<String> exeIds = new ArrayList<>() ;
					JSONArray jsarray2 = new JSONArray(executionResponse.toString());
					System.out.println("length="+jsarray2.length());
					for (int j=0;j<jsarray2.length();j++){
						JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
						String exeid =jsobj2.getJSONObject("execution").get("id").toString();
						exeIds.add(exeid);
						Long issueId = issueIds.get(j);
						executionJson.setIssueId(issueId);
						System.out.println(issueId);
						executionJson.setDefects(defectsList);
						long StatusId = j+1;
						executionJson.setStatusId(StatusId);
						executionJson.setExecutionId(exeid);
						

		}
					
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"priorities\":\"1,2,3\" ,\"hasDefects\":true }";
//String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"priorities\":\"1,2,3\" }";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Blocker/Critical/Major/Minor/Trivial), Execution status
	 * and Component
	 * 
	 */
	
	@Test(priority = 15)
	public void addTestsToCycleFromCycle_Test15(){

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

	//	String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		List<Long> issueIds = new ArrayList<>() ;
		for(int i=1; i<4;i++)
		{
		//Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		String priority = ""+ i ;
		issuePayLoad.setPriority(priority);
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		
		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(statuss, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		issueIds.add(issueId);
		System.out.println("*****"+issueIds);		
		}
		
		
		//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(issueIds);
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
					
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
}
	


	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Highest,High, Medium, Low, Lowest), Execution status and
	 * Linked Defects
	 */
	  @Test(priority = 16)
	public void addTestsToCycleFromCycle_Test16() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle to take execution to another cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(issueIds);
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setDefects(defectsList);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
			
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
//String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\"}";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"hasDefects\":true }";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Highest,High, Medium, Low, Lowest)), Execution status,
	 * Component and Linked Defects
	 */
	 @Test(priority = 17)
	public void addTestsToCycleFromCycle_Test17() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle to take execution to another cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		List<Long> issueIds = new ArrayList<>() ;
		for(int i=1; i<4;i++)
		{
		//Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		String priority = ""+ i ;
		issuePayLoad.setPriority(priority);
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		
		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(statuss, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		issueIds.add(issueId);
		/*//JSONArray jsarray = new JSONArray(Createtestresponse);
		JSONObject js = new JSONObject(Createtestresponse);
		for(int j= 0;j<js.length();j++){
	
	    	Long l= Long.parseLong(js.get("id").toString());
			issueIds.add(l);
		}*/
		
		
		System.out.println("*****"+issueIds);		
		}
	
		
	//	Issue issuePayLoad = null;
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(issueIds);
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setDefects(defectsList);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
			
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
//String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\"}";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"hasDefects\":true  ,\"priorities\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Priority (Highest,High, Medium, Low, Lowest), Component and status
	 */

	
	@Test(priority = 18)
	public void addTestsToCycleFromCycle_Test18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

	//	String cycleId = "-1";
		
		List<Long> issueIds = new ArrayList<>() ;
		for(int i=3; i<6;i++) //if user wants priority - Highest,High then he can start loop from 1
		{
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		String priority = ""+ i ;
		issuePayLoad.setPriority(priority);
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		
		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(statuss, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		issueIds.add(issueId);
		System.out.println("*****"+issueIds);
					
		
		}
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(issueIds);
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
					
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Execution Status and Component 
	 */
	
	 @Test(priority = 19)
		public void addTestsToCycleFromCycle_Test19() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
//String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}
	
		

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Execution Status and Component
	 */
	 @Test(priority = 20)
	public void addTestsToCycleFromCycle_Test20() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Execution Status and Linked Defects
	 */
	
	 @Test(priority = 21)
		public void addTestsToCycleFromCycle_Test21() {
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			Long ProjectID = Long.parseLong(Config.getValue("projectId"));
			Long versionId = Long.parseLong(Config.getValue("versionFourId"));
			// implement cycle with test executed schedules having defect
			// links/comments/component/label
			int numberOfExecutions = 2;

			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(ProjectID);
			cycleJson.setVersionId(versionId);
			cycleJson.setName("Cycle to take execution to another cycle");
			cycleJson.setDescription("Cycle moved");

			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

			// Creating tests
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(ProjectID));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			
			List<Long> issueIds = new ArrayList<>() ;
			JSONArray jsarray = new JSONArray(issueResponse);
			for(int i= 0;i<jsarray.length();i++){
		
				JSONObject jsobj = new JSONObject(jsarray.getString(i));
				Long l= Long.parseLong(jsobj.get("id").toString());
				issueIds.add(l);
			}
			System.out.println("*****"+issueIds);
			
			//create defect to link		
			issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
			issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			//
			boolean issueStatus = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
			List<Long> defectsList = new ArrayList<>();
			defectsList.add(bugId);
			
		
			//create executions
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(ProjectID);
			executionJson.setIssueIds(issueIds);
			executionJson.setVersionId(versionId);
			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setCycleId(cycleId);
			System.out.println(executionJson.toString());
			
			JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS,
					"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId = issueIds.get(j);
				executionJson.setIssueId(issueId);
				System.out.println(issueId);
				executionJson.setDefects(defectsList);
				long StatusId = j+1;
				executionJson.setStatusId(StatusId);
				executionJson.setExecutionId(exeid);
				
				////update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}
				
			Cycle cycleJson2 = new Cycle();
			cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
			cycleJson2.setName("taken test from another cycle");

			Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
			Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			System.out.println("qqq2response" + createCycleresponse2.toString());

			boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
			Assert.assertTrue(status21, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
			System.out.println("cycleIDresponse" + cycleId2);

	//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\"}";
	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2\" ,\"hasDefects\":true }";
//		String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//		String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
	Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
	Assert.assertNotNull(response2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response2.getBody().asString());

	boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
	Assert.assertTrue(status22, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);

		}
	 
	 
	 
	 
	 
	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle,
	 * Filter by Execution Status, Component and Linked Defects
	 */
   @Test(priority = 22)
	public void addTestsToCycleFromCycle_Test22() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle to take execution to another cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"hasDefects\":true,\"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Component, Linked Defects
	 */
	 @Test(priority = 23)
	public void addTestsToCycleFromCycle_Test23() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle to take execution to another cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);

		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\" ,\"hasDefects\":true,\"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by Linked Defects
	 */
	@Test(priority = 24)
	public void addTestsToCycleFromCycle_Test24() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle to take execution to another cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\"}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Add Tests from another Cycle
	 * Filter by more than 1-values  (ex:
	 * Priority=High, Low; Exec status=Pass,Fail etc.,)in filter criteria
	 */
	// @Test(priority = 25)
	public void addTestsToCycleFromCycle_Test25() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		componentId1 = Long.parseLong(Config.getValue("componentId1"));
		componentId2 = Long.parseLong(Config.getValue("componentId2"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

	//	String cycleId = "-1";
		
		List<Long> issueIds = new ArrayList<>() ;
		for(int i=3; i<6;i++) //if user wants priority - Highest,High then he can start loop from 1
		{
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		JSONArray components = new JSONArray();
		components.put(componentId1);
		components.put(componentId2);
		issuePayLoad.setComponents(components);
		String priority = ""+ i ;
		issuePayLoad.setPriority(priority);
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		
		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean statuss = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(statuss, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		
		issueIds.add(issueId);
		/*//JSONArray jsarray = new JSONArray(Createtestresponse);
		JSONObject js = new JSONObject(Createtestresponse);
		for(int j= 0;j<js.length();j++){
	
	    	Long l= Long.parseLong(js.get("id").toString());
			issueIds.add(l);
		}*/
		
		
		System.out.println("*****"+issueIds);
					
		
		}
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(issueIds);
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());
		
		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
					
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"priorities\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
//	String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
//	String payLoad2 = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"projectId\":10200,\"method\":\"3\",\"assigneeType\":\"currentUser\",\"statuses\":\"1,2,3,4\"}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add Tests from another
	 * Cycle if there is no list of matches for selected criteria
	 * Priority/Component/Label/Linked Defects
	 */
	
	
	 @Test(priority = 26)
		public void addTestsToCycleFromCycle_Test26() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");
	Long ProjectID = Long.parseLong(Config.getValue("projectId"));
	Long versionId = Long.parseLong(Config.getValue("versionFourId"));
	//Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
	// implement cycle with test executed to different statuses
	int numberOfExecutions = 3;

	Cycle cycleJson = new Cycle();
	cycleJson.setProjectId(ProjectID);
	cycleJson.setVersionId(versionId);
	cycleJson.setName("cycle having partial exec");
	cycleJson.setDescription("Cycle for export");

	Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
	Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
	test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
	boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
	Assert.assertTrue(status, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated successfully.");
	String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

	
	
	// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
			issuePayLoad.setSummary("Test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");
			int numberOfExecution = 3;

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecution);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");

			System.out.println("issueResponse" + issueResponse.toString());

			/*JSONArray responseJson = new JSONArray(issueResponse);
			JSONObject json = new JSONObject(issueResponse.get(0).toString());
			String issueid = json.get("id").toString();

			JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
			String issueid2 = json2.get("id").toString();

			JSONObject json3 = new JSONObject(responseJson.get(2).toString());
			String issueid3 = json3.get("id").toString();
	*/
	/*Issue issuePayLoad = new Issue();
	issuePayLoad.setProject(String.valueOf(projectId));
	issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
	issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
	issuePayLoad.setPriority("1");
	issuePayLoad.setReporter("admin");
	JSONArray components = new JSONArray();
	components.put(Config.getValue("componentId1"));
	components.put(Config.getValue("componentId2"));
	issuePayLoad.setComponents(components);*/
	

	
	List<Long> issueIds = new ArrayList<>() ;
	JSONArray jsarray = new JSONArray(issueResponse);
	for(int i= 0;i<jsarray.length();i++){

		JSONObject jsobj = new JSONObject(jsarray.getString(i));
		Long l= Long.parseLong(jsobj.get("id").toString());
		issueIds.add(l);
	}
	System.out.println("*****"+issueIds);

	//create executions
	Execution executionJson = new Execution();
	executionJson.setStatusId(-1l);
	executionJson.setProjectId(ProjectID);
	executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
	executionJson.setVersionId(versionId);
	executionJson.setNoOfExecutions(numberOfExecutions);
	executionJson.setCycleId(cycleId);
	System.out.println(executionJson.toString());

	JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
	Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS,
			"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
	
	List<String> exeIds = new ArrayList<>() ;
	JSONArray jsarray2 = new JSONArray(executionResponse.toString());
	System.out.println("length="+jsarray2.length());
	for (int j=0;j<jsarray2.length();j++){
		JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
		String exeid =jsobj2.getJSONObject("execution").get("id").toString();
		exeIds.add(exeid);
		Long issueId = issueIds.get(j);
		executionJson.setIssueId(issueId);
		System.out.println(issueId);
		long StatusId = j+1;
		executionJson.setStatusId(StatusId);
		executionJson.setExecutionId(exeid);
		
		/*////update executions
		Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
				executionJson.toString());
		Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
		System.out.println(updateExecutionResponse.getBody().asString());
		System.out.println("updated execution");*/
	}
	
	Cycle cycleJson2 = new Cycle();
	cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
	cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
	cycleJson2.setName("taken test from another cycle");

	Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
	Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
	test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

	System.out.println("qqq2response" + createCycleresponse2.toString());

	boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
	Assert.assertTrue(status21, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated successfully.");
	String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
	System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"hasDefects\":true,\"components\":" + componentId1 + "}";

Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
}	
	

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to Add tests to cycle,
	 * from another cycle if "toCycleId" is null
	 */
	// test will fail for now bcoz of this issue ZFJCLOUD-2595 scenario3
	 @Test(priority = 27)
	public void addTestsToCycleFromCycle_Test27() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);
	
	//	long projectId = 111l;
	//	long versionId2 = 111l;		
		
		String cycleId1 = null;
		
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to Add tests to cycle,
	 * from another cycle if "toCycleId" is null
	 */
	 @Test(priority = 28)
	public void addTestsToCycleFromCycle_Test28() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);
	
	//	long projectId = 111l;
	//	long versionId2 = 111l;		
		
		String cycleId21 = null;
		
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId21, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add tests to cycle,
	 * from another cycle, if "fromCycleId" is invalid
	 */
	// test will fail for now bcoz of this issue ZFJCLOUD-2595 scenario3
	 @Test(priority = 29)
	public void addTestsToCycleFromCycle_Test29() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);
	
	//	long projectId = 111l;
	//	long versionId2 = 111l;		
		
		String cycleId1 = "111";
		
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId1 +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add tests to cycle,
	 * from another cycle, if "fromVersionId" is invalid
	 */
	// @Test(priority = 30)
	public void addTestsToCycleFromCycle_Test30() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);
	
	//	long projectId = 111l;
		long versionId2 = 111l;
		
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId2+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add tests to cycle,
	 * from another cycle, if "ToCycleId" is invalid
	 */
	 @Test(priority = 31)
	public void addTestsToCycleFromCycle_Test31() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			/*////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");*/
		}
		
		/*Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);*/
	
	//	long projectId = 111l;
	//	long versionId2 = 111l;
		String cycleId2 = "111";
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add tests to cycle,
	 * from another cycle, if "toVersionId" is invalid
	 */
	 @Test(priority = 32)
	public void addTestsToCycleFromCycle_Test32() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);
	
	//	long projectId = 111l;
		long versionId2 = 111l;
		
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId2 + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);


	}

	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add tests to cycle,
	 * from another cycle, if "projectId" is invalid
	 */
	
	
	@Test(priority = 33)
	public void addTestsToCycleFromCycle_Test33() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

		long projectId = 111l;
		
//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}
	
	
	
	/**
	 * Created by debadatta.kathar on 25-Nov-2016 Attempt to add same test scheduled
	 * in adhoc to a non adhoc cycle, from another Cycle Filter by Execution Status,
	 * Components
	 */
	
	
	
	@Test(priority = 34)
	public void addTestsToCycleFromCycle_Test34() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionFourId"));
		Long componentId1 = Long.parseLong(Config.getValue("componentId1"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 3;

	/*	Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("cycle having partial exec");
		cycleJson.setDescription("Cycle for export");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

		
		String cycleId = "-1";
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test with component" + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		JSONArray components = new JSONArray();
		components.put(Config.getValue("componentId1"));
		components.put(Config.getValue("componentId2"));
		issuePayLoad.setComponents(components);
		

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(versionId);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		Cycle cycleJson2 = new Cycle();
		cycleJson2.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson2.setVersionId(Long.parseLong(Config.getValue("versionFourId")));
		cycleJson2.setName("taken test from another cycle");

		Response createCycleresponse2 = zapiService.createCycle(jwtGenerator, cycleJson2.toString());
		Assert.assertNotNull(createCycleresponse2, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		System.out.println("qqq2response" + createCycleresponse2.toString());

		boolean status21 = zapiService.validateCycle(cycleJson2.toString(), createCycleresponse2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId2 = new JSONObject(createCycleresponse2.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId2);

//String payLoad = "{\"issues\":["+ issueid + "," issueid2 "," + issueid3 + "," + issueid4 + "],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"  ,\" statuses\": \"1,2,3,4\" }";
String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response2, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response2.getBody().asString());

boolean status22= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status22, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

//String payLoad2 = "{\"versionId\":" + versionId + ", \"fromCycleId\":\""   +cycleId +  "\", \"fromVersionId\":" +versionId+",\"projectId\":" + projectId + ",\"method\":\"3\", \"statuses\":\"1,2,3\" ,\"components\":" + componentId1 + "}";
Response response21 = zapiService.addTestsTocycle(jwtGenerator, cycleId2, payLoad2);
Assert.assertNotNull(response21, "Create Execution Api Response is null.");
test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
System.out.println(response21.getBody().asString());
System.out.println("Attempt to add same test scheduled in adhoc to a non adhoc cycle - pass, only 1 time user is able to add same test");
boolean status3= zapiService.validateAddTestsToCycle(payLoad2, response2);
Assert.assertTrue(status3, "Response Validation Failed.");
test.log(LogStatus.PASS, "Response validated suuccessfully.");
extentReport.endTest(test);

	}
	
	

	// @Test(priority = 34444) old code
	public void addTestsToCycleFromCycle_Test34444() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Destination CycleId
		String cycleId = "0001479828784567-242ac111f-0001";

		String payLoad = "{\"versionId\":10300,\"fromVersionId\":\"10300\",\"fromCycleId\":\"-1\",\"projectId\":10200,\"components\":\"10200\",\"method\":\"3\",\"statuses\":\"1,2,3,4\",\"assigneeType\":\"currentUser\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		// 	String payLoad = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"priorities\":\"\",\"statuses\":\"\",\"components\":\"10200\",\"labels\":\"\",\"hasDefects\":false,\"projectId\":10200,\"method\":\"3\"}";
	//	String payLoad = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"0001479980766013-242ac1122-0001\",\"statuses\":\"1,2,3,4\",\"labels\":\"\",\"hasDefects\":true,\"projectId\":10200,\"method\":\"3\"}";
	//	String payLoad = "{\"versionId\":-1,\"fromVersionId\":\"-1\",\"fromCycleId\":\"-1\",\"priorities\":\"1,2,3\",\"statuses\":\"1,2\",\"components\":\"10200\",\"labels\":\"\",\"hasDefects\":false,\"projectId\":10200,\"method\":\"3\"}";
	}

}
