package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;


import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.CommonUtils;

public class UpdateExecutionCustomfield extends BaseTest{

	String cycleId = null;
	String issueKey = null;
	Long issueId = null;

	String cycleIdScheduledVersion = null;
	String cycleIdUnscheduledVersion = null;
	String executionObject = null;

	@BeforeClass
	public void beforeClass() {
     jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));

		}
    @BeforeMethod
	public void beforeMethod() {
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		//issuePayLoad.setparent(Config.getValue("issueKey"));
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		System.out.println(issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
	}


//Update the TextSingleLine customfield at execution level
     @Test(priority=1,enabled=testEnabled)
     public void test1(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String TextSingleLine = Config.getValue("TextSingleLine");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		//{"customFieldId":"04d63d4c-8773-4085-9ad5-47a59587585e","value":{"value":"rr"}}
	String payLoad="{\"customFieldId\":\""+TextSingleLine+"\",\"value\":{\"value\":\"SingleText\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
	
	}
       
  // Update the TextMultiLine customfield at execution level
     @Test(priority=2,enabled=testEnabled)
     public void test2(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String TextMultiLine = Config.getValue("TextMultiLine");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String Multiline="This resource represents issue link types. Use it to get, create, update, and delete link issue types as well as get lists of all link issue types.";
	String payLoad="{\"customFieldId\":\""+TextMultiLine+"\",\"value\":{\"value\":\""+Multiline+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
     
  // Update the Number customfield at execution level
     @Test(priority=3,enabled=testEnabled)
     public void test3(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String Number = Config.getValue("Number");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input="123";
	String payLoad="{\"customFieldId\":\""+Number+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
     
  // Update the Radiobutton customfield at execution level
     @Test(priority=4,enabled=testEnabled)
     public void test4(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String Radiobutton = Config.getValue("Radiobutton");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		//
		String input="option1";
	String payLoad="{\"customFieldId\":\""+Radiobutton+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
     // Update the Checkbox customfield at execution level
     @Test(priority=5,enabled=testEnabled)
     public void test5(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String Checkbox = Config.getValue("Checkbox");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		//
		String input="option1";
		//,"value":{"value":["option2"]}}
	String payLoad="{\"customFieldId\":\""+Checkbox+"\",\"value\":{\"value\":[\""+input+"\"]}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
  // Update the SelectSingleChoices customfield at execution level
     @Test(priority=6,enabled=testEnabled)
     public void test6(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String SelectSingleChoices = Config.getValue("SelectSingleChoices");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		//
		String input="option1";
		//,"value":{"value":["option2"]}}
	String payLoad="{\"customFieldId\":\""+SelectSingleChoices+"\",\"value\":{\"value\":[\""+input+"\"]}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
  // Update the SelectMultiChoices customfield at execution level
     @Test(priority=7,enabled=testEnabled)
     public void test7(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String SelectMultiChoices = Config.getValue("SelectMultiChoices");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		//
		String input1="option1";
		String input2="option2";
		//,"value":{"value":["option2"]}}
	String payLoad="{\"customFieldId\":\""+SelectMultiChoices+"\",\"value\":{\"value\":[\""+input1+"\",\""+input2+"\"]}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
  // Update the DatePicker customfield at execution level
     @Test(priority=8,enabled=testEnabled)
     public void test8(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String DatePicker = Config.getValue("DatePicker");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input1="07/10/2019";
		
		//,"value":{"value":["option2"]}}
	String payLoad="{\"customFieldId\":\""+DatePicker+"\",\"value\":{\"value\":\""+input1+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

  // Update the TimePicker customfield at execution level
     @Test(priority=9,enabled=testEnabled)
     public void test9(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String TimePicker = Config.getValue("TimePicker");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input1="07/10/2019 01:00:00";
		
		//,"value":{"value":["option2"]}}
	String payLoad="{\"customFieldId\":\""+TimePicker+"\",\"value\":{\"value\":\""+input1+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

     // Update the Negative Number customfield at execution level
     @Test(priority=10,enabled=testEnabled)
     public void test10(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String Number = Config.getValue("Number");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input="-10";
	String payLoad="{\"customFieldId\":\""+Number+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
     // Update the Decimal number in  Number customfield at execution level
     @Test(priority=11,enabled=testEnabled)
     public void test11(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String Number = Config.getValue("Number");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input="2.456";
	String payLoad="{\"customFieldId\":\""+Number+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
     //Attempt to Update the text in  Number customfield at execution level
     @Test(priority=12,enabled=testEnabled)
     public void test12(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String Number = Config.getValue("Number");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input="a";
	String payLoad="{\"customFieldId\":\""+Number+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateinvalidExecutionCustomfield(response,executionId);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
  // Update the TextMultiLine customfield at execution level with special characters
     @Test(priority=13,enabled=testEnabled)
     public void test13(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String TextMultiLine = Config.getValue("TextMultiLine");
	//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String Multiline="!@$$$**&^*~!@";
	String payLoad="{\"customFieldId\":\""+TextMultiLine+"\",\"value\":{\"value\":\""+Multiline+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateupdateExecutionCustomfield(payLoad, response);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
  // Attempt to update customfield with invalid executionid
     @Test(priority=14,enabled=testEnabled)
     public void test14(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String TextSingleLine = Config.getValue("TextSingleLine");
	    String executionId ="0092b928-4007-1234";
		System.out.println("executionid"+executionId);
		//update execution
		String input="text";
	String payLoad="{\"customFieldId\":\""+TextSingleLine+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateinvalidExecutionCustomfield(response,executionId);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
  // Attempt to update date customfield with invalid format
     @Test(priority=15,enabled=testEnabled)
     public void test15(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
 		test.assignAuthor("Sneha");
 		String DatePicker = Config.getValue("DatePicker");
 		//create execution
 		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(-1l);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");

		String executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		System.out.println("executionid"+executionId);
		//update execution
		String input="2019/02/30";
	String payLoad="{\"customFieldId\":\""+DatePicker+"\",\"value\":{\"value\":\""+input+"\"}}";
	System.out.println("Payload of customfield "+payLoad);
	Response response=zapiService.updateExecutionCustomfield(jwtGenerator, executionId, payLoad);
	Assert.assertNotNull(response, "Update Execution Customfield Api Response is null.");
	test.log(LogStatus.PASS, "Update Execution Customfield  Api executed successfully.");
	System.out.println(response.getBody().asString());
	System.out.println(response.getStatusCode());
	//validation
	boolean status1 = zapiService.validateinvalidExecutionCustomfield(response,executionId);
	Assert.assertTrue(status1);
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
}