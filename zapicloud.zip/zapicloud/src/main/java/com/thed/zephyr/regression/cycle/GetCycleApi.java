/**
 * Created by manoj.behera on 16-Nov-2016.
 */
package com.thed.zephyr.regression.cycle;

import java.util.List;
import java.util.Random;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;

/**
 * @author manoj.behera 16-Nov-2016
 *
 */
public class GetCycleApi extends BaseTest {

	/**
	 * Get cycle if cycle created in UI
	 */
	@Test(priority = 1, enabled = false)
	public void reg1_getCycle_by_cycleId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setId("0001487576555600-242ac112-0001");

		Response response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get Unscheduled version Adhoc cycle details
	 * @author Created by manoj.behera on 20-Feb-2017.
	 */
	@Test(priority = 2, enabled = testEnabled)
	public void reg2_getCycle_scheduledVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Ad hoc");
		cycleJson.setId("-1");

		Response response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get Scheduled version Adhoc cycle details
	 * @author Created by manoj.behera on 20-Feb-2017.
	 */
	@Test(priority = 3, enabled = testEnabled)
	public void reg3_getCycle_unscheduledVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Ad hoc");
		cycleJson.setId("-1");

		Response response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get cycle created through API in Unscheduled version
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void reg4_getCycle_Adhoc() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create Cycle by Api");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = new JSONObject(response.body().asString()).get("id").toString();

		cycleJson.setId(cycleId);

		response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	/**
	 * Get cycle in scheduled version if no planned cycle is created
	 * @author Created by manoj.behera on 20-Feb-2017.
	 */
	@Test(priority = 5, enabled = testEnabled)
	public void reg5_getCycle_scheduledversion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create Cycle by Api");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = new JSONObject(response.body().asString()).get("id").toString();

		cycleJson.setId(cycleId);

		response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Cycle if  if cycle is fully executed
	 * @author Created by manoj.behera on 20-Feb-2017.
	 */
	@Test(priority = 6, enabled = testEnabled)
	public void reg6_getCycle_fullyExecuted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numberOfExecutions = 5;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create Cycle by Api");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		cycleJson.setId(cycleId);

		// Creating Issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		List<Long> issueList = CommonUtils.getListAsLong(issueResponse, "id");
		for (int i = 0; i < issueResponse.size(); i++) {
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(projectId);
			executionJson.setVersionId(versionId);
			executionJson.setIssueId(issueList.get(i));
			executionJson.setCycleId(cycleId);

			Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Create execution in scheduled version adhoc cycle(5 executions) successfully.");
			status = zapiService.validateExecution(executionJson.toString(), executionResponse);
			Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
			test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
			
			String executionId = new JSONObject(
					new JSONObject(executionResponse.getBody().asString()).get("execution").toString())
							.getString("id");
			
			executionJson.setStatusId(CommonUtils.getStatusId());
			executionJson.setExecutionId(executionId);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
			Assert.assertTrue(updateExecutionStatus, "UpdateExecution Response Validation Failed.");
		}
		
		response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get Cycle if  if cycle is partially executed
	 * @author Created by manoj.behera on 20-Feb-2017.
	 */
	@Test(priority = 7, enabled = testEnabled)
	public void reg7_getCycle_partiallyExecuted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numberOfExecutions = 5;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create Cycle by Api");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		cycleJson.setId(cycleId);

		// Creating Issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		List<Long> issueList = CommonUtils.getListAsLong(issueResponse, "id");
		for (int i = 0; i < issueResponse.size(); i++) {
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(projectId);
			executionJson.setVersionId(versionId);
			executionJson.setIssueId(issueList.get(i));
			executionJson.setCycleId(cycleId);

			Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Create execution in scheduled version adhoc cycle(5 executions) successfully.");
			status = zapiService.validateExecution(executionJson.toString(), executionResponse);
			Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
			test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
			
			String executionId = new JSONObject(
					new JSONObject(executionResponse.getBody().asString()).get("execution").toString())
							.getString("id");
			
			executionJson.setStatusId(CommonUtils.getStatusId("unexecuted", "default"));
			executionJson.setExecutionId(executionId);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
			Assert.assertTrue(updateExecutionStatus, "UpdateExecution Response Validation Failed.");
		}
		
		response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get cycle if some schedules are linked to Single/multiple defects
	 * @author Created by manoj.behera on 20-Feb-2017.
	 */
	@Test(priority = 8, enabled = testEnabled)
	public void reg8_getCycle_singleAndMultipleDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numberOfExecutions = 5;

		Issue issueBugPayLoad = new Issue();
		issueBugPayLoad.setProject(Config.getValue("projectId"));
		issueBugPayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issueBugPayLoad.setSummary("Summary " + System.currentTimeMillis());
		issueBugPayLoad.setPriority("1");
		issueBugPayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueBugListResponse = jiraService.createIssues(basicAuth, issueBugPayLoad.toString(), 2);
		Assert.assertNotNull(issueBugListResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create Cycle by Api");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		cycleJson.setId(cycleId);

		// Creating Issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		List<Long> issueList = CommonUtils.getListAsLong(issueResponse, "id");
		for (int i = 0; i < issueResponse.size(); i++) {
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(projectId);
			executionJson.setVersionId(versionId);
			executionJson.setIssueId(issueList.get(i));
			executionJson.setCycleId(cycleId);

			Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Create execution in scheduled version adhoc cycle(5 executions) successfully.");
			status = zapiService.validateExecution(executionJson.toString(), executionResponse);
			Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
			test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
			
			String executionId = new JSONObject(
					new JSONObject(executionResponse.getBody().asString()).get("execution").toString())
							.getString("id");
			
			executionJson.setStatusId(CommonUtils.getStatusId("unexecuted", "default"));
			executionJson.setExecutionId(executionId);
			executionJson.setDefects(CommonUtils.getListAsLong(issueBugListResponse, "id"));
			
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
			Assert.assertTrue(updateExecutionStatus, "UpdateExecution Response Validation Failed.");
		}
		
		response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get Cycle if  if cycle is partially executed with 100 executions
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 9, enabled = testEnabled)
	public void reg9_getCycle_partiallyExecuted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numberOfExecutions = 100;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create Cycle by Api");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");

		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		cycleJson.setId(cycleId);

		// Creating Issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		List<Long> issueList = CommonUtils.getListAsLong(issueResponse, "id");
		for (int i = 0; i < issueResponse.size(); i++) {
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(projectId);
//			executionJson.setIssueIds();
			executionJson.setVersionId(versionId);
//			executionJson.setNoOfExecutions(numberOfExecutions);
			executionJson.setIssueId(issueList.get(i));
			executionJson.setCycleId(cycleId);

			Response executionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Create execution in scheduled version adhoc cycle(5 executions) successfully.");
			status = zapiService.validateExecution(executionJson.toString(), executionResponse);
			Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
			test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
			
			String executionId = new JSONObject(
					new JSONObject(executionResponse.getBody().asString()).get("execution").toString())
							.getString("id");
			
			executionJson.setStatusId(CommonUtils.getStatusId("unexecuted", "default"));
			executionJson.setExecutionId(executionId);
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, executionId,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			boolean updateExecutionStatus = zapiService.validateExecution(executionJson.toString(), updateExecutionResponse);
			Assert.assertTrue(updateExecutionStatus, "UpdateExecution Response Validation Failed.");
		}
		
		response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get cycle if Version contains 50 cycles
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 10, enabled = testEnabled)
	public void reg10_getCycle_Withen50Cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numOfCycles = 50;
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create 50 Cycles by Api");

		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		int i = new Random().nextInt(response.length());
		JSONObject cycle = new JSONObject(response.get(i).toString());
		cycleJson.setId(cycle.get("id").toString());
		cycleJson.setName(cycle.get("name").toString());

		Response getCycleResponse = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(getCycleResponse.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), getCycleResponse);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get cycle if Version contains 500 cycles
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 11, enabled = false)
	public void reg11_getCycle_Withen500Cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numOfCycles = 500;
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create "+numOfCycles+" Cycles by Api");

		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		int i = new Random().nextInt(response.length());
		JSONObject cycle = new JSONObject(response.get(i).toString());
		cycleJson.setId(cycle.get("id").toString());
		cycleJson.setName(cycle.get("name").toString());

		Response getCycleResponse = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(getCycleResponse.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), getCycleResponse);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get cycle if Version contains 1000 cycles
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 12, enabled = false)
	public void reg12_getCycle_Withen1000Cycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		int numOfCycles = 1000;
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Create "+numOfCycles+" Cycles by Api");

		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), numOfCycles);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		int i = new Random().nextInt(response.length());
		JSONObject cycle = new JSONObject(response.get(i).toString());
		cycleJson.setId(cycle.get("id").toString());
		cycleJson.setName(cycle.get("name").toString());

		Response getCycleResponse = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(getCycleResponse.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), getCycleResponse);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Attempt to Get Cycle without providing project id
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void reg13_getCycle_Attempt_ProjectId_Null() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(null);
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setId("-1");
		cycleJson.setName("Ad hoc");
		
		Response response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Attempt to Get Cycle without providing version id
	 * @author Created by manoj.behera on 21-Feb-2017.
	 */
	@Test(priority = 14, enabled = testEnabled)
	public void reg14_getCycle_Attempt_VersionId_Null() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(null);
		cycleJson.setId("-1");
		cycleJson.setName("Ad hoc");

		Response response = zapiService.getCycle(jwtGenerator, cycleJson.getProjectId(), cycleJson.getVersionId(),
				cycleJson.getId());
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
