package com.thed.zephyr.regression.attachment;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;

public class DeleteAttachment extends BaseTest {

	/**
	 * Before executing the attachment Api , first download all different types
	 * of attachments from the specified location. Location :
	 * "\\192.168.100.203\share\Dev\ZFJCloud\API\"
	 */

	String cycleId = null;
	Long issueId = null;
	String teststepId = null;
	JSONObject teststepObj = null;
	String executionId = null;
	String stepResId = null;

	@BeforeClass
	public void beforeClass() {
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		System.out.println(issueId);
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
				teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
		System.out.println(teststepObj);
		teststepId = teststepObj.getString("id");

	}

	@BeforeMethod
	public void beforeMethod() {
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		// executionId = "0001479158020117-242ac1134-0001";
		// Long issueId = 10100l;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println(response.getBody().asString());
		JSONArray ja = new JSONObject(response.getBody().asString()).getJSONArray("stepResults");
		JSONObject stepres = ja.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
	}

	/**
	 * Delete attachment to execution
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 1, enabled = testEnabled)
	public void reg1_deleteTestAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachments to teststepresult in unscheduled version Ad hoc Cycle
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 2, enabled = testEnabled)
	public void reg2_deleteStepAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete multiple attachments from execution of same file type to entity
	 * exeution
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 3, enabled = testEnabled)
	public void reg3_deleteMultipleTestAttachments() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Multiple Attachments added successfully.");
		System.err.println(response);

		// Delete Multiple Attachements
		for (int i = 0; i < response.length(); i++) {
			JSONObject jsonObject = new JSONObject(response.get(i).toString());
			String testAattachmentId = jsonObject.getString("id");
			System.err.println(testAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);

	}

	/**
	 * Add multiple attachments to teststepresult of same file type to entity
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void reg4_deleteMultipleStepAttachments() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "multiple Attachments are added successfully.");
		System.err.println(response);

		// Delete Multiple Attachements
		for (int i = 0; i < response.length(); i++) {
			JSONObject jsonObject = new JSONObject(response.get(i).toString());
			String stepAattachmentId = jsonObject.getString("id");
			System.err.println(stepAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);
	}

	/**
	 * Add attachment to execution of .exe file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 5, enabled = testEnabled)
	public void reg5_deleteTestAttachment_exeFileType() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_exe.exe";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to execution of 10 MB file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 6, enabled = testEnabled)
	public void reg6_deleteTestAttachment_10mbFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_10mb.zip";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of no exetension file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 7, enabled = testEnabled)
	public void reg7_deleteTestAttachment_noExtentionFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_noextention";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .tif file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 8, enabled = testEnabled)
	public void reg8_deleteTestAttachment_tifFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_tif.tif";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of jpg file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 9, enabled = testEnabled)
	public void reg9_deleteTestAttachment_jpgFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_jpg.jpg";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of conf file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 10, enabled = testEnabled)
	public void reg10_deleteTestAttachment_confFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_conf.conf";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of odt file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 11, enabled = testEnabled)
	public void reg11_deleteTestAttachment_odtFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_odt.odt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of long name file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 12, enabled = testEnabled)
	public void reg12_deleteTestAttachment_longFileName() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "fileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileName_longfilename.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of png file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void reg13_deleteTestAttachment_pngFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .tar file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 14, enabled = testEnabled)
	public void reg14_deleteTestAttachment_tarFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_tar.tar";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .mp3 file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 15, enabled = testEnabled)
	public void reg15_deleteTestAttachment_mp3File() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_mp3.mp3";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .ods file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 16, enabled = testEnabled)
	public void reg16_deleteTestAttachment_odsFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_ods.ods";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .txt file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 17, enabled = testEnabled)
	public void reg17_deleteTestAttachment_txtFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_txt.txt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .xpi file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 18, enabled = testEnabled)
	public void reg18_deleteTestAttachment_xpiFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xpi.xpi";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .flv file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 19, enabled = testEnabled)
	public void reg19_deleteTestAttachment_flvFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_flv.flv";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of of .htm file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 20, enabled = testEnabled)
	public void reg20_deleteTestAttachment_flvFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_html.htm";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .xls file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 21, enabled = testEnabled)
	public void reg21_deleteTestAttachment_xlsFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xls.xls";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .flv file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 22, enabled = testEnabled)
	public void reg22_deleteTestAttachment_xlsxFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xlsx.xlsx";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .xml file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 23, enabled = testEnabled)
	public void reg23_deleteTestAttachment_xmlFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xml.xml";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to execution of .ppt file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 24, enabled = testEnabled)
	public void reg24_deleteTestAttachment_pptFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_ppt.ppt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .flv file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 25, enabled = testEnabled)
	public void reg25_deleteTestAttachment_sqlFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_sql.sql";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Add attachment to execution of .gif file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 26, enabled = testEnabled)
	public void reg26_deleteTestAttachment_gifFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_gif.gif";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to execution of .pdf file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 27, enabled = testEnabled)
	public void reg27_deleteTestAttachment_pdfFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_pdf.pdf";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to execution of file name having international character
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 28, enabled = testEnabled)
	public void reg28_deleteTestAttachment_internationalCharsFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		// Config.setValue("language", "ru");
		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "мгновенно переводит.txt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to execution of .bmp file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 29, enabled = testEnabled)
	public void reg29_deleteTestAttachment_bmpFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_bmp.bmp";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .exe file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 30, enabled = testEnabled)
	public void reg30_deleteStepAttachment_exeFileType() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_exe.exe";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of 10 MB file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 31, enabled = testEnabled)
	public void reg31_deleteStepAttachment_10mbFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_10mb.zip";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of no exetension file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 32, enabled = testEnabled)
	public void reg32_deleteStepAttachment_noExtentionFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_noextention";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .tif file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 33, enabled = testEnabled)
	public void reg33_deleteStepAttachment_tifFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_tif.tif";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of jpg file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 34, enabled = testEnabled)
	public void reg34_deleteStepAttachment_jpgFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_jpg.jpg";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of conf file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 35, enabled = testEnabled)
	public void reg35_deleteStepAttachment_confFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_conf.conf";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of odt file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 36, enabled = testEnabled)
	public void reg36_deleteStepAttachment_odtFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_odt.odt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of long name file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 37, enabled = testEnabled)
	public void reg37_deleteStepAttachment_longFileName() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "fileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileNamefileName_longfilename.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of png file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 38, enabled = testEnabled)
	public void reg38_deleteStepAttachment_pngFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .tar file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 39, enabled = testEnabled)
	public void reg39_deleteStepAttachment_tarFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_tar.tar";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .mp3 file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 40, enabled = testEnabled)
	public void reg40_deleteStepAttachment_mp3File() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_mp3.mp3";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .ods file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 41, enabled = testEnabled)
	public void reg41_deleteStepAttachment_odsFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_ods.ods";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .txt file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 42, enabled = testEnabled)
	public void reg42_deleteStepAttachment_txtFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_txt.txt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .xpi file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 43, enabled = testEnabled)
	public void reg43_deleteStepAttachment_xpiFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xpi.xpi";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .flv file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 44, enabled = testEnabled)
	public void reg44_deleteStepAttachment_flvFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_flv.flv";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of of .htm file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 45, enabled = testEnabled)
	public void reg45_deleteStepAttachment_flvFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_html.htm";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .xls file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 46, enabled = testEnabled)
	public void reg46_deleteStepAttachment_xlsFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xls.xls";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .flv file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 47, enabled = testEnabled)
	public void reg47_deleteStepAttachment_xlsxFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xlsx.xlsx";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .xml file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 48, enabled = testEnabled)
	public void reg48_deleteStepAttachment_xmlFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_xml.xml";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .ppt file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 49, enabled = testEnabled)
	public void reg49_deleteStepAttachment_pptFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_ppt.ppt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .flv file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 50, enabled = testEnabled)
	public void reg50_deleteStepAttachment_sqlFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_sql.sql";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .gif file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 51, enabled = testEnabled)
	public void reg51_deleteStepAttachment_gifFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_gif.gif";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .pdf file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 52, enabled = testEnabled)
	public void reg52_deleteStepAttachment_pdfFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_pdf.pdf";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of file name having international character
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 53, enabled = testEnabled)
	public void reg53_deleteStepAttachment_internationalCharsFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		// Config.setValue("language", "ko");
		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "이 확장은 전체 웹 페이지를 번역.txt";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachment to stepresult of .bmp file type
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 54, enabled = testEnabled)
	public void reg54_deleteStepAttachment_bmpFile() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment_bmp.bmp";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String stepAattachmentId = stepAattachmentObj.getString("id");

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Add attachments to execution in cycle unscheduled version
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 55, enabled = testEnabled)
	public void reg55_deleteTestAttachments_unscheduledVersion_scheduledCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle one created");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(response.body().asString()).get("id").toString();

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(versionId);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		String entityName = "execution";
		String entityId = executionId;
		String cycleId = "-1";
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response1 = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response1, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response1);
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		// Delete Multiple Attachements
		for (int i = 0; i < response1.length(); i++) {
			JSONObject jsonObject = new JSONObject(response1.get(i).toString());
			String testAattachmentId = jsonObject.getString("id");
			System.err.println(testAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);

	}

	/**
	 * Add attachments to execution in a cycle scheduled version
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 56, enabled = testEnabled)
	public void reg56_deleteTestAttachments_scheduledVersion_scheduledCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle one created");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(response.body().asString()).get("id").toString();

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(versionId);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");

		String entityName = "execution";
		String entityId = executionId;
		String cycleId = "-1";
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response1 = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response1, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response1);
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		// Delete Multiple Attachements
		for (int i = 0; i < response1.length(); i++) {
			JSONObject jsonObject = new JSONObject(response1.get(i).toString());
			String testAattachmentId = jsonObject.getString("id");
			System.err.println(testAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);

	}

	/**
	 * Add attachments to execution in a adhoc scheduled version
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 57, enabled = testEnabled)
	public void reg57_deleteTestAttachments_scheduledVersion_Adhoc() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response);
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		// Delete Multiple Attachements
		for (int i = 0; i < response.length(); i++) {
			JSONObject jsonObject = new JSONObject(response.get(i).toString());
			String testAattachmentId = jsonObject.getString("id");
			System.err.println(testAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);

	}

	/**
	 * Add attachments to stepResult in cycle unscheduled version
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 58, enabled = testEnabled)
	public void reg58_deleteStepAttachments_unscheduledVersion_scheduledCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle one created");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(response.body().asString()).get("id").toString();

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(versionId);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "get stepresult Api Response is null.");
		System.out.println(response.getBody().asString());
		JSONArray ja = new JSONObject(response.getBody().asString()).getJSONArray("stepResults");
		JSONObject stepres = ja.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);

		String entityName = "stepResult";
		String entityId = stepResId;
		String cycleId = "-1";
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response1 = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response1, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response1);
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		// Delete Multiple Attachements
		for (int i = 0; i < response1.length(); i++) {
			JSONObject jsonObject = new JSONObject(response1.get(i).toString());
			String stepAattachmentId = jsonObject.getString("id");
			System.err.println(stepAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);
	}

	/**
	 * Add attachments to stepResult in a cycle scheduled version
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 59, enabled = testEnabled)
	public void reg59_deleteStepAttachments_scheduledVersion_scheduledCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Cycle one created");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(response.body().asString()).get("id").toString();

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectId);
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId(cycleId);
		executionJson.setVersionId(versionId);

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "get stepresult Api Response is null.");
		System.out.println(response.getBody().asString());
		JSONArray ja = new JSONObject(response.getBody().asString()).getJSONArray("stepResults");
		JSONObject stepres = ja.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);

		String entityName = "stepResult";
		String entityId = stepResId;
		String cycleId = "-1";
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response1 = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response1, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response1);
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		// Delete Multiple Attachements
		for (int i = 0; i < response1.length(); i++) {
			JSONObject jsonObject = new JSONObject(response1.get(i).toString());
			String stepAattachmentId = jsonObject.getString("id");
			System.err.println(stepAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);
	}

	/**
	 * Add attachments to stepResult in adhoc cycle scheduled version
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 60, enabled = testEnabled)
	public void reg60_deleteStepAttachments_scheduledVersion_Adhoc() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		String comment = "comment";
		String fileName = "attachment.png";
		List<String> fileNames = new ArrayList<>();
		fileNames.add(fileName);
		fileNames.add(fileName);
		fileNames.add(fileName);
		JSONArray response = zapiService.addMultipleAttachment(jwtGenerator, projectId, versionId, issueId, cycleId,
				entityName, entityId, comment, fileNames);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response);
		test.log(LogStatus.PASS, "Add Attachment Response validated suuccessfully.");

		// Delete Multiple Attachements
		for (int i = 0; i < response.length(); i++) {
			JSONObject jsonObject = new JSONObject(response.get(i).toString());
			String stepAattachmentId = jsonObject.getString("id");
			System.err.println(stepAattachmentId);

			Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
			Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
			test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
			boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(stepAattachmentId,
					deleteAttachmentResponse);
			Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
			test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		}

		extentReport.endTest(test);
	}

	/**
	 * Attempt to Delete attachment to execution with invalid attachment Id
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 61, enabled = testEnabled)
	public void reg61_deleteAttachment_AttemptAttachmentId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String stepAattachmentId = "12234";
		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateInvalidAttachmentId(stepAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");

		extentReport.endTest(test);
	}
	/**
	 * Delete attachment to execution
	 * 
	 * @author Created by manoj.behera on 22-Feb-2017.
	 */
	@Test(priority = 62, enabled = testEnabled)
	public void reg62_deleteTestAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("ZAPICloud - Delete Attachment API Regression Suite");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Add Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Add Attachment Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		JSONObject testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		String testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);

		// Delete Attachement

		Response deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		boolean deleteAttachmentStatus = zapiService.validateDeletedAttachment(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");

		deleteAttachmentResponse = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(deleteAttachmentResponse, "Delete Attachment Api Response is null.");
		test.log(LogStatus.PASS, "Delete Attachment Api executed successfully.");
		deleteAttachmentStatus = zapiService.validateInvalidAttachmentId(testAattachmentId,
				deleteAttachmentResponse);
		Assert.assertTrue(deleteAttachmentStatus, "Not validated deleted attachment");
		test.log(LogStatus.PASS, "Deleted Attachment Response validated suuccessfully.");
		extentReport.endTest(test);

	}


}
