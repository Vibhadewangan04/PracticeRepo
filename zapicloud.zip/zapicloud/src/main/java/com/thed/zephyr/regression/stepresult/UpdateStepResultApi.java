/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.stepresult;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class UpdateStepResultApi extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	

	//Attempt to updateStepResult with no steps
	//@Test(priority = 2)
	public void updateStepResult1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479422438880-242ac113a-0001");
		stepresultJson.setStepId("");
		stepresultJson.setIssueId(10409l);
		stepresultJson.setStatus(1);
		stepresultJson.setComment("comments");
		//List<Long> list = new ArrayList<>();
		//list.add(10206l);
		//stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
		//Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//updateStepResult from unexecuted to PASS
	//@Test(priority = 2)
	public void updateStepResult2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361083240-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		stepresultJson.setStepId("0001479361083240-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		stepresultJson.setStatus(1);
		stepresultJson.setComment("comments");
		List<Long> list = new ArrayList<>();
		//list.add(10206l);
		stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
		//Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//updateStepResult from unexecuted to FAIL
	//@Test(priority = 2)
	public void updateStepResult3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361083393-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		//stepresultJson.setStepId("0001479361083393-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		stepresultJson.setStatus(2);
		//stepresultJson.setComment("comments");
		List<Long> list = new ArrayList<>();
		//list.add(10206l);
		stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
		//Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//updateStepResult from unexecuted to WIP
	//@Test(priority = 2)
	public void updateStepResult4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361083577-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		//stepresultJson.setStepId("0001479361083577-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		stepresultJson.setStatus(2);
		//stepresultJson.setComment("comments");
		//List<Long> list = new ArrayList<>();
		//list.add(10206l);
		//stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	}
		
	//updateStepResult from unexecuted to BLOCKED
	//@Test(priority = 2)
	public void updateStepResult5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361083796-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		//stepresultJson.setStepId("0001479361083796-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		stepresultJson.setStatus(2);
		//stepresultJson.setComment("comments");
		//List<Long> list = new ArrayList<>();
		//list.add(10206l);
		//stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	}
	//updateStepResult from unexecuted to CUSTOM
	//@Test(priority = 2)
	public void updateStepResult6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361083980-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		stepresultJson.setStepId("0001479361083980-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		stepresultJson.setStatus(2);
		//stepresultJson.setComment("comments");
		//List<Long> list = new ArrayList<>();
		//list.add(10206l);
		//stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	}
	//updateStepResult from PASS to unexecuted
	//@Test(priority = 2)
	public void updateStepResult7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361083240-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		stepresultJson.setStepId("0001479361084233-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		//Set status to PASS
		stepresultJson.setStatus(1);
		
		Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		
		//Set status to UNEXECUTED
		stepresultJson.setStatus(-1);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	}
	//updateStepResult from  FAILto unexecuted
	//@Test(priority = 2)
	public void updateStepResult8() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		String stepResultId = "0001479361084384-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
		stepresultJson.setStepId("0001479361084384-242ac1139-0001");
		stepresultJson.setIssueId(10100l);
		stepresultJson.setComment("");
		//Set status to FAIL
		stepresultJson.setStatus(2);
		
		Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		
		//Set status to UNEXECUTED
		stepresultJson.setStatus(-1);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	}
	
	//updateStepResult from WIP to UNEXECUTED
	//@Test(priority = 2)
		public void updateStepResult9() {
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			Long projectId = Long.parseLong(Config.getValue("projectId"));;
			String stepResultId = "0001479361084565-242ac1139-0001";
			Stepresult stepresultJson = new Stepresult();
			stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
			stepresultJson.setStepId("0001479361084565-242ac1139-0001");
			stepresultJson.setIssueId(10100l);
			stepresultJson.setComment("");
			//Set status to WIP
			stepresultJson.setStatus(3);
			
			Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
			Assert.assertNotNull(response1, "Create Execution Api Response is null.");
			
			//Set status to UNEXECUTED
			stepresultJson.setStatus(-1);
			Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());
		}
	
	///updateStepResult from BLOCKED to UNEXECUTED
		//@Test(priority = 2)
				public void updateStepResult10() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361084857-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361084857-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to BLOCKED
					stepresultJson.setStatus(4);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to UNEXECUTED
					stepresultJson.setStatus(-1);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
	//updateStepResult from CUSTOM to UNEXECUTED
				//@Test(priority = 2)
				public void updateStepResult11() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085021-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085021-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to CUSTOM
					stepresultJson.setStatus(5);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to UNEXECUTED
					stepresultJson.setStatus(-1);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
	
	//updateStepResult from PASS to FAIL
				//@Test(priority = 2)
				public void updateStepResult12() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085115-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085115-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to PASS
					stepresultJson.setStatus(1);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to FAIL
					stepresultJson.setStatus(2);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
				//updateStepResult from FAIL to WIP
				//@Test(priority = 2)
				public void updateStepResult13() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085212-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085212-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to FAIL
					stepresultJson.setStatus(2);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to UNEXECUTED
					stepresultJson.setStatus(3);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
	//updateStepResult from WIP to BLOCKED
				//@Test(priority = 2)
				public void updateStepResult14() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085320-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085320-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to WIP
					stepresultJson.setStatus(2);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to BLOCKED
					stepresultJson.setStatus(4);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
	//updateStepResult from BLOCKED to CUSTOM
				//@Test(priority = 2)
				public void updateStepResult15() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085434-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085434-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to BLOCKED
					stepresultJson.setStatus(4);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to CUSTOM
					stepresultJson.setStatus(5);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
	//updateStepResult from CUSTOM to PASS
				//@Test(priority = 2)
				public void updateStepResult16() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085538-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085538-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("");
					//Set status to CUSTOM
					stepresultJson.setStatus(5);
					
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					
					//Set status to PASS
					stepresultJson.setStatus(1);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	
	//updateStepResult by adding step comment in numeric format
				//@Test(priority = 2)
				public void updateStepResult17() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085640-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085640-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("1234567677788900894734637");
					//Set status to PASS
					stepresultJson.setStatus(1);
					
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
				
	//updateStepResult by adding step comment in alphanumeric format
				//@Test(priority = 2)
				public void updateStepResult18() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479361085771-242ac1139-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479361085771-242ac1139-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("Aplha1234 comment");
					//Set status to PASS
					stepresultJson.setStatus(1);
					
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	//updateStepResult by adding step comment in international  format
				//@Test(priority = 2)
				public void updateStepResult19() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121881-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121881-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("este comentario ISA en espa�ol");
					//Set status to PASS
					stepresultJson.setStatus(1);
					
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	//updateStepResult by adding step comment in special char format
				//@Test(priority = 2)
				public void updateStepResult20() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121857-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121857-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("~!@#$%^&*()_+{'");
					//Set status to PASS
					stepresultJson.setStatus(1);
					
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	//updateStepResult by adding step comment with upper and lowercase alphabets
				//@Test(priority = 2)
				public void updateStepResult21() {
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121766-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121766-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setComment("lowerCASE");
					//Set status to WIP
					stepresultJson.setStatus(3);
					
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
				}
	//updateStepResult by linking single defect
				//@Test(priority = 2)
				public void updateStepResult22(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121578-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121578-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					stepresultJson.setComment("comments");
					List<Long> list = new ArrayList<>();
					list.add(10206l);
					stepresultJson.setDefects(list);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//updateStepResult by linking multiple defects, say 5
				//@Test(priority = 2)
				public void updateStepResult23(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121682-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121682-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					stepresultJson.setComment("comments");
					List<Long> list = new ArrayList<>();
					list.add(10404l);
					list.add(10405l);
					list.add(10406l);
					list.add(10407l);
					list.add(10408l);
					stepresultJson.setDefects(list);
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//updateStepResult by linking multiple defects, say 20
	//updateStepResult by linking multiple defects and appending comments
				//@Test(priority = 2)
				public void updateStepResult24(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121626-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121626-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					stepresultJson.setComment("First comments");
					List<Long> list = new ArrayList<>();
					list.add(10404l);
					list.add(10405l);
					list.add(10406l);
					list.add(10407l);
					list.add(10408l);
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Append comments
					stepresultJson.setComment("Append comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//updateStepResult by linking multiple defects, adding comments and, attachments
				//@Test(priority = 2)
				public void updateStepResult25(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479421121900-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479421121900-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10404l);
					list.add(10405l);
					list.add(10406l);
					list.add(10407l);
					list.add(10408l);
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
		//updateStepResult of a clone teststep to a diff status
				//@Test(priority = 2)
				public void updateStepResult26(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479422084792-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479422084792-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10404l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
		//updateStepResult of a clone teststep to link a defect and comments
				//@Test(priority = 2)
				public void updateStepResult27(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479422084841-242ac113a-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479361082816-242ac1139-0001");
					stepresultJson.setStepId("0001479422084841-242ac113a-0001");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10404l);
					list.add(10405l);
					list.add(10406l);
					list.add(10407l);
					list.add(10408l);
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult with invalid status Id
				@Test(priority = 2)
				public void updateStepResult28(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(100);
					//List<Long> list = new ArrayList<>();
					//list.add(10100l);
					//stepresultJson.setComment("First comments");
					//stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult with invalid defect Id
				@Test(priority = 2)
				public void updateStepResult30(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(9999l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult with wrong project Id
				@Test(priority = 2)
				public void updateStepResult31(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					//projectId belonging to another project
					Long projectId = 10000l;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult with invalid Execution Id
				@Test(priority = 2)
				public void updateStepResult32(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("000000000-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult with invalid stepResult Id
				@Test(priority = 2)
				public void updateStepResult33(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult with invalid stepresultId
				@Test(priority = 2)
				public void updateStepResult34(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "000147925600000-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult of a deleted teststep
				@Test(priority = 2)
				public void updateStepResult35(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
				   /* Create a issue with steps
					* Create a execution
					* get stepresult
					* delete step
					*/
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult of a deleted Execution
				@Test(priority = 2)
				public void updateStepResult36(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					/* Create a issue with steps
					* Create a execution
					* get stepresult
					* delete execution
					*/
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//Attempt to updateStepResult of a deleted Issue
				/* Create a issue with steps
				* Create a execution
				* get stepresult
				* delete issue
				*
				*/
				@Test(priority = 2)
				public void updateStepResult37(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					/* Create a issue with steps
					* Create a execution
					* get stepresult
					* delete execution
					*/
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
				
	//Attempt to updateStepResult by linking self as a defect
				@Test(priority = 2)
				public void updateStepResult38(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//updateStepResult if execution is scheduled in Adhoc of Unscheduled
				@Test(priority = 2)
				public void updateStepResult39(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	//updateStepResult if execution is scheduled in a non-adhoc cycle
				@Test(priority = 2)
				public void updateStepResult40(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Manoj");
					
					Long projectId = Long.parseLong(Config.getValue("projectId"));;
					String stepResultId = "0001479256073444-242ac1137-0001";
					Stepresult stepresultJson = new Stepresult();
					stepresultJson.setExecutionId("0001479256072154-242ac1137-0001");
					//stepresultJson.setStepId("");
					stepresultJson.setIssueId(10100l);
					stepresultJson.setStatus(1);
					List<Long> list = new ArrayList<>();
					list.add(10100l);
					stepresultJson.setComment("First comments");
					stepresultJson.setDefects(list);
					Response response1 = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response1, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
					//Step Attachment API call goes here
					//Append comment
					
					stepresultJson.setComment("First comments");
					Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());
					
					//boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(), response);
					//Assert.assertTrue(status);

					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
	


}
