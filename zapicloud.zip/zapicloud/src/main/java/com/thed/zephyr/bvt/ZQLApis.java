/**
 * Created by manoj.behera on 07-Dec-2016.
 */
package com.thed.zephyr.bvt;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 07-Dec-2016
 *
 */
public class ZQLApis extends BaseTest {
	String cycleId = null;
	Long issueId = null;
	String teststepId = null;


//	@BeforeClass
//	public void beforeClass() {
//		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
//				Config.getValue("secretKey"), Config.getValue("adminUserName"));
//	}

	// TODO // ZQL APi
	@Test(priority = 82, enabled = testEnabled)
	public void bvt82_getZQLFieldConfiguration() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getZQLFieldConfiguration(jwtGenerator);
		Assert.assertNotNull(response, "getZQLFieldConfiguration Api Response is null.");
		test.log(LogStatus.PASS, "getZQLFieldConfiguration Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldConfiguration(response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldConfiguration Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 83, enabled = testEnabled)
	public void bvt83_executeZQLSearch() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"maxRecords\":50,\"offset\":20,\"zqlQuery\":\"project = ROSE\",\"fields\":{\"project\":[{\"id\":10000,\"key\":\"IE\",\"name\":\"IE\"}]}}";
		System.out.println(payLoad);
		Response response = zapiService.executeZQLSearch(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO
	@Test(priority = 84, enabled = testEnabled)
	public void bvt84_getZQLAutoComplete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "fixVersion";
		String fieldValue = "v";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 85, enabled = testEnabled)
	public void bvt85_getZQLFieldValues() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject json = new JSONObject();

		Response getAllProjectResponse = jiraService.getProjects(basicAuth, "20");
		Assert.assertNotNull(getAllProjectResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(getAllProjectResponse.getBody().asString());
		JSONArray projectJsonArray = new JSONArray(getAllProjectResponse.getBody().asString());
		json.put("project", projectJsonArray);

		Response response = zapiService.getZQLFieldValues(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

//		boolean status = zapiService.validateGetZQLFieldValues(json, response);
//		Assert.assertTrue(status, "Not validated response of getZQLFieldValues Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
