package com.thed.zephyr.regression.teststep;

import org.testng.Assert;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
//import com.thed.zephyr.cloud.rest.util.json.TeststepJsonParser;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class MoveTeststepApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	private Long projectId = Long.parseLong(Config.getValue("projectId"));
	private Long issueId;

	JSONArray jsarray = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	// created 5 steps and Get test steps in all testcases
	@BeforeMethod
	public void beforeMethod() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueTypeTestId = Long.parseLong(Config.getValue("issueTypeTestId"));
		String issueKey = null;

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeTestId));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("id").toString();
		// System.out.println("this is the issue key "+ issueKey);
		issueId = Long.parseLong(issueKey);
		test.log(LogStatus.PASS, "Response validated successfully.");

		List<String> step = new ArrayList<>();
		step.add("step1 8765rtfgjhy89iujhgv");
		step.add("step2 &*()(*&^%$()+_)(*&^%$#@");
		step.add("step3 ");
		step.add("step4 tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		step.add("step5 Nuevo status de ejecuci�n para coincidir con ejecuciones");

		List<String> stepData = new ArrayList<>();
		stepData.add("data1 hsgytd87yhjuy89iu");
		stepData.add("data2 +_)(*&^%$");
		stepData.add("data3 ");
		stepData.add("data4 tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepData.add("data5 Zugangserlaubnis");

		List<String> stepRes = new ArrayList<>();
		stepRes.add("~!@#$%");
		stepRes.add("Supprimer cette �tape de statut d'ex�cution");
		stepRes.add("");
		stepRes.add("tyujhg67876   hgfytui98^%^&*  ~!@#$% iuyt789");
		stepRes.add("This issue is not existing in the following test bed");

		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);
		System.out.println("Request PayLoad: " + teststepJson.toString());

		JSONArray createresponse = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createresponse, "create test step Api Response is null.");
		test.log(LogStatus.PASS, "create test step executed successfully.");
		System.out.println("Response: " + createresponse);

		boolean createIssueStatus = zapiService.validateTeststepsWithData(projectId, issueId, teststepJson.toString(),
				createresponse);
		Assert.assertTrue(createIssueStatus);
		test.log(LogStatus.PASS, "Response of validated suuccessfully.");

		Response getResponse = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(getResponse, "get Test step Api Response is null.");
		test.log(LogStatus.PASS, "get test step Api executed successfully.");
		System.out.println("Response:--> " + getResponse.getBody().asString());

		boolean validateStatus = zapiService.validateTeststepsData(projectId, issueId, teststepJson.toString(),
				getResponse);
		Assert.assertTrue(validateStatus);

		jsarray = new JSONArray(getResponse.getBody().asString());
	}

	// Move last test step to first position. i.e- 5to1
	@Test(priority = 2, enabled = true)
	public void test2_moveStepFromLastToFirst() {

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(0);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move first test step to last position. i.e- 1 to 5
	@Test(priority = 3, enabled = true)
	public void test3_moveStepFromFirstToLast() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(0);
	//	JSONObject destStep = jsarray.getJSONObject(4);
		JSONObject destStep = null;

		String sourceStepId = srcStep.get("id").toString();

		String payLoad = "{\"position\":\"First\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move first test step to 2nd position. i.e- 1 to 2
	@Test(priority = 4, enabled = true)
	public void test4_moveStepFromFirstToSecond() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(0);
		JSONObject destStep = jsarray.getJSONObject(2);
		
		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

	//	String sourceStepId = srcStep.get("orderId").toString();
	//	String destStepId = destStep.get("orderId").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move first test step to 3rd position. i.e- 1 to 3
	@Test(priority = 5, enabled = true)
	public void test5_moveStepFromFirstToThird() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(0);
		JSONObject destStep = jsarray.getJSONObject(3);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();
		System.out.println(sourceStepId);
		System.out.println(destStepId);

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move first test step to 4th position. i.e- 1 to 4
	@Test(priority = 6, enabled = true)
	public void test6_moveStepFromFirstToFourth() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(0);
		JSONObject destStep = jsarray.getJSONObject(4);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move 2nd test step to 4th position. i.e- 2 to 4
	@Test(priority = 7, enabled = true)
	public void test7_moveStepFromSecondToFourth() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(1);
		JSONObject destStep = jsarray.getJSONObject(4);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move 5th test step to 2nd position. i.e- 5 to 2
	@Test(priority = 8, enabled = true)
	public void test8_moveStepFromFifthToSecond() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move 4th test step to 1st position. i.e- 4 to 1
	@Test(priority = 9, enabled = true)
	public void test9_moveStepFromFourthToFirst() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(3);
		JSONObject destStep = jsarray.getJSONObject(0);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to Move test step from same position to same position (here it is
	// 4th to 4th)
	@Test(priority = 10, enabled = true)
	public void test10_moveStepToSamePosition() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(3);
		JSONObject destStep = jsarray.getJSONObject(4);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to Move test step by giving "before" in payload
	/*
	 * @Test(priority = 11) public void test11_attempttoMoveStepByUsingBefore(){
	 * ExtentTest test =
	 * extentReport.startTest(Thread.currentThread().getStackTrace()[1].
	 * getMethodName()); test.assignCategory(
	 * "Automation API BVT Suite - ZFJCLOUD");
	 * test.assignAuthor("soumyaranjan");
	 * 
	 * JSONObject srcStep = jsarray.getJSONObject(4); JSONObject destStep =
	 * jsarray.getJSONObject(0);
	 * 
	 * String sourceStepId = srcStep.get("id").toString(); String destStepId =
	 * destStep.get("id").toString();
	 * 
	 * String payLoad = "{\"before\":\""+destStepId+"\"}";
	 * 
	 * Response response = zapiService.moveTeststep(jwtGenerator, projectId,
	 * issueId,sourceStepId,payLoad); Assert.assertNotNull(response,
	 * "Move test step Api Response is null."); test.log(LogStatus.PASS,
	 * "Move test step Api executed successfully."); //
	 * System.out.println(response.getBody().asString());
	 * 
	 * boolean status =
	 * zapiService.validateMoveStep(srcStep,destStep,payLoad,response);
	 * Assert.assertTrue(status); test.log(LogStatus.PASS,
	 * "Response validated suuccessfully."); extentReport.endTest(test); }
	 */
	// Move test step after edit and update the step
	@Test(priority = 12, enabled = true)
	public void test12_moveStepAfterEdit() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();
		
		// updating the source step
		String updatePayLoad = "{\"id\":\"" + sourceStepId + "\",\"step\":\"step5 Nuevo status de ejecuci�n para coincidir con ejecuciones\",\"data\":\"data5 Zugangserlaubnis\",\"result\":\"This issue is not existing in the following test bed\"}";
		Response updateResponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, sourceStepId,
				updatePayLoad);
		Assert.assertNotNull(updateResponse, "Update test step Api Response is null.");
		test.log(LogStatus.PASS, "update test step Api executed successfully.");
		System.out.println(updateResponse.getBody().asString());

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move test step, then edit and update the step
	@Test(priority = 13, enabled = true)
	public void test13_moveStepThenUpdateStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		// updating the source step
		String updatePayLoad = "{\"id\":\"" + sourceStepId + "\",\"step\":\"xyz\",\"data\":\"nmo\",\"result\":\"lmi\"}";
		Response updateResponse = zapiService.updateTeststep(jwtGenerator, projectId, issueId, sourceStepId,
				updatePayLoad);
		Assert.assertNotNull(updateResponse, "Update test step Api Response is null.");
		test.log(LogStatus.PASS, "update test step Api executed successfully.");
		System.out.println(updateResponse.getBody().asString());
		extentReport.endTest(test);
	}

	// Delete a test step, then move one step
	@Test(priority = 14, enabled = true)
	public void test14_moveStep_AfterDelete_A_Step() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(3);
		JSONObject destStep1 = jsarray.getJSONObject(1);
		JSONObject deleteStep = jsarray.getJSONObject(2);

		String sourceStepId = srcStep.get("id").toString();
		String deleteStepId = deleteStep.get("id").toString();
		// delete one step
		Response deleteStepReponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, deleteStepId);
		Assert.assertNotNull(deleteStepReponse);
		JSONObject destStep2 = jsarray.getJSONObject(1);
		String destStepId2 = destStep2.get("id").toString();
		String payLoad = "{\"after\":\"" + destStepId2 + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		 System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep2, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move test step, then add another step and again move that step
	@Test(priority = 15, enabled = true)
	public void test15_moveStep_AfterAddedOneStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		// Step Values
		String stepValue = "newly created";
		String dataValue = "newly created";
		String resultValue = "newly created";

		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createResponse);
		System.out.println("new step got cretaed");

		boolean validateCreateStep = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createResponse);
		Assert.assertNotNull(validateCreateStep);
		System.out.println("new step creation validated");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	// Move test step, then delete one step and again move one step
	@Test(priority = 16, enabled = true)
	public void test16_moveStep_Then_Delete_a_step() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		// delete one step
		Response deleteStepReponse = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, destStepId);
		Assert.assertNotNull(deleteStepReponse);
	}

	// attempt to move test step with invalid sourceStepid
	@Test(priority = 17, enabled = true)
	public void test17_moveTeststep_invalidSourceStepId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		// JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String InvalidSourceStepId = "4567uygf";
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, InvalidSourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidStepId(InvalidSourceStepId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with invalid destinationStepid
	@Test(priority = 18, enabled = true)
	public void test18_moveTeststep_invalidDestinationStepId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		// JSONObject srcStep = jsarray.getJSONObject(4);
		// JSONObject destStep = jsarray.getJSONObject(1);

		String InvalidDestStepId = "4567uygf";
		// String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + InvalidDestStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, InvalidDestStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidStepId(InvalidDestStepId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with invalid issueid
	@Test(priority = 19, enabled = true)
	public void test19_moveTeststep_invalidIssueid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidIssueId = 15544l;
		Response response = zapiService.moveTeststep(jwtGenerator, projectId, InvalidIssueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(InvalidIssueId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with invalid projectId
	@Test(priority = 20, enabled = true)
	public void test20_moveTeststep_invalidProjectid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidProjectId = 34567890l;
		Response response = zapiService.moveTeststep(jwtGenerator, InvalidProjectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidProjectId(InvalidProjectId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with projectId Null
	@Test(priority = 21, enabled = true)
	public void test21_moveTeststep_ProjectidNull() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidProjectId = 0l;
		Response response = zapiService.moveTeststep(jwtGenerator, InvalidProjectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidProjectId(InvalidProjectId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	@Test(priority = 22, enabled = true)
	public void test22_moveTeststep_ProjectidNull() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		//Long InvalidIssueId = null;
		Long InvalidProjectId = null;
		Response response = zapiService.moveTeststep(jwtGenerator, projectId, InvalidProjectId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(InvalidProjectId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with IssueId Null
	@Test(priority = 23, enabled = true)
	public void test23_moveTeststep_IssueidNull() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidIssueId = null;
		Response response = zapiService.moveTeststep(jwtGenerator, projectId, InvalidIssueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(InvalidIssueId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with projectId 0
	@Test(priority = 24, enabled = true)
	public void test24_moveTeststep_Projectid_zero() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidProjectId = 0l;
		Response response = zapiService.moveTeststep(jwtGenerator, InvalidProjectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidProjectId(InvalidProjectId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with IssueId 0
	@Test(priority = 25, enabled = true)
	public void test25_moveTeststep_Issueid_zero() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidIssueId = 0l;
		Response response = zapiService.moveTeststep(jwtGenerator, projectId, InvalidIssueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateInvalidIssueId(InvalidIssueId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// attempt to move test step with IssueId and projectId mismatch
	@Test(priority = 26, enabled = true)
	public void test26_moveTeststep_IssueId_mismatch_projectId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";
		Long InvalidProjectId = 10000l;
		Response response = zapiService.moveTeststep(jwtGenerator, InvalidProjectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMismatchOfProjectIdAndIssueId(InvalidProjectId, issueId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Move Third test step to last position. i.e- 3 to 5
	@Test(priority = 27, enabled = true)
	public void test27_moveStepFromThirdToLast() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		JSONObject srcStep = jsarray.getJSONObject(2);
		JSONObject destStep = null;

		String sourceStepId = srcStep.get("id").toString();

		String payLoad = "{\"position\":\"First\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	@Test(priority = 28, enabled = true)
	public void test28_moveStep_AfterAddingnewStep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("soumyaranjan");

		// Step Values
		String stepValue = "newly created";
		String dataValue = "newly created";
		String resultValue = "newly created";

		Teststep teststepJson = new Teststep();
		teststepJson.setStep(stepValue);
		teststepJson.setData(dataValue);
		teststepJson.setResult(resultValue);

		Response createResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(createResponse);
		System.out.println("new step got cretaed");

		boolean validateCreateStep = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(),
				createResponse);
		Assert.assertNotNull(validateCreateStep);
		System.out.println("new step creation validated");

		JSONObject srcStep = jsarray.getJSONObject(4);
		JSONObject destStep = jsarray.getJSONObject(1);

		String sourceStepId = srcStep.get("id").toString();
		String destStepId = destStep.get("id").toString();

		String payLoad = "{\"after\":\"" + destStepId + "\"}";

		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, sourceStepId, payLoad);
		Assert.assertNotNull(response, "Move test step Api Response is null.");
		test.log(LogStatus.PASS, "Move test step Api executed successfully.");
		// System.out.println(response.getBody().asString());

		boolean status = zapiService.validateMoveStep(srcStep, destStep, payLoad, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}
	

}

