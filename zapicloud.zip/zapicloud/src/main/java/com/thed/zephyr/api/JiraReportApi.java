/**
 * Created by manoj.behera on 21-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 21-Nov-2016
 *
 */
public interface JiraReportApi {


	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getTestDistributionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String groupFld);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param issueStatuses
	 * @param howMany
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getTopDefects(JwtGenerator jwtGenerator, Long projectId, Long versionId, int issueStatuses, int howMany);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getExecutionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);

}
