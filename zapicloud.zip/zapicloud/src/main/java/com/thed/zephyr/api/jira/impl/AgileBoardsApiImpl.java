package com.thed.zephyr.api.jira.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.api.jira.AgileBoardsApi;

@Service("AgileboardApi")
public class AgileBoardsApiImpl implements AgileBoardsApi {

	@Override
	public Response getProjectBoard(RequestSpecification basicAuth, String projectId) {
		String api = "/rest/greenhopper/1.0/rapidview";
		 return basicAuth.when().get(api);
	}

	@Override
	public Response createSprint(RequestSpecification basicAuth, String payload) {
		
		 String api = "/rest/agile/1.0/sprint";
		 Map<String, String> headers = new HashMap<String, String>();
		 headers.put("Content-Type", "application/json");
		 return basicAuth.headers(headers).body(payload).when().post(api);
	}

	@Override
	public Response addissuetosprint(RequestSpecification basicAuth, Long sprintId,String payload) {
		 String api = "/rest/agile/1.0/sprint/"+sprintId+"/issue";
		 Map<String, String> headers = new HashMap<String, String>();
		 headers.put("Content-Type", "application/json");
		 return basicAuth.headers(headers).body(payload).when().post(api);
	}

	@Override
	public Response updatesprint(RequestSpecification basicAuth, Long sprintId, String payload) {
		String api = "/rest/agile/1.0/sprint/"+sprintId;
		 Map<String, String> headers = new HashMap<String, String>();
		 headers.put("Content-Type", "application/json");
		 return basicAuth.headers(headers).body(payload).when().put(api);
	}

	@Override
	public Response deletesprint(RequestSpecification basicAuth, Long sprintId) {
		// TODO Auto-generated method stub
		String api = "/rest/agile/1.0/sprint/"+sprintId;
		 Map<String, String> headers = new HashMap<String, String>();
		 headers.put("deleteSprint", "true");
		 headers.put("Content-Type", "application/json");
		 //return basicAuth.headers(headers).body(sprintId).when().delete(api);
		 return basicAuth.headers(headers).delete(api);
	}

}
