package com.thed.zephyr.regression.jiraReport;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

public class GetTopDefects extends BaseTest {

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	@Test(priority = 1)
	public void test1_getTopDefects_byPassing_allQueryParam() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 2)
	public void test2_getTopDefects_without_allQueryParam() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 3)  //response will be: {"data":[]}
	public void test3_getTopDefects_when_noDefect_Linked() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 3;    //given issueStatus which is still not assigned to any Test. so that it will not display anything.
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 4)
	public void test4_getTopDefects_when_issueStatus_ToDo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 5)
	public void test5_getTopDefects_when_issueStatus_inProgress() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 3;
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 6)
	public void test6_getTopDefects_when_issueStatus_Done() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10001;
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 7)
	public void test7_getTopDefects_when_howMany_5() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 5;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 8)
	public void test8_getTopDefects_when_howMany_10() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 10;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 9)
	public void test9_getTopDefects_when_howMany_15() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 15;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 10)
	public void test10_getTopDefects_when_howMany_moreThan15() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 17;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 11)
	public void test11_getTopDefects_when_howMany_zero() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 0;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 12)
	public void test12_getTopDefects_when_howMany_is_oddNumber() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
	//	int howMany = 10;
		int howMany = 6;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 13)
	public void test13_getTopDefects_with_howMany_5_when_sufficientDataIsNotAvailable() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 5;
		
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 14)
	public void test14_getTopDefects_with_howMany_10_when_sufficientDataIsNotAvailable() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 10;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 15)
	public void test15_getTopDefects_with_howMany_15_when_sufficientDataIsNotAvailable() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 16)
	public void test16_getTopDefects_unsheduled() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 17)
	public void test17_getTopDefects_sheduledVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10106l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 18)
	public void test18_getTopDefects_when_versionName_capital() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10202l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 19)
	public void test19_getTopDefects_when_versionName_smallLetter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10203l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 20)
	public void test20_getTopDefects_when_versionName_numeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10201l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 21)
	public void test21_getTopDefects_when_versionName_alphaNumeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10205l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 22)
	public void test22_getTopDefects_when_versionName_special() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10200l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 23)
	public void test23_getTopDefects_when_versionName_InternationalChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10207l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 24)
	public void test24_getTopDefects_when_versionName_LongName() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 25)
	public void test25_getTopDefects_when_versionName_withSpacesBetweeen() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 26)
	public void test26_attempt_to_getTopDefects_when_defects_associated_stepLevel() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");

		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 27)
	public void test27_getTopDefects_when_custom_issueStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 28)
	public void test28_getTopDefects_when_issueStatus_open_and_resolved() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 29)
	public void test29_getTopDefects_when_issueStatus_open_and_inProgress() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 30)
	public void test30_getTopDefects_when_issueStatus_default_and_custom() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 31)
	public void test31_getTopDefects_when_moreThan3_issueStatus_given() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 32)
	public void test32_getTopDefects_after_Renamed_issueStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Long projectId = 10201l;
		Long versionId = 10208l;
		int issueStatuses = 10000;
		int howMany = 15;
	
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}