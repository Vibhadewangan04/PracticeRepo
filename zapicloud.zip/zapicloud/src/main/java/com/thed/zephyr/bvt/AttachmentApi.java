/**
 * Created by manoj.behera on 07-Dec-2016.
 */
package com.thed.zephyr.bvt;

import java.text.ParseException;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 07-Dec-2016
 *
 */
public class AttachmentApi extends BaseTest {
	String cycleId = null;
	Long issueId = null;
	String teststepId = null;
	String testAattachmentId = null;
	JSONObject testAattachmentObj = null;
	String stepAattachmentId = null;
	JSONObject stepAattachmentObj = null;
	JSONObject teststepObj = null;
	String executionId = null;
	String stepResId = null;

	/*
	 * JwtGenerator jwtGenerator = null;
	 * 
	 * @BeforeClass public void beforeClass() { jwtGenerator =
	 * RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"),
	 * Config.getValue("accessKey"), Config.getValue("secretKey"),
	 * Config.getValue("adminUserName")); }
	 */
	@BeforeClass
	public void beforeClass(){
//		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
//					Config.getValue("secretKey"), Config.getValue("adminUserName"));
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
				teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
		System.out.println(teststepObj);
		teststepId = teststepObj.getString("id");
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
//		executionId = "0001479158020117-242ac1134-0001";
//		Long issueId = 10100l;
		response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		System.out.println(response.getBody().asString());
		JSONArray ja=new JSONObject(response.getBody().asString()).getJSONArray("stepResults");
		JSONObject stepres = ja.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
	}
	/**
	 * Add attachment at test level(JPEG) by providing entityName, entityId,
	 * projectId, issueId, cycleId, versionId
	 */

	@Test(priority = 74, enabled = testEnabled)
	public void bvt74_addTestAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = executionId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
//		Long issueId = issueId;
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
//		String entityId = "0001486367179586-242ac112-0001";
//		Long projectId = 10001l;
//		Long issueId = 10012l;
//		String cycleId = "-1";
//		Long versionId = -1l;
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		testAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		testAattachmentId = testAattachmentObj.getString("id");
		System.err.println(testAattachmentId);
	}

	/**
	 * Get the execution Attachments List by providing entityId(execution Id)
	 * 
	 */

	@Test(priority = 75, enabled = testEnabled)
	public void bvt75_getExecutionAttachmentsList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		String entityId = executionId;
		/*
		 * String entityName = "execution"; String entityId =
		 * "0001485870537988-242ac112-0001"; Long projectId = 10000l; Long
		 * issueId = 10303l; String cycleId = "-1"; Long versionId = -1l; String
		 * comment = "comment"; String fileName = "attachment.png"; Response
		 * response = zapiService.addAttachment(jwtGenerator, projectId,
		 * versionId, issueId, cycleId, entityName, entityId, comment,
		 * fileName); Assert.assertNotNull(response,
		 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
		 * "Update Cycle Api executed successfully.");
		 * System.out.println(response.getBody().asString()); JSONArray
		 * jsonArray = new JSONArray(response.getBody().asString());
		 * 
		 * boolean status = zapiService.validateCreatedAttachment(versionId,
		 * cycleId, entityName, entityId, comment, fileName, response);
		 * Assert.assertTrue(status, "Not validated added attachment");
		 * test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 */
		// String entityId = "0001485870537988-242ac112-0001";
		Response response1 = zapiService.getExecutionAttachmentsList(jwtGenerator,
				testAattachmentObj.getString("entityId"));
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		// Boolean status1 =
		// zapiService.validateGetAttachment(attachmentObj.getString("entityId"),
		// jsonArray, response1);
		// Assert.assertTrue(status1, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Should able to add attachment at step level(PNG) by providing entityName,
	 * entityId, executionId, projectId, issueId, cycleId, versionId
	 */
	@Test(priority = 76, enabled = testEnabled)
	public void bvt76_addStepAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = stepResId;
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		String cycleId = "-1";
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
//		String entityId = "0001486368385075-242ac112-0001";
//		Long projectId = 10001l;
//		Long issueId = 10012l;
//		String cycleId = "-1";
//		Long versionId = -1l;
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCreatedAttachment(versionId, cycleId, entityName, entityId, comment,
				fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		JSONArray jsonArray = new JSONArray(response.getBody().asString());
		stepAattachmentObj = new JSONObject(jsonArray.get(0).toString());
		stepAattachmentId = stepAattachmentObj.getString("id");
	}

	/**
	 * Get the step level execution Attachments List by providing
	 * entityId(stepresultId)
	 * 
	 */

	@Test(priority = 77, enabled = testEnabled)
	public void bvt77_getStepResultAttachmentsList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String stepResultId = "0001485870538018-242ac112-0001";
		Response response = zapiService.getStepResultAttachmentsList(jwtGenerator,
				stepAattachmentObj.getString("entityId"));
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Boolean status = zapiService.validateGetAttachment(response);
		// Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the attachment thumbnail of added attachment by providing
	 * attachmentId
	 * 
	 */
	@Test(priority = 78, enabled = testEnabled)
	public void bvt78_getAttachmentThumbnail() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001485870951014-242ac112-0001";
		Response response = zapiService.getAttachmentThumbnail(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Get the attachmentImage of added attachment by providing attachmentId
	 * 
	 */
	@Test(priority = 79, enabled = testEnabled)
	public void bvt79_getAttachmentImage() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001485870951014-242ac112-0001";
		Response response = zapiService.getAttachmentImage(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Delete an attachment at test level by providing attachmentId Response :
	 * {"message":
	 * "attachment 0001485893805356-242ac112-0001 successfully deleted"
	 * ,"timestamp":"2017-01-31"}
	 */
	@Test(priority = 80, enabled = testEnabled)
	public void bvt80_deleteAttachment() throws ParseException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String attachmentId = "0001485893841361-242ac112-0001";
		System.err.println(testAattachmentId);
		Response response = zapiService.deleteAttachment(jwtGenerator, testAattachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateDeletedAttachment(testAattachmentId, response);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * Delete an attachment at step level by providing attachmentId
	 * 
	 */
	@Test(priority = 81, enabled = testEnabled)
	public void bvt81_deleteAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001485870951014-242ac112-0001";
		Response response = zapiService.deleteAttachment(jwtGenerator, stepAattachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateDeletedAttachment(stepAattachmentId, response);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
