package com.thed.zephyr.bvt;

import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera
 *
 */
public class JiraApisTestSamples extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("accountId"));
	}

	/**
	 * Create a Cycle
	 */
	@Test(priority = 1)
	public void test1_createCycle1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
		cycleJson.setVersionId(10001l);
		cycleJson.setName("Cycle one");
		cycleJson.setDescription("Cycle one desc");
//		cycleJson.setBuild("build");
//		cycleJson.setEnvironment("environment");
//		cycleJson.setStartDate("2016-11-21");
//		cycleJson.setEndDate("2016-11-35");//yyyy-mm-dd
//		cycleJson.setStartDate("2017-01-23");
//		cycleJson.setEndDate("2017-01-23");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		    
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
//		cycleId = new JSONObject(response.body().asString()).get("id").toString();
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void test1_createCycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Cycle example");
		cycleJson.setDescription("Cycle one desc");

		JSONArray response = zapiService.createCycles(jwtGenerator, cycleJson.toString(), 10);
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Created Cycles through Api successfully.");

		extentReport.endTest(test);
	}

	/**
	 * get Cycle
	 */
	 @Test(priority = 3)
	public void test1_getCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

//		Long projectId = Long.parseLong(Config.getValue("projectId"));
//		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
//		String cycleId = "-1";
		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "0001485582670713-242ac112-0001";

		Response response = zapiService.getCycle(jwtGenerator,projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

//		boolean status = zapiService.validateGetCycle(projectId, versionId, cycleId, response);
//		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * get Cycles
	 */
	@Test(priority = 4)
	public void test1_getCycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = 10002l;

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update a Cycle
	 */
	 @Test(priority = 5)
	public void test2_updateCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Cycle one");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setId(null);
		String payLoad = "{\"name\":\"sdsd\",\"build\":\"sdsd\",\"environment\":\"sd\",\"description\":\"sd\",\"versionId\":10001,\"projectId\":10000,\"id\":\"0001483966060987-242ac112-0001\",\"sprintId\":null}";

		Response response = zapiService.updateCycle(jwtGenerator, "0001483965889631-242ac112-0001", payLoad.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(payLoad.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 5)
	public void test2_moveCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
//		 cycleJson.setVersionId(null);
		cycleJson.setName("Cycle for move!!");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setId("0001479754888220-242ac111e-0001");

		// Response response = zapiService.createCycle(jwtGenerator,
		// cycleJson.toString());
		// Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		// test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		//
		// boolean status =
		// zapiService.validateCreateCycle(cycleJson.toString(), response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		// test.log(LogStatus.PASS, "Response validated suuccessfully.");
		// Cycle cycleJson = new Cycle();
		// cycleJson.setProjectId(10000l);
		// cycleJson.setVersionId(10001l);
		// cycleJson.setName("cycle for move");
		//// cycleJson.setDescription("Cycle one desc");
		// cycleJson.setId("0001478798400755-242ac1131-0001");
		cycleJson.setVersionId(10001l);
		String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
		// JSONObject json = new
		// JSONObject(response.getBody().asString()).put("versionId", 10001l);
		// System.out.println(":::::"+json);
		// String cycleJs =
		// "{\"name\":\"zephyr\",\"build\":\"null\",\"environment\":\"\",\"description\":\"\",\"startDate\":\"\","endDate":"","versionId":10001,"projectId":10000,"id":"0001478783320714-242ac1131-0001","sprintId":1}";
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 5)
	public void test2_cloneCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(10000l);
		cycleJson.setVersionId(10003l);
		cycleJson.setName("Cycle for clone!!");
		// cycleJson.setId("0001478607794406-242ac1128-0001");

		//		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
//		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
//		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
//
//		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
//		Assert.assertTrue(status, "Response Validation Failed.");
//		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		// Cycle cycleJson = new Cycle();
		// cycleJson.setProjectId(10000l);
		// cycleJson.setVersionId(10001l);
		// cycleJson.setName("cycle for move");
		//// cycleJson.setDescription("Cycle one desc");
		// cycleJson.setId("0001478798400755-242ac1131-0001");
		String cycleId = "0001483965717513-242ac112-0001";
		cycleJson.setName("Cycled for clone!!");
		// JSONObject json = new
		// JSONObject(response.getBody().asString()).put("versionId", 10001l);
		// System.out.println(":::::"+json);
		// String cycleJs =
		// "{\"name\":\"zephyr\",\"build\":\"null\",\"environment\":\"\",\"description\":\"\",\"startDate\":\"\","endDate":"","versionId":10001,"projectId":10000,"id":"0001478783320714-242ac1131-0001","sprintId":1}";
		Response response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete a Cycle
	 */
	@Test(priority = 6)
	public void test3_deleteCycle1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		String cycleId = "0001480522174293-242ac112-0001";

		Response response = zapiService.deleteCycle(jwtGenerator, projectId, null, cycleId);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		boolean status = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 7)
	public void exportCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 1000110l;
		Long versionId = -1l;
		String cycleId = "0001482126709527-242ac112-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, null, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * copy Executions to cycle
	 */
	 @Test(priority = 2)
	public void copyExecutionsToCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String projectId = "10000";
		String versionId = "10000";
		String s = "{\"executions\":[\"0001479981906949-242ac1122-0001\"],\"projectId\":10000,\"versionId\":-1,\"clearDefectMappingFlag\":false,\"clearStatusFlag\":false}";
		System.out.println(s);
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, "0001478784491716-242ac1131-0001", s);
		System.out.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * move Executions to cycle
	 */
	// @Test(priority = 2)
	public void moveExecutionsToCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String projectId = "10000";
		String versionId = "10000";
		String s = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":false,\"clearStatusFlag\":false}";
		System.out.println(s);
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, "0001478862534005-242ac1132-0001", s);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO //Execution Apis
	/**
	 * create execution
	 */
	 @Test(priority = 2)
	public void test1_createExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(10000l);
		executionJson.setIssueId(10000l);
		executionJson.setVersionId(10003l);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void addTestsTocycle1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10000l);
		executionJson.setIssueId(10000l);
		executionJson.setVersionId(10001l);
		String cycleId = "0001478783320714-242ac1131-0001";
		String payLoad = "{\"jql\":\"project = 10000 AND issuetype = Test\",\"versionId\":10001,\"projectId\":10000,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void addTestsTocycle2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String cycleId = "-1";
		String payLoad = "{\"issues\":[\"SPAR-1\",\"SPAR-2\",\"SPAR-3\",\"SPAR-4\",\"SPAR-5\"],\"versionId\":10003,\"projectId\":10000,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void addTestsTocycle3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10000l);
		executionJson.setIssueId(10000l);
		executionJson.setVersionId(10001l);
		String cycleId = "0001479758029549-242ac111e-0001";
		String payLoad = "{\"versionId\":10001,\"fromVersionId\":\"10001\",\"fromCycleId\":\"-1\",\"priorities\":\"\",\"statuses\":\"\",\"components\":\"\",\"labels\":\"\",\"hasDefects\":false,\"projectId\":10000,\"method\":\"3\",\"assigneeType\":\"currentUser\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void getExecutionsByZQL() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String executionId = "0001483385337542-242ac112-0001";
//		String payLoad = "{\"maxRecords\":20,\"offset\":0,\"zqlQuery\":\"field = \"value\"}";
		String payLoad = "{\"zql\":\"project = IE\",\"offset\":0}";
		Response response = zapiService.getExecutionsByZQL(jwtGenerator, executionId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void test1_createExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		List<Long> list = new ArrayList<>();
		list.add(10050l);
		list.add(10051l);
		executionJson.setIssueIds(list);
		executionJson.setVersionId(-1l);
//		List<String> cycleIdsList = new ArrayList<>();
//		cycleIdsList.add("-1");
//		cycleIdsList.add("0001482229430542-242ac112-0001");
//		executionJson.setCycleIds(cycleIdsList);
		executionJson.setNoOfExecutions(2);
		executionJson.setCycleId("0001482229430542-242ac112-0001");
		
//		executionObject.cycleId = cycleIds.get(random.nextInt(cycleIds.size()));

		JSONArray response = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		// test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Create a Issue
	 */
	// @Test(priority = 4)
	public void test4_createIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10000");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueKey = new JSONObject(response.body().asString()).get("key").toString();

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 4)
	public void test4_createIssues() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10000");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 5);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 4)
	public void test4_createIssues1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject("10000");
		issuePayLoad.setIssuetype("10005");
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfIssues = 2;

		List<String> response = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfIssues);
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		List<String> issueList = CommonUtils.getDataListFromJsonArray(response, "id");
		for (Iterator iterator = issueList.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			Long projectId = 10000l;
			Long issueId = Long.parseLong(string);
			Teststep teststepJson = new Teststep();
			teststepJson.setNoOfTeststeps(5);

			JSONArray responseArray = zapiService.createTeststeps(jwtGenerator, projectId, issueId,
					teststepJson.toString());
			Assert.assertNotNull(responseArray, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

			Execution executionJson = new Execution();
			executionJson.setStatusId(1l);
			executionJson.setProjectId(10000l);
			executionJson.setIssueId(Long.parseLong(string));
			executionJson.setVersionId(-1l);

			Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(createExecutionResponse.getBody().asString());
			boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
			Assert.assertTrue(status, "Response Validation Failed.");
		}

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void deleteExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long issueId = 10130l;
		Response response = zapiService.deleteExecution(jwtGenerator, issueId, "0001480458638988-242ac112-0001");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = -1l;
		Response response = zapiService.getExecutions(jwtGenerator, projectId, issueId, 0, 10);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void getExecutionsByCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = 10000l;
		Long versionId = -1l;
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId,
				"0001484982432221-242ac112-0001", 0, 50);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void exportExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "HTML";
		String payLoad = "{\"exportType\":\"html\",\"expand\":\"teststeps\",\"executions\":[],\"startIndex\":0,\"maxAllowed\":true,\"zqlQuery\":\"project = BVT\"}";
		// String payLoad =
		// "{\"exportType\":\"html\",\"expand\":\"teststeps\",\"executions\":[],\"startIndex\":0,\"maxAllowed\":true,\"zqlQuery\":\"project
		// = \"IE\" AND fixVersion = \"Unscheduled\" AND cycleName = \"cycle
		// update\"\"}";
		Response response = zapiService.exportExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadExecutionsExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getExecutionSummariesBySprintAndIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String issueIdOrKey = "10000";
		int offset = 0;
		int size = 10;

		Response response = zapiService.getExecutionSummariesBySprintAndIssue(jwtGenerator, 1l, issueIdOrKey);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getExecutionsByIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String issueIdOrKey = "10000";
		int offset = 0;
		int size = 111111;
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOrKey, offset, size);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void reOrderExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"projectId\":10000,\"cycleId\":\"0001478768964952-242ac1131-0001\",\"versionId\":-1,\"executions\":[{\"id\":\"0001479331595772-242ac1139-0001\",\"orderId\":2},{\"id\":\"0001479331535002-242ac1139-0001\",\"orderId\":1}],\"offset\":\"0\",\"sortBy\":\"orderId\",\"sortOrder\":\"asc\"}";
		Response response = zapiService.reOrderExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getExecutionStatuses() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getExecutionStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void updateBulkStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479189122203-242ac1134-0001\",\"0001479189123203-242ac1134-0001\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":2}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void deleteBulkExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479123858871-242ac1134-0001\",\"0001479123804740-242ac1134-0001\",\"0001479123763535-242ac1134-0001\",\"0001479125359956-242ac1134-0001\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void assignBulkExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479228127201-242ac1135-0001\",\"0001478768982671-242ac1131-0001\"],\"assigneeType\":\"assignee\",\"assignee\":\"admin\"}";
		System.out.println(payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void getExecutionByExecutionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = 10000l;
		Long issueId = -1l;
		String executionId = "0001484344585619-242ac112-0001";
		Response response = zapiService.getExecution(jwtGenerator, projectId, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void updateExecution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String executionId = "0001484983555565-242ac112-0001";
		//String payLoad = "{\"status\":{\"id\":3},\"id\":\"0001484104200148-242ac112-0001\",\"projectId\":10001,\"issueId\":11311,\"cycleId\":\"-1\",\"defects\":[\"10000\"],\"comment\":\"comment\",\"assigneeType\":\"currentUser\",\"changeAssignee\":true}";
		String payLoad = "{\"status\":{\"id\":1},\"id\":\"0001484983555565-242ac112-0001\",\"projectId\":10000,\"issueId\":10000,\"cycleId\":\"-1\",\"versionId\":-1}";
		Response response = zapiService.updateExecution(jwtGenerator, executionId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	// TODO // Test step Api

	/**
	 * creating teststep
	 */
	// @Test(priority = 2)
	public void createTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		Teststep teststepJson = new Teststep();
		teststepJson.setNoOfTeststeps(5);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void createTeststeps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		Teststep teststepJson = new Teststep();
		teststepJson.setNoOfTeststeps(5);

		JSONArray response = zapiService.createTeststeps(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		// boolean status = zapiService.validateTeststep(projectId, issueId,
		// teststepJson.toString(), response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void createTeststepsWithData() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		List<String> step = new ArrayList<>();
		step.add("step 1");
		step.add("step 2");
		step.add("step 3");
		List<String> stepData = new ArrayList<>();
		stepData.add("stepData 1");
		stepData.add("stepData 2");
		stepData.add("stepData 3");
		List<String> stepRes = new ArrayList<>();
		stepRes.add("stepRes 1");
		stepRes.add("stepRes 2");
		stepRes.add("stepRes 3");
		Teststep teststepJson = new Teststep();
		teststepJson.setStepList(step);
		teststepJson.setDataList(stepData);
		teststepJson.setResultList(stepRes);

		JSONArray response = zapiService.createTeststeps(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		// boolean status = zapiService.validateTeststep(projectId, issueId,
		// teststepJson.toString(), response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * clone teststep -1 - clone after , 0 - before, -2 - last step, position -
	 * position need to give
	 */
	@Test(priority = 2)
	public void cloneTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10201l;
		Long issueId = 10442l;
		String stepId = "0001480965510505-242ac112b-0001";
		String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"1147\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void updateTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001478768938625-242ac1131-0001";
		String payLoad = "{\"id\":\"0001478768938625-242ac1131-0001\",\"step\":\"updated step\",\"data\":\"updated data\",\"result\":\"updated res\"}";
		System.out.println(payLoad);
		Response response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * creating teststep
	 */
	// @Test(priority = 2)
	public void deleteTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001479672303748-242ac111e-0001";
		Response response = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// not working
	 @Test(priority = 2)
	public void moveTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 11401l;
		Long issueId = 15645l;
		String stepId = "0001481294452585-242ac112-0001";
//		String payLoad = "{\"after\":\"/connect/public/rest/api/1.0/teststep/15645/0001481294455457-242ac112-0001?projectId=11401\"}";
		String payLoad = "{\"after\":\"0001481294885064-242ac112-0001\"}";
		System.out.println(payLoad);
		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001478768938625-242ac1131-0001";
		Response response = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void getTeststeps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10001l;
		Long issueId = 10000l;
		Response response = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getTeststepStatuses() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getTeststepStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO // Config Api
	// Completed
	 @Test(priority = 2)
	public void getGeneralConfigInfo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getGeneralConfigInfo(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean generalConfigInfoStatus = zapiService.validateGeneralConfigInfo(response);
		Assert.assertTrue(generalConfigInfoStatus, "generalConfigInfo Api validation failed.");
		test.log(LogStatus.PASS, "getServerInfo Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Completed
	 @Test(priority = 2)
	public void getServerInfo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getServerInfo(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean serverInfoStatus = zapiService.validateServerInfo(response);
		Assert.assertTrue(serverInfoStatus, "getServerInfo Api validation failed.");
		test.log(LogStatus.PASS, "getServerInfo Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Changed to private api now
	// @Test(priority = 2)
	public void getSystemProp() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getSystemProp(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO //ZQLFilter Api
	@Test(priority = 2)
	public void createZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = IElkuy1444");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		// String payLoad = "{\"zql\":\"project = IE\",\"name\":\"api filter
		// 1231111\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		System.out.println(zqlfilterJson.toString());
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println("Response : " + response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter("get filter");
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Get api filter" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		// String payLoad = "{\"zql\":\"project = IE\",\"name\":\"api filter
		// 1231111\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		// System.out.println(payLoad);
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();

		response = zapiService.getZQLFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void quickSearchZQLFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("se arch" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		// // String payLoad = "{\"zql\":\"project = IE\",\"name\":\"api filter
		// //
		// 1231111\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		// System.out.println(payLoad);
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		String filterName = new JSONObject(response.getBody().asString()).get("name").toString();
		// String filterName = "se arch";
		Response response1 = zapiService.quickSearchZQLFilter(jwtGenerator, filterName);
		Assert.assertNotNull(response1, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());
		// status = zapiService.validateZQLFilter(zqlfilterJson.toString(),
		// response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getFavouriteZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		boolean fav = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getFavouriteZQLFilters(jwtGenerator, byUser, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getMyZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean byUser = true;
		int offset = 0;
		int maxRecords = 50;
		Response response = zapiService.getMyZQLFilters(jwtGenerator, byUser, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getPapularZQLFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("getZqlFilters");
		zqlFilter.setFav(true);
		zqlFilter.setByUser(true);
		zqlFilter.setOffset(0);

		boolean fav = true;
		int offset = 0;
		int maxRecords = 100;
		Response response = zapiService.getPapularZQLFilters(jwtGenerator, fav, offset, maxRecords);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		// boolean status = zapiService.validateZQLFilters("", response);
		// Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void searchZqlFilters() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlFilter = new Zqlfilter("searchZQLFilters");
		zqlFilter.setName("a");
		zqlFilter.setSize(20);
		zqlFilter.setOffset(0);
		System.out.println(zqlFilter.toString());
		Response response = zapiService.searchZQLFilters(jwtGenerator, zqlFilter.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateZQLFilters("", response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void copyFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Zqlfilter zqlfilterJson = new Zqlfilter("copy filter");
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("copy api filter for copy " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		// String payLoad = "{\"zql\":\"project = IE\",\"name\":\"api filter
		// 1231111\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		// System.out.println(payLoad);
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		// Copy filter
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for copy " + System.currentTimeMillis());
		// String payLoad =
		// "{\"id\":\"0001479409306195-242ac113a-0001\",\"name\":\"Copy of
		// filter 1 2 from api48958511\",\"zql\":\"project = IE AND fixVersion =
		// v1\",\"favorite\":true}";
		response = zapiService.copyFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void updateFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Update api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		// Copy filter
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setId(filterId);
		zqlfilterJson.setName("api filter for update1");

		// String payLoad =
		// "{\"favorite\":true,\"id\":\"0001479409306195-242ac113a-0001\",\"description\":\"\",\"name\":\"sd42\",\"sharePerm\":\"global\",\"zql\":\"project
		// = IE\"}";
		response = zapiService.updateFilter(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void deleteFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("Delete api filter " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		// Copy filter
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();

		// String filterId = "0001480574298023-242ac112-0001";
		response = zapiService.deleteFilter(jwtGenerator, filterId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateDeleteZqlFilter(filterId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void toggleFavorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Zqlfilter zqlfilterJson = new Zqlfilter("toggle");
		zqlfilterJson.setZql("project = IE");
		zqlfilterJson.setName("api filter for toggle " + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		Response response = zapiService.createZQLFilter(jwtGenerator, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateZQLFilter(zqlfilterJson.toString(), response);
		Assert.assertTrue(status);

		// Copy filter
		String filterId = new JSONObject(response.getBody().asString()).get("id").toString();
		zqlfilterJson.setFavorite(false);
		// String payLoad =
		// "{\"favorite\":true,\"id\":\"0001479392804387-242ac113a-0001\"}";

		response = zapiService.toggleFavorite(jwtGenerator, filterId, zqlfilterJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO // ZQL APi
	@Test(priority = 2)
	public void getZQLFieldConfiguration() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getZQLFieldConfiguration(jwtGenerator);
		Assert.assertNotNull(response, "getZQLFieldConfiguration Api Response is null.");
		test.log(LogStatus.PASS, "getZQLFieldConfiguration Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldConfiguration(response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldConfiguration Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void executeZQLSearch() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"maxRecords\":50,\"offset\":20,\"zqlQuery\":\"project = IE\",\"fields\":{\"project\":[{\"id\":10000,\"key\":\"IE\",\"name\":\"IE\"}]}}";
		System.out.println(payLoad);
		Response response = zapiService.executeZQLSearch(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO
	@Test(priority = 2)
	public void getZQLAutoComplete() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "fixVersion";
		String fieldValue = "v";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getZQLFieldValues() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject json = new JSONObject();

		Response getAllProjectResponse = jiraService.getProjects(basicAuth, "20");
		Assert.assertNotNull(getAllProjectResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(getAllProjectResponse.getBody().asString());
		JSONArray projectJsonArray = new JSONArray(getAllProjectResponse.getBody().asString());
		json.put("project", projectJsonArray);

		Response response = zapiService.getZQLFieldValues(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldValues(json, response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldValues Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO // Attachment Api
	@Test(priority = 2)
	public void getExecutionAttachmentsList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String entityId = "0001480405585365-242ac112-0001";
		Response response = zapiService.getExecutionAttachmentsList(jwtGenerator, entityId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getStepResultAttachmentsList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String stepResultId = "0001480405585473-242ac112-0001";
		Response response = zapiService.getStepResultAttachmentsList(jwtGenerator, stepResultId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getAttachmentThumbnail() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001479733330468-242ac111e-0001";
		Response response = zapiService.getAttachmentThumbnail(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getAttachmentImage() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String attachmentId = "0001479733330468-242ac111e-0001";
		Response response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void addAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String entityName = "execution";
		String entityId = "0001478842855816-242ac1131-0001";
		Long projectId = 10000l;
		Long issueId = 10001l;
		String cycleId = "0001478783248567-242ac1131-0001";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void addAttachmentStepLevel() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String entityName = "stepResult";
		String entityId = "0001478842855916-242ac1131-0001";
		Long projectId = 10000l;
		Long issueId = 10001l;
		String cycleId = "0001478783248567-242ac1131-0001";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "attachment.png";
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName,
				entityId, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 6)
	public void deleteAttachment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		//
		// String entityName = "execution";
		// String entityId = "0001478842855816-242ac1131-0001";
		// String executionId = "0001478842855816-242ac1131-0001";
		// Long projectId = 10000l;
		// Long issueId = 10001l;
		// String cycleId = "0001478783248567-242ac1131-0001";
		// Long versionId = -1l;
		// String comment = "comment";
		// String fileName = "attachment.png";
		// Response response = zapiService.addAttachment(jwtGenerator,
		// projectId, versionId, issueId, executionId, cycleId, entityName,
		// entityId, comment, fileName);
		// Assert.assertNotNull(response, "Create Execution Api Response is
		// null.");
		// test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());
		//
		// String attachmentId = new
		// JSONObject(response.getBody().asString()).get("progress").toString();

		Response response = zapiService.deleteAttachment(jwtGenerator, "0001480521683914-242ac112-0001");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO //StepResult Apis
	// @Test(priority = 2)
	public void getStepResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String executionId = "0001479331535002-242ac1139-0001";
		String stepResultId = "0001479331535243-242ac1139-0001";
		Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateStepResult(stepResultId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getStepResults() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String executionId = "0001479403864785-242ac113a-0001";
		Long issueId = 10000l;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void updateStepResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		String stepResultId = "0001484994104028-242ac112-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001483964254087-242ac112-0001");
		stepresultJson.setStepId("0001483964271423-242ac112-0001");
		stepresultJson.setIssueId(10009l);
		stepresultJson.setStatus(1);
		stepresultJson.setComment("comments");
//		List<Long> list = new ArrayList<>();
//		list.add(10206l);
//		stepresultJson.setDefects(list);
		System.out.println(stepresultJson.toString());
		String pay = "{\"status\":{\"id\":1},\"issueId\":10000,\"stepId\":\"0001484994061797-242ac112-0001\",\"executionId\":\"0001484994103643-242ac112-0001\"}";
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, pay.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(),
				response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getStepDefectsByExecutionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		String executionId = "0001478875753996-242ac1132-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getStepResultByStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		int statusId = 1;
		int offset = 0;
		int maxResults = 10;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResults);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// TODO // Traceability Apis
	@Test(priority = 2)
	public void exportTraceabilityReport() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// String payLoad =
		// "{\"exportType\":\"html\",\"defectIdList\":[\"10129\"],\"versionId\":0}";
		String payLoad = "{\"exportType\":\"ht1ml\",\"requirementIdList\":[\"10129\"],\"versionId\":0}";
		Response response = zapiService.exportTraceabilityReport(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator,
				new JSONObject(response.getBody().asString()).get("jobProgressTicket").toString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("message").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void generateRequirementTraceability() throws UnsupportedEncodingException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10103l;
		List<Long> requirementIdOrKeyList = new ArrayList<>();
		requirementIdOrKeyList.add(10405l);
		requirementIdOrKeyList.add(10017l);

		String requirementList = CommonUtils.convertListToCSVString(requirementIdOrKeyList);
		Response response = zapiService.generateRequirementTraceability(jwtGenerator, versionId, requirementList);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void generateDefectTraceability() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10000l;
		List<Long> defectIdList = new ArrayList<>();
		defectIdList.add(10525l);
		defectIdList.add(10397l);
		String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
		Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void searchExecutionsByDefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10000l;
		Long defectId = 10105l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void searchExecutionsByTest() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10103l;
		Long testId = 10000l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByTest(jwtGenerator, versionId, testId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete an Issue
	 */
	// @Test(priority = 5)
	public void test5_deleteIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = jiraService.deleteIssue(basicAuth, issueKey);
		Assert.assertNotNull(response, "Delete Issue Api Response is null.");
		test.log(LogStatus.PASS, "Delete Issue Api executed successfully.");

		RestUtils.ValidateStatusIs204(response);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void getTestsCreated() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		int daysPrevious = 30;
		String periodName = "daily";
		int maxResults = 5;
		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	 @Test(priority = 2)
	public void getExecutionsCreated() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getExecutionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		String groupFld = "cycle";
		Long versionId = -1l;
		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getTopDefects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10202l;
		Long versionId = -1l;
		int issueStatuses = 10000;
		int howMany = 10;
		Response response = zapiService.getTopDefects(jwtGenerator, projectId, versionId, issueStatuses, howMany);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// @Test(priority = 2)
	public void getTestDistributionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "-1";
		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getProjectsList() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = jiraService.getProjects(basicAuth, "20");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void testPingjob() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.pingJob(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 2)
	public void testGetListOfCyclesBySprint() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Long sprintId = 2l;
		String payLoad = "{\"projectId\":10001,\"versionId\":\"-1,10002,10003,10004\",\"sprintId\":1,\"offset\":0,\"expand\":\"executionSummaries\"}";
		Response response = zapiService.getListOfCyclesBySprint(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
