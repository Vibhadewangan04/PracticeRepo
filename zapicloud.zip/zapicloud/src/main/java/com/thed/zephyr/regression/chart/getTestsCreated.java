/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.chart;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class getTestsCreated extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//getTestsCreated for a project with default values of 30days, periodName=daily and maxResults=10
	//@Test(priority = 2)
	public void getTestsCreated1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 0;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//Attempt to getTestsCreated by passing invalid ProjectId
	//@Test(priority = 2)
	public void getTestsCreated2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 9999l;
		int daysPrevious = 30;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getTestsCreated by passing ProjectId as null
	//@Test(priority = 2)
	public void getTestsCreated3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = null;
		int daysPrevious = 30;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestsCreated for a project with dayPrevious=1 and periodName="hourly"  - NOT APPLICABLE FOR THIS RELEASE
	//@Test(priority = 2)
	public void getTestsCreated4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 1;
		String periodName = "hourly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestsCreated for a project with dayPrevious=30 and periodName="hourly" - NOT APPLICABLE FOR THIS RELEASE
	//@Test(priority = 2)
	public void getTestsCreated5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 30;
		String periodName = "hourly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestsCreated for a project with dayPrevious=365 and periodName="hourly" - NOT APPLICABLE FOR THIS RELEASE
	//@Test(priority = 2)
	public void getTestsCreated6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 365;
		String periodName = "hourly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestsCreated for a project with dayPrevious=1 and periodName="daily"
	//@Test(priority = 2)
	public void getTestsCreated7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 1;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestsCreated for a project with dayPrevious=30 and periodName="daily"
	//@Test(priority = 2)
	public void getTestsCreated8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 30;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getTestsCreated for a project with dayPrevious=365 and periodName="daily"
	//@Test(priority = 2)
	public void getTestsCreated9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 365;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getTestsCreated for a project with dayPrevious=1 and periodName="monthly"
	//@Test(priority = 2)
	public void getTestsCreated10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 1;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getTestsCreated for a project with dayPrevious=30 and periodName="monthly"
	//@Test(priority = 2)
	public void getTestsCreated11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 30;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getTestsCreated for a project with dayPrevious=365 and periodName="monthly"
	//@Test(priority = 2)
	public void getTestsCreated12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 365;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getTestsCreated for a project with dayPrevious=1 and periodName="yearly"
	//@Test(priority = 2)
	public void getTestsCreated13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 1;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getTestsCreated for a project with dayPrevious=30 and periodName="yearly"
	@Test(priority = 2)
	public void getTestsCreated14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 30;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getTestsCreated for a project with dayPrevious=365 and periodName="yearly"
	//@Test(priority = 2)
	public void getTestsCreated15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 365;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//Attempt to getTestsCreated for a project with dayPrevious=366 and periodName="hourly"  - NOT APPLICABLE
	//@Test(priority = 2)
	public void getTestsCreated16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 366;
		String periodName = "hourly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	

	//Attempt to getTestsCreated for a project with dayPrevious=366 and periodName="daily"
	//@Test(priority = 2)
	public void getTestsCreated17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 366;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//Attempt to getTestsCreated for a project with dayPrevious=366 and periodName="monthly"
	//@Test(priority = 2)
	public void getTestsCreated18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 366;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//Attempt to getTestsCreated for a project with dayPrevious=366 and periodName="yearly"
	//@Test(priority = 2)
	public void getTestsCreated19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 366;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//Attempt to getTestsCreated for a project with dayPrevious=0 and periodName=hourly  - NOT APPLICABLE
	//@Test(priority = 2)
	public void getTestsCreated20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 0;
		String periodName = "hourly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}				
	//Attempt to getTestsCreated for a project with dayPrevious=0 and periodName=daily
	//@Test(priority = 2)
	public void getTestsCreated21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 0;
		String periodName = "daily";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}				
	//getTestsCreated for a project with dayPrevious=0 and periodName=monthly
	//@Test(priority = 2)
	public void getTestsCreated22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 0;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}				
	//getTestsCreated for a project with dayPrevious=0 and periodName=yearly
	//@Test(priority = 2)
	public void getTestsCreated23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 0;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}				
	//Attempt to getTestsCreated for a project with periodName as an invalid value
	//@Test(priority = 2)
	public void getTestsCreated24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 0;
		String periodName = "invalid";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}				

	//Attempt to getTestsCreated for a project having only issueType=bug
	//@Test(priority = 2)
	public void getTestsCreated25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId2"));;
		int daysPrevious = 10;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}			
	//Attempt to getTestsCreated for a project having only issueType=Improvement
	//@Test(priority = 2)
	public void getTestsCreated26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId2"));;
		int daysPrevious = 60;
		String periodName = "monthly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}			
	//Attempt to getTestsCreated for a project having only issueType=New Feature
	//@Test(priority = 2)
	public void getTestsCreated27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId2"));;
		int daysPrevious = 4;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}			
	//Attempt to getTestsCreated for a project having only issueType=Story
	//@Test(priority = 2)
	public void getTestsCreated28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 4;
		String periodName = "yearly";

		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestsCreated for a project after deleting 2 tests
	//@Test(priority = 2)
	public void getTestsCreated29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 1;
		String periodName = "daily";
		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getTestsCreated after cloning a test 
	//@Test(priority = 2)
	public void getTestsCreated30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));;
		int daysPrevious = 1;
		String periodName = "daily";
		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	


}