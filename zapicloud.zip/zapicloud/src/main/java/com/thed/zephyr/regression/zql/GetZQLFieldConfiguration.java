/**
 * Created by manoj.behera on 02-Dec-2016.
 */
package com.thed.zephyr.regression.zql;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 02-Dec-2016
 *
 */
public class GetZQLFieldConfiguration extends BaseTest{
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	@Test(priority = 1, enabled = testEnabled)
	public void getZQLFieldConfiguration() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getZQLFieldConfiguration(jwtGenerator);
		Assert.assertNotNull(response, "getZQLFieldConfiguration Api Response is null.");
		test.log(LogStatus.PASS, "getZQLFieldConfiguration Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateGetZQLFieldConfiguration(response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldConfiguration Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
