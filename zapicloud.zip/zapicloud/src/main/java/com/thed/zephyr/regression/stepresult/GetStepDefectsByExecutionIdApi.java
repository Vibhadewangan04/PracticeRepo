/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.stepresult;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class GetStepDefectsByExecutionIdApi extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	//1. Manual - Attempt to getstepDefectsCountByExecution with no valid authentication
	//2. Attempt to getstepDefectsCountByExecution with no browse permission to project
		
	//3. Attempt to getstepDefectsCountByExecution with valid executionId and valid ProjectId with no steps
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API getStepDefectsByExecutionId Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10000l;
		String executionId = "0001479256072154-242ac1137-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//4. Attempt to getstepDefectsCountByExecution with steps but no defect linked to any step
	/*Create an issue with 1 step
	 * create an execution
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountByExecutionId with 1 stepdefect linked to the step 
	/*Create an issue with 1 step
	 * create 1 defect
	 * create an execution
	 * call to updateStepResult to link 1 defect to a step
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountByexecution when there are 5 defects  associated to a step
	/*Create an issue with 1 step
	 * create 5 defects
	 * create an execution
	 * call to updateStepResult to link 5 defects to a step
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479256072154-242ac1137-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getStepDefectsCountByExecution when there are multiple defects associated with the steps that are of different issue types (bug/task/new feature/improvement/test)
	/*Create an issue with 1 step
	 * create 5 defects with type "BUG", "IMPROVEMENT", "NEW FEATURE", "TASK", "TEST"
	 * create an execution
	 * call to updateStepResult to link 5 defects to a step
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479256072154-242ac1137-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getStepDefectsCountByExecution when there are multiple defects associated with the step that are of different status (Open/Resolved/Verified/WorkInProgress/Closed)
	/*Create an issue with 5 step 
	 * create defects with different status "TO DO", "IN PROGRESS", "DONE"
	 * create an execution
	 * call to updateStepResult to link 5 defects to a step
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479505774622-242ac111d-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Get step defects if the defects associated belong to different projects , different issue types and different status 
	/*Create an issue with 5 step 
	 * create defects in different projects
	 * create an execution
	 * call to updateStepResult to link 5 defects belonging to different projects
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	//Get step defects if the defects associated belong to different projects , different issue types and different status 
	/*Create an issue with 5 step 
	 * create defects in different projects of different types "BUG", "IMPROVEMENT", "NEW FEATURE" with status "TO DO", "IN PROGRESS", "DONE"
	 * create an execution
	 * call to updateStepResult to link these defects
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Manual - Get step defects if the defect was created as new issue through the Execute Test page in the UI
	/*Create an issue with 5 step 
	 * create an execution
	 * Link a defect to this execution from UI
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Attempt to get step defects if the defects have been deleted after they were associated to the step result
	/*Create an issue with 5 step 
	 * create defect
	 * create an execution
	 * call to updateStepResult to link this defect and validate by calling getstepDefectsCountByExecution
	 * call to updateStepResult to delete this defect
	 * call to getstepDefectsCountByExecution
	*/
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	//getStepDefectCountbyExecution if there are multiple defects associated with each step result (500 step results and 50 defects in each step result )
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Get step defects by execution if the step defects are of different issue types (bug/task/new feature/improvement/test)
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if the stepresult is executed to status  UNEXECUTED
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectCountbyExecution if the stepresult is executed to status  PASS
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if the stepresult is executed to status  FAIL
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if the stepresult is executed to status  WIP
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if the stepresult is executed to status  BLOCKED
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefecstCountbyExecution if the stepresult is executed to status CUSTOM
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefecstCountbyExecution if partial step results have the same defects associated 
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if all step results have the same defects associated 
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if the test execution has the same defects associated as the step results
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//getStepDefectsCountbyExecution if there are no defects associated to the step results and a few defects associated to the execution
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = "0001479158020117-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	//Attempt to getStepDefectsCountbyExecution if the execution id is invalid
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId23() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 10100l;
		String executionId = "00014000000-242ac1134-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
		
	//Attempt to getStepDefectsCountbyExecution if project id is invalid
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 9999l;
		String executionId = "0001479505774622-242ac111d-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getStepDefectsCountbyExecution if the execution id is null
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		Long projectId = 10100l;
		String executionId = null;
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getStepDefectsCountbyExecution if project id is null
	//@Test(priority = 2)
	public void getStepDefectsByExecutionId26() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = null;
		String executionId = "0001479505774622-242ac111d-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getStepDefectsCountbyExecution if executionId belongs to another project
	// @Test(priority = 2)
	public void getStepDefectsByExecutionId27() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 10000l;
		String executionId = "0001479505774622-242ac111d-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getStepDefectsCountByExecution by Bulk copy test to cycle by clearing defect mapping, execution, assignment flags 
	// @Test(priority = 2)
	public void getStepDefectsByExecutionId28() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 10100l;
		String executionId = "0001479509424076-242ac111d-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getStepDefectsCountByExecution by Bulk copy test to cycle without clearing defect mapping, execution, assignment flags
	// @Test(priority = 2)
	public void getStepDefectsByExecutionId29() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = null;
		String executionId = "0001479505774622-242ac111d-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

		//Attempt to getStepDefectsCountByExecution by Bulk move test to cycle by clearing defect mapping, execution, assignment flags 
	// @Test(priority = 2)
	public void getStepDefectsByExecutionId30() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 10100l;
		String executionId = "0001479280129539-242ac1138-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getStepDefectsCountByExecution by Bulk move test to cycle without clearing defect mapping, execution, assignment flags
	@Test(priority = 2)
	public void getStepDefectsByExecutionId31() {
		ExtentTest test = extentReport.startTest(Thread.currentThread()
				.getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 10100l;
		String executionId = "0001479280129539-242ac1138-0001";
		Response response = zapiService.getStepDefectsByExecutionId(
				jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(
				projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
