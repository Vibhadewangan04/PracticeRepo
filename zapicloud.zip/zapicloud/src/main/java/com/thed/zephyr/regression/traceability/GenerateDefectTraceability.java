package com.thed.zephyr.regression.traceability;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class GenerateDefectTraceability extends BaseTest {
	
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
/**
 * SearchDefectStatistics
 * Generate defect to  Requirement for selected version and selected Defect 
 */	
@Test(priority = 1)	
	public void Test1_generateDefectTraceability(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long versionId = 10103l;
		List<Long> defectIdList = new ArrayList<>();
		defectIdList.add(10223l);
		//defectIdList.add(10397l);
		String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
		Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchDefectStatistics
 * Attempt to Generate defect to  Requirement  for selected version and selected invalid Defect id
 * response-400
 */	
@Test(priority = 2)	
	public void Test2_generateDefectTraceability(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
	
		Long versionId = 10103l;
		List<Long> defectIdList = new ArrayList<>();
		defectIdList.add(1023l);
		//defectIdList.add(10397l);
		String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
		Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchDefectStatistics
 * Generate defect to  Requirement for invalid version and selected valid Defect id
 * Hence version id is not mandatory field we are getting 200 response.
 * 200 response
 */	
@Test(priority = 3)	
	public void Test3_generateDefectTraceability(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
	
		Long versionId = 1013l;
		List<Long> defectIdList = new ArrayList<>();
		defectIdList.add(10223l);
		//defectIdList.add(10397l);
		String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
		Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * SearchDefectStatistics
 * Attempt to Generate defect to  Requirement  for invalid version and invalid Defect id
 * 400 response
 */	
@Test(priority = 4)	
	public void Test4_generateDefectTraceability(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
	
		Long versionId = 1013l;
		List<Long> defectIdList = new ArrayList<>();
		defectIdList.add(1023l);
		//defectIdList.add(10397l);
		String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
		Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect id where Defect is TODO
 * statusId":10000
 * 200 response
 */
@Test(priority = 5)	
public void Test5_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10224l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect id where Defect is In Progress
 * statusId":10000
 * 200 response
 */
@Test(priority = 6)	
public void Test6_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10226l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect id where Defect is Done
 * statusId":10000
 * 200 response
 */
@Test(priority = 7)	
public void Test7_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10225l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
/**
 * SearchDefectStatistics
 * Attempt to Generate defect to Requirement  for selected version id  and Defect id is deleted 
 * statusId":10001
 * 400 response/[{}]
 */
@Test(priority = 8)	
public void Test8_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10227l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to no Tests Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 9)	
public void Test9_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10536l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate Defect to Requirement  for selected version id has Multiple Defect linked 
 * statusId":10001
 * 200 response
 */	
@Test(priority = 10)	
public void Test10_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10567l);
	defectIdList.add(10568l);
	defectIdList.add(10569l);
	defectIdList.add(10570l);
	defectIdList.add(10571l);
	defectIdList.add(10572l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to pass Tests Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 11)	
public void Test11_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10567l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}


/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to Fail Tests Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 12)	
public void Test12_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10568l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to WIP Tests Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 13)	
public void Test13_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10569l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to Blocked Tests Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 14)	
public void Test14_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10570l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to UnExecuted Tests status Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 15)	
public void Test15_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10571l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate defect to Requirement  for selected version id  and Defect linked to Custom status Tests Executions
 * statusId":10001
 * 200 response
 */	

@Test(priority = 16)	
public void Test16_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10572l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate Defect to Requirement  for selected version id  and Defect linked to Tests Executions has Todo  Requirement
 * statusId":10001
 * 200 response
 */	
@Test(priority = 17)	
public void Test17_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10580l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}

/**
 * SearchDefectStatistics
 * Generate Defect to Requirement  for selected version id  and Defect linked to Tests Executions has In Progress  Requirement
 * statusId":10001
 * 200 response
 */	
@Test(priority = 18)	
public void Test18_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10581l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
/**
 * SearchDefectStatistics
 * Generate Defect to Requirement  for selected version id  and Defect linked to  Tests Executions has Done Requirement
 * statusId":10001
 * 200 response
 */	
@Test(priority = 19)	
public void Test19_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10582l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}
/**
 * SearchDefectStatistics
 * Generate Defect to Requirement  for selected version id  and Defect linked to Test Executions has Deleted  Requirement
 * statusId":10001
 * 200 response
 */	
@Test(priority = 20)	
public void Test20_generateDefectTraceability(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Manoj");

	Long versionId = 10103l;
	List<Long> defectIdList = new ArrayList<>();
	defectIdList.add(10584l);
	//defectIdList.add(10397l);
	String requirementListAsString = CommonUtils.convertListToCSVString(defectIdList);
	Response response = zapiService.generateDefectTraceability(jwtGenerator, versionId, requirementListAsString);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());

	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
}











}
