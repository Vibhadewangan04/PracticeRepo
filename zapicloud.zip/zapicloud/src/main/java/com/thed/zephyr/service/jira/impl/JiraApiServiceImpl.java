package com.thed.zephyr.service.jira.impl;

import com.thed.zephyr.service.jira.JiraApiService;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.testng.Assert;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.api.jira.AgileBoardsApi;
import com.thed.zephyr.api.jira.ComponentApi;
import com.thed.zephyr.api.jira.IssueApi;
import com.thed.zephyr.api.jira.PriorityApi;
import com.thed.zephyr.api.jira.ProjectApi;
import com.thed.zephyr.api.jira.SearchApi;
import com.thed.zephyr.api.jira.UserApi;
import com.thed.zephyr.api.jira.VersionApi;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("jiraService")
public class JiraApiServiceImpl implements JiraApiService {

	@Autowired
	private IssueApi issueApi;
	
	@Autowired
	private AgileBoardsApi AgileBoardsApi ;
	
	@Autowired
	private ProjectApi projectApi;
	
	@Autowired
	private PriorityApi priorityApi;
	
	@Autowired
	private UserApi userApi;
	@Autowired
	private VersionApi versionApi;
	
	@Autowired
	private ComponentApi componentApi;
	
	@Autowired
	private SearchApi searchApi;

	private Object payload;

	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#createIssue(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createIssue(RequestSpecification basicAuth, String payLoad) {
		return issueApi.createIssue(basicAuth, payLoad);
	}
	@Override
	public List<String> createIssues(RequestSpecification basicAuth, String payLoad, int numberOfIssues) {
		JSONArray issueObjects = new JSONArray();
		List<String> list = new ArrayList<>();
		String payLoadCopy = payLoad;
		System.out.println("Started creation of "+numberOfIssues+" issues.");
		Object jsonObj = new JSONObject(payLoadCopy).get("fields");
		for(int i=1;i<=numberOfIssues; i++){
			
			JSONObject json = new JSONObject(jsonObj.toString());
			String issueSummary = json.get("summary").toString()+" "+i;
			
			json.remove("summary");
			json.put("summary", issueSummary);
			payLoad = json.toString();
			payLoad = new JSONObject().put("fields", json).toString();
			System.out.println(payLoad);
			Response response = issueApi.createIssue(basicAuth, payLoad);
			System.out.println(response.getBody().asString());
			Assert.assertTrue(validateCreateIssueApi( response), "Validated response successfully.");
			issueObjects.put(response.getBody().asString());
			list.add(response.getBody().asString());
			
			System.out.println("Issue created successfully : "+i);
		}
		return list;
	}
	
	
	
	
	
	
	
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#validateCreateIssueApi(com.jayway.restassured.response.Response)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public boolean validateCreateIssueApi(Response response) {
		System.out.println(response.body().asString());
		JSONObject JSONResponseBody = new JSONObject(response.body().asString());
		System.out.println(JSONResponseBody);
		RestUtils.ValidateStatusIs201(response);
		Assert.assertNotNull(JSONResponseBody.get("id"), "Created issue id is null.");
		Assert.assertNotNull(JSONResponseBody.get("key"), "Created issue key is null.");
		return true;
	}
	
	
	
	
	
	
	
	
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#deleteIssue(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteIssue(RequestSpecification basicAuth, String issueKey) {
		return issueApi.deleteIssue(basicAuth, issueKey);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getProjects(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 03-Dec-2016.
	 */
	@Override
	public Response getProjects(RequestSpecification basicAuth, String recent) {
		return projectApi.getProjects(basicAuth, recent);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getPriorities(com.jayway.restassured.specification.RequestSpecification)
	 * @author Created by manoj.behera on 04-Dec-2016.
	 */
	@Override
	public Response getPriorities(RequestSpecification basicAuth) {
		return priorityApi.getPriorities(basicAuth);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getUsersFromPicker(com.jayway.restassured.specification.RequestSpecification, java.lang.String, int, int, boolean, java.lang.String)
	 * @author Created by manoj.behera on 04-Dec-2016.
	 */
	@Override
	public Response getUsersFromPicker(RequestSpecification basicAuth, String query, int offset, int maxResults,
			boolean showAvatar, String exclude) {
		return userApi.getUsersFromPicker(basicAuth, query, offset, maxResults, showAvatar, exclude);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getProjectVersions(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response getProjectVersions(RequestSpecification basicAuth, String projectIdOrKey) {
		return projectApi.getProjectVersions(basicAuth, projectIdOrKey);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getProjectComponents(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response getProjectComponents(RequestSpecification basicAuth, String projectIdOrKey) {
		return projectApi.getProjectComponents(basicAuth, projectIdOrKey);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getAllProjects(com.jayway.restassured.specification.RequestSpecification)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response getAllProjects(RequestSpecification basicAuth) {
		return projectApi.getAllProjects(basicAuth);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getAllProjectTypes(com.jayway.restassured.specification.RequestSpecification)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response getAllProjectTypes(RequestSpecification basicAuth) {
		return projectApi.getAllProjectTypes(basicAuth);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#createVersion(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response createVersion(RequestSpecification basicAuth, String versionPayLoad) {
		return versionApi.createVersion(basicAuth, versionPayLoad);
	}
	@Override
	public Response getProjectBoard(RequestSpecification basicAuth, String projectId) {
		return AgileBoardsApi.getProjectBoard(basicAuth, projectId);
	}
	
	
	
	
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#getVersion(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response getVersion(RequestSpecification basicAuth, String versionId) {
		return versionApi.getVersion(basicAuth, versionId);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#deleteVersion(com.jayway.restassured.specification.RequestSpecification, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Override
	public Response deleteVersion(RequestSpecification basicAuth, String versionId, String moveFixIssuesTo,
			String moveAffectedIssuesTo) {
		return versionApi.deleteVersion(basicAuth, versionId, moveFixIssuesTo, moveAffectedIssuesTo);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#createComponent(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 21-Mar-2017.
	 */
	@Override
	public Response createComponent(RequestSpecification basicAuth, String componentPayLoad) {
		return componentApi.createComponent(basicAuth, componentPayLoad);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.service.jira.JiraApiService#searchRequest(com.jayway.restassured.specification.RequestSpecification, java.lang.String)
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	@Override
	public Response searchRequest(RequestSpecification basicAuth, String payLoad) {
		return searchApi.searchRequest(basicAuth, payLoad);
	}
	@Override
	public Response searchRequest(RequestSpecification basicAuth, String jql, int startAt, int maxResults) {
		return searchApi.searchRequest(basicAuth, jql, startAt, maxResults);
	}
	@Override
	public Response createFilterInSearchTest(RequestSpecification basicAuth, String payload) {
		// TODO Auto-generated method stub
		//return null;
		return searchApi.createFilterInSearchTest(basicAuth, payload);
	}
	@Override
	public Response createIssueLink(RequestSpecification basicAuth, String payload) {
		// TODO Auto-generated method stub
		return searchApi.createIssueLink(basicAuth, payload);
		
		//return null;
	}
	@Override
	public Response createSprint(RequestSpecification basicAuth, String payload) {
		return AgileBoardsApi.createSprint(basicAuth, payload);
}
	@Override
	public Response addissuetosprint(RequestSpecification basicAuth, Long sprintId,String payload) {
		// TODO Auto-generated method stub
		return AgileBoardsApi.addissuetosprint(basicAuth, sprintId, payload);
}
	@Override
	public  Response editissue(RequestSpecification basicAuth, String issueKey,String payload) {
		// TODO Auto-generated method stub
		return issueApi.editissue( basicAuth, issueKey,payload);
	}
	@Override
	public Response updatesprint(RequestSpecification basicAuth, Long sprintId, String payload) {
		// TODO Auto-generated method stub
		return AgileBoardsApi.updatesprint(basicAuth, sprintId, payload);
	}
	@Override
	public Response deletesprint(RequestSpecification basicAuth, Long sprintId) {
		// TODO Auto-generated method stub
		return AgileBoardsApi.deletesprint(basicAuth, sprintId);
	}
	@Override
	public Response getTransitions(RequestSpecification basicAuth, String issueKey) {
		// TODO Auto-generated method stub
		return issueApi.getTransitions(basicAuth, issueKey);
	}
}