/**
 *
 */
package com.thed.zephyr.regression.cycle;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetCyclesApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	Long projectId = null;
	Long versionId = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	//TODO
	//Get cycles under unscheduled version if no planned cycle is created(Get Only Adhoc Cycle)
	@Test(priority = 1, enabled = testEnabled)
	public void test1_getCyclesUnderUnscheduledVersionIfNoPlannedCycleIsCreated(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get Cycles After Create cycle in unscheduled version
	@Test(priority = 2, enabled = testEnabled)
	public void test2_getCyclesThatAreCreatedInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10001l;
		versionId = -1l;

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get cycles under scheduled version if no planned cycle is created(Get Only Adhoc Cycle)
	@Test(priority = 3, enabled = testEnabled)
	public void test3_getCyclesUnderScheduledVersionIfNoPlannedCycleIsCreated(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10001l;
		versionId = -1l;

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get cycles if Version contains 50 cycles
	@Test(priority = 4, enabled = testEnabled)
	public void test4_getCyclesIfVersionContains50Cycles(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionThreeId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get cycles if Version contains 500 cycles
	@Test(priority = 5, enabled = false)
	public void test5_getCyclesIfVersionContains500Cycles(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionThreeId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get cycles if Version contains 1000 cycles
	@Test(priority = 6, enabled = false)
	public void test6_getCyclesIfVersionContains1000Cycles(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionThreeId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to Get Cycles without providing project id
	@Test(priority = 7)
	public void test7_attemptToGetCyclesWithoutProvidingProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong("12345678");
		versionId = Long.parseLong(Config.getValue("versionThreeId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to Get Cycles without providing version id
	@Test(priority = 8, enabled = testEnabled)
	public void test8_attemptToGetCyclesWithoutProvidingVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong("12345678");

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

}
