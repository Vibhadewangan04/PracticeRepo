/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.io.File;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.AttachmentApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("attachmentApi")
public class AttachmentApiImpl implements AttachmentApi{

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.AttachmentApi#addAttachment(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response addAttachment(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long issueId, String cycleId, String entityName, String entityId, String comment, String fileName) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/attachment";
		/*String entityName = "execution";
		String entityId = "0001479331535002-242ac1139-0001";
		String executionId = "0001479331535002-242ac1139-0001";
		Long projectId = 10000l;
		Long issueId = 10001l;
		String cycleId = "0001478768964952-242ac1131-0001";
		Long versionId = -1l;
		String comment = "comment";*/
//		String entityName = "stepResult";
//		String entityId = "0001479331535243-242ac1139-0001";
//		String executionId = "0001479331535002-242ac1139-0001";
//		Long projectId = 10000l;
//		Long issueId = 10001l;
//		String cycleId = "0001478768964952-242ac1131-0001";
//		Long versionId = -1l;
//		String comment = "comment";
//		String uriStr = "https://916be189.ngrok.io/connect/public/rest/api/1.0/attachment?entityName=execution&entityId=0001479331535002-242ac1139-0001&executionId=0001479331535002-242ac1139-0001&projectId=10000&issueId=10001&cycleId=0001478768964952-242ac1131-0001&versionId=-1&comment=";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("entityName", entityName).queryParam("entityId", entityId).queryParam("projectId", projectId).queryParam("issueId", issueId).queryParam("cycleId", cycleId).queryParam("versionId", versionId).queryParam("comment", comment).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		System.out.println(uri);
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "multipart/form-data");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		 File attachmentFile = new File(Config.getValue("attachmentPath")+fileName);
		 String attachmentFile1 = new File(Config.getValue("attachmentPath")+fileName).getAbsolutePath();
		return given().headers(headers).multiPart(attachmentFile).when().post(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.AttachmentApi#getExecutionAttachmentsList(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecutionAttachmentsList(JwtGenerator jwtGenerator, String entityId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/attachment/search/execution";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("entityId", entityId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.AttachmentApi#getStepResultAttachmentsList(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getStepResultAttachmentsList(JwtGenerator jwtGenerator, String stepResultId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/attachment/search/stepresult";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).formParam("stepResultId", stepResultId).when().post(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.AttachmentApi#getAttachmentThumbnail(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getAttachmentThumbnail(JwtGenerator jwtGenerator, String attachmentId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/attachment/"+attachmentId+"/thumbnail";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/octet-stream");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getAttachmentImage(JwtGenerator jwtGenerator, String attachmentId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/attachment/"+attachmentId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/octet-stream");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.AttachmentApi#deleteAttachment(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteAttachment(JwtGenerator jwtGenerator, String attachmentId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/attachment/"+attachmentId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("DELETE", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().delete(uri);
	}

}
