/**
 *
 */
package com.thed.zephyr.regression.jiraReport;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetExecutionCountApi extends BaseTest{

	JwtGenerator jwtGenerator = null;
	Long projectId = null;
	Long versionId = null;
	String groupFld = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//Get Execution Count by passing projectId, versionId of unscheduled version and groupBy cycle
	@Test(priority = 1)
	public void test1_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "cycle";
		versionId = -1l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Get Execution Count by passing projectId, versionId of unscheduled version and groupBy user
	@Test(priority = 2)
	public void test2_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "user";
		versionId = -1l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Get Execution Count by passing projectId, versionId of unscheduled version and groupBy component
	@Test(priority = 3)
	public void test3_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "component";
		versionId = -1l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Get Execution Count by passing projectId, versionId of scheduled version and groupBy cycle
	@Test(priority = 4)
	public void test4_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "cycle";
		versionId = 10108l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Get Execution Count by passing projectId, versionId of scheduled version and groupBy user
	@Test(priority = 5)
	public void test5_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "user";
		versionId = 10108l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Get Execution Count by passing projectId, versionId of scheduled version and groupBy component
	@Test(priority = 6)
	public void test6_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "component";
		versionId = 10108l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//  Attempt to get Execution Count without passing projectId
	@Test(priority = 30)
	public void test30_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = null;
		groupFld = "cycle";
		versionId = -1l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Attempt to get Execution Count without passing versionId
	@Test(priority = 31)
	public void test31_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = "cycle";
		versionId = null;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//	Attempt to get Execution Count without passing groupFId
	@Test(priority = 32)
	public void test32_(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = 10000l;
		groupFld = null;
		versionId = -1l;

		Response response = zapiService.getExecutionCount(jwtGenerator, projectId, versionId, groupFld);
		Assert.assertNotNull(response, "Get Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Cycles Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

}
