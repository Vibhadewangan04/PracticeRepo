/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.chart;

import java.util.ArrayList;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class getExecutionsCreated extends BaseTest {
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//getExecutionsCreated for a project with default values of 30days, periodName=daily
	//@Test(priority = 2)
	public void getExecutionsCreated1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//Attempt to getExecutionsCreated by passing invalid ProjectId
	//@Test(priority = 2)
	public void getExecutionsCreated2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = 9999l;
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionsCreated by passing ProjectId as null
	//@Test(priority = 2)
	public void getExecutionsCreated3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = null;
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with dayPrevious=1 and periodName="hourly" -NOT APPLICABLE IN THIS RELEASE
	//@Test(priority = 2)
	public void getExecutionsCreated4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 1;
		String periodName = "hourly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with dayPrevious=30 and periodName="hourly" -NOT APPLICABLE IN THIS RELEASE
	//@Test(priority = 2)
	public void getExecutionsCreated5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "hourly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with dayPrevious=365 and periodName="hourly" -NOT APPLICABLE IN THIS RELEASE
	//@Test(priority = 2)
	public void getExecutionsCreated6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 365;
		String periodName = "hourly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with dayPrevious=1 and periodName="daily"
	//@Test(priority = 2)
	public void getExecutionsCreated7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 1;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with dayPrevious=30 and periodName="daily"
	//@Test(priority = 2)
	public void getExecutionsCreated8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with dayPrevious=365 and periodName="daily"
	//@Test(priority = 2)
	public void getExecutionsCreated9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 365;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getExecutionsCreated for a project with dayPrevious=1 and periodName="monthly"
	//@Test(priority = 2)
	public void getExecutionsCreated10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 1;
		String periodName = "monthly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getExecutionsCreated for a project with dayPrevious=30 and periodName="monthly"
	//@Test(priority = 2)
	public void getExecutionsCreated11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "monthly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getExecutionsCreated for a project with dayPrevious=1 and periodName="monthly"
	//@Test(priority = 2)
	public void getExecutionsCreated12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 365;
		String periodName = "monthly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getExecutionsCreated for a project with dayPrevious=1 and periodName="yearly"
	//@Test(priority = 2)
	public void getExecutionsCreated13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 1;
		String periodName = "yearly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getExecutionsCreated for a project with dayPrevious=30 and periodName="yearly"
	//@Test(priority = 2)
	public void getExecutionsCreated14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "yearly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//getExecutionsCreated for a project with dayPrevious=1 and periodName="yearly"
	//@Test(priority = 2)
	public void getExecutionsCreated15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 365;
		String periodName = "yearly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//Attempt to getExecutionsCreated for a project with dayPrevious=366 and periodName="hourly"  -NOT APLLICABLE IN RELEASE 2.1
	//@Test(priority = 2)
	public void getExecutionsCreated16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 366;
		String periodName = "hourly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}


	//Attempt to getExecutionsCreated for a project with dayPrevious=366 and periodName="daily"
	//@Test(priority = 2)
	public void getExecutionsCreated17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 366;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getExecutionsCreated for a project with dayPrevious=366 and periodName="monthly"
	//@Test(priority = 2)
	public void getExecutionsCreated18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 366;
		String periodName = "monthly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionsCreated for a project with dayPrevious=366 and periodName="yearly"
	//@Test(priority = 2)
	public void getExecutionsCreated19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 366;
		String periodName = "yearly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionsCreated for a project with dayPrevious=0 and periodName=hourly  - NOT APPLICABLE FOR RELEASE 2.1
	//@Test(priority = 2)
	public void getExecutionsCreated20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 0;
		String periodName = "hourly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getExecutionsCreated for a project with dayPrevious=0 and periodName=daily
	//@Test(priority = 2)
	public void getExecutionsCreated21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 0;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getExecutionsCreated for a project with dayPrevious=0 and periodName=monthly
	//@Test(priority = 2)
	public void getExecutionsCreated22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 0;
		String periodName = "monthly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getExecutionsCreated for a project with dayPrevious=0 and periodName=yearly
	//@Test(priority = 2)
	public void getExecutionsCreated23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 0;
		String periodName = "yearly";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	//Attempt to getExecutionsCreated for a project with periodName as an invalid value
	//@Test(priority = 2)
	public void getExecutionsCreated24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "invalid";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}		
	//getExecutionsCreated for a project with no tests executed
	//@Test(priority = 2)
	public void getExecutionsCreated25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId2"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//getExecutionsCreated for a project with 1 test executed to a status
	//@Test(priority = 2)
	public void getExecutionsCreated26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId2"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	//Attempt to getExecutionsCreated for a project having only issueType=bug
	//@Test(priority = 2)
	public void getExecutionsCreated27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	//Attempt to getExecutionsCreated for a project having only issueType=Improvement
	//@Test(priority = 2)
	public void getExecutionsCreated28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId2"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	//Attempt to getExecutionsCreated for a project having only issueType=New Feature
	//@Test(priority = 2)
	public void getExecutionsCreated29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	

	//Attempt to getExecutionsCreated for a project having only issueType=Story
	//@Test(priority = 2)
	public void getExecutionsCreated30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	


}