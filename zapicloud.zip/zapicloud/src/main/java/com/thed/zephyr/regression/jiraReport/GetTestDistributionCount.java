package com.thed.zephyr.regression.jiraReport;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

public class GetTestDistributionCount extends BaseTest {
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	Long projectId=10300l;
	Long VersionId1=10209l;
	Long VersionId2=10230l;
	
	
/**
 * JiraReport
 * getTestDistributionCount  
 * 1.Create a Test schedule Adhoc but don't execute 
 * 
*/	
 @Test(priority = 1)
	public void Test1_getTestDistributionCount() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = -1l;
		String cycleId = "0001480769547843-242ac1129-0001";
		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
 /**
  * JiraReport
  * getTestDistributionCount  
  * 2.Create a Test schedule Adhoc but don't execute and execute on same day
  * 
 */	
  //@Test(priority = 2)
 	public void Test2_getTestDistributionCount() {
 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
 		test.assignAuthor("Manoj");

 		//Long projectId = Long.parseLong(Config.getValue("projectId"));
 		Long versionId = -1l;
 		String cycleId = "-1";
 		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
 		Assert.assertNotNull(response, "Create Execution Api Response is null.");
 		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
 		System.out.println(response.getBody().asString());

 		test.log(LogStatus.PASS, "Response validated suuccessfully.");
 		extentReport.endTest(test);
 	}
 	
/**
  * JiraReport
  * getTestDistributionCount  
  * 3.Create a 2 Test schedule Adhoc but  execute one test execution and view completionDate(next day)
  * 
 */	
 // @Test(priority = 3)
 	public void Test3_getTestDistributionCount() {
 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
 		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
 		test.assignAuthor("Manoj");

 		//Long projectId = Long.parseLong(Config.getValue("projectId"));
 		Long versionId = -1l;
 		String cycleId = "-1";
 		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
 		Assert.assertNotNull(response, "Create Execution Api Response is null.");
 		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
 		System.out.println(response.getBody().asString());

 		test.log(LogStatus.PASS, "Response validated suuccessfully.");
 		extentReport.endTest(test);
 	}
  
  /**
   * JiraReport
   * getTestDistributionCount  
   * 4.Add >5 Test schedule Adhoc but  execute one test execution and view completionDate
   * 
  */	
  // @Test(priority = 4)
  	public void Test4_getTestDistributionCount() {
  		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
  		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
  		test.assignAuthor("Manoj");

  		//Long projectId = Long.parseLong(Config.getValue("projectId"));
  		Long versionId = -1l;
  		String cycleId = "-1";
  		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
  		Assert.assertNotNull(response, "Create Execution Api Response is null.");
  		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
  		System.out.println(response.getBody().asString());

  		test.log(LogStatus.PASS, "Response validated suuccessfully.");
  		extentReport.endTest(test);
  	}
   /**
    * JiraReport
    * getTestDistributionCount  
    * 5.Add >5 Test schedule Adhoc but  execute one test execution and view completionDate
    * 
   */	
   // @Test(priority = 5)
   	public void Test5_getTestDistributionCount() {
   		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
   		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
   		test.assignAuthor("Manoj");

   		//Long projectId = Long.parseLong(Config.getValue("projectId"));
   		Long versionId = -1l;
   		String cycleId = "-1";
   		Response response = zapiService.getTestDistributionCount(jwtGenerator, projectId, versionId, cycleId);
   		Assert.assertNotNull(response, "Create Execution Api Response is null.");
   		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
   		System.out.println(response.getBody().asString());

   		test.log(LogStatus.PASS, "Response validated suuccessfully.");
   		extentReport.endTest(test);
   	}

	

}
