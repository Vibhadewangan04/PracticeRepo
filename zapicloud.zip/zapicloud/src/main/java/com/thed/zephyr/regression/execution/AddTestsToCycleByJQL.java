//add test to cycle by filter


package com.thed.zephyr.regression.execution;

import java.net.URISyntaxException;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class AddTestsToCycleByJQL extends BaseTest{
	
	String cycleId = null;
	String issueKey = null;
	Long versionId = null;
	 private Long projectId = Long.parseLong(Config.getValue("projectId")); 
	  private Long projectId1 = Long.parseLong(Config.getValue("projectId1")); 
    private Long issueId;
    Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
    Long issueTypeId1 = Long.parseLong(Config.getValue("issueTypeStoryId"));
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add tests to a cycle through search filter
	 */

	
	@Test(priority = 0)
    public void CreateFilterInSearchTest_Test(){
        ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
        test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
        test.assignAuthor("poornachandra");
    String JQL="Project="+Config.getValue("projectKey") + " AND issuetype = Test";
    String Description="CreateFilterInSearchTest_through api";
    String JQLName="CreateFilterInSearchTest"+System.currentTimeMillis();
    String payload="{\"jql\": \""+JQL+"\",\"name\": \""+JQLName+"\",\"description\": \""+Description+"\"}";
    System.out.println(payload);
   
	Response createFilterResponse = jiraService.createFilterInSearchTest(basicAuth, payload);
	System.out.println(createFilterResponse.statusCode());
	Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
	test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
	System.out.println("create issue api response: " + createFilterResponse.getBody().asString());
}
	
	
	@Test(priority = 1)
	public void addTestsToCycleByJQL_Test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("Cycle with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);		
		
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND priority = Low\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add 500 tests to a cycle through search filter, if the test contains multiple test steps (if there are 100 tests for the filter)
	 */
	
	
	
	@Test(priority = 2)
	public void addTestsToCycleByJQL_Test2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionOneId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("Cycle with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);		
		
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND priority = Low\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		// as of now above filer have few test cases, if user want to add 100/500 test then he can use this query project = "+projectKey+" AND issuetype = Test
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add tests to a cycle through search filter if some issues in the filter are not of type test
	 */

	
	@Test(priority = 3)
	public void addTestsToCycleByJQL_Test3(){
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("unscheduleId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create search test filter
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("Ccycle with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);		
		
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype in (Epic, Task)\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	
		
	//	String cycleId = "0001479990794954-242ac1122-0001";
		/*String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND priority = Low\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
//		String payLoad = "{\"jql\":\"project = TRAC AND issuetype in (Bug, Task, Test)\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);*/
	}
	
	
	@Test(priority = 21, enabled = testEnabled)
	public void bvt21_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("unscheduleId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("ccc2 with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);		
		
	
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Epic \",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add tests to an adhoc cycle through search filter 
	 */
	
	
	
	@Test(priority = 4, enabled = testEnabled)
	public void bvt4_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		/*Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("ccc2 with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);	*/	
		
		
		
	String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		System.out.println("check above payload");
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	

	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to a cycle through search filter, if none of the issues are of type test
	 */
	
	
	@Test(priority = 5, enabled = testEnabled)
	public void bvt5_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype  in (Epic, Task)\" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		System.out.println("check above payload");
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	
//	@Test(priority = 5)
	/*public void addTestsToCycleByJQL_Test5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "-1";
		String payLoad = "{\"jql\":\"project = TRAC AND issuetype in (Bug, Task)\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	*/
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add tests to cycle through search filter if some tests are already existing in that cycle
	 */
	
	
	@Test(priority = 6, enabled = testEnabled)
	public void bvt6_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("now cycle with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);
		

		
		
		//String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		String payLoad2 ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter2 \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad2.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		System.out.println(response2.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
		
	}
	
	

	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to Add tests to cycle through search filter if all tests already exists in the cycle
	 */
	
	
	
	@Test(priority = 7, enabled = testEnabled)
	public void bvt7_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		//create Cycle code 
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(versionid);
		cycleJson.setName("test7 cycle with Add test to Cycle using Filter");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild(Config.getValue("connectBuildNumber"));
		cycleJson.setEnvironment("QA-Bench");
		Response createcycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createcycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(createcycleresponse.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), createcycleresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String Cycleid = new JSONObject(createcycleresponse.body().asString()).get("id").toString();	
		System.out.println(Cycleid);
		
		//String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		String payLoad2 ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad2.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response2.getBody().asString());
		response2 = zapiService.jobProgressHandler(jwtGenerator, response2.getBody().asString());
		System.out.println(response2.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	

	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add  tests to adhoc cycle through search filter when JQL filter query is "null"
	 */	
	// need to check
	@Test(priority = 8, enabled = testEnabled)
	public void bvt8_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId1"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test\",\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":null ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	//	response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
	//	System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
//	@Test(priority = 8)
	public void addTestsToCycleByJQL_Test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479989561727-242ac1122-0001";
		String payLoad = "{\"jql\":\"null\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add tests to cycle through search filter if some tests does not belong to the project
	 */
	
	
	@Test(priority = 9, enabled = testEnabled)
	public void bvt9_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		String projectkey2 = Config.getValue("projectKey1");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		//String payLoad = "{\"jql\":\"project = TRAC AND issuetype in (Bug, Task)\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project in ("+projectKey+ "," +projectkey2+ ") AND issuetype = Test AND labels = anotherProject \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to cycle through search filter if none of the tests belong to the project
	 */
	
	
	
	
	@Test(priority = 10, enabled = testEnabled)
	public void bvt10_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey1");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		// boolean status =
		// zapiService.validateCreatedExecution(executionJson.toString(),
		// response);
		// Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
//	@Test(priority = 10)
	public void addTestsToCycleByJQL_Test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479989561727-242ac1122-0001";
		String payLoad = "{\"jql\":\"project = APIB AND issuetype=Test\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests through search filter by passing invalid cycleId
	 */
	
	
	// need to check
	@Test(priority = 11, enabled = testEnabled)
	public void bvt11_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		/*Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");*/
		
		
		String Cycleid = "1111";
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
		Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		/*response = zapiService.jobProgressHandler2(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);*/
	}
	

	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests through search filter by passing invalid versionId
	 */
	
	
	@Test(priority = 12, enabled = testEnabled)
	public void bvt12_addTestsTocycle_ScheduledAdhoc_by_filter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		//projectId = 111l;
		versionid = 111l;
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
	    Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		/*response = zapiService.jobProgressHandler2(jwtGenerator, response.getBody().asString());
		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);*/
	}
	

	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests through search filter by passing invalid projectId
	 */
	
	@Test(priority = 13)
	public void addTestsToCycleByJQL_Test13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		projectid = 111l;
		//versionid = 111l;
		//String payLoad = "{\"jql\":\"project = 10006 AND issuetype = Test\",\"versionId\":10009,\"projectId\":10006,\"method\":\"2\"}";
		//String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Test AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
	    Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to cycle through search filter if filter results has no tests
	 */
	
	@Test(priority = 14)
	public void addTestsToCycleByJQL_Test14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectid= Long.parseLong(Config.getValue("projectId"));
		Long versionid= Long.parseLong(Config.getValue("versionFourId"));
		String projectKey = Config.getValue("projectKey");
		
		//create issue with priority
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("4");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		boolean status = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		issueKey = new JSONObject(response1.body().asString()).getString("key");
		
		
		String Cycleid = "-1";
		String payLoad ="{\"jql\":\"project = "+projectKey+" AND issuetype = Task AND labels = filter \" ,\"versionId\":"+versionid+",\"projectId\":"+projectid+",\"method\":\"2\"}";
		System.err.println(payLoad.toString());
		//String payLoad = "{\"jql\":\"project = "+ Config.getValue("projectId")"+\"AND issuetype ="+" Test ,\versionId\":"+versionId+,\"projectId\":"+projectId+",\"method\":\"2\"};
	    Response response = zapiService.addTestsTocycle(jwtGenerator, Cycleid, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479981727-242ac1122-0001";
		String payLoad = "{\"jql\":\"project = IE AND issuetype=Test\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());*/
		
	}
	
	
	
	
//	@Test(priority = 1111) old code
	public void addTestsToCycleByJQL_Test1111(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479981727-242ac1122-0001";
		String payLoad = "{\"jql\":\"project = TRAC AND issuetype=Test\",\"versionId\":10301,\"projectId\":10200,\"method\":\"2\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
	}
	
}







