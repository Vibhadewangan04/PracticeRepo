/**
 * Created by Manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.stepresult;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Manoj.behera 17-Nov-2016
 *
 */
public class GetStepResultByStatusApi extends BaseTest{
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	// getstepresultstatus of an execution with stepstatus PASS
	//@Test(priority = 2)
	public void getStepResultByStatus1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 9;
		int offset = 0;
		int maxResult = 500;
		JSONObject JSONResponseBody = new JSONObject();
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		Long issueId = (Long) JSONResponseBody.get("id");
		System.out.println(issueId);
		
		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);
		
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//getstepresultstatus of an execution with stepstatus FAIL
	//@Test(priority = 2)
	public void getStepResultByStatus2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 5;
		int offset = 501;
		int maxResult = 500;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//getstepresultstatus of an execution with stepstatus WIP
	//@Test(priority = 2)
	public void getStepResultByStatus3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 3;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//getstepresultstatus of an execution with stepstatus BLOCKED
	//@Test(priority = 2)
	public void getStepResultByStatus4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 4;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//getstepresultstatus of an execution with custom stepstatus CUSTOM#
	//@Test(priority = 2)
	public void getStepResultByStatus5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 7;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//getstepresultstatus of an execution with stepstatus UNEXECUTED
	//@Test(priority = 2)
	public void getStepResultByStatus6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = -1;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to getstepresultstatus of an execution with stepstatus that does not exist
	//@Test(priority = 2)
	public void getStepResultByStatus7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 10000;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Manual - Edit test step status PASS to PASSED and getstepresultstatus of an execution 
	//@Test(priority = 2)
	public void getStepResultByStatus8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 1;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Manual -Edit test step status FAIL to FAILED and getstepresultstatus of an execution 
	//@Test(priority = 2)
	public void getStepResultByStatus9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 2;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Edit test step status WIP to PROGRESS and getstepresultstatus of an execution 
	//@Test(priority = 2)
	public void getStepResultByStatus10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 3;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Edit test step status BLOCKED to CRITICAL and getstepresultstatus of an execution 
	//@Test(priority = 2)
	public void getStepResultByStatus11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 4;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Manual - Edit custom test step status CUSTOM# to RANDOM and getstepresultstatus of an execution 
	//@Test(priority = 2)
	public void getStepResultByStatus12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 5;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Edit the teststepresult status from PASS to WIP and make a call to getstepresultstatus 
	//@Test(priority = 2)
	public void getStepResultByStatus13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 1;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Change the teststepresult status from FAIL to WIP and make a call to getstepresultstatus 
	//@Test(priority = 2)
	public void getStepResultByStatus14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 2;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Change the teststepresult status from WIP to CUSTOM and make a call to getstepresultstatus 
	//@Test(priority = 2)
	public void getStepResultByStatus15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 3;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Change the teststepresult status from BLOCKED to WIP and make a call to getstepresultstatus by passing PASS value
	//@Test(priority = 2)
	public void getStepResultByStatus16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 4;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Edit the teststepresult status from CUSTOM to WIP and make a call to getstepresultstatus by passing PASS value
	//@Test(priority = 2)
	public void getStepResultByStatus17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 5;
		int offset = 0;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Attempt to getstepresultstatus by Delete a CUSTOM step status and make a call to getstepstatus by passing CUSTOM status
	@Test(priority = 2)
	public void getStepResultByStatus18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 9;
		int offset = 1501;
		int maxResult = 500;

		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Make a call to getstepresultstatus by passing status that does not have any stepresult executions
	//@Test(priority = 2)
	public void getStepResultByStatus19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 7;
		int offset = 0;
		int maxResult = 400;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Edit test step status UNEXECUTED to PASS and getstepresultstatus of an execution
	//@Test(priority = 2)
	public void getStepResultByStatus20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 5;
		int offset = 0;
		int maxResult = 500;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//getTeststepStatus of a execution by setting the offset value to be 20 and maxResult=500
	//@Test(priority = 2)
	public void getStepResultByStatus21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 9;
		int offset = 0;
		int maxResult = 500;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//getTeststepStatus of a execution by setting the offset value to be 20 and maxResult=30
	//@Test(priority = 2)
	public void getStepResultByStatus22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 1;
		int offset = 0;
		int maxResult = 501;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Attempt to getTeststepStatus of a execution by setting the offset value to a negative value
	//@Test(priority = 2)
	public void getStepResultByStatus23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 9;
		int offset = -1;
		int maxResult = 500;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//getTeststepStatus of a execution by setting the offset value greater than the maxResult
	//@Test(priority = 2)
	public void getStepResultByStatus24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 7;
		int offset = 10;
		int maxResult = 5;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Attempt to getTeststepStatus of a execution by setting the offset =0 and maxResult = 501
	//@Test(priority = 2)
	public void getStepResultByStatus25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 9;
		int offset = 0;
		int maxResult = 501;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Attempt to getTeststepStatus of a execution by setting the maxResult to a negative value
	//@Test(priority = 2)
	public void getStepResultByStatus26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 1;
		int offset = 0;
		int maxResult = -1;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	//Attempt to getTeststepStatus of a execution by setting the offset and maxResult to the same value
	//@Test(priority = 2)
	public void getStepResultByStatus27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 1;
		int offset = 10;
		int maxResult = 10;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//getTeststepStatus of a execution by setting the offset =20 and maxResult=30
	//@Test(priority = 2)
	public void getStepResultByStatus28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");

		int statusId = 1;
		int offset = 20;
		int maxResult = 30;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

}

