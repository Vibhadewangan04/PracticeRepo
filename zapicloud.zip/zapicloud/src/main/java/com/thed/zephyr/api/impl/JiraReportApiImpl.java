/**
 * Created by manoj.behera on 21-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.JiraReportApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 21-Nov-2016
 *
 */
@Service("jiraReportApi")
public class JiraReportApiImpl  implements JiraReportApi{

	@Override
	public Response getExecutionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String groupFld){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executioncount";
		URI uri;
		if (projectId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("versionId", versionId).queryParam("groupFld", groupFld).build();
		}
		else if (versionId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("groupFld", groupFld).build();
		}
		else if (groupFld == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).build();
		}
		else {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("groupFld", groupFld).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());

		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getTopDefects(JwtGenerator jwtGenerator, Long projectId, Long versionId, int issueStatuses, int howMany){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/defectcount";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("issueStatuses", issueStatuses).queryParam("howMany", howMany).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());

		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getTestDistributionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executioncount";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("cycleId", cycleId).queryParam("groupFld", "timePeriod").queryParam("periodName", "daily").build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());

		return given().headers(headers).when().get(uri);
	}
}
