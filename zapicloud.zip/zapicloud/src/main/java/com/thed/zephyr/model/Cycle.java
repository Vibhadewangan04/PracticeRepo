package com.thed.zephyr.model;

import org.json.JSONObject;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class Cycle {

	
	private Long projectId;
	private Long versionId;
	private String name;
	private String description;
	private String build;
	private String environment;
	private String startDate;
	private String endDate;
	private String id;
	
	
	/**
	 * @param projectId the projectId to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}
	/**
	 * @param versionId the versionId to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setVersionId(Long versionId) {
		this.versionId = versionId;
	}
	/**
	 * @param name the name to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @param description the description to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	/**
	 * @return the projectId
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public Long getProjectId() {
		return projectId;
	}
	/**
	 * @return the versionId
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public Long getVersionId() {
		return versionId;
	}
	/**
	 * @return the name
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @return the description
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getDescription() {
		return description;
	}
	/**
	 * @return the build
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getBuild() {
		return build;
	}
	/**
	 * @return the environment
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getEnvironment() {
		return environment;
	}
	/**
	 * @return the startDate
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getStartDate() {
		return startDate;
	}
	/**
	 * @return the endDate
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getEndDate() {
		return endDate;
	}
	/**
	 * @return the id
	 * Created by manoj.behera on 20-Feb-2017.
	 */
	public String getId() {
		return id;
	}
	/**
	 * @param build the build to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setBuild(String build) {
		this.build = build;
	}
	/**
	 * @param environment the environment to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	/**
	 * @param startDate the startDate to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	/**
	 * @param endDate the endDate to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	/**
	 * @param id the id to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setId(String id) {
		this.id = id;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public String toString() {
		JSONObject cycleJson = new JSONObject();
		cycleJson.put("projectId", this.projectId);
		cycleJson.put("versionId", this.versionId);
		cycleJson.put("name", this.name);
		cycleJson.put("clearCustomFieldsFlag", true);
		if(this.description != null || this.description != ""){
			cycleJson.put("description", this.description);
		}
		if(this.build != null || this.build != ""){
			cycleJson.put("build", this.build);
		}
		if(this.environment != null || this.environment != ""){
			cycleJson.put("environment", this.environment);
		}
		if(this.startDate != null || this.startDate != ""){
			cycleJson.put("startDate", this.startDate);
		}
		if(this.endDate != null || this.endDate != ""){
			cycleJson.put("endDate", this.endDate);
		}
		if(this.id != null || this.id != ""){
			cycleJson.put("id", this.id);
		}
		return cycleJson.toString();
	}
}
