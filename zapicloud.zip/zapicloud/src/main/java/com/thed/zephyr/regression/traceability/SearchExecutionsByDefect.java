package com.thed.zephyr.regression.traceability;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.cloud.rest.model.StepResult;
import com.thed.zephyr.cloud.rest.util.json.StepResultJsonParser;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;


public class SearchExecutionsByDefect extends BaseTest{

	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated to only 1 execution
	 */
	
	//@Test(priority = 1)
	public void searchExecutionsByDefect_test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated to only 10 executions
	 */
	
	//@Test(priority = 2)
	public void searchExecutionsByDefect_test2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated to only 1 execution
	 */
	
	//@Test(priority = 3)
	public void searchExecutionsByDefect_test3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated execution status is unexecuted
	 */
	
	//@Test(priority = 4)
	public void searchExecutionsByDefect_test4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated execution status is Pass
	 */
	
	//@Test(priority = 5)
	public void searchExecutionsByDefect_test5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated execution status is Fail
	 */
	
	//@Test(priority = 6)
	public void searchExecutionsByDefect_test6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated execution status is WIP
	 */
	
	//@Test(priority = 7)
	public void searchExecutionsByDefect_test7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated execution status is Blocked
	 */
	
	//@Test(priority = 8)
	public void searchExecutionsByDefect_test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect associated execution status is Custom
	 */
	
	//@Test(priority = 9)
	public void searchExecutionsByDefect_test9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect status is TO DO
	 */
	
	//@Test(priority = 10)
	public void searchExecutionsByDefect_test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect status is In Progress
	 */
	
	//@Test(priority = 11)
	public void searchExecutionsByDefect_test11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect status is DONE
	 */
	
	//@Test(priority = 12)
	public void searchExecutionsByDefect_test12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level
	 */
	
	//@Test(priority = 13)
	public void searchExecutionsByDefect_test13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and step status is Unexecuted
	 */
	
	//@Test(priority = 14)
	public void searchExecutionsByDefect_test14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and step status is Pass
	 */
	
	//@Test(priority = 15)
	public void searchExecutionsByDefect_test15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and step status is Fail
	 */
	
	//@Test(priority = 16)
	public void searchExecutionsByDefect_test16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and step status is WIP
	 */
	
	//@Test(priority = 17)
	public void searchExecutionsByDefect_test17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and step status is Blocked
	 */
	
	//@Test(priority = 18)
	public void searchExecutionsByDefect_test18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and step status is Custom
	 */
	
	//@Test(priority = 19)
	public void searchExecutionsByDefect_test19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and defect status is TO DO
	 */
	
	//@Test(priority = 20)
	public void searchExecutionsByDefect_test20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and defect status is In Progress
	 */
	
	//@Test(priority = 21)
	public void searchExecutionsByDefect_test21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where defect is associated to step level and defect status is DONE
	 */
	
	//@Test(priority = 22)
	public void searchExecutionsByDefect_test22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect more than 10 executions where maxResult = 10
	 */
	
	//@Test(priority = 23)
	public void searchExecutionsByDefect_test23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * SearchExecutionsByDefect where offset = 5 and maxResult = 15
	 */
	
	//@Test(priority = 24)
	public void searchExecutionsByDefect_test24(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 5;
		int maxResult = 15;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect more than offset limit(for 10 executions, set offset = 15)
	 */
	
	//@Test(priority = 25)
	public void searchExecutionsByDefect_test25(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 15;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect where defect removed from execution
	 */
	
	//@Test(priority = 26)
	public void searchExecutionsByDefect_test26(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect where defect removed from step level execution
	 */
	
	//@Test(priority = 27)
	public void searchExecutionsByDefect_test27(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect where execution is deleted
	 */
	
	//@Test(priority = 28)
	public void searchExecutionsByDefect_test28(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect where step is removed from issue
	 */
	
	//@Test(priority = 29)
	public void searchExecutionsByDefect_test29(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect where the test is deleted
	 */
	
	//@Test(priority = 30)
	public void searchExecutionsByDefect_test30(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefect(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 03-Dec-2016
	 * Attempt to SearchExecutionsByDefect where the defect is deleted
	 */
	
	//@Test(priority = 31)
	public void searchExecutionsByDefect_test31(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long versionId = 10100l;
		Long defectId = 10741l;
		int offset = 0;
		int maxResult = 10;
		Response response = zapiService.searchExecutionsByDefect(jwtGenerator, versionId, defectId, offset, maxResult);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateSearchExecutionsByDefectInvalidIssueId(response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
