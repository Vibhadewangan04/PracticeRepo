/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.regression.stepresult;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.ExportExecution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
public class GetStepResultApi extends BaseTest{
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
//	String exportType = null;
	private Long projectId1;
	private int projectName1;
	private String expand;
	private boolean maxAllowed;
	private int startIndex;
	private Execution executionJson1;
	private JSONObject teststepObj;
	String stepId = null;
	String clonedstep = null;
	String stepid = null;
	private Long projectId = Long.parseLong(Config.getValue("projectId")); 
    private Long issueId;
    Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
    Long issueTypeId2 = Long.parseLong(Config.getValue("issueTypeStoryId"));
	
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	/**
	 * getStepResult API
	 */
	
	

	/* 1 - getTestStepResult of an execution with stepresult execution status as PASS*/
	
	
	@Test(priority = 1, enabled = true)
	public void test1_exportExecutionsInXMLFormatWhenExecutionsHaveExecutedTestSteps(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		
		
		
				
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"1\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult When stepResult is Pass:" + response2.getBody().asString());			
	}

	
	
	//1st one creating 2 issue hen creating step in both
	@Test(priority = 111, enabled = false)
	public void same1stOne_test111(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		
		//create test steps to 1st issue
				Teststep teststepJson1 = new Teststep();
				teststepJson1.setStep("step");
				teststepJson1.setData("data");
				teststepJson1.setResult("result");

				Response createTeststepResponse1 = zapiService.createTeststep(jwtGenerator, projectId, issueId1,
						teststepJson1.toString());
				Assert.assertNotNull(createTeststepResponse1, "Create Teststep Api Response is null.");
				test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
				System.out.println(createTeststepResponse1.getBody().asString());

				boolean createTeststepValidationStatus1 = zapiService.validateTeststep(projectId, issueId1,teststepJson1.toString(), createTeststepResponse);
				Assert.assertTrue(createTeststepValidationStatus1, "Create Teststep Api response not validated.");
				test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

				teststepObj = new JSONObject(createTeststepResponse1.body().asString());
			
				Long issueId2 = teststepObj.getLong("issueId");
				String stepId2 = teststepObj.getString("id");
		
	
				
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"1\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				
	}

	
	
	
	
	
	//@Test(priority = 111, enabled = true)
	public void getStepResult1111(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Roopa");
		
		String executionId = "0001479158020117-242ac1134-0001";
		String stepResultId = "0001479158020540-242ac1134-0001";
		Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateStepResult(stepResultId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/* 2 - getTestStepResult of an execution with stepresult execution status as FAIL */
	@Test(priority = 2)
	public void getStepResult2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"2\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	
				
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult When stepResult is fail:" + response2.getBody().asString());
				
	}
	
	/* 3 - getTestStepResult of an execution with stepresult execution status as WIP */
	@Test(priority = 3,enabled = true)
	public void getStepResult3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	
				
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult When stepResult is wip:" + response2.getBody().asString());
				
	}
	
	/* 4 - getTestStepResult of an execution with stepresult execution status as BLOCKED */
	@Test(priority = 4, enabled = true)
	public void getStepResult4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"4\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	
				
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult When stepResult is Blocked:" + response2.getBody().asString());
				
	}
	
	/* 5 - getTestStepResult of an execution with stepresult execution status as CUSTOM */
	@Test(priority = 5, enabled = true)
	public void getStepResult5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
				
				//execute test step
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"5\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");				
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult :" + response2.getBody().asString());
				
	}
	
		/* getTeststepResult of an execution whose stepresult has been updated to a different status */
		@Test(priority = 6, enabled = true)
	public void getStepResult6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"5\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");				
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult :" + response2.getBody().asString());
		
	}
		/* Manual -  getTeststepResult of an execution whose stepresult status is changed by a different user */
	@Test(priority = 7, enabled = true)
	public void getStepResult7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
							//jsarray2.getString(0).toString();
				//	String	ex2=exeIds.get(1).toString();
				
				//execute test step
				
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println(StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"5\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");				
				Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
				System.out.println("getting stepResult :" + response2.getBody().asString());
		
	}

				
		/* Attempt to getTestStepResult with invalid executionId but valid ProjectId and valid stepResultId */
	@Test(priority = 8, enabled = true)
	public void getStepResult8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long projectId = Long.parseLong(Config.getValue("projectId1"));
		String projectName =(Config.getValue("projectName1"));
		//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		expand = "teststeps";
		String exportType = "xml";
		maxAllowed=true;
		startIndex=0;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test with steps result");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
				
		//create test steps
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
	
		Long issueId11 = teststepObj.getLong("issueId");
		String stepId = teststepObj.getString("id");
		
		// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(-1l);
		cycleJson.setName("export execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);
		
		//1 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(2);
		executionJson11.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
						

			//update execution	
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(executionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				Long issueId111 = issueIds.get(j);
				executionJson11.setIssueId(issueId111);
				System.out.println(issueId111);
				executionJson11.setStatusId(1l);
				executionJson11.setComment("Comment added for all executions");
				executionJson11.setExecutionId(exeid);
				
				//update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson11.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}					
					String	ex1=exeIds.get(0).toString();
					
				//execute test step
					Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
					System.out.println("1st response" +StepResultsresponse.getBody().asString());
					
	
					JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
					JSONArray value = js1.getJSONArray("stepResults");
					JSONObject stepResult = value.getJSONObject(0);
					String stepresultid = stepResult.get("id").toString();
					stepId= stepResult.get("stepId").toString();
					ex1 =stepResult.get("executionId").toString();
					issueId =Long.parseLong(stepResult.get("issueId").toString());
					System.err.println(stepresultid);
			//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
				String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"-1\"}}";
				System.err.println(payLoad);

				//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

				Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
				Assert.assertNotNull(response2, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					
			//	Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
			//	System.out.println("getting stepResult When stepResult is Pass:" + response2.getBody().asString()); 
				
				String executionId = "123";
				
					Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, executionId, stepresultid);
					System.out.println("2nd response of get stepResult :" + StepResultsresponse1.asString() + "true but response is empty");
					
				//	boolean StepResultsresponse1 = zapiService.getStepResult2(jwtGenerator, executionId, projectId, StepResultsresponse );
				//	System.out.println("2nd response of get stepResult :" + StepResultsresponse1);
	}
	
		
		/* Attempt to getTestStepResult with invalid projectId but valid executionId and valid stepResultId */
				@Test(priority = 9)
				public void getStepResult9(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					String exportType = "xml";
					maxAllowed=true;
					startIndex=0;
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
							teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
									

						//update execution	
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
								
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println("1st response" +StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"-1\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
								
						//	Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
						//	System.out.println("getting stepResult When stepResult is Pass:" + response2.getBody().asString()); 
							
							Long projectId2 = 1111l;
							
							//	Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, executionId, stepresultid);
							//	System.out.println("2nd response of get stepResult :" + StepResultsresponse1.asString());
								
								boolean StepResultsresponse1 = zapiService.getStepResult2(jwtGenerator, ex1, projectId2, StepResultsresponse );
								System.out.println("2nd response of get stepResult :" + StepResultsresponse1+ "true but response is empty");
				}
				
				
		/* Attempt to getTestStepResult with invalid stepResultId but valid executionId and valid projectId */ 
				@Test(priority = 2) 
				public void getStepResult10(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					String exportType = "xml";
					maxAllowed=true;
					startIndex=0;
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
							teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
									

						//update execution	
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
								
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println("1st response" +StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"-1\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
								
						//	Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
						//	System.out.println("getting stepResult When stepResult is Pass:" + response2.getBody().asString()); 
							
							
							  String stepresultid2 = "1111";
							
								Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid2);
								System.out.println("2nd response of get stepResult :" + StepResultsresponse1.asString()+ "true but response is empty");
								
							//	boolean StepResultsresponse1 = zapiService.getStepResult2(jwtGenerator, ex1, projectId2, StepResultsresponse );
							//	System.out.println("2nd response of get stepResult :" + StepResultsresponse1+ "true but response is empty");
				}
					
					
		/* Attempt to getTestStepResult with valid valid ExecutionId and stepResultId belonging to another executionId */
				@Test(priority = 11, enabled = true)
				public void getStepResult11(){					
						ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
						test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
						test.assignAuthor("Praveen");

						Long projectId = Long.parseLong(Config.getValue("projectId1"));
						String projectName =(Config.getValue("projectName1"));
						//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
						expand = "teststeps";
						
						//create issues
						Issue issuePayLoad = new Issue();
						issuePayLoad.setProject(Config.getValue("projectId1"));
						issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
						issuePayLoad.setSummary("test with steps result");
						issuePayLoad.setPriority("1");
						issuePayLoad.setReporter(Config.getValue("adminUserName"));
						
						List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
						Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
					
						List<Long> issueIds = new ArrayList<>() ;
						JSONArray jsarray = new JSONArray(createIssueResponse);
						for(int i= 0;i<jsarray.length();i++){
					
							JSONObject jsobj = new JSONObject(jsarray.getString(i));
							Long l= Long.parseLong(jsobj.get("id").toString());
							issueIds.add(l);
						
						}
						System.out.println("*****"+issueIds);
						Long issueId = issueIds.get(0);
						System.out.println(issueId);
						Long issueId1= issueIds.get(1);
								
						//create test steps
						Teststep teststepJson = new Teststep();
						teststepJson.setStep("step");
						teststepJson.setData("data");
						teststepJson.setResult("result");

						Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
						Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
						test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
						System.out.println(createTeststepResponse.getBody().asString());

						boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
						Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
						test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

						teststepObj = new JSONObject(createTeststepResponse.body().asString());
					
						Long issueId11 = teststepObj.getLong("issueId");
						String stepId = teststepObj.getString("id");
						
						// Create cycle
						Cycle cycleJson = new Cycle();
						cycleJson.setProjectId(projectId);
						cycleJson.setVersionId(-1l);
						cycleJson.setName("export execution"+System.currentTimeMillis());
						cycleJson.setDescription("Get execution by cycle");
						
						Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
						Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
						test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
						boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
						Assert.assertTrue(status1, "Response Validation Failed.");
						test.log(LogStatus.PASS, "Response validated successfully.");
						String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
						String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
						System.out.println(CycleName);
						
						//1 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
							//update execution
							List<String> exeIds = new ArrayList<>() ;
							JSONArray jsarray2 = new JSONArray(executionResponse.toString());
							System.out.println("length="+jsarray2.length());
							for (int j=0;j<jsarray2.length();j++){
								JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
								String exeid =jsobj2.getJSONObject("execution").get("id").toString();
								exeIds.add(exeid);
								Long issueId111 = issueIds.get(j);
								executionJson11.setIssueId(issueId111);
								System.out.println(issueId111);
								executionJson11.setStatusId(1l);
								executionJson11.setComment("Comment added for all executions");
								executionJson11.setExecutionId(exeid);
								
								//update executions
								Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
										executionJson11.toString());
								Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
								test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
								System.out.println(updateExecutionResponse.getBody().asString());
								System.out.println("updated execution");
							}					
									String	ex1=exeIds.get(0).toString();
								
								//execute test step
									Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
									System.out.println(StepResultsresponse.getBody().asString());
									
					
									JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
									JSONArray value = js1.getJSONArray("stepResults");
									JSONObject stepResult = value.getJSONObject(0);
									String stepresultid = stepResult.get("id").toString();
									stepId= stepResult.get("stepId").toString();
									ex1 =stepResult.get("executionId").toString();
									issueId =Long.parseLong(stepResult.get("issueId").toString());
									System.err.println(stepresultid);
							//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
								String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"2\"}}";
								System.err.println(payLoad);

								//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

								Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
								Assert.assertNotNull(response2, "Create Execution Api Response is null.");
								test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
								System.out.println(response2.getBody().asString());
								
								// id of different execution
								String ex2 = "0001479158020117-242ac1134-0001";
						    	String	stepresultid2 = "0048bb02-25d5-4fb2-ba0b-bb0a638db52f";
								
								Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex2, stepresultid2);
								System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
								System.out.println("stepResult is blank in above responce bcoz user is passing another executionId- tc passed");
						
					
					
				}
				
				
		/* Attempt to getTestStepResult with valid valid ExecutionId and stepResultId belonging to executionId of another project */
				@Test(priority = 12, enabled = true)
				public void getStepResult12(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"2\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							// id of different execution of another project
							
							String ex2 = "0001479158020117-242ac1134-0001";
					    	String	stepresultid2 = "0001479236634944-242ac1135-0001";
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex2, stepresultid2);
							System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
							System.out.println("stepResult is blank in above responce bcoz user is passing another executionId- tc passed");
					
				
					
				}
				
				
				
		// Attempt to getTestStepResult with projectId as NULL
				@Test(priority = 13, enabled = true) 
				public void getStepResult13(){
					
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							  String executionId=exeIds.get(0).toString();
								
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"2\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Long projectId1 = null;
						//	String executionId = "0001479158020117-242ac1134-0001";
							
							/*Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
							System.out.println("stepResult is blank in above responce bcoz user is passing another executionId- tc passed");*/
					

							boolean StepResultsresponse1 = zapiService.getStepResult2(jwtGenerator, executionId, projectId1, StepResultsresponse );
							System.out.println("2nd response of get stepResult :" + StepResultsresponse1);
							
							
					
				/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Roopa");
					
					Long projectId = null;
					String executionId = "0001479158020117-242ac1134-0001";
					String stepResultId = "0001479236634944-242ac1135-0001";
					Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateStepResult(stepResultId, response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);*/
				}
				
				
		/* Attempt to getTestStepResult with executionId as NULL */
				@Test(priority = 14, enabled = true) 
				public void getStepResult14(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"2\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
						//	Long projectId1 = null;
							String ex2 = "";
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex2, stepresultid);
							System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
							System.out.println("stepResult is blank in above responce bcoz user is passing null executionId- tc passed");
					
				}
				
				
		/* Attempt to getTestStepResult with stepresultId as NULL */
				@Test(priority = 15, enabled = true) 
				public void getStepResult15(){
						ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
						test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
						test.assignAuthor("Praveen");

						Long projectId = Long.parseLong(Config.getValue("projectId1"));
						String projectName =(Config.getValue("projectName1"));
						//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
						expand = "teststeps";
						
						//create issues
						Issue issuePayLoad = new Issue();
						issuePayLoad.setProject(Config.getValue("projectId1"));
						issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
						issuePayLoad.setSummary("test with steps result");
						issuePayLoad.setPriority("1");
						issuePayLoad.setReporter(Config.getValue("adminUserName"));
						
						List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
						Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
					
						List<Long> issueIds = new ArrayList<>() ;
						JSONArray jsarray = new JSONArray(createIssueResponse);
						for(int i= 0;i<jsarray.length();i++){
					
							JSONObject jsobj = new JSONObject(jsarray.getString(i));
							Long l= Long.parseLong(jsobj.get("id").toString());
							issueIds.add(l);
						
						}
						System.out.println("*****"+issueIds);
						Long issueId = issueIds.get(0);
						System.out.println(issueId);
						Long issueId1= issueIds.get(1);
								
						//create test steps
						Teststep teststepJson = new Teststep();
						teststepJson.setStep("step");
						teststepJson.setData("data");
						teststepJson.setResult("result");

						Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
						Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
						test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
						System.out.println(createTeststepResponse.getBody().asString());

						boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
						Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
						test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

						teststepObj = new JSONObject(createTeststepResponse.body().asString());
					
						Long issueId11 = teststepObj.getLong("issueId");
						String stepId = teststepObj.getString("id");
						
						// Create cycle
						Cycle cycleJson = new Cycle();
						cycleJson.setProjectId(projectId);
						cycleJson.setVersionId(-1l);
						cycleJson.setName("export execution"+System.currentTimeMillis());
						cycleJson.setDescription("Get execution by cycle");
						
						Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
						Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
						test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
						boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
						Assert.assertTrue(status1, "Response Validation Failed.");
						test.log(LogStatus.PASS, "Response validated successfully.");
						String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
						String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
						System.out.println(CycleName);
						
						//1 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
							//update execution
							List<String> exeIds = new ArrayList<>() ;
							JSONArray jsarray2 = new JSONArray(executionResponse.toString());
							System.out.println("length="+jsarray2.length());
							for (int j=0;j<jsarray2.length();j++){
								JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
								String exeid =jsobj2.getJSONObject("execution").get("id").toString();
								exeIds.add(exeid);
								Long issueId111 = issueIds.get(j);
								executionJson11.setIssueId(issueId111);
								System.out.println(issueId111);
								executionJson11.setStatusId(1l);
								executionJson11.setComment("Comment added for all executions");
								executionJson11.setExecutionId(exeid);
								
								//update executions
								Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
										executionJson11.toString());
								Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
								test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
								System.out.println(updateExecutionResponse.getBody().asString());
								System.out.println("updated execution");
							}					
									String	ex1=exeIds.get(0).toString();
								
								//execute test step
									Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
									System.out.println(StepResultsresponse.getBody().asString());
									
					
									JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
									JSONArray value = js1.getJSONArray("stepResults");
									JSONObject stepResult = value.getJSONObject(0);
									String stepresultid = stepResult.get("id").toString();
									stepId= stepResult.get("stepId").toString();
									ex1 =stepResult.get("executionId").toString();
									issueId =Long.parseLong(stepResult.get("issueId").toString());
									System.err.println(stepresultid);
							//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
								String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
								System.err.println(payLoad);

								//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

								Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
								Assert.assertNotNull(response2, "Create Execution Api Response is null.");
								test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
								System.out.println(response2.getBody().asString());
								
							//	Long projectId1 = null;
							//	String ex2 = null;
								stepresultid = null;
								
								Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
								System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
								System.out.println("stepResult is blank in above response bcoz user is passing null stepresultid- tc passed");
						
					}
					

				
				/*getTestStepResult of issue with clone step executed to WIP */
				
				@Test(priority = 16, enabled = true) 
				public void getStepResult16(){
						ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
						test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
						test.assignAuthor("Praveen");

						Long projectId = Long.parseLong(Config.getValue("projectId1"));
						String projectName =(Config.getValue("projectName1"));
						//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
						expand = "teststeps";
						
						//create issues
						Issue issuePayLoad = new Issue();
						issuePayLoad.setProject(Config.getValue("projectId1"));
						issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
						issuePayLoad.setSummary("test with steps result");
						issuePayLoad.setPriority("1");
						issuePayLoad.setReporter(Config.getValue("adminUserName"));
						
						List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
						Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
					
						List<Long> issueIds = new ArrayList<>() ;
						JSONArray jsarray = new JSONArray(createIssueResponse);
						for(int i= 0;i<jsarray.length();i++){
					
							JSONObject jsobj = new JSONObject(jsarray.getString(i));
							Long l= Long.parseLong(jsobj.get("id").toString());
							issueIds.add(l);
						
						}
						System.out.println("*****"+issueIds);
						Long issueId = issueIds.get(0);
						System.out.println(issueId);
						Long issueId1= issueIds.get(1);
								
						//create test steps
						String stepValue = "step";
						String dataValue = "data";
						String resultValue = "result"; 		
						Teststep teststepJson = new Teststep();
						teststepJson.setStep(stepValue);
						teststepJson.setData(dataValue);
						teststepJson.setResult(resultValue);
						System.out.println("payload-->"+ teststepJson.toString());

						Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
						Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
						test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
						System.out.println(createTeststepResponse.getBody().asString());

						boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
						Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
						test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

						teststepObj = new JSONObject(createTeststepResponse.body().asString());
					
						Long issueId11 = teststepObj.getLong("issueId");
						String stepId = teststepObj.getString("id");
						
						
						
						String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
						System.out.println("Step id "+ stepid);	
						String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
						System.out.println(payLoad);
						teststepJson.setStep("Clone"+stepValue);
						teststepJson.setClone_position_Id("0");
						Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
						Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
						test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
						System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
						boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
						Assert.assertTrue(Clonestatus);
						test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
						extentReport.endTest(test);						
				
						System.out.println(Cloneteststepresponse.asString());
						String responseData = Cloneteststepresponse.getBody().asString();
						System.out.println(responseData);
						JSONArray responseJson = new JSONArray(responseData);
						JSONObject json = new JSONObject(responseJson.get(0).toString());
							
						String stepId2= json.get("id").toString();
						System.out.println("stepId2 is"+stepId2);
						
						// Create cycle
						Cycle cycleJson = new Cycle();
						cycleJson.setProjectId(projectId);
						cycleJson.setVersionId(-1l);
						cycleJson.setName("export execution"+System.currentTimeMillis());
						cycleJson.setDescription("Get execution by cycle");
						
						Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
						Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
						test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
						boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
						Assert.assertTrue(status1, "Response Validation Failed.");
						test.log(LogStatus.PASS, "Response validated successfully.");
						String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
						String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
						System.out.println(CycleName);
						
						//1 executions
						Execution executionJson11 = new Execution();
						executionJson11.setStatusId(-1l);
						executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
						executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
						executionJson11.setVersionId(-1l);
						executionJson11.setNoOfExecutions(2);
						executionJson11.setCycleId(cycleId);

						JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
						Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
					
							//update execution
							List<String> exeIds = new ArrayList<>() ;
							JSONArray jsarray2 = new JSONArray(executionResponse.toString());
							System.out.println("length="+jsarray2.length());
							for (int j=0;j<jsarray2.length();j++){
								JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
								String exeid =jsobj2.getJSONObject("execution").get("id").toString();
								exeIds.add(exeid);
								Long issueId111 = issueIds.get(j);
								executionJson11.setIssueId(issueId111);
								System.out.println(issueId111);
								executionJson11.setStatusId(1l);
								executionJson11.setComment("Comment added for all executions");
								executionJson11.setExecutionId(exeid);
								
								//update executions
								Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
										executionJson11.toString());
								Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
								test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
								System.out.println(updateExecutionResponse.getBody().asString());
								System.out.println("updated execution");
							}					
									String	ex1=exeIds.get(0).toString();
								
								//execute test step
									Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
									System.out.println(StepResultsresponse.getBody().asString());
									
					
									JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
									JSONArray value = js1.getJSONArray("stepResults");
									JSONObject stepResult = value.getJSONObject(0);
									String stepresultid = stepResult.get("id").toString();
									stepId= stepResult.get("stepId").toString();
									ex1 =stepResult.get("executionId").toString();
									issueId =Long.parseLong(stepResult.get("issueId").toString());
									System.err.println(stepresultid);
							//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
								String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
								System.err.println(payLoad1); 

								//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

								Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
								Assert.assertNotNull(response2, "Create Execution Api Response is null.");
								test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
								System.out.println(response2.getBody().asString());
								
								Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
								System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
								System.out.println("stepResult is blank in above response bcoz user is passing null stepresultid- tc passed");
						
					}
				
				
				
				/* getTestStepResult of issue with cloned step executed to BLOCKED */
				@Test(priority = 17, enabled = true) 
				public void getStepResult17(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad);
					teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);						
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString());
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2);
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"4\"}}";
							System.err.println(payLoad1); 

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("Attempt to get stepResult :" + StepResultsresponse1.getBody().asString());
							System.out.println("stepResult is blank in above response bcoz user is passing null stepresultid- tc passed");
					
				}
				
				
				/* getTestStepResult of issue with cloned step executed to CUSTOM */
				@Test(priority = 18, enabled = true) 
				public void getStepResult18(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad);
					teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);						
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString());
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2);
					
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"5\"}}";
							System.err.println(payLoad1); 

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("get stepResult :" + StepResultsresponse1.getBody().asString());
							
					
				}
				
				
				/* getTestStepResult of issue with cloned step linked to defects */
				@Test(priority = 19, enabled = true) 
				public void getStepResult19(){
					
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad);
					teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);						
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString());
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2);
					
					
					//create defect to link		
					issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
					issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
							
					Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
					Assert.assertNotNull(response, "Create Issue Api Response is null.");
					//
					boolean issueStatus = jiraService.validateCreateIssueApi(response);
					Assert.assertTrue(issueStatus, "Response Validation Failed.");
					Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
					List<Long> defectsList = new ArrayList<>();
					defectsList.add(bugId);
					System.out.println("bugId is"+bugId);
					
		
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setDefects(defectsList);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							
							String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\", \"defects\":[" +bugId+ "] ,\"status\":{\"id\":\"3\"}}";
							System.out.println("*******payLoad1" +payLoad1);
							
							System.err.println(payLoad1); 
							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("get stepResult :" + StepResultsresponse1.getBody().asString());
							
					
					
					/*ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Roopa");
					
					
					String executionId = "0001479158020117-242ac1134-0001";
					String stepResultId = "0001479236634944-242ac1135-0001";
					Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateStepResult(stepResultId, response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);*/
				}
				/* getTestStepResult of issue with cloned step linked to defects, comments */
				@Test(priority = 20, enabled = true) 
				public void getStepResult20(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad);
					teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);						
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString());
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2);
					
					
					//create defect to link		
					issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
					issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
							
					Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
					Assert.assertNotNull(response, "Create Issue Api Response is null.");
					//
					boolean issueStatus = jiraService.validateCreateIssueApi(response);
					Assert.assertTrue(issueStatus, "Response Validation Failed.");
					Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
					List<Long> defectsList = new ArrayList<>();
					defectsList.add(bugId);
					System.out.println("bugId is"+bugId);
					
		
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setDefects(defectsList);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							
							String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\", \"defects\":[" +bugId+ "] , \"comment\":\"comment added\",   \"status\":{\"id\":\"3\"}}";
							System.out.println("*******payLoad1" +payLoad1);
							
							System.err.println(payLoad1); 
							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("get stepResult :" + StepResultsresponse1.getBody().asString());
				}
				
				
				
				/* getTestStepResult of issue with cloned step linked */
				@Test(priority = 21, enabled = true) 
				public void getStepResult21(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad);
					teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);						
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString());
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2);
					
					
					//create defect to link		
					issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
					issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
							
					Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
					Assert.assertNotNull(response, "Create Issue Api Response is null.");
					//
					boolean issueStatus = jiraService.validateCreateIssueApi(response);
					Assert.assertTrue(issueStatus, "Response Validation Failed.");
					Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
					List<Long> defectsList = new ArrayList<>();
					defectsList.add(bugId);
					System.out.println("bugId is"+bugId);
					
		
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setDefects(defectsList);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							
							String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\", \"defects\":[" +bugId+ "] , \"comment\":\"comment added\",   \"status\":{\"id\":\"3\"}}";
							System.out.println("*******payLoad1" +payLoad1);
							
							System.err.println(payLoad1); 
							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("get stepResult :" + StepResultsresponse1.getBody().asString());
				}
				
				
				/* getTestStepResult of issue with cloned step linked to  attachments, defects and comments */
				@Test(priority = 22, enabled = true) 
				public void getStepResult22(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad);
					teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);						
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString());
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2);
					
					
					//create defect to link		
					issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
					issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
							
					Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
					Assert.assertNotNull(response, "Create Issue Api Response is null.");
					//
					boolean issueStatus = jiraService.validateCreateIssueApi(response);
					Assert.assertTrue(issueStatus, "Response Validation Failed.");
					Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
					List<Long> defectsList = new ArrayList<>();
					defectsList.add(bugId);
					System.out.println("bugId is"+bugId);
					
		
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setDefects(defectsList);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
							
							//execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							
							String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\", \"defects\":[" +bugId+ "] , \"comment\":\"comment added\",   \"status\":{\"id\":\"3\"}}";
							System.out.println("*******payLoad1" +payLoad1);
							
							System.err.println(payLoad1); 
							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("get stepResult :" + StepResultsresponse1.getBody().asString());
				}
			
				
				/* Attempt to getTestStepResult with no valid authentication */
				@Test(priority = 23, enabled = false) 
				public void getStepResult23(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Roopa");

					String executionId = "0001479158020117-242ac1134-0001";
					String stepResultId = "0001479236634944-242ac1135-0001";
					Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateStepResult(stepResultId, response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
				
				
				/* Attempt to getTestStepResult with no browse permission to project */
				// manually remove browse permission to project  then execute it
				
				@Test(priority = 24, enabled = true)
				public void getStepResult24(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					String exportType = "xml";
					maxAllowed=true;
					startIndex=0;
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
							teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
							
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
									

						//update execution
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
										//jsarray2.getString(0).toString();
							//	String	ex2=exeIds.get(1).toString();
							
							//execute test step
							
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"1\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
							Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
							System.out.println("getting stepResult When stepResult is Pass:" + response2.getBody().asString());			
				}
				
				
				@Test(priority = 244, enabled = false) 
				public void getStepResult244(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Roopa");

					String executionId = "0001479158020117-242ac1134-0001";
					String stepResultId = "0001479236634944-242ac1135-0001";
					Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateStepResult(stepResultId, response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);
				}
				
				
				/* Attempt to getTestStepResult with valid executionId and valid ProjectId with no steps */
				 @Test(priority = 25, enabled = true) 
				public void getStepResult25(){
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
				/*	String stepValue = "step";
					String dataValue = "data";
					String resultValue = "result"; 		
					Teststep teststepJson = new Teststep();
					teststepJson.setStep(stepValue);
					teststepJson.setData(dataValue);
					teststepJson.setResult(resultValue);
					System.out.println("payload-->"+ teststepJson.toString());

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,	teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully."); 

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					String stepid= new JSONObject(createTeststepResponse.body().asString()).get("id").toString();
					System.out.println("Step id "+ stepid);	
					String payLoad = "{\"step\":\"steps 1111111111111\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"0\"}";
					System.out.println(payLoad); */
					/*teststepJson.setStep("Clone"+stepValue);
					teststepJson.setClone_position_Id("0");
					Response Cloneteststepresponse = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepid, teststepJson.toString());
					Assert.assertNotNull(Cloneteststepresponse, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Clone Teststep API  executed successfully.");
					System.out.println("Cloneteststepresponse is "+Cloneteststepresponse.getBody().asString());		
					boolean Clonestatus = zapiService.validateClonedTeststep(projectId, issueId, payLoad, Cloneteststepresponse);
					Assert.assertTrue(Clonestatus);
					test.log(LogStatus.PASS, "Clone Teststep API Response validated suuccessfully.");
					extentReport.endTest(test);				
			
					System.out.println(Cloneteststepresponse.asString());
					String responseData = Cloneteststepresponse.getBody().asString();
					System.out.println(responseData);
					JSONArray responseJson = new JSONArray(responseData);
					JSONObject json = new JSONObject(responseJson.get(0).toString()); 
						
					String stepId2= json.get("id").toString();
					System.out.println("stepId2 is"+stepId2); */
					
		
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
						//update execution
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();

							String executionId = exeIds.get(0).toString();
							    //execute test step
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println(StepResultsresponse.getBody().asString());
								
				
								/*JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);*/
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"3\"}}";
							
						//	String payLoad1 = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId2 +"\",\"issueId\":\""+ issueId11 + "\", \"defects\":[" +bugId+ "] , \"comment\":\"comment added\",   \"status\":{\"id\":\"3\"}}";
						//	System.out.println("*******payLoad1" +payLoad1);
							
						//	System.err.println(payLoad1); 
							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							/*Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad1);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");		
							System.out.println(response2.getBody().asString());
							
							Response StepResultsresponse1 = zapiService.getStepResult(jwtGenerator, ex1, stepresultid);
							System.out.println("get stepResult :" + StepResultsresponse1.getBody().asString()); */
							
							
						
						  boolean StepResultsresponse1 = zapiService.getStepResult2(jwtGenerator, executionId, projectId, StepResultsresponse );
							System.out.println("get stepResult :" + StepResultsresponse1);
							
						
							
				}
				
				/* Attempt to getTestStepResult with valid executionId and valid ProjectId with a step - UNEXECUTED */
			@Test(priority = 26,  enabled = true) 
				public void getStepResult26(){
	
					ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
					test.assignAuthor("Praveen");

					Long projectId = Long.parseLong(Config.getValue("projectId1"));
					String projectName =(Config.getValue("projectName1"));
					//Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
					expand = "teststeps";
					String exportType = "xml";
					maxAllowed=true;
					startIndex=0;
					
					//create issues
					Issue issuePayLoad = new Issue();
					issuePayLoad.setProject(Config.getValue("projectId1"));
					issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
					issuePayLoad.setSummary("test with steps result");
					issuePayLoad.setPriority("1");
					issuePayLoad.setReporter(Config.getValue("adminUserName"));
					
					List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
					Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
				
					List<Long> issueIds = new ArrayList<>() ;
					JSONArray jsarray = new JSONArray(createIssueResponse);
					for(int i= 0;i<jsarray.length();i++){
				
						JSONObject jsobj = new JSONObject(jsarray.getString(i));
						Long l= Long.parseLong(jsobj.get("id").toString());
						issueIds.add(l);
					
					}
					System.out.println("*****"+issueIds);
					Long issueId = issueIds.get(0);
					System.out.println(issueId);
					Long issueId1= issueIds.get(1);
							
					//create test steps
					Teststep teststepJson = new Teststep();
					teststepJson.setStep("step");
					teststepJson.setData("data");
					teststepJson.setResult("result");

					Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
							teststepJson.toString());
					Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
					test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
					System.out.println(createTeststepResponse.getBody().asString());

					boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,teststepJson.toString(), createTeststepResponse);
					Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
					test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

					teststepObj = new JSONObject(createTeststepResponse.body().asString());
				
					Long issueId11 = teststepObj.getLong("issueId");
					String stepId = teststepObj.getString("id");
					
					
					
					
							
					// Create cycle
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(projectId);
					cycleJson.setVersionId(-1l);
					cycleJson.setName("export execution"+System.currentTimeMillis());
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
					System.out.println(CycleName);
					
					//1 executions
					Execution executionJson11 = new Execution();
					executionJson11.setStatusId(-1l);
					executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
					executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
					executionJson11.setVersionId(-1l);
					executionJson11.setNoOfExecutions(2);
					executionJson11.setCycleId(cycleId);

					JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
					Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
									

						//update execution
						
						List<String> exeIds = new ArrayList<>() ;
						JSONArray jsarray2 = new JSONArray(executionResponse.toString());
						System.out.println("length="+jsarray2.length());
						for (int j=0;j<jsarray2.length();j++){
							JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
							String exeid =jsobj2.getJSONObject("execution").get("id").toString();
							exeIds.add(exeid);
							Long issueId111 = issueIds.get(j);
							executionJson11.setIssueId(issueId111);
							System.out.println(issueId111);
							executionJson11.setStatusId(1l);
							executionJson11.setComment("Comment added for all executions");
							executionJson11.setExecutionId(exeid);
							
							//update executions
							Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
									executionJson11.toString());
							Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
							System.out.println(updateExecutionResponse.getBody().asString());
							System.out.println("updated execution");
						}					
								String	ex1=exeIds.get(0).toString();
										//jsarray2.getString(0).toString();
							//	String	ex2=exeIds.get(1).toString();
							
								String executionId =exeIds.get(0).toString();
								
							//execute test step
							
								Response StepResultsresponse = zapiService.getStepResults(jwtGenerator, issueId, ex1);
								System.out.println("1st response" +StepResultsresponse.getBody().asString());
								
				
								/*JSONObject js1 = new JSONObject(StepResultsresponse.getBody().asString());
								JSONArray value = js1.getJSONArray("stepResults");
								JSONObject stepResult = value.getJSONObject(0);
								String stepresultid = stepResult.get("id").toString();
								stepId= stepResult.get("stepId").toString();
								ex1 =stepResult.get("executionId").toString();
								issueId =Long.parseLong(stepResult.get("issueId").toString());
								System.err.println(stepresultid);
						//	String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\"" + stepId + "\",\"issueId\": "+ issueId +"}";
							String payLoad = "{\"executionId\":\"" +ex1+ "\",\"stepId\":\""+ stepId +"\",\"issueId\":\""+ issueId11 + "\",\"status\":{\"id\":\"-1\"}}";
							System.err.println(payLoad);

							//String payLoad = "{\"defects\":[12512,13823],\"executionId\":\"0001481183885510-242ac112-0001\",\"issueId\":13820,\"stepId\":\"0001481199002232-242ac112-0001\"}";

							Response response2 = zapiService.updateStepResult(jwtGenerator, stepresultid, payLoad);
							Assert.assertNotNull(response2, "Create Execution Api Response is null.");
							test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
								
							Response StepResultsresponse2 = zapiService.getStepResults(jwtGenerator, issueId, ex1);
							System.out.println("getting stepResult When stepResult is Pass:" + response2.getBody().asString()); */
							
								
								
								boolean StepResultsresponse1 = zapiService.getStepResult2(jwtGenerator, executionId, projectId, StepResultsresponse );
								System.out.println("2nd response of get stepResult :" + StepResultsresponse1);
				}
				
				
				
				
				
					/*ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
					test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
					test.assignAuthor("Roopa");
					
					
					String executionId = "0001479158020117-242ac1134-0001";
					String stepResultId = "0001479236634944-242ac1135-0001";
					Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
					Assert.assertNotNull(response, "Create Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
					System.out.println(response.getBody().asString());

					boolean status = zapiService.validateStepResult(stepResultId, response);
					Assert.assertTrue(status);
					test.log(LogStatus.PASS, "Response validated suuccessfully.");
					extentReport.endTest(test);*/
				
}
