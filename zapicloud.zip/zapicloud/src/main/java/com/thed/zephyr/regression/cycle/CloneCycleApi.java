package com.thed.zephyr.regression.cycle;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class CloneCycleApi extends BaseTest {

	String cycleId = null;

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("accountId"));
	}

	/**
	 * 
	 * Clone cycle if Cycle is empty
	 */

	int offset = 0;
	int size = 10;

	@Test(priority = 1, enabled = testEnabled)
	public void test1_cloneCycle_Emptycycle() throws InterruptedException {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Cycle_Emptycycle";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		cycleJson.setName("CLONE-" + Cyclename);
		
		Thread.sleep(1000);
		// Cloning cycle
		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());

		// Validating clonned cycle
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		extentReport.endTest(test);
	}

	/**
	 * Clone cycle if source cycle has 1 schedules Pass the cycleId which has 1
	 * execution
	 */

	@Test(priority = 2, enabled = testEnabled)
	public void test2_cloneCycle_with_one_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		int numberOfExecutions = 1;
		String Cyclename = "Cycle_with_oneExecution";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");

		// pass cycleid below with cycle has one Execution
		//String cycleId = "5302ed44-dae7-4b34-9517-34b9fac93b35";
					
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to clone a deleted cycle Validation method is pending due to bug
	 * ZAPICLOUD-149
	 * @throws InterruptedException 
	 */

	@Test(priority = 3, enabled = testEnabled)
	public void test3_Attempt_clone_Delete_Cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Cycle_with_oneExecution";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		

		// delete cycle
		response = zapiService.deleteCycle(jwtGenerator, Projectid, Versionid, cycleId);
		String myRes = response.getBody().asString();
		System.err.println(myRes);
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");
		

		status = zapiService.validateDeletedCycle(Projectid, Versionid, cycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		
		cycleJson.setName("CLONE-" + Cyclename);
		// give Deleted cycle id in place of Cycleid
		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		
		System.out.println(response.getBody().asString());
		System.out.println(response.getStatusCode());

		// Validating clonned cycle
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if cycle is fully unexecuted Pass the cycleId which is fully
	 * unexecuted
	 */

	@Test(priority = 4, enabled = testEnabled)
	public void test4_cloneCycle_with_fully_unexecuted() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionFourId"));
		offset = 0;
		size = 10;
		String Cyclename = " fully unexecuted";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 2;

		// give fully unexecuted cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";

		//code for cyle with unexecuted test
		
cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if cycle is partially executed to any status Passs the
	 * cycleId which is partially executed to any status
	 */

	@Test(priority = 5, enabled = testEnabled)
	public void test5_cloneCycle_with_partially_executed_by_any_status() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionFourId"));
		String Cyclename = "partially executed";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle partially executed");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 2;

		// give partially executed cycle id in place of Cycleid
		//String cycleId = "9ed06998-d236-45b7-a32d-9a48beb649d7";
		// code for partial executed cycle
		
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		

		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if cycle is fully executed to any status Pass the cycleId
	 * which is fully executed to any status
	 */

	@Test(priority = 6, enabled = testEnabled)
	public void test6_cloneCycle_with_Fully_executed_by_any_status() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionTwoId"));
		String Cyclename = "fully executed";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		int numberOfExecutions = 5;
		cycleJson.setName("CLONE-" + Cyclename);

		// give fully executed cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for fully executed cycle
		
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if some schedules are linked to Single/multiple defects Pass
	 * the cycleId where some schedules are linked to single/multiple defects
	 */

	@Test(priority = 7, enabled = testEnabled)
	public void test7_cloneCycle_with_executions_having_single_or_multiple_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionTwoId"));
		String Cyclename = " Single/multiple defects";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 2;

		// give cycle having single and multiple defect having cycle id in place
		// of Cycleid
		//cycleId = "0001483015009242-242ac112-0001";
			
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		

		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println(sourceCycle);
		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");

		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String clonnedCycle = responseGetExecutionsClonnedCycle.getBody().asString();
		System.out.println(clonnedCycle);

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");

		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Clone cycle and modify details cycle details
	 */

	@Test(priority = 8, enabled = testEnabled)
	public void test8_cloneCycle_with_Modified_Cycle_details() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Modified_Cycle_details";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();

		cycleJson.setName("CLONE-" + Cyclename);
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setDescription(" Modified Cycle description");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");

		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if source cycle has 50 schedules Pass the cycleId which has
	 * 50 schedules
	 */

	@Test(priority = 9, enabled = false)
	public void test9_cloneCycle_having_50_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "50_Executions";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 50_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 50;

		// give cycle having 50 executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 50 executions
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if source cycle has 500 schedules Pass cycleId which has 500
	 * schedules
	 */

	@Test(priority = 10, enabled = false)
	public void test10_cloneCycle_having_500_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "500_Executions";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 500_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 500;

		// give cycle having 500 Executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 500 executions
				cycleJson.setName("CLONE-" + Cyclename);
				
				Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(response, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());
				String cycleId = new JSONObject(response.body().asString()).get("id").toString();
				System.err.println("cycle id " + cycleId);
				
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(Projectid));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				
				
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Projectid);
				executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
				executionJson.setVersionId(Versionid);
				executionJson.setNoOfExecutions(numberOfExecutions);
				executionJson.setCycleId(cycleId);
		
		
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if source cycle has 1000 schedules Pass the cycleId where
	 * cycle has 1000 schedules
	 */

	@Test(priority = 11, enabled = false)
	public void test11_cloneCycle_having_1000_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "1000_Executions";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 1000_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions=1000;
		// give cycle having 1000 Executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 1000 executions
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if source cycle has >5000 schedules Pass the cycleId where
	 * cycle has >5000 schedules
	 */

	@Test(priority = 12, enabled=false)
	public void test12_cloneCycle_having_greaterthan_5000_Executions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Greaterthan_5000_Executions";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning greaterthan_5000_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 5500;
		// give cycle having greater than 5000 Executions cycle id in place of
		// Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(Projectid));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Projectid);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(Versionid);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Clone cycle if source cycle created in UI Pass the cycleId created in UI
	 */

	@Test(priority = 13, enabled=true)
	public void test13_cloneCycle_created_in_UI() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = Config.getValue("Cyclename");
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
	

		// Give Cycleid which created in UI in cycleid
		String cycleId = Config.getValue("cyleId");
		cycleJson.setName("CLONE-" + Cyclename);

		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, Projectid, Versionid, cycleId,
				offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int beforeCloneExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).getInt("totalCount");
		System.out.println("Printing total executions beforeCloneExecutionCount" + beforeCloneExecutionCount);

		Response responseCloneCycle = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(responseCloneCycle, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		String clonnedCycleId = new JSONObject(responseCloneCycle.body().asString()).get("id").toString();

		Response responseGetExecutionsClonnedCycle = zapiService.getExecutionsByCycle(jwtGenerator, Projectid,
				Versionid, clonnedCycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsClonnedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");

		int afterCloneExecutionCount = new JSONObject(responseGetExecutionsClonnedCycle.getBody().asString())
				.getInt("totalCount");
		System.out.println("Printing total executions afterCloneExecutionCount " + afterCloneExecutionCount);

		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsClonnedCycle, Projectid,
				Versionid, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), responseCloneCycle);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		Assert.assertEquals(afterCloneExecutionCount, beforeCloneExecutionCount, "Executions count is not same.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * invalid case in UI its allowing Clone cycle by passing same cycle details
	 */

	@Test(priority = 14, enabled=true)
	public void test14_CloneCycle_with_same_details() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "clone cycle with same details";
		String description = "Cycle Empty cycle";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription(description);
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		// Add one Execution to Cycle code
		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		// cycleJson.setName("CLONE-"+Cyclename);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription(description);
		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Clone Cycle by removing project ID from Cycle Object before
	 * passing to Clone Cycle
	 */

	@Test(priority = 15, enabled=true)
	public void test15_Attempt_cloneCycle_by_removing_projectid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Attempt_cloneCycle_by_removing_projectid";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		cycleJson.setName("CLONE-" + Cyclename);
		cycleJson.setProjectId(null);

		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		System.err.println("data" + response.getBody().asString());
		Assert.assertNotNull(response, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Clone Cycle by removing Version Id from Cycle Object before
	 * passing to Clone Cycle
	 */

	@Test(priority = 16, enabled=true)
	public void test16_Attempt_cloneCycle_with_Empty_versionid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionTwoId"));
		String Cyclename = "Attempt_cloneCycle_with_Empty_versionid";
		Integer sourceExecutionCount = 0;
		Integer clonnedExecutionCount = 0;
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		cycleJson.setName("CLONE-" + Cyclename);
		cycleJson.setVersionId(null);

		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Attempt to Clone Cycle by removing Cycle name from Cycle Object before
	 * passing to Clone Cycle
	 */

	@Test(priority = 17, enabled=true)
	public void test17_Attempt_cloneCycle_with_empty_cycle_name() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long Projectid = Long.parseLong(Config.getValue("projectId"));
		Long Versionid = Long.parseLong(Config.getValue("versionThreeId"));
		String Cyclename = "Cycle_with_oneExecution";
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Projectid);
		cycleJson.setVersionId(Versionid);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cycle Empty cycle");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();
		cycleJson.setName(null);
		// give Deleted cycle id in place of Cycleid
		response = zapiService.cloneCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Clone Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Clone  Cycle Api executed successfully.");

		Integer sourceExecutionCount = 0;
		Integer clonnedExecutionCount = 0;
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		System.out.println(response.getBody().asString());
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
