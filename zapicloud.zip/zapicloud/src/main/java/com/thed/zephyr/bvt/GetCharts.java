/**
 * Created by manoj.behera on 07-Dec-2016.
 */
package com.thed.zephyr.bvt;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 07-Dec-2016
 *
 */
public class GetCharts extends BaseTest {
	@Test(priority = 1)
	public void bvt70_getTestsCreated() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getTestsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		String jql = "project= "+Config.getValue("projectId")+" AND issuetype=Test";
		int startAt = 0;
		int maxResults = 50;
		Response getTestsResponse = jiraService.searchRequest(basicAuth, jql, startAt, maxResults);
		Assert.assertNotNull(getTestsResponse, "get Tests Api Response is null.");
		System.out.println(getTestsResponse.getBody().asString());
		
		String totalCount = new JSONObject(getTestsResponse.getBody().asString()).get("total").toString();
		boolean validationStatus = zapiService.validateGetTestsCreated(totalCount, response);
		Assert.assertTrue(validationStatus, "Not validated getTestsCreated Chart.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void bvt71_getExecutionsCreated() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		int daysPrevious = 30;
		String periodName = "daily";
		Response response = zapiService.getExecutionsCreated(jwtGenerator, projectId, daysPrevious, periodName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		String payLoad = "{\"maxRecords\":50,\"offset\":20,\"zqlQuery\":\"project = "+Config.getValue("projectKey")+" AND executionStatus != UNEXECUTED \",\"fields\":{\"project\":[{\"id\":"+Config.getValue("projectId")+",\"key\":\""+Config.getValue("projectKey")+"\",\"name\":\""+Config.getValue("projectKey")+"\"}]}}";
		System.out.println(payLoad);
		Response getExecResponse = zapiService.executeZQLSearch(jwtGenerator, payLoad);
		Assert.assertNotNull(getExecResponse, "get Executions Api Response is null.");
		System.out.println(getExecResponse.getBody().asString());
		String totalCount = new JSONObject(getExecResponse.getBody().asString()).get("totalCount").toString();
		
		boolean validationStatus = zapiService.validateGetExecutionsCreated(totalCount, response);
		Assert.assertTrue(validationStatus, "Not validated getTestsCreated Chart.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
