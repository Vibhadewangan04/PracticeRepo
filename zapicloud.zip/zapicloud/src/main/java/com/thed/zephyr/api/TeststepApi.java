/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api;

import org.json.JSONArray;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface TeststepApi {

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response updateTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response cloneTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response moveTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getTeststeps(JwtGenerator jwtGenerator, Long projectId, Long issueId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getTeststepStatuses(JwtGenerator jwtGenerator);
}
