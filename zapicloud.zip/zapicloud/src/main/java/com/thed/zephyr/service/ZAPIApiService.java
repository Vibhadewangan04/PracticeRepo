package com.thed.zephyr.service;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface ZAPIApiService {
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createCycle(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public JSONArray createCycles(JwtGenerator jwtGenerator, String payLoad, int numberOfCycles);

	/**
	 * This will validate the created cycle.
	 * @param reqPayLoad
	 * @param response
	 * @return boolean value
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	boolean validateCycle(String reqPayLoad, Response response);
	/**
	 * This method will update the cycle by taking as the following input.
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response updateCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);

//	/**
//	 * This method will validate the updated cycle response.
//	 * @param response
//	 * @return boolean value
//	 * @author Created by manoj.behera on 14-Nov-2016.
//	 */
//	boolean validateUpdateCycle(Response response);
	/**
	 * This method will delete the cycle by taking as the following input.
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);
	
	//Delete folder
	Response DeleteFolderId(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long cycleid, long folderId);
	/**
	 * This method will validate the deleted cycle response.
	 * @param response
	 * @return boolean value
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	boolean validateDeletedCycle(Long projectId, Long versionId, String cycleId, Response response);

	/**
	 * @param jwtGenerator
	 * @param cycleId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response moveExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param cycleId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response copyExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getCycles(JwtGenerator jwtGenerator, Long projectId, Long versionId);
	boolean validateGetCycles(Long projectId, Long versionId, Response response);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);
//	/**
//	 * @param projectId
//	 * @param versionId
//	 * @param cycleId
//	 * @param response
//	 * @return
//	 * @author Created by manoj.behera on 16-Nov-2016.
//	 */
//	boolean validateGetCycle(Long projectId, Long versionId, String cycleId, Response response);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @param exportType
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response exportCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId,
			String exportType);

	boolean validateExportCycle(Long projectId, Long versionId, String cycleId,String exportType, Response response);


	//Test step Apis

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String payLoad);
	
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	JSONArray createTeststeps(JwtGenerator jwtGenerator, Long projectId, Long issueId, String payLoad);
	
	boolean validateTeststep(Long projectId, Long issueId, String reqPayLoad, Response response);
 	boolean validateTeststepsWithData(Long projectId, Long issueId, String reqPayLoad, JSONArray response);
	
 	boolean validateTeststepsData(Long projectId, Long issueId, String reqPayLoad, Response response);
 	
	boolean validateCreateTestStepInvalidIsueId(Long projectId, Long issueId, String reqPayLoad, Response response);
  boolean validateCreateTestStepInvalidIsueId2(Long projectId, Long issueId, String stepid, Response response);
	boolean validateCreateTestStepInvalidProjectId(Long projectId, Long issueId, String reqPayLoad, Response response);
	boolean validateCreateTestStepOtherIssueType(Long projectId, Long issueId, String reqPayLoad, Response response);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response updateTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response cloneTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response moveTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getTeststeps(JwtGenerator jwtGenerator, Long projectId, Long issueId);
	Response getTeststepStatuses(JwtGenerator jwtGenerator);
	boolean validateGetStepStatuses(Response response);
	
	//Zql filters apis

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createZQLFilter(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 22-Nov-2016.
	 */
	boolean validateZQLFilter(String reqPayLoad, Response response);
//	boolean validateGetZqlFilter(String payLoad,Response response);
	/**
	 * ZQL APis
	 */

	/**
	 * @param jwtGenerator
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLFieldConfiguration(JwtGenerator jwtGenerator);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response executeZQLSearch(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param fieldName
	 * @param fieldValue
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLAutoComplete(JwtGenerator jwtGenerator, String fieldName, String fieldValue);
	/**
	 * @param jwtGenerator
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLFieldValues(JwtGenerator jwtGenerator);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	Response copyFilter(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param filterId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	Response updateFilter(JwtGenerator jwtGenerator, String filterId, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param filterId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 18-Nov-2016.
	 */
	Response deleteFilter(JwtGenerator jwtGenerator, String filterId);
	/**
	 * @param jwtGenerator
	 * @param filterId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response toggleFavorite(JwtGenerator jwtGenerator, String filterId, String payLoad);

	/**
	 * @param jwtGenerator
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getServerInfo(JwtGenerator jwtGenerator);
	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	boolean validateServerInfo(Response response);

	/**
	 * @param jwtGenerator
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getSystemProp(JwtGenerator jwtGenerator);

	/**
	 * @param jwtGenerator
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getGeneralConfigInfo(JwtGenerator jwtGenerator);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	boolean validateGeneralConfigInfo(Response response);

	/**
	 * Execution Apis
	 */

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createExecution(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @return
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	Response getExecutionStatuses(JwtGenerator jwtGenerator);
	boolean validateGetExecutionStatuses(Response response);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param executionId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getExecution(JwtGenerator jwtGenerator, Long projectId, Long issueId, String executionId);
	boolean validateGetExecution(Response response, Long projectId, Long issueId);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param offset
	 * @param size
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getExecutions(JwtGenerator jwtGenerator, Long projectId, Long issueId, int offset, int size);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @param offset
	 * @param size
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public Response getExecutionsByCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId, int offset, int size);
	boolean validateGetExecutionsByCycle(Response response, Long  projectId, Long versionId, String cycleId, int offset, int size);
	/**
	 * @param jwtGenerator
	 * @param sprintId
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getExecutionSummariesBySprintAndIssue(JwtGenerator jwtGenerator, Long sprintId, String issueIdorKeys);
	/**
	 * @param jwtGenerator
	 * @param issueId
	 * @param executionId
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteExecution(JwtGenerator jwtGenerator, Long issueId, String executionId);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response updateBulkStatus(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response deleteBulkExecutions(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response assignBulkExecutions(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param issueIdOrKey
	 * @param offset
	 * @param size
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getExecutionsByIssue(JwtGenerator jwtGenerator, Long issueId, int offset, int size);
	Response getExecutionsByIssue(JwtGenerator jwtGenerator, String issueKey, int offset, int size);
	boolean validateGetExecutionsByIssue(Response response, Long issueId, int offset, int size);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response addAttachment(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long issueId, String cycleId, String entityName, String entityId, String comment, String fileName);
	/**
	 * @param jwtGenerator
	 * @param entityId
	 * @param projectId
	 * @param issueId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getExecutionAttachmentsList(JwtGenerator jwtGenerator, String entityId);
	/**
	 * @param jwtGenerator
	 * @param executionId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getStepResultAttachmentsList(JwtGenerator jwtGenerator, String stepResultId);
	/**
	 * @param jwtGenerator
	 * @param attachmentId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getAttachmentThumbnail(JwtGenerator jwtGenerator, String attachmentId);
	/**
	 * @param jwtGenerator
	 * @param attachmentId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteAttachment(JwtGenerator jwtGenerator, String attachmentId);

	/**
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	boolean validateExecution(String reqPayLoad, Response response);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param executionId
	 * @param stepResultId
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response getStepResult(JwtGenerator jwtGenerator, String executionId, String stepResultId);
	boolean validateStepResult(String stepResultObj, Response response);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param executionId
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response getStepResults(JwtGenerator jwtGenerator, Long issueId, String executionId);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateCreatedExecutionInvalidCycleId(String executionJson, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateInvalidIssueId(Long issueId, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateInvalidVersionId(Long versionId, Response response);

//	/**
//	 * @param executionJson
//	 * @param response
//	 * @return
//	 * @author Created by manoj.behera on 16-Nov-2016.
//	 */
//	boolean validateCreatedExecutionInvalidProjectId(String executionJson, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateMultipleExecutionsWithSameIssueInScheduledCycle(Response response);

//	/**
//	 * @param executionJson
//	 * @param response
//	 * @return
//	 * @author Created by manoj.behera on 16-Nov-2016.
//	 */
//	boolean validateCreatedExecutionIsueIdOtherProject(String executionJson, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateInvalidTestType(Long issueId, Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateDeletedExecutionWithInvalidIsueId(Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	boolean validateDeletedExecutionWithInvalidExecutionId(Response response);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response exportExecutions(JwtGenerator jwtGenerator, String payLoad);
	Response updateStepResult(JwtGenerator jwtGenerator, String stepResultId, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param executionId
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response getStepDefectsByExecutionId(JwtGenerator jwtGenerator, Long projectId, String executionId);
	/**
	 * @param jwtGenerator
	 * @param statusId
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response getStepResultByStatus(JwtGenerator jwtGenerator, int statusId, int offset, int maxResults);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	boolean validateGetStepResultByStatus(Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	boolean validateGetStepDefectsByExecutionId(Long projectId, String executionId, Response response);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response exportTraceabilityReport(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response reOrderExecutions(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param attachmentId
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response getAttachmentImage(JwtGenerator jwtGenerator, String attachmentId);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	JSONArray createExecutions(JwtGenerator jwtGenerator, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param requirementList
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response generateRequirementTraceability(JwtGenerator jwtGenerator, Long versionId, String requirementList);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param defectIdList
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response generateDefectTraceability(JwtGenerator jwtGenerator, Long versionId, String defectIdList);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param defectId
	 * @param offset
	 * @param maxResult
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response searchExecutionsByDefect(JwtGenerator jwtGenerator, Long versionId, Long defectId, int offset,
			int maxResult);

	/**
	 * @param jwtGenerator
	 * @param versionId
	 * @param defectId
	 * @param offset
	 * @param maxResult
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response searchExecutionsByTest(JwtGenerator jwtGenerator, Long versionId, Long testId, int offset,
			int maxResult);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param daysPrevious
	 * @param periodName
	 * @param maxResults
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getTestsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param daysPrevious
	 * @param periodName
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getExecutionsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName);
	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getTestDistributionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param issueStatuses
	 * @param howMany
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getTopDefects(JwtGenerator jwtGenerator, Long projectId, Long versionId, int issueStatuses, int howMany);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param cycleId
	 * @return
	 * @author Created by manoj.behera on 21-Nov-2016.
	 */
	Response getExecutionCount(JwtGenerator jwtGenerator, Long projectId, Long versionId, String groupFld);

	Response moveCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	Response cloneCycle(JwtGenerator jwtGenerator, String clonedCycleId, String payLoad);
	Response addTestsTocycle(JwtGenerator jwtGenerator, String cycleId, String payLoad);
	Response getExecutionsByZQL(JwtGenerator jwtGenerator, String executionId, String payLoad);
	/**
	 * @param response
	 * @param projectId
	 * @param issueId
	 * @param offset
	 * @param size
	 * @return
	 * @author Created by Praveenkumar
	 */
	boolean validateGetExecutions(Response response, Long projectId, Long issueId, int offset, int size);

	/**
	 * @param response
	 * @return
	 * @author Created by Praveenkumar
	 */
	boolean validateGetExecutionsWithInvalidIssueId(Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by Praveenkumar
	 */
	boolean validateGetExecutionsWithInvalidProjectId(Response response);

	/**
	 * @param response
	 * @param exportType
	 * @return
	 * @author Created by Praveenkumar
	 */
	boolean validateExportExecutions(String response, String exportType);

	/**
	 * @param response
	 * @return
	 * @author Created by Praveenkumar
	 */
	boolean validateCopyExecutionsToCycle(Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by Praveenkumar
	 */
	boolean validateMoveExecutionsToCycle(Response response);
	boolean validateDeleteZqlFilter(String zqlFilterId, Response response);

	/**
	 * @param jwtGenerator
	 * @param jobProgressId
	 * @return
	 */
	Response jobProgressHandler(JwtGenerator jwtGenerator, String jobProgressId);
	boolean validateJobProgress(Response response,String payload);

	/**
	 * @param response
	 * @return
	 */
	boolean validateCopyExecutionsToCycleWithInvalidCycleId(Response response);

	/**
	 * @param response
	 * @return
	 */
	boolean validateMoveExecutionsToCycleWithInvalidCycleId(Response response);

	/**
	 * @param response
	 * @return
	 */
	boolean validateCopyExecutionsToCycleWithInvalidProjectId(Response response);

	/**
	 * @param response
	 * @return
	 */
	boolean validateMoveExecutionsToCycleWithInvalidProjectId(Response response);

	/**
	 * @param response
	 * @return
	 */
	boolean validateCopyExecutionsToCycleWithInvalidVersionId(Response response);
	boolean validateCreatedAttachment(Long versionId, String cycleId,
			String entityName, String entityId, String comment, String fileName, Response response);
	/**
	 * @param response
	 * @return
	 */
	boolean validateMoveExecutionsToCycleWithInvalidVersionId(Response response);

	/**
	 * @param response
	 * @param projectId
	 * @param issueId
	 * @param teststepId
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateDeleteTeststep(Response response, Long projectId, Long issueId, String teststepId);

	/**
	 * @param jwtGenerator
	 * @param fileName
	 * @author Created by manoj.behera on 25-Nov-2016.
	 * @return 
	 */
	boolean downloadCycleExportedFile(JwtGenerator jwtGenerator, String fileName);

	/**
	 * @param jwtGenerator
	 * @param fileName
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean downloadTraceabilityExportedFile(JwtGenerator jwtGenerator, String fileName);

	/**
	 * @param jwtGenerator
	 * @param fileName
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean downloadExecutionsExportedFile(JwtGenerator jwtGenerator, String fileName);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateUpdatedTeststep(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateClonedTeststep(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateUpdatedTestStepDeletedTestStep(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateClonedTestStepInvalidTeststep(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateClonedTestStepInvalidPositionId(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateUpdatedTestStepInvalidIssueId(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateClonedTestStepInvalidProjectId(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateUpdatedTestStepInvalidProjectId(Long projectId, Long issueId, String reqPayLoad, Response response);

	/**
	 * @param reqPayLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateUpdatedExecution(String reqPayLoad, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateInvalidProjectId(Long projectId, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateInvalidStatusId(Long statusId, Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateInvalidCycleId(String cycleId , Response response);

	/**
	 * @param executionJson
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 25-Nov-2016.
	 */
	boolean validateInvalidExecutionId(String executionId, Response response);


	boolean validateAddTestsToCycle(String reqPayLoad, Response response);
	boolean validateZQLFilters(String reqPayLoad, Response response);

	/**
	 * @param jwtGenerator
	 * @param byUser
	 * @param fav
	 * @param offset
	 * @param maxRecords
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */
	Response getFavouriteZQLFilters(JwtGenerator jwtGenerator, boolean byUser, boolean fav, int offset, int maxRecords);

	/**
	 * @param jwtGenerator
	 * @param byUser
	 * @param offset
	 * @param maxRecords
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */

	boolean validateAddTestsToCycleInvalidCycleId(String executionJson, Response response);
	Response getMyZQLFilters(JwtGenerator jwtGenerator, boolean byUser, int offset, int maxRecords);

	/**
	 * @param jwtGenerator
	 * @param fav
	 * @param offset
	 * @param maxRecords
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */
	boolean validateAddTestsToCycleBlankCycleId(String executionJson, Response response);
	Response getPapularZQLFilters(JwtGenerator jwtGenerator, boolean fav, int offset, int maxRecords);

	/**
	 * @param jwtGenerator
	 * @param zqlFilterId
	 * @return
	 * @author Created by manoj.behera on 28-Nov-2016.
	 */
	Response getZQLFilter(JwtGenerator jwtGenerator, String zqlFilterId);

	/**
	 * @param jwtGenerator
	 * @param executionId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	boolean validateAddTestsToCycleInvalidId(String executionJson, Response response);
	Response updateExecution(JwtGenerator jwtGenerator, String executionId, String payLoad);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 02-Dec-2016.
	 */
	boolean validateDeletedAttachment(String attachmentId, Response response);
	boolean validateGetZQLFieldConfiguration(Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 02-Dec-2016.
	 */
	boolean validateAddedAttachmentInvalidValues(Response response);
	boolean validateGetZQLFieldValues(JSONObject jsonObjectList , Response response);

	/**
	 * @param jwtGenerator
	 * @param zqlFilter
	 * @return
	 * @author Created by manoj.behera on 03-Dec-2016.
	 */
	boolean validateGetAttachment(String entityId, JSONArray jsonArray, Response response);
	Response searchZQLFilters(JwtGenerator jwtGenerator, String zqlFilter);

	/**
	 * @param jwtGenerator
	 * @param zqlFilterName
	 * @return
	 * @author Created by manoj.behera on 03-Dec-2016.
	 */
	Response quickSearchZQLFilter(JwtGenerator jwtGenerator, String zqlFilterName);
	boolean validateGetAttachmentThumbanail(Response response);
	/**
	 * @param textForSearch
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Dec-2016.
	 */
	boolean validateSearchExecutionsByTest(Response response);
	boolean validateGetZQLAutoComplete(String textForSearch, Response response);

	boolean validateSearchExecutionsByTestInvalidIssueId(Response response);
	boolean validateZQLFilterWithInvalidFilterId(String reqPayLoad, Response response);
	boolean validateSearchExecutionsByDefect(Response response);
	/**
	 * @param response
	 * @param exportType
	 * @return
	 */
	boolean validateSearchExecutionsByDefectInvalidIssueId(Response response);
	boolean validateExportTraceabilityReport(String response, String exportType);

	/**
	 * @param reqPayLoad
	 * @param response
	 * @return
	 */
	boolean validateDeletedAttachmentInvalidAttachmentId(Response response);
	boolean validateExecuteZQLSearch(String reqPayLoad, Response response);
	
	Response pingJob(JwtGenerator jwtGenerator);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Jan-2017.
	 */
	boolean validateAlreadyExistsZQLFilter(Response response);

	/**
	 * @param zqlFilterId
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Jan-2017.
	 */
	boolean validateInvalidZQLFilterId(String zqlFilterId, Response response);

	/**
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Jan-2017.
	 */
	boolean validateInvalidIssueTypeId(Response response);

	/**
	 * @param stepId
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Jan-2017.
	 */
	boolean validateInvalidStepId(String stepId, Response response);

	/**
	 * @param srcStep
	 * @param destStep
	 * @param payLoad
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Jan-2017.
	 */
	boolean validateMoveStep(JSONObject srcStep, JSONObject destStep, String payLoad, Response response);

	/**
	 * @param projectId
	 * @param issueId
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 03-Jan-2017.
	 */
	boolean validateMismatchOfProjectIdAndIssueId(Long projectId, Long issueId, Response response);

	/**
	 * @param Executionid
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 06-Jan-2017.
	 */
	boolean validateDeletedExecution(String Executionid, Response response);

	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 10-Jan-2017.
	 */
	Response getListOfCyclesBySprint(JwtGenerator jwtGenerator, String payLoad);

	
	/**
	 * @param attachmentId
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 01-Feb-2017.
	 */
	boolean validateInvalidAttachmentId(String attachmentId, Response response);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param issueId
	 * @param cycleId
	 * @param entityName
	 * @param entityId
	 * @param comment
	 * @param fileName
	 * @return
	 * @author Created by manoj.behera on 15-Feb-2017.
	 */
	JSONArray addMultipleAttachment(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long issueId,
			String cycleId, String entityName, String entityId, String comment, List<String> fileName);


	/**
	 * @param stepResId
	 * @param stepResultObj
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	boolean validateUpdatedStepResult(String stepResId, String stepResultObj, Response response);

	/**
	 * @param testsCount
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	boolean validateGetTestsCreated(String testsCount, Response response);

	/**
	 * @param executionsCount
	 * @param response
	 * @return
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	boolean validateGetExecutionsCreated(String executionsCount, Response response);

	boolean validateGetExecutionCount(JwtGenerator jwtGenerator, String groupFld, Response response);

	boolean validateGetTopDefects(JwtGenerator jwtGenerator, Response response);

	boolean validateGetTestDistributionCount(JwtGenerator jwtGenerator, Response response);
	
	//Adding Folder API
	
	/*Need to implement
	New APIs:
		POST /public/rest/api/1.0/folder - Create or clone folder
		GET /public/rest/api/1.0/folder/:folderId - Get folder by projectId, versionId, cycleId, folderId
		
		DELETE /public/rest/api/1.0/folder/:folderId - Delete folder by projectId, versionId, cycleId, folderId
		
		PUT /public/rest/api/1.0/folder/:folderId - Update folder by folderId(Name or Description)
		
		GET /public/rest/api/1.0/folders - Get folders for a projectId, versionId and cycleId
		
		POST /public/rest/api/1.0/executions/add/folder/:folderId. - Add tests to folder
		
		GET /public/rest/api/1.0/executions/search/folder/:folderId - Get executions by folder
		
		POST /public/rest/api/1.0/cycle/:cycleId/move/:folderId. - Move executions from cycle to folder*/
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response createFolderCycle(JwtGenerator jwtGenerator, String payLoad);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response GetFolderbyid(JwtGenerator jwtGenerator, String payLoad,String Folderid);
	
	// Execution workflow
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_Inprogress(JwtGenerator jwtGenerator,String Executionid,String Issueid);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_Done(JwtGenerator jwtGenerator,String action,String timeLogged,String Executionid,String Issueid);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_Modifytime(JwtGenerator jwtGenerator,String action,String timeLogged,String Executionid,String Issueid);
	
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 15-Nov-2017.
	 */
	Response Executionworflow_Reopen(JwtGenerator jwtGenerator,String Executionid,String Issueid);

	Response getExecutionTimeTracking(JwtGenerator jwtGenerator, Long projectid, Long versionid, String cycleId);

	boolean ValidateGetExecutionTimeTracking(JwtGenerator jwtGenerator, Response response);

	Response getFolders(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);

	boolean validateGetFolders(Long projectid, Long versionid, String cycleId, Response getFolderbyidResponse);
	
	Response cloneFolder(JwtGenerator jwtGenerator, String clonedCycleId, String clonedFolderId, String payLoad);

	Response clonedFolder(JwtGenerator jwtGenerator, String cycleId, String string);
	
	boolean DeleteFolderId(Long projectId, Long versionId, Long cycleid, Response response);
	
	boolean validatenullIssueId(Long issueId, Response response);
	
	boolean validateInvalidIssueIdForStep1(Long issueId, Response response);
	
	boolean validateInvalidProjectIdForTestStep(Long projectId, Response response);
	
	boolean validateNullProjectId(Long projectId, Response response);
	
	boolean validateInvalidProjectIdForCreateTestStep(Long projectId, Response response);
	
	boolean validateTeststepWithProjectIdNull(Long projectId, Long issueId, String reqPayLoad, Response response);

	boolean validateinvalidJobProgress(Response response, String payload);

	boolean validateCreateTestStepInvalidIsueId(Long projectId, Long issueId, String reqPayLoad, Response response,
			String stepid);
	
	boolean validateAttemptToDeleteTeststep(Response response, Long projectId, Long issueId);
	
	boolean validateGetExecutionsWithOtherCycleId(Response response, Long projectId, Long versionId, String cycleId,
			int offset, int size);

	boolean validateZQLFilters(Response reqPayLoad, Response response);
	
	boolean validateAddTestsToCycleInvalidIssueIdAndVersionId(String executionJson, Response response);
	
	boolean validateMoveInvalidExecutionsToCycle(Response response);
	
	boolean validateCopyInvalidExecutionsToCycle(Response response);

	boolean validateExecutionIdNull(String ExecutionId, Response response);
	boolean validateZqlWithInvalidExecutionId(Response response, String executionId);

	boolean validateExecuteZQLSearchWithoutPassingZql(String reqPayLoad, Response response);

	boolean validategetExecutionSummariesBySprintAndIssue(Response response);
	
	boolean validategetinvalidExecutionSummariesBySprintAndIssue(Response response);

	boolean getStepResult2(JwtGenerator jwtGenerator, String executionId, Long projectId, Response stepResultsresponse);
	
	boolean validateFolder(String string, Response response);

	boolean validateZQLSearch(String reqPayLoad, Response response);

	boolean validateZQLSearchWithMaxRecordExceed(String reqPayLoad, Response response);

	boolean validateInvalidZQLSearch(String reqPayLoad, Response response);

	boolean validateZQLFieldValues(JSONObject jsonObjectList, Response response);
	
	Response updateExecutionCustomfield(JwtGenerator jwtGenerator, String executionId, String payLoad);
	boolean validateupdateExecutionCustomfield(String payLoad, Response response);
	boolean validateinvalidExecutionCustomfield(Response response,String executionId );

	boolean validateCycle(Long projectId, Long versionId, String cycleId, Response response);
}


