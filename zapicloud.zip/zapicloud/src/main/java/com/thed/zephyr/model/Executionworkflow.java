/**
 * Created by manoj.behera on 16-Nov-2016.
 */
package com.thed.zephyr.model;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.thed.zephyr.util.CommonUtils;

/**
 * @author manoj.behera 16-Nov-2016
 *
 */
public class Executionworkflow {
	private Long statusId;
	private Long projectId;
	private Long issueId;
	private List<Long> issueIds;
	private String cycleId;
	private List<String> cycleIds;
	private Long versionId;
	private String executionId;
	private List<String> executions;
	private String assigneeType;
	private boolean changeAssignee;
	private String assignee;
	private int noOfExecutions;
	private List<Long> defects;
	private String comment;

	/**
	 * @return the comment Created by manoj.behera on 05-Jan-2017.
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * @param comment
	 *            the comment to set
	 * @author Created by manoj.behera on 05-Jan-2017.
	 */
	public void setComment(String comment) {
		this.comment = comment;
	}

	/**
	 * @return the defects Created by manoj.behera on 05-Jan-2017.
	 */
	public List<Long> getDefects() {
		return defects;
	}

	/**
	 * @param defects
	 *            the defects to set
	 * @author Created by manoj.behera on 05-Jan-2017.
	 */
	public void setDefects(List<Long> defects) {
		this.defects = defects;
	}

	/**
	 * @param statusId
	 * @author Created by manoj.behera on 05-Jan-2017.
	 */
	public Executionworkflow(String response) {
		super();
		JSONObject executionJson = new JSONObject(response);
		if (executionJson.has("id")) {
			this.executionId = executionJson.getString("id");
		}
		if (executionJson.has("projectId")) {
			this.projectId = executionJson.getLong("projectId");
		}
		if (executionJson.has("issueId")) {
			this.issueId = executionJson.getLong("issueId");
		}
		if (executionJson.has("issueIds")) {
			JSONArray jsonArray = executionJson.getJSONArray("issueIds");
			this.issueIds = CommonUtils.convertToList(jsonArray);
		}
		if (executionJson.has("status")) {
			this.statusId = executionJson.getJSONObject("status").getLong("id");
		}
		if (executionJson.has("cycleId")) {
			this.cycleId = executionJson.getString("cycleId");
		}
		if (executionJson.has("versionId")) {
			this.versionId = executionJson.getLong("versionId");
		}
		if (executionJson.has("assigneeType")) {
			this.assigneeType = executionJson.getString("assigneeType");
		}
		if (executionJson.has("changeAssignee")) {
			this.changeAssignee = executionJson.getBoolean("changeAssignee");
		}
	}

	/**
	 * @return the statusId Created by manoj.behera on 05-Jan-2017.
	 */
	public Long getStatusId() {
		return statusId;
	}

	/**
	 * @return the projectId Created by manoj.behera on 05-Jan-2017.
	 */
	public Long getProjectId() {
		return projectId;
	}

	/**
	 * @return the issueId Created by manoj.behera on 05-Jan-2017.
	 */
	public Long getIssueId() {
		return issueId;
	}

	/**
	 * @return the issueIds Created by manoj.behera on 05-Jan-2017.
	 */
	public List<Long> getIssueIds() {
		return issueIds;
	}

	/**
	 * @return the cycleId Created by manoj.behera on 05-Jan-2017.
	 */
	public String getCycleId() {
		return cycleId;
	}

	/**
	 * @return the cycleIds Created by manoj.behera on 05-Jan-2017.
	 */
	public List<String> getCycleIds() {
		return cycleIds;
	}

	/**
	 * @return the versionId Created by manoj.behera on 05-Jan-2017.
	 */
	public Long getVersionId() {
		return versionId;
	}

	/**
	 * @return the executionId Created by manoj.behera on 05-Jan-2017.
	 */
	public String getExecutionId() {
		return executionId;
	}

	/**
	 * @return the executions Created by manoj.behera on 05-Jan-2017.
	 */
	public List<String> getExecutions() {
		return executions;
	}

	/**
	 * @return the assigneeType Created by manoj.behera on 05-Jan-2017.
	 */
	public String getAssigneeType() {
		return assigneeType;
	}


	/**
	 * @return the noOfExecutions Created by manoj.behera on 05-Jan-2017.
	 */
	public int getNoOfExecutions() {
		return noOfExecutions;
	}

	/**
	 * 
	 * @author Created by manoj.behera on 05-Jan-2017.
	 */
	public Executionworkflow() {
		super();
	}

	/**
	 * @param noOfExecutions
	 *            the noOfExecutions to set
	 * @author Created by manoj.behera on 18-Dec-2016.
	 */
	public void setNoOfExecutions(int noOfExecutions) {
		this.noOfExecutions = noOfExecutions;
	}

	/**
	 * @param statusId
	 *            the statusId to set
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	public void setStatusId(Long statusId) {
		this.statusId = statusId;
	}

	/**
	 * @param projectId
	 *            the projectId to set
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	public void setProjectId(Long projectId) {
		this.projectId = projectId;
	}

	/**
	 * @param issueId
	 *            the issueId to set
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	public void setIssueId(Long issueId) {
		this.issueId = issueId;
	}

	public void setIssueIds(List<Long> issueIds) {
		this.issueIds = issueIds;
	}

	/**
	 * @param cycleId
	 *            the cycleId to set
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	public void setCycleId(String cycleId) {
		this.cycleId = cycleId;
	}

	/**
	 * @param cycleIds
	 *            the cycleIds to set
	 * @author Created by manoj.behera on 18-Dec-2016.
	 */
	public void setCycleIds(List<String> cycleIds) {
		this.cycleIds = cycleIds;
	}

	/**
	 * @param versionId
	 *            the versionId to set
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	public void setVersionId(Long versionId) {
		this.versionId = versionId;
	}

	/**
	 * @param executionId
	 *            the executionId to set
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	public void setExecutionId(String executionId) {
		this.executionId = executionId;
	}

	/**
	 * @param executionIdList
	 *            the executionId to set
	 * @author Created by soumyaranjan on 30-Nov-2016.
	 */
	public void setExecutions(List<String> executions) {
		this.executions = executions;
	}

	/**
	 * @param assignType
	 *            the assignType to set
	 * @author Created by soumyaranjan on 30-Nov-2016.
	 */
	public void setAssigneeType(String assigneeType) {
		this.assigneeType = assigneeType;
	}


	@Override
	public String toString() {
		JSONObject executionJson = new JSONObject();
		if (statusId != null) {
			executionJson.put("status", new JSONObject().put("id", this.statusId));
		}
		executionJson.put("projectId", this.projectId);
		executionJson.put("issueId", this.issueId);
		if (this.issueIds != null) {
			executionJson.put("issueIds", this.issueIds);
		}
		if (this.defects != null) {
			executionJson.put("defects", this.defects);
		}
		if (this.comment != null) {
			executionJson.put("comment", this.comment);
		}
		if (this.cycleIds != null) {
			executionJson.put("cycleIds", this.cycleIds);
		}
		executionJson.put("cycleId", this.cycleId);
		executionJson.put("versionId", this.versionId);
		executionJson.put("id", this.executionId);
		if (this.executions != null) {
			executionJson.put("executions", this.executions);
		}
		if (this.assigneeType != null) {
			if(this.assigneeType.equals("currentUser")){
				executionJson.put("assigneeType", this.assigneeType);
				executionJson.put("changeAssignee", this.changeAssignee);
			}else{
				executionJson.put("assigneeType", this.assigneeType);
				executionJson.put("assignee", this.assignee);
				executionJson.put("changeAssignee", this.changeAssignee);
			}
			
		}
		if (this.noOfExecutions != 0) {
			executionJson.put("noOfExecutions", this.noOfExecutions);
		}
		return executionJson.toString();
	}

	/**
	 * @return the changeAssignee
	 * Created by manoj.behera on 06-Jan-2017.
	 */
	public boolean isChangeAssignee() {
		return changeAssignee;
	}

	/**
	 * @param changeAssignee the changeAssignee to set
	 * @author Created by manoj.behera on 06-Jan-2017.
	 */
	public void setChangeAssignee(boolean changeAssignee) {
		this.changeAssignee = changeAssignee;
	}

	/**
	 * @return the assignee
	 * Created by manoj.behera on 06-Jan-2017.
	 */
	public String isAssignee() {
		return assignee;
	}

	/**
	 * @param assignee the assignee to set
	 * @author Created by manoj.behera on 06-Jan-2017.
	 */
	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}
}
