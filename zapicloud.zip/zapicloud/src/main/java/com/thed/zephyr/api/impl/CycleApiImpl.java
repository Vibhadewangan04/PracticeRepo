package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.CycleApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("cycleApi")
public class CycleApiImpl implements CycleApi {
	
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#createCycle(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public Response createCycle(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle";
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
//		headers.put("Cookie","PLAY_LANG=zh");
		 System.out.println(uri.toString());
		 System.out.println(payLoad);
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response cloneCycle(JwtGenerator jwtGenerator, String clonedCycleId, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("expand", "executionSummaries").queryParam("clonedCycleId", clonedCycleId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		JSONObject json = new JSONObject(payLoad);
		if(json.has("id")){
			json.remove("id");
		}
		payLoad = json.toString();
		System.out.println(payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#updateCycle(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public Response updateCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad){
//		String cycleId = new JSONObject(payLoad).get("id").toString();
	
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId;
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		JSONObject json = new JSONObject(payLoad);
		json.remove("id");
		payLoad = json.toString();
		System.out.println(payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).put(uriStr);
	 }
	@Override
	public Response moveCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad){
//		String cycleId = new JSONObject(payLoad).get("id").toString();
	
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId;
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		JSONObject json = new JSONObject(payLoad);
		json.remove("id");
		payLoad = json.toString();
		System.out.println(payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).put(uriStr);
	 }
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#deleteCycle(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public Response deleteCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId;
		URI uri = null;
		if(projectId == null){
			uri = UriBuilder.fromUri(uriStr).queryParam("versionId", versionId).build();
		}else if (versionId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}else{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("DELETE", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		return given().headers(headers).delete(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#getCycle(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId;
		URI uri = null;
		if(projectId == null){
			uri = UriBuilder.fromUri(uriStr).queryParam("versionId", versionId).build();
		}else if (versionId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}else{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
//		headers.put("USER-AGENT", "None");
		System.out.println(uri.toString());
		return given().headers(headers).get(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#getCycles(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getCycles(JwtGenerator jwtGenerator, Long projectId, Long versionId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycles/search";
		URI uri = null;
		if(projectId == null){
			uri = UriBuilder.fromUri(uriStr).queryParam("versionId", versionId).build();
		}else if (versionId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}else{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).get(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#copyExecutionsToCycle(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response copyExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId+"/copy";
		System.out.println(uriStr);
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.CycleApi#moveExecutionsToCycle(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response moveExecutionsToCycle(JwtGenerator jwtGenerator, String cycleId, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId+"/move";
		System.out.println(uriStr);
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response exportCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId, String exportType){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/"+cycleId+"/export";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("exportType", exportType).build();
		System.out.println(uri.toString());
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response downloadExportedFile(JwtGenerator jwtGenerator, String downloadFilename){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/export/download/"+downloadFilename;
		System.out.println(uriStr);
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getListOfCyclesBySprint(JwtGenerator jwtGenerator, String payLoad){
	
		String uriStr = Config.getValue("zephyrBaseUrl")+"/private/rest/api/1.0/cycles/versionsandsprint";
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		return given().headers(headers).body(payLoad).post(uriStr);
	 }
}
