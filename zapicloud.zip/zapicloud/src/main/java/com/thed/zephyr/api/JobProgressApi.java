/**
 * Created by manoj.behera on 16-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 16-Nov-2016
 *
 */
public interface JobProgressApi {

	/**
	 * @param jwtGenerator
	 * @param jobProgressId
	 * @return
	 * @author Created by manoj.behera on 16-Nov-2016.
	 */
	Response getJobProgress(JwtGenerator jwtGenerator, String jobProgressId);

}
