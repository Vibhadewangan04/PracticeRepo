/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.jira.ProjectApi;
import com.thed.zephyr.api.jira.SearchApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
@Service("searchApi")
public class SearchApiImpl implements SearchApi {
	private SearchApi searchApi;
	@Override
	public Response searchRequest(RequestSpecification basicAuth, String payLoad) {
		String api = "/rest/api/2/search";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body(payLoad).when().post(api);
	}
	@Override
	public Response searchRequest(RequestSpecification basicAuth, String jql, int startAt, int maxResults) {
		String api = "/rest/api/2/search?jql="+jql+"&startAt="+startAt+"&maxResults="+maxResults;
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).when().get(api);
	}
	
	
	@Override
	public Response createFilterInSearchTest(RequestSpecification basicAuth, String payload) {
		String api = "rest/api/2/filter";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		//return basicAuth.headers(headers).when().get(api);
		return basicAuth.headers(headers).body(payload).when().post(api);
	}
	@Override
	public Response createIssueLink(RequestSpecification basicAuth, String payload) {
	
		String api = "rest//api/2/issueLink";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body(payload).when().post(api);
	}
	

	
	
}
