/**
 * Created by manoj.behera on 21-Mar-2017.
 */
package com.thed.zephyr.api.jira;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author manoj.behera 21-Mar-2017
 *
 */
public interface ComponentApi {

	/**
	 * @param basicAuth
	 * @param versionPayLoad
	 * @return
	 * @author Created by manoj.behera on 21-Mar-2017.
	 */
	Response createComponent(RequestSpecification basicAuth, String componentPayLoad);

}
