package com.thed.zephyr.regression.cycle;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class MoveCycleAPI extends BaseTest {
	String cycleId = null;

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * Cycle Api updateCycle Move cycle to another Version if empty
	 */
	@Test(priority = 1, enabled=true)
	public void Test1_moveCycle_empty_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionFourId"));
		Cycle cycleJson = new Cycle();
		cycleJson.setName("Moved Cycle");
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		// Set Description
		cycleJson.setDescription("Cycle moved from version -1");

		// Creating cycle
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		String cycleId = new JSONObject(response.getBody().asString()).get("id").toString();

		// Set version which we want move
		Long move_to_version = Long.parseLong(Config.getValue("versionTwoId"));
		cycleJson.setVersionId(move_to_version);

		// Move cycle
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle if source cycle has 1 schedule
	 */
	@Test(priority = 2, enabled=true)
	public void Test2_moveCycle_cycle_one_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionFourId"));
		
		//create cycle
		
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

			
		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is having one execution
		
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle moved");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionTwoId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");

		// Move cycle
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle if cycle is fully unexecuted
	 */
	@Test(priority = 3, enabled=true)
	public void Test3_moveCycle_cycle_Fully_unexecuted_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionFourId"));
		
		//create cycle
		
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");

		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");

		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is fully unexecuted
		
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle moved");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");

		// Move cycle
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle if cycle is partially executed to any
	 * status
	 */
	@Test(priority = 4, enabled=true)
	public void Test4_moveCycle_cycle_partially_executed_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		//New cycle
		//create cycle
		
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length()-1;j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(1l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		

		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is partially unexecuted
		
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Partially Moved Cycle jagadeesh");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle moved");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");

		// Move cycle
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	/**
	 * Cycle Api updateCycle Move cycle if cycle is fully executed to any status
	 */
	 @Test(priority = 5, enabled=true)
	public void Test5_moveCycle_cycle_fully_executed_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		//Cycle cycleJson = new Cycle();
		// Set which cycle you want to move and which version
		// Set the cycleId which is fully executed to any status
		
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle fully executed");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle moved fully executed");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");

		// Move cycle
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			}

	/**
	 * Cycle Api updateCycle Move cycle if some schedules are linked to
	 * single/multiple defects
	 */
	@Test(priority = 6, enabled=true)
	public void Test6_moveCycle_cycle_with_single_or_multiple_with_defects_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
		// Set which cycle you want to move and which version
		// Set the cycleId which is linked to defects
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle with defects linked ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle with defects");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status1 = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");

		// Move cycle
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			}

	/**
	 * Cycle Api updateCycle Move cycle with same details as source cycle
	 */
	@Test(priority = 7, enabled=true)
	public void Test7_moveCycle_cycle_with_same_source_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		String Cyclename = " same details as source cycle";
		cycleJson.setName(Cyclename);
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		cycleJson.setId(Cycleid_to_move);
		// cycleJson.setDescription("Cycle moved from version -1");
		// Set version which we want move//versionFiveId
		Long move_to_version = Long.parseLong(Config.getValue("versionFourId"));
		cycleJson.setVersionId(move_to_version);
		String cycleId = Cycleid_to_move;

		// Move cycle
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Validating MoveCycle
		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle and modify details cycle details
	 */
	 @Test(priority = 8, enabled=true)
	public void Test8_moveCycle_cycle_with_modify_details() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		String Cyclename = " same details as source cycle";
		cycleJson.setName(Cyclename);
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		cycleJson.setId(Cycleid_to_move);
		// cycleJson.setDescription("Cycle moved from version -1");
		// Set version which we want move//versionFiveId
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);
		cycleJson.setName("modified" + Cyclename);
		cycleJson.setDescription(" modfied Cycle one desc");
		cycleJson.setBuild("modified build");
		cycleJson.setEnvironment("modified environment");

		String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
		
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle if source cycle has 50 schedules
	 */
	 @Test(priority = 9, enabled=false)
	public void Test9_moveCycle_cycle_50_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		//create cycle with 50 scheducles
		String Cyclename = "50_Executions";
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 50_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 50;

		// give cycle having 50 executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 50 executions
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		int offset = 0;
		int size = 50;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		// Set which cycle you want to move and which version
		// Set the cycleId which has 50 schedules
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle which is having 50 executions ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle with 50 executions");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);		
		
		
		// Get the execution count of cycle before move
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		// Move cycle
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

			}

	/**
	 * Cycle Api updateCycle Move cycle if source cycle has 500 schedules
	 */
	 @Test(priority = 10, enabled=false)
	public void Test10_moveCycle_cycle_500_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		//create cycle with 50 scheducles
		String Cyclename = "500_Executions";
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 50_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 500;

		// give cycle having 500 executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 50 executions
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		int offset = 0;
		int size = 500;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		// Set which cycle you want to move and which version
		// Set the cycleId which has 500 schedules
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle which is having 500 executions ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle with 500 executions");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);		
		
		
		// Get the execution count of cycle before move
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		// Move cycle
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

			}

	/**
	 * Cycle Api updateCycle Move cycle if source cycle has 1000 schedules
	 */
	@Test(priority = 11, enabled=false)
	public void Test11_moveCycle_cycle_1000_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		//create cycle with 1000 scheducles
		String Cyclename = "1000_Executions";
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 50_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 1000;

		// give cycle having 1000 executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 1000 executions
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		int offset = 0;
		int size = 1000;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		// Set which cycle you want to move and which version
		// Set the cycleId which has 500 schedules
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle which is having 1000 executions ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle with 1000 executions");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);		
		
		
		// Get the execution count of cycle before move
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		// Move cycle
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			}

	/**
	 * Cycle Api updateCycle Move cycle if source cycle has >5000 schedules
	 */
	@Test(priority = 12, enabled=false)
	public void Test12_moveCycle_cycle_greaterthan_5000_Execution() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		//create cycle with >5000 scheducles
		String Cyclename = ">5000_Executions";
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName(Cyclename);
		cycleJson.setDescription("Cloning 50_Executions");
		cycleJson.setName("CLONE-" + Cyclename);
		int numberOfExecutions = 5500;

		// give cycle having 1000 executions cycle id in place of Cycleid
		//String cycleId = "0001482926357416-242ac112-0001";
		//code for cycle with 5000 executions
		cycleJson.setName("CLONE-" + Cyclename);
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();
		System.err.println("cycle id " + cycleId);
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		int offset = 0;
		int size = 5500;
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		// Set which cycle you want to move and which version
		// Set the cycleId which has 500 schedules
		//String cycleId = "0001482927072336-242ac112-0001";
		cycleJson.setId(cycleId);
		cycleJson.setName("Moved Cycle which is having >5000 executions ");
		cycleJson.setProjectId(ProjectID);
		// Set Description
		cycleJson.setDescription("Cycle with >5000 executions");
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);		
		
		
		// Get the execution count of cycle before move
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		// Move cycle
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Move cycle if source cycle created in UI
	 */
	 @Test(priority = 13, enabled=true)
	public void Test13_moveCycle_cycle_created_in_UI() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionThreeId"));
		
		String Cyclename = Config.getValue("Cyclename1");
		String cycleId = Config.getValue("cyleId1");
		System.out.println(cycleId);
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName(Cyclename);
		
		// Set version which we want to move
		Long move_to_version = Long.parseLong(Config.getValue("versionFiveId"));
		cycleJson.setVersionId(move_to_version);

		// Get the execution count of cycle before move
		int offset = 0;
		int size = 10;
		Response responseGetExecutions = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutions, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String sourceCycle = responseGetExecutions.getBody().asString();
		System.out.println("Cycle before move " + sourceCycle);
		System.out.println(responseGetExecutions.getBody().asString());

		String beforeMoveExecutionCount = new JSONObject(responseGetExecutions.getBody().asString()).get("totalCount").toString();
		Integer beforeMoveExecutionNumbers = Integer.parseInt(beforeMoveExecutionCount);
		System.out.println("Total number of executions " + beforeMoveExecutionNumbers);
		boolean status = zapiService.validateGetExecutionsByCycle(responseGetExecutions, ProjectID, VersionID, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		// Move cycle
		Response response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		// Get executions of cycle after move
		Response responseGetExecutionsMovedCycle = zapiService.getExecutionsByCycle(jwtGenerator, ProjectID,
				move_to_version, cycleId, offset, size);
		Assert.assertNotNull(responseGetExecutionsMovedCycle, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		String movedCycle = responseGetExecutionsMovedCycle.getBody().asString();
		System.out.println("Cycle after move " + movedCycle);
		String afterMoveExecutionCount = new JSONObject(responseGetExecutionsMovedCycle.getBody().asString())
				.get("totalCount").toString();
		Integer afterMoveExecutionNumbers = Integer.parseInt(afterMoveExecutionCount);
		System.out.println("Total number of executions of moved cycle " + afterMoveExecutionNumbers);
		status = zapiService.validateGetExecutionsByCycle(responseGetExecutionsMovedCycle, ProjectID, VersionID,
				cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");

		Assert.assertTrue(afterMoveExecutionNumbers == beforeMoveExecutionNumbers);
		
		//Moving back the cycle to original version
		cycleJson.setVersionId(VersionID);
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());
		System.out.println("Moved back the cycle to original version to avoid other test case failure");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	// Attempt cases
	/**
	 * Cycle Api updateCycle Attempt to Move a deleted cycle
	 * Validation pending due to bug ZAPICLOUD-158
	 */
	@Test(priority = 14, enabled=true)
	public void Test14_Attempt_moveCycle_Delete_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle for move!!");
		cycleJson.setDescription("Cycle one desc");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		response = zapiService.deleteCycle(jwtGenerator, ProjectID, VersionID, Cycleid_to_move);
		cycleJson.setId(Cycleid_to_move);
		cycleJson.setDescription("Cycle moved from version -1");
		// Set version which we want move
		Long move_to_version = Long.parseLong(Config.getValue("versionFourId"));
		cycleJson.setVersionId(move_to_version);
		//String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
		
		response = zapiService.moveCycle(jwtGenerator, Cycleid_to_move, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

//		status = zapiService.validateInvalidCycleId(Cycleid_to_move, response);
//		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Attempt to move Cycle by Providing same Version as
	 * Source Cycle
	 * 
	 * UI Also its not supporting because it will update same details
	 */
	@Test(priority = 15, enabled=true)
	public void Test15_Attempt_moveCycle_same_version_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle for move!!");
		cycleJson.setDescription("Cycle one desc");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		cycleJson.setId(Cycleid_to_move);
		cycleJson.setVersionId(VersionID);
		String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
	
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Attempt to Move Cycle by removing project ID from
	 * Cycle Object before passing to Move Cycle
	 */
	@Test(priority = 16, enabled=true)
	public void Test16_Attempt_moveCycle_empty_projectid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle for move!!");
		cycleJson.setDescription("Cycle one desc");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		// Set which cycle you want to move and which version
		cycleJson.setId("0001478798400755-242ac1131-0001");
		cycleJson.setId(Cycleid_to_move);
		cycleJson.setDescription("Cycle moved from version -1");
		// Set version which we want move
		Long move_to_version = Long.parseLong(Config.getValue("versionFourId"));
		cycleJson.setVersionId(move_to_version);
		cycleJson.setProjectId(null);
		String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
		
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Attempt to Move Cycle by removing Version Id from
	 * Cycle Object before passing to Move Cycle
	 * Validation pending due to bug ZAPICLOUD-156
	 */
	@Test(priority = 17, enabled=true)
	public void Test17_Attempt_moveCycle_empty_versionid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Cycle for move!!");
		cycleJson.setDescription("Cycle one desc");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		// Set which cycle you want to move and which version
		cycleJson.setId("0001478798400755-242ac1131-0001");
		cycleJson.setId(Cycleid_to_move);
		cycleJson.setDescription("Cycle moved from version -1");
		// Set version which we want move
		cycleJson.setVersionId(null);
		String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
		
		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

//		status = zapiService.validateCycle(cycleJson.toString(), response);
//		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Cycle Api updateCycle Attempt to Move Cycle by removing Cycle name from
	 * Cycle Object before passing to Move Cycle
	 */
	@Test(priority = 18, enabled=true)
	public void Test18_moveCycle_empty_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Empty cycle name");
		cycleJson.setDescription("Cycle one desc");
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		String Cycleid_to_move = new JSONObject(response.getBody().asString()).get("id").toString();
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		cycleJson.setId(Cycleid_to_move);
		cycleJson.setDescription("Cycle moved from version -1");
		// Set version which we want move
		Long move_to_version = Long.parseLong(Config.getValue("versionFourId"));
		cycleJson.setVersionId(move_to_version);
		cycleJson.setName("");
		String cycleId = new JSONObject(cycleJson.toString()).get("id").toString();
		
		Response response1 = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response1, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response1.getBody().asString());

		status = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
