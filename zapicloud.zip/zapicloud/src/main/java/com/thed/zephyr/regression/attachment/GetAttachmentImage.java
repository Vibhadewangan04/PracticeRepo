package com.thed.zephyr.regression.attachment;


import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.cloud.rest.model.StepResult;
import com.thed.zephyr.cloud.rest.util.json.StepResultJsonParser;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

public class GetAttachmentImage extends BaseTest {
	
	String cycleId = null;
	String issueKey = null;
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution of png file type
	 */

	//@Test(priority = 1)
		public void getAttachmentImage_test1(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			test.assignAuthor("Debadatta");

			String entityName = "execution";
			String entityId = "0001480513561057-242ac1124-0001";
			Long projectId = 10200l;
			Long issueId = 10201l;
			String cycleId = "-1";
			Long versionId = -1l;
			String comment = "comment";
			String fileName = "attachment.png";
			
			Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
			Assert.assertNotNull(response, "Create stepResult Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
			Assert.assertTrue(status, "Not validated added attachment");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			
			String responseData = response.getBody().asString();
			JSONArray json = new JSONArray(responseData);
			
			JSONObject obj = new JSONObject(json.get(0).toString());
			String attachmentId = obj.get("id").toString();
			System.out.println("Created attachmentId is "+ attachmentId);

			response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution jpg file type attachmnet
	 */

	//@Test(priority = 2)
	public void getAttachmentImage_test2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "kan kala se.jpg";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution gif file type attachmnet
	 */

	//@Test(priority = 3)
	public void getAttachmentImage_test3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "tt.gif";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution tiff file type attachmnet
	 */

	//@Test(priority = 4)
	public void getAttachmentImage_test4(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "1234.tiff";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution bmp file type attachmnet
	 */

	//@Test(priority = 5)
	public void getAttachmentImage_test5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution in adhoc unscheduled
	 */

	//@Test(priority = 6)
	public void getAttachmentImage_test6(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution in non adhoc cycle unscheduled version
	 */

	//@Test(priority = 7)
	public void getAttachmentImage_test7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution in adhoc scheduled version
	 */

	//@Test(priority = 8)
	public void getAttachmentImage_test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for execution in non adhoc scheduled version
	 */

	//@Test(priority = 9)
	public void getAttachmentImage_test9(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "execution";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Attempt to get attachment image for execution by passing invalid attachmentId
	 */

	//@Test(priority = 10)
	public void getAttachmentImage_test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String attachmentId = "1234";

		Response response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult of png file type
	 */

	//@Test(priority = 11)
		public void getAttachmentImage_test11(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
			test.assignAuthor("Debadatta");

			String entityName = "stepResult";
			String entityId = "0001480513561347-242ac1124-0001";
			Long projectId = 10200l;
			Long issueId = 10201l;
			String cycleId = "-1";
			Long versionId = -1l;
			String comment = "comment";
			String fileName = "attachment.png";
			
			Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
			Assert.assertNotNull(response, "Create stepResult Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
			Assert.assertTrue(status, "Not validated added attachment");
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
			
			String responseData = response.getBody().asString();
			JSONArray json = new JSONArray(responseData);
			
			JSONObject obj = new JSONObject(json.get(0).toString());
			String attachmentId = obj.get("id").toString();
			System.out.println("Created attachmentId is "+ attachmentId);

			response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
			Assert.assertNotNull(response, "Create stepResult Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult jpg file type attachmnet
	 */

	//@Test(priority = 12)
	public void getAttachmentImage_test12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "kan kala se.jpg";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult gif file type attachmnet
	 */

	//@Test(priority = 13)
	public void getAttachmentImage_test13(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561693-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "tt.gif";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult tiff file type attachmnet
	 */

	//@Test(priority = 14)
	public void getAttachmentImage_test14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561693-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "1234.tiff";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult bmp file type attachmnet
	 */

	//@Test(priority = 15)
	public void getAttachmentImage_test15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult in adhoc unscheduled
	 */

	//@Test(priority = 16)
	public void getAttachmentImage_test16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult in non adhoc cycle unscheduled version
	 */

	//@Test(priority = 7)
	public void getAttachmentImage_test17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}
	
	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult in adhoc scheduled version
	 */

	//@Test(priority = 18)
	public void getAttachmentImage_test18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Get attachment image for stepResult in non adhoc scheduled version
	 */

	//@Test(priority = 19)
	public void getAttachmentImage_test19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");

		String entityName = "stepResult";
		String entityId = "0001480513561057-242ac1124-0001";
		Long projectId = 10200l;
		Long issueId = 10201l;
		String cycleId = "-1";
		Long versionId = -1l;
		String comment = "comment";
		String fileName = "report.bmp";
			
		Response response = zapiService.addAttachment(jwtGenerator, projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateAddedAttachment(projectId, versionId, issueId, cycleId, entityName, entityId, comment, fileName, response);
		Assert.assertTrue(status, "Not validated added attachment");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		String responseData = response.getBody().asString();
		JSONArray json = new JSONArray(responseData);
			
		JSONObject obj = new JSONObject(json.get(0).toString());
		String attachmentId = obj.get("id").toString();
		System.out.println("Created attachmentId is "+ attachmentId);

		response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}

	/**
	 * Created by debadatta.kathar on 01-Dec-2016
	 * Attempt to get attachment image for stepResult by passing invalid attachmentId
	 */

	//@Test(priority = 20)
	public void getAttachmentImage_test20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String attachmentId = "0001480596056446-24-0001";

		Response response = zapiService.getAttachmentImage(jwtGenerator, attachmentId);
		Assert.assertNotNull(response, "Create stepResult Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");			
		}	
	

}
