package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

public interface FolderApi {
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createfolder(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */

	Response Getfolderbyid(JwtGenerator jwtGenerator, String payLoad,String Folderid);
	
	Response getFolders(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId);

}
