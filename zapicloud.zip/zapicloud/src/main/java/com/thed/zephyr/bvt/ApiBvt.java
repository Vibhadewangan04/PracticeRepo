package com.thed.zephyr.bvt;


import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class ApiBvt extends BaseTest {
	String cycleId = null;
	Long issueId = null;
	String teststepId = null;

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		System.out.println("into bfore class");
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("accountId"));
	}

	/**
	 * Get the General Config Info
	 * 
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	@Test(priority = 3, enabled = testEnabled)
	public void bvt3_getGeneralConfigInfo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getGeneralConfigInfo(jwtGenerator);
		Assert.assertNotNull(response, "Get the General Config Info response is null.");
		test.log(LogStatus.PASS, "Get the General Config Info Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean generalConfigInfoStatus = zapiService.validateGeneralConfigInfo(response);
		Assert.assertTrue(generalConfigInfoStatus, "Get the General Config Info Api validation failed.");
		test.log(LogStatus.PASS, "Get the General Config Info Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get the ServerInfo
	 * 
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	@Test(priority = 4, enabled = testEnabled)
	public void bvt4_getServerInfo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getServerInfo(jwtGenerator);
		Assert.assertNotNull(response, "Get  the ServerInfo Api Response is null.");
		test.log(LogStatus.PASS, "Get  the ServerInfo Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean serverInfoStatus = zapiService.validateServerInfo(response);
		Assert.assertTrue(serverInfoStatus, "Get  the ServerInfo Api validation failed.");
		test.log(LogStatus.PASS, "Get the ServerInfo Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * creating teststep
	 */
	@Test(priority = 5, enabled = testEnabled)
	public void bvt5_createTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		// Long issueId = 10206l;
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		test.log(LogStatus.PASS, "Create Teststep Api executed successfully.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
				teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");
		test.log(LogStatus.PASS, "Create Teststep Api Response validated suuccessfully.");

		teststepId = new JSONObject(createTeststepResponse.body().asString()).getString("id");
		extentReport.endTest(test);
	}
	/**
	 * Get a teststep
	 * 
	 */
	@Test(priority = 6, enabled = testEnabled, dependsOnMethods = { "bvt5_createTeststep" })
	public void bvy6_getTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueId = this.issueId;
		String stepId = this.teststepId;
//		Long issueId = 10104l;
//		String stepId = "0001481023338301-242ac112-0001";
		Response response = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get teststeps
	 * 
	 */
	@Test(priority = 7, enabled = testEnabled)
	public void bvt7_getTeststeps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueId = this.issueId;
		Response response = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update a teststep
	 * 
	 */
	@Test(priority = 8, enabled = testEnabled, dependsOnMethods = { "bvt5_createTeststep" })
	public void bvt8_updateTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		// Long issueId = 10206l;
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("updated step");
		teststepJson.setData("updated data");
		teststepJson.setResult("updated result");
		teststepJson.setId(this.teststepId);
		Long issueId = this.issueId;
		String stepId = this.teststepId;
		System.out.println(teststepJson.toString());
		Response response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId,
				teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * clone teststep -1 - clone after , 0 - before, -2 - last step, position -
	 * position need to give
	 */
	 @Test(priority = 9, enabled = testEnabled, dependsOnMethods = { "bvt5_createTeststep" })
	public void bvt9_cloneTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long issueId = this.issueId;
		String stepId = this.teststepId;
		String payLoad = "{\"step\":\"steps updated\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"-1\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Deleting a teststep
	 */
	@Test(priority = 11, enabled = testEnabled, dependsOnMethods = { "bvt5_createTeststep" })
	public void bvt11_deleteTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		// Long issueId = 10000l;
		String stepId = teststepId;
		Response response = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	@Test(priority = 12, enabled = testEnabled)
	public void bvt12_getTeststepStatuses() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getTeststepStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Create a new cycle under planned version, with all fields filled. Create
	 * a Cycle
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void bvt13_createCycle_with_Allfeilds() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		cycleJson.setName("bvt2_createCycle_with_Allfeilds");
		cycleJson.setDescription("Cycle one desc");
		cycleJson.setBuild("build");
		cycleJson.setEnvironment("environment");
		cycleJson.setStartDate("2016-11-20");
		cycleJson.setEndDate("2016-11-25");// yyyy-mm-dd

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		cycleId = new JSONObject(response.body().asString()).get("id").toString();
		extentReport.endTest(test);
	}

	/**
	 * Fetch the Created Cycle by CycleId (need to create cycle manually and
	 * pass cycle id in below method)
	 * 
	 */
	@Test(priority = 32, enabled = testEnabled)
	public void bvt32_getCycle_by_cycleid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));
		// String cycleId = "0001479724041422-242ac111e-0001";

		Response response = zapiService.getCycle(jwtGenerator, projectId, versionId, cycleId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, " Get Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

	//	boolean status = zapiService.validateCycle(projectId, versionId, cycleId, response);
	/*//	boolean status = zapiService.validateCycle(cycleId, response);
		Assert.assertTrue(status, "Get cycle response not validated.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);*/
	}

	/**
	 * Fetch the List of Cycles from a single version.
	 */
	@Test(priority = 33, enabled = testEnabled)
	public void bvt33_getCycles() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionTwoId"));

		Response response = zapiService.getCycles(jwtGenerator, projectId, versionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetCycles(projectId, versionId, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "getCycles Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update a Cycle Update the Cycle by changing names and dates
	 */
	@Test(priority = 34, enabled = testEnabled)
	public void bvt34_updateCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// Create Cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("test1_createCycle_with_Allfeilds");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		System.out.println(response.getBody().asString());

		// Add data for update cycle
		cycleJson.setName("Updated Cycle Name");
		cycleJson.setDescription("Changing cycle name updated cycle to Cycle updated");
		cycleJson.setId(new JSONObject(response.body().asString()).get("id").toString());
		cycleJson.setStartDate("2016-11-20");
		cycleJson.setEndDate("2016-11-25");

		response = zapiService.updateCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Update Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateUpdateCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Update Cycle Api Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 35, enabled = testEnabled)
	public void bvt35_moveCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("test1_createCycle_with_Allfeilds");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		System.out.println(response.getBody().asString());

		// Add data for update cycle
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionThreeId")));
		cycleJson.setId(new JSONObject(response.body().asString()).get("id").toString());

		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Move Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateUpdateCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Should able to Clone partially executed planned Cycle
	 */
	@Test(priority = 36, enabled = testEnabled)
	public void bvt36_cloneCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("clone cycle for bvt");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		System.out.println(response.getBody().asString());

		// Add data for update cycle
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionThreeId")));
		cycleJson.setId(new JSONObject(response.body().asString()).get("id").toString());

		response = zapiService.moveCycle(jwtGenerator, cycleId, cycleJson.toString());
		Assert.assertNotNull(response, "Move Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		status = zapiService.validateUpdateCycle(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Should able to Export and download Cycle to HTML Format
	 */
//	@Test(priority = 8, enabled = testEnabled)
	public void bvt8_exportCycle_HTML_format() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "-1";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Should able to Export and download Cycle to csv Format
	 */
//	@Test(priority = 9, enabled = testEnabled)
	public void bvt9_exportCycle_CSV_format() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "-1";
		String exportType = "HTML";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Should able to Delete partially executed planned Cycle
	 */
	@Test(priority = 39, enabled = testEnabled)
	public void bvt39_deleteCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));
		cycleJson.setName("Create cycle for delete");

		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");

		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		System.out.println(response.getBody().asString());

		// delete cycle
		String cycleId = new JSONObject(response.body().asString()).get("id").toString();

		response = zapiService.deleteCycle(jwtGenerator, Long.parseLong(Config.getValue("projectId")),
				Long.parseLong(Config.getValue("versionTwoId")), cycleId);
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Delete Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

		status = zapiService.validateDeletedCycle(Long.parseLong(Config.getValue("projectId")),
				Long.parseLong(Config.getValue("versionTwoId")), cycleId, response);
		Assert.assertTrue(status, "Response Validation Failed.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * copy Executions to cycle Bulk Copy test executions with status and
	 * defects carried over
	 */
//	@Test(priority = 11, enabled = testEnabled)
	public void bvt11_copyExecutionsToCycle_with_status_and_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":false,\"clearStatusFlag\":false}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";

		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Copy Execution to Cycle Api executed successfully.");
		System.out.println("Job progressId  = " + response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println("Response : " + response.getBody().asString());
		Assert.assertNotNull(response, "Copy Execution to Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Copy Execution to Cycle Api executed successfully.");

		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Copy Execution to Cycle Api not validation failed.");
		test.log(LogStatus.PASS, "Copy Execution to Cycle Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * copy Executions to cycle Bulk Copy test executions to a different Cycle -
	 * by clearing statuses and carry defects
	 */
//	@Test(priority = 12, enabled = testEnabled)
	public void bvt12_copyExecutionsToCycle_byclearning_status_and_carrying_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":false,\"clearStatusFlag\":true}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "copy Executions to cycle Api Response is null.");
		test.log(LogStatus.PASS, "Copy Executions to Cycle Api executed successfully.");
		System.out.println("Job progressId  = " + response.getBody().asString());
		response = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		System.out.println("Response : " + response.getBody().asString());
		Assert.assertNotNull(response, "Copy Execution to Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Copy Execution to Cycle Api executed successfully.");

		boolean status = zapiService.validateCopyExecutionsToCycle(response);
		Assert.assertTrue(status, "Copy Execution to Cycle Api not validation failed.");
		test.log(LogStatus.PASS, "Copy Execution to Cycle Api validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * copy Executions to cycle Bulk Copy test executions to a different Cycle -
	 * by clearing defects and carry statuses
	 */
	// @Test(priority = 10)
	public void Test10_copyExecutionsTo_different_Cycle_byclearning_status_and_carry_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// we have give different cycle id below
		// url:0001479100186625-242ac1133-0001
		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * copy Executions to cycle Bulk Copy test executions to a different Cycle -
	 * by clearing defects and statuses
	 */
	// @Test(priority = 11)
	public void Test11_copyExecutionsTo_different_Cycle_byclearning_status_and_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		// we have give different cycle id below
		// url:0001479100186625-242ac1133-0001
		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":true,\"clearStatusFlag\":true}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.copyExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	// -------------------------------------------------------------------------------

	/**
	 * move Executions to cycle 12.Bulk Move test executions with defects and
	 * status carried
	 */
	// @Test(priority = 12)
	public void Test12_moveExecutionsToCycle_withdefects_and_status_carried() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":false,\"clearStatusFlag\":false}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * move Executions to cycle 13.Bulk Move test executions to a different
	 * Cycle - by clearing statuses and carry defects
	 */

	// @Test(priority =13)
	public void Test13_moveExecutionsToCycle_by_clearing_status_and_carry_defects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":false,\"clearStatusFlag\":}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * move Executions to cycle 14.Bulk Move test executions to a different
	 * Cycle - by clearing defects and carry statuses
	 */
	// @Test(priority = 14)
	public void Test14_moveExecutionsToCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":true,\"clearStatusFlag\":false}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * move Executions to cycle 15.Bulk Move test executions to a different
	 * Cycle - by clearing defects and statuses
	 * 
	 */

	// @Test(priority = 15)
	public void Test15_moveExecutionsToCycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479100186625-242ac1133-0001\"],\"projectId\":10001,\"versionId\":-1,\"clearDefectMappingFlag\":true,\"clearStatusFlag\":true}";
		System.out.println(payLoad);
		String cycleId = "0001478862534005-242ac1132-0001";
		Response response = zapiService.moveExecutionsToCycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * create execution 16.Create Execution in an adhoc cycle, in unscheduled
	 * version of the project
	 */
	// @Test(priority = 16)
	public void test16_createExecution_unscheduled_version_adhoc_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(1l);
		executionJson.setProjectId(10000l);
		executionJson.setIssueId(60688l);
		executionJson.setVersionId(10001l);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
	//	boolean status = zapiService.validateCreatedExecution(executionJson.toString(), response);
	//	Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * create execution 17.Create Execution in an non-adhoc cycle, in scheduled
	 * version of the project
	 */
	// @Test(priority = 17)
	public void test17_createExecution_non_adhoc_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Execution executionJson = new Execution();
		executionJson.setStatusId(2l);
		executionJson.setProjectId(10000l);
		executionJson.setIssueId(10000l);
		executionJson.setVersionId(10001l);

		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateCreatedExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * 18.Update Execution to Default Status 19.Update Execution to Customized
	 * Status 20.Update Execution link New Defect 21.Update Execution to link
	 * multiple existing Defect 22.Update Execution and add comment 23.Update
	 * Execution and Modify comment 24.Update Execution change status from old
	 * to new status, link existing defect and comment
	 */

	/**
	 * create execution 25.Delete an Execution using â€œdeleteExecutionâ€� Api
	 */

	// @Test(priority = 25)
	public void Test25_deleteExecution_by_Execution_id() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long issueId = 10000l;
		// String Executionid="0001478799352819-242ac1131-0001";
		Response response = zapiService.deleteExecution(jwtGenerator, issueId, "0001478799352819-242ac1131-0001");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * create execution 26.Get Execution by cycle id of adhoc cycle, in
	 * unscheduled version of the project
	 */

	// @Test(priority = 26)
	public void getExecutionsByCycle_Adhoc_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = 10000l;
		Long versionId = -1l;
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, "-1", 0, 10);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * create execution Get Execution by cycle id of non-adhoc cycle, in
	 * scheduled version of the project
	 */

	// @Test(priority = 27)
	public void getExecutionsByCycle_Non_Adhoc_cycle() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = 10000l;
		Long versionId = -1l;
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId,
				"0001478768964952-242ac1131-0001", 0, 10);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Get Executions By cycle Get Execution by cycle id of adhoc cycle, in
	 * unscheduled version of the project
	 */

	/*
	 * @Test(priority = 28) public void Test28_getExecutionsByCycle(){
	 * ExtentTest test =
	 * extentReport.startTest(Thread.currentThread().getStackTrace()[1].
	 * getMethodName()); test.assignCategory(
	 * "Automation API BVT Suite - ZFJCLOUD"); test.assignAuthor("Manoj"); Long
	 * projectId = 10000l; Long versionId = -1l; Response response =
	 * zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId,
	 * "0001478862534005-242ac1132-0001", 0, 10); Assert.assertNotNull(response,
	 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
	 * "Update Cycle Api executed successfully.");
	 * System.out.println(response.getBody().asString());
	 * 
	 * test.log(LogStatus.PASS, "Response validated suuccessfully.");
	 * extentReport.endTest(test); }
	 *//**
		 * Get Executions By cycle Get Execution by cycle id of non-adhoc cycle,
		 * in scheduled version of the project
		 *//*
		 * 
		 * //@Test(priority = 29) public void Test29_getExecutionsByCycle(){
		 * ExtentTest test =
		 * extentReport.startTest(Thread.currentThread().getStackTrace()[1].
		 * getMethodName()); test.assignCategory(
		 * "Automation API BVT Suite - ZFJCLOUD"); test.assignAuthor("Manoj");
		 * Long projectId = 10000l; Long versionId = -1l; Response response =
		 * zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId,
		 * "0001478862534005-242ac1132-0001", 0, 10);
		 * Assert.assertNotNull(response,
		 * "Create Execution Api Response is null."); test.log(LogStatus.PASS,
		 * "Update Cycle Api executed successfully.");
		 * System.out.println(response.getBody().asString());
		 * 
		 * test.log(LogStatus.PASS, "Response validated suuccessfully.");
		 * extentReport.endTest(test); }
		 */

	/*
	 * 30.Add Multiple tests by issueids to planned Cycle 31.Add Tests to a
	 * Cycle from another Cycle 32.Add Tests to a Cycle by using Jira
	 * Filter(JQL)
	 */

	/**
	 * Export Executions Export test executions in CSV format
	 */

	// @Test(priority = 33)
	public void Test_33_exportExecutions_into_CSV() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		Response response = zapiService.exportCycle(jwtGenerator, projectId, versionId, cycleId, exportType);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadCycleExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Export Executions Export test executions in HTML format
	 */

	// @Test(priority = 34)
	public void Test_34_exportExecutions_into_HTML() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long versionId = -1l;
		String cycleId = "0001479189557520-242ac1134-0001";
		String exportType = "CSV";
		String payLoad = "{\"exportType\":\"xml\",\"expand\":\"teststeps\",\"executions\":[],\"startIndex\":0,\"maxAllowed\":true,\"zqlQuery\":\"project = IE\"}";
		// â€‚â€‚â€‚â€‚String payLoad =
		// "{\"exportType\":\"html\",\"expand\":\"teststeps\",\"executions\":[],\"startIndex\":0,\"maxAllowed\":true,\"zqlQuery\":\"project
		// = \"IE\" AND fixVersion = \"Unscheduled\" AND cycleName = \"cycle
		// update\"\"}";
		Response response = zapiService.exportExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		Response jobProgressResponse = zapiService.jobProgressHandler(jwtGenerator, response.getBody().asString());
		String fileName = new JSONObject(jobProgressResponse.getBody().asString()).get("summaryMessage").toString();

		boolean status = zapiService.downloadExecutionsExportedFile(jwtGenerator, fileName);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Executions by issueid getExecutionByIssueId/Get Execution by issue id
	 * need to clarify with respective person
	 */
	// @Test(priority = 35)
	public void Test35_getExecutionsByIssue_by_issuekey() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String issueIdOrKey = "10000";
		int offset = 0;
		int size = 30;
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOrKey, offset, size);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Executions by issueid 36.Fetch executions by issueKey
	 */
	// @Test(priority = 36)
	public void Test36_getExecutionsByIssue_by_issueid() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String issueIdOrKey = "IE-1";
		int offset = 0;
		int size = 30;
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOrKey, offset, size);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Get Executions by issueKey 37.getExecutionById/Fetch executions by
	 * issueId
	 */
	// @Test(priority = 37)
	public void Test37_getExecutionsByIssue() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		String issueIdOrKey = "10000";
		int offset = 0;
		int size = 111111;
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOrKey, offset, size);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update Executions 38.Bulk Update Status of test executions
	 */

	// @Test(priority = 38)
	public void Test_38_updateBulkStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479189122203-242ac1134-0001\",\"0001479189123203-242ac1134-0001\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":false,\"stepStatus\":2}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Update Executions 39.Bulk Update Status of test executions including
	 * Steps
	 */

	// @Test(priority = 39)
	public void Test_39_updateBulkStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479189122203-242ac1134-0001\",\"0001479189123203-242ac1134-0001\"],\"status\":2,\"clearDefectMappingFlag\":false,\"testStepStatusChangeFlag\":true,\"stepStatus\":2}";
		System.out.println(payLoad);
		Response response = zapiService.updateBulkStatus(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Assignee Executions 40.Assignee bulk executions
	 */
	// @Test(priority = 40)
	public void Test40_assignBulkExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479228127201-242ac1135-0001\",\"0001478768982671-242ac1131-0001\"],\"assigneeType\":\"assignee\",\"assignee\":\"admin\"}";
		System.out.println(payLoad);
		Response response = zapiService.assignBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Bulk Delete Executions Bulk delete executions of non-adhoc cycle, in
	 * scheduled version of the project
	 */
	// @Test(priority = 41)
	public void Test41_deleteBulkExecutions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"executions\":[\"0001479123858871-242ac1134-0001\",\"0001479123804740-242ac1134-0001\",\"0001479123763535-242ac1134-0001\",\"0001479125359956-242ac1134-0001\"]}";
		System.out.println(payLoad);
		Response response = zapiService.deleteBulkExecutions(jwtGenerator, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/*
	 * 42.get the created execution 43.get executions by zql
	 */

	// 44.Create one test step for given issueid and project by using
	// AddjsonSteps Api
	@Test(priority = 44)
	public void test44_createTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		Teststep teststepJson = new Teststep();
		teststepJson.setNoOfTeststeps(5);

		Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// 45.Get a particular test step for the given issueid by using GetJsonStep
	// Api
	@Test(priority = 45)
	public void Test45_getTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001478768938625-242ac1131-0001";
		Response response = zapiService.getTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// 46.Get all test steps for the given issueid by using GetJsonStep Api
	// @Test(priority = 46)
	public void Test46_getTeststeps() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		Response response = zapiService.getTeststeps(jwtGenerator, projectId, issueId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/*
	 * 
	 * 
	 * 47.Update Test Step by using UpdateJsonSteps Api
	 */
	// @Test(priority = 47)
	public void Test47_updateTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001478768938625-242ac1131-0001";
		String payLoad = "{\"id\":\"0001478768938625-242ac1131-0001\",\"step\":\"updated step\",\"data\":\"updated data\",\"result\":\"updated res\"}";
		System.out.println(payLoad);
		Response response = zapiService.updateTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// 48.Clone a test step at any given position by using CloneTestStep
	@Test(priority = 48)
	public void Test48_cloneTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001479672301761-242ac111e-0001";
		String payLoad = "{\"step\":\"steps\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"8\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// 49.Clone a test step as last step, by using CloneTestStep
	@Test(priority = 49)
	public void Test49_cloneTeststep_as_laststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001479672301761-242ac111e-0001";
		String payLoad = "{\"step\":\"step\",\"data\":\"datas\",\"result\":\"results\",\"position\":\"-2\"}";
		System.out.println(payLoad);
		Response response = zapiService.cloneTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Delete teststep Delete a test step by using deleteTestStep Api
	 */
	// @Test(priority = 50)
	public void Test50_deleteTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001478812190393-242ac1131-0001";
		Response response = zapiService.deleteTeststep(jwtGenerator, projectId, issueId, stepId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * Move Test step 45.Rearrange test step by using moveTestStep Api
	 */
	// @Test(priority = 51)
	public void Test51_moveTeststep() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		Long projectId = 10000l;
		Long issueId = 10000l;
		String stepId = "0001478813360753-242ac1131-0001";
		String payLoad = "{\"before\":\"/connect/public/rest/api/1.0/teststep/10000/0001478812559392-242ac1131-0001?projectId=10000\"}";
		System.out.println(payLoad);
		Response response = zapiService.moveTeststep(jwtGenerator, projectId, issueId, stepId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * getTeststepStatuses 46.Get Test Step status by using getTeststepStatuses
	 * Api
	 */

	// @Test(priority = 52)
	public void Test_52_getTeststepStatuses() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response response = zapiService.getTeststepStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * StepResult Api 47.Get step result of an execution by providing
	 * stepresultId using â€œgetStepResultâ€� Api
	 */
	// @Test(priority = 53)
	public void Test53_getStepResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String executionId = "0001479331535002-242ac1139-0001";
		String stepResultId = "0001479331535243-242ac1139-0001";
		Response response = zapiService.getStepResult(jwtGenerator, executionId, stepResultId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateStepResult(stepResultId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * StepResult Api 48.Get step results of a test step/execution by using
	 * getStepResults Api
	 */

	// @Test(priority = 54)
	public void test_54_getStepResults() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		String executionId = "0001479403864785-242ac113a-0001";
		Long issueId = 10000l;
		Response response = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * updateStepResult 55.Update the step result with status to default status
	 * /** updateStepResult 56.Get step results of a test step/execution by
	 * using getStepResults Api 57.Update the step result with status to custom
	 * status 58.Update the step result with new defects associated 59.Update
	 * the step result with old defects associated 60.Update the step result
	 * with comments associated 61.Update the step result with status, comment
	 * and defect associated
	 */

	// @Test(priority = 62)
	public void Test62_updateStepResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		String stepResultId = "0001479331535243-242ac1139-0001";
		Stepresult stepresultJson = new Stepresult();
		stepresultJson.setExecutionId("0001479331535002-242ac1139-0001");
		stepresultJson.setStepId("0001478796469006-242ac1131-0001");
		stepresultJson.setIssueId(10000l);
		stepresultJson.setStatus(3);
		stepresultJson.setComment("comments");
		List<Long> list = new ArrayList<>();
		list.add(10206l);
		stepresultJson.setDefects(list);
		Response response = zapiService.updateStepResult(jwtGenerator, stepResultId, stepresultJson.toString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateUpdatedStepResult(projectId, stepResultId, stepresultJson.toString(),
				response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * StepResult Api 63.get the step defects id using
	 * â€œgetStepDefectsByExecutionIdâ€� Api
	 */

	// @Test(priority = 63)
	public void Test63_getStepDefectsByExecutionId() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Long projectId = 10000l;
		String executionId = "0001478875753996-242ac1132-0001";
		Response response = zapiService.getStepDefectsByExecutionId(jwtGenerator, projectId, executionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepDefectsByExecutionId(projectId, executionId, response);
		Assert.assertTrue(status);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	/**
	 * StepResult Api 64.get the step results by status using
	 * â€œgetStepResultByStatusâ€� Api
	 */

	// @Test(priority = 64)
	public void Test64_getStepResultByStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		int statusId = 1;
		int offset = 0;
		int maxResults = 10;
		Response response = zapiService.getStepResultByStatus(jwtGenerator, statusId, offset, maxResults);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetStepResultByStatus(response);
		Assert.assertTrue(status);

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// ====
	// 65.Get the zql filter using â€œgetFilterâ€� Api
	// @Test(priority = 65)
	public void getZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"zql\":\"project = IE\",\"name\":\"api filter 1231\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		System.out.println(payLoad);
		Response response = zapiService.getZQLFilter(jwtGenerator, "0001478855466716-242ac1132-0001");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// 66.Search the zql filter by providing name using â€œsearchâ€� Api
//	@Test(priority = 66)
	public void searchZqlFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String payLoad = "{\"zql\":\"project = IE\",\"name\":\"api filter 1231\",\"description\":\"\",\"favorite\":true,\"sharePerm\":\"global\"}";
		System.out.println(payLoad);
		// Response response = zapiService.searchZQLFilter(jwtGenerator, "v1");
		// Assert.assertNotNull(response, "Create Execution Api Response is
		// null.");
		// test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		// System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	// Update the zql Filter using the â€œupdateFilterâ€� Api
//	@Test(priority = 67)
	public void updateFilter() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String filterId = "0001479409306195-242ac113a-0001";
		String payLoad = "{\"favorite\":true,\"id\":\"0001479409306195-242ac113a-0001\",\"description\":\"\",\"name\":\"sd42\",\"sharePerm\":\"global\",\"zql\":\"project = IE\"}";
		Response response = zapiService.updateFilter(jwtGenerator, filterId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/*@Test(priority = 68)
	public void createfolder() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		
		String Payload2= "{\"name\":\"Test123\",\"description\":\"\",\"cycleId\":\"0001510576270764-242ac112-0001\",\"versionId\":-1,\"projectId\":10000}";
		
		String payLoad = "{\"favorite\":true,\"id\":\"0001479409306195-242ac113a-0001\",\"description\":\"\",\"name\":\"sd42\",\"sharePerm\":\"global\",\"zql\":\"project = IE\"}";
		Response response = zapiService.createFolderCycle(jwtGenerator, Payload2);
		System.out.println(response.getBody().toString());
		
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}*/
	
	

}
