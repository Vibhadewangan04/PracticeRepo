/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira.impl;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.api.jira.ProjectApi;
import com.thed.zephyr.api.jira.VersionApi;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
@Service("versionApi")
public class VersionApiImpl implements VersionApi {
	@Override
	public Response createVersion(RequestSpecification basicAuth, String versionPayLoad) {
		String api = "/rest/api/2/version";
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).body(versionPayLoad).when().post(api);
	}

	@Override
	public Response getVersion(RequestSpecification basicAuth, String versionId) {
		String api = "/rest/api/2/version/" + versionId;
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).when().get(api);
	}
	@Override
	public Response deleteVersion(RequestSpecification basicAuth, String versionId, String moveFixIssuesTo, String moveAffectedIssuesTo) {
		String api = "/rest/api/2/version/" + versionId;
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		return basicAuth.headers(headers).queryParam("moveAffectedIssuesTo", moveAffectedIssuesTo).queryParam("moveFixIssuesTo", moveFixIssuesTo).when().get(api);
	}
}
