/**
 *
 */
package com.thed.zephyr.model;

import java.util.Arrays;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * @author Praveenkumar
 *
 */
public class ExportTraceability {

	private String exportType;
	private String[] defectIdList;
	private String[] requirementIdList;
	private Long versionId;

	public void setExportType(String exportType) {
		this.exportType = exportType;
	}

	public void setDefectIdList(String[] defectIdList) {
		this.defectIdList = defectIdList;
	}

	public void setRequirementIdList(String[] requirementIdList) {
		this.requirementIdList = requirementIdList;
	}

	public void setVersionId(Long versionId) {
		this.versionId = versionId;
	}

	@Override
	public String toString() {
		JSONObject exportJson = new JSONObject();
		exportJson.put("exportType", this.exportType);
		if ((this.defectIdList != null)) {
			exportJson.put("defectIdList",new JSONArray(Arrays.asList(this.defectIdList)));
		}
		if ((this.requirementIdList != null)) {
			exportJson.put("requirementIdList",new JSONArray(Arrays.asList(this.requirementIdList)));
		}
		exportJson.put("versionId", this.versionId);
		return exportJson.toString();
	}

}
