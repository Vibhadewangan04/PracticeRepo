// TestStepAPi implementation


/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.json.JSONObject;
import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.TeststepApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;


import static com.jayway.restassured.RestAssured.given;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("teststepApi")
public class TeststepApiImpl implements TeststepApi {

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#createTeststep(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String payLoad) {
//		String projectId=new JSONObject(payLoad).get("projectId").toString();
//		String issueId=new JSONObject(payLoad).get("issueId").toString();
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId;
		//URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		
		URI uri;
		if(projectId==null)
		{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", "").build();
		}
		else {
			 uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}
		
		
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	/*public Response createTeststepf(JwtGenerator jwtGenerator, String projectId, String issueId, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		int expirationInSec = 3600;
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}*/

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#updateTeststep(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response updateTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId,
			String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId+"/"+teststepId;
		//URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		URI uri;
		if(projectId==null){
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", "").build();
		}
		else
		{
			 uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}
		
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().put(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#cloneTeststep(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response cloneTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId,
			String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId+"/clone/"+teststepId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).when().post(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#deleteTeststep(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId+"/"+teststepId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("DELETE", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).delete(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#moveTeststep(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response moveTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId,
			String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId+"/"+teststepId+"/move";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#getTeststep(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getTeststep(JwtGenerator jwtGenerator, Long projectId, Long issueId, String teststepId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId+"/"+teststepId;
		URI uri;
		if(projectId==null)
		{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", "").build();
		}
		else {
			 uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}
		
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#getTeststeps(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getTeststeps(JwtGenerator jwtGenerator, Long projectId, Long issueId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/"+issueId;
		//URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		URI uri;
		if(projectId==null)
		{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", "").build();
		}
		else {
			 uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}
		
		
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.TeststepApi#getTeststepStatuses(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getTeststepStatuses(JwtGenerator jwtGenerator) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/teststep/statuses";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}

}
