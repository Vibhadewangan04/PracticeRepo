/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.regression.zql;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
public class GetZQLAutoComplete extends BaseTest{
	JwtGenerator jwtGenerator = null;

	/**
	 * Auto complete Api is not available for executionDate, creationDate and issue
	 * 
	 * @author Created by manoj.behera on 05-Dec-2016.
	 */
	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	@Test(priority = 1)
	public void getZQLAutoComplete1() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "project";
		String fieldValue = "i";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 2)
	public void getZQLAutoComplete2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "priority";
		String fieldValue = "High";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 3)
	public void getZQLAutoComplete3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "cycleName";
		String fieldValue = "cycle";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 4)
	public void getZQLAutoComplete4() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "cycleName";
		String fieldValue = "Ad";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 5)
	public void getZQLAutoComplete5() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "executionStatus";
		String fieldValue = "Pass";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 6)
	public void getZQLAutoComplete6() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "fixVersion";
		String fieldValue = "v";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 7)
	public void getZQLAutoComplete7() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "executedBy";
		String fieldValue = "admin";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 8)
	public void getZQLAutoComplete8() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "component";
		String fieldValue = "c";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	@Test(priority = 9)
	public void getZQLAutoComplete9() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		String fieldName = "assignee";
		String fieldValue = "ad";
		Response response = zapiService.getZQLAutoComplete(jwtGenerator, fieldName, fieldValue);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLAutoComplete(fieldValue, response);
		Assert.assertTrue(status, "Response not validated");
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
}
