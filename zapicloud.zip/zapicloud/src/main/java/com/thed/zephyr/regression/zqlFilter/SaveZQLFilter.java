package com.thed.zephyr.regression.zqlFilter;


import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Zqlfilter;
import com.thed.zephyr.util.RestUtils;

public class SaveZQLFilter extends BaseTest {

	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
/**
 * Test case - 1
 * create ZQL filter: "Zql":"project = projectName"
 */
//create ZQL filter: "Zql":"project = IE"
@Test(priority = 1)
	public void test1_createZqlFilter_by_project_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project = "+Config.getValue("projectKey"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

/**
 * Test case - 2
 * create ZQL filter: "Zql":"project != projectName"
 */
@Test(priority = 2)
	public void test2_createZqlFilter_by_project_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project != "+Config.getValue("projectKey"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	
	}
/**
 * Test case - 3
 * create ZQL filter: "Zql":"project is not Empty"
 */

// create ZQL filter: "Zql":"project is not Empty"
@Test(priority = 3)
	public void test3_createZqlFilter_by_project_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is not EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	
	}
/**
 * Test case - 4
 * create ZQL filter: "Zql":"project is EMPTY"
 */
// create ZQL filter: "Zql":"project is Empty"
@Test(priority = 4)
	public void test4_createZqlFilter_by_project_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
}
/**
 * Test case - 5
 * create ZQL filter: "Zql":"project not in (projectkey,projectkey1)"
 */

// create ZQL filter: "Zql":"project not in (IE,Rock)"
@Test(priority = 5)
	public void test5_createZqlFilter_by_project_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project not in"+ "("+Config.getValue("projectKey")+","+Config.getValue("projectKey1")+")");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 6
 * create ZQL filter: "Zql":"project in (projectkey,projectkey1)"
 */

// create ZQL filter: "Zql":"project in (IE,Rock,RUBY)"
@Test(priority = 6)
	public void test6_createZqlFilter_by_project_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project in"+ "("+Config.getValue("projectKey")+","+Config.getValue("projectKey1")+")");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 7
 * create ZQL filter: "Zql":"priority = Highest"
 */

// create ZQL filter: "Zql":"priority = Highest"
@Test(priority = 7)
	public void test7_createZqlFilter_by_priority_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority = Highest");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 8
 * create ZQL filter: "Zql":"priority != Medium"
 */

// create ZQL filter: "Zql":"priority != Medium"
@Test(priority = 8)
	public void test8_createZqlFilter_by_priority_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority != Medium");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 9
 * create ZQL filter: "Zql":"priority is not EMPTY"
 */
// create ZQL filter: "Zql":"priority is not Empty"
@Test(priority = 9)
	public void test9_createZqlFilter_by_priority_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority is not EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 10
 * create ZQL filter: "Zql":"priority is EMPTY"
 */

// create ZQL filter: "Zql":"priority is Empty"
@Test(priority = 10)
	public void test10_createZqlFilter_by_priority_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 11
 * create ZQL filter: "Zql":"priority not in (Low,Lowest,Medium)"
 */


// create ZQL filter: "Zql":"priority not in (Low,Lowest,Medium)"
@Test(priority = 11)
	public void test11_createZqlFilter_by_priority_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority not in (Low,Lowest,Medium)");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 12
 * create ZQL filter: "Zql":"priority in (Low,Lowest,Medium)"
 */
// create ZQL filter: "Zql":"priority in (Highest,High)"
@Test(priority = 12)
	public void test12_createZqlFilter_by_priority_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("priority in (Low,Lowest,Medium)");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 13
 * create ZQL filter: "Zql":"component = component name"
 */

// create ZQL filter: "Zql":"component = RC10"
@Test(priority = 13)
	public void test13_createZqlFilter_by_component_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component ="+Config.getValue("component"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 14
 * create ZQL filter: "Zql":"component != component name"
 */

// create ZQL filter: "Zql":"component != RC10"
@Test(priority = 14)
	public void test14_createZqlFilter_by_component_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component !="+Config.getValue("component"));		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 15
 * create ZQL filter: "Zql":"component is not Empty"
 */

// create ZQL filter: "Zql":"component is not Empty"
@Test(priority = 15)
	public void test15_createZqlFilter_by_component_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component is not EMPTY");
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 16
 * create ZQL filter: "Zql":"component is Empty"
 */
// create ZQL filter: "Zql":"component is Empty"
@Test(priority = 16)
	public void test16_createZqlFilter_by_component_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component is EMPTY");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 17
 * create ZQL filter: "Zql":"component not in (component,component1)"
 */

// create ZQL filter: "Zql":"component not in (RC10,RC20)"
@Test(priority = 17)
	public void test17_createZqlFilter_by_component_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component not in ("+Config.getValue("component")+","+Config.getValue("component1")+")");		
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 18
 * create ZQL filter: "Zql":"component not in (component,component1)"
 */

// create ZQL filter: "Zql":"component in (RC10,RC20,c1)"
@Test(priority = 18)
	public void test18_createZqlFilter_by_component_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("component in ("+Config.getValue("component")+","+Config.getValue("component1")+")");			
		zqlfilterJson.setName("create api filter " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 19
 * create ZQL filter: "Zql":cycleName="cyclename"
 */

// create ZQL filter: "Zql":"cycleName = 123"
@Test(priority = 19)
	public void test19_createZqlFilter_by_cycleName_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName=\""+Config.getValue("cyclename")+"\"");			
		zqlfilterJson.setName("cyclename1 " + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 20
 * create ZQL filter: "Zql":cycleName!="cyclename"
 */
// create ZQL filter: "Zql":"cycleName != 123"
@Test(priority = 20)
	public void test20_createZqlFilter_by_cycleName_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName!=\""+Config.getValue("cyclename")+"\"");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 21
 * create ZQL filter: "Zql":cycleName is not EMPTY"
 */

// create ZQL filter: "Zql":"cycleName is not Empty"
@Test(priority = 21)
	public void test21_createZqlFilter_by_cycleName_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName is not EMPTY");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 22
 * create ZQL filter: "Zql":cycleName is EMPTY"
 */

// create ZQL filter: "Zql":"cycleName is Empty"
@Test(priority = 22)
	public void test22_createZqlFilter_by_cycleName_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName is EMPTY");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 23
 * create ZQL filter: "Zql":cycleName not in (cyclename,cyclename1)"
 */
// create ZQL filter: "Zql":"cycleName not in (123,50 exe)"
@Test(priority = 23)
	public void test23_createZqlFilter_by_cycleName_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName not in ("+Config.getValue("cyclename")+","+Config.getValue("cyclename1")+")");
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 24
 * create ZQL filter: "Zql":cycleName in (cyclename,cyclename1)"
 */

// create ZQL filter: "Zql":"cycleName in (123,50 exe,Ad hoc)"
@Test(priority = 24)
	public void test24_createZqlFilter_by_cycleName_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName in ("+Config.getValue("cyclename")+","+Config.getValue("cyclename1")+")");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}

/**
 * Test case - 25
 * create ZQL filter: "Zql":cycleName ~ad"
 */

// create ZQL filter: "Zql":"cycleName ~ 123"
@Test(priority = 25)
	public void test25_createZqlFilter_by_cycleName_tilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName ~ad");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}

/**
 * Test case - 26
 * create ZQL filter: "Zql":cycleName !~ad"
 */
// create ZQL filter: "Zql":"cycleName !~ 123"
@Test(priority = 26)
	public void test26_createZqlFilter_by_cycleName_NotTilde() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("cycleName !~ad");			
		zqlfilterJson.setName("cyclename" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 27
 * create ZQL filter: "Zql":fixVersion = fixversioname"
 */

// create ZQL filter: "Zql": fixVersion = "RUBY#2.0"
@Test(priority = 27)
	public void test27_createZqlFilter_by_fixVersion_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion = "+Config.getValue("fixVersion"));			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 28
 * create ZQL filter: "Zql":fixVersion != fixversioname"
 */
// create ZQL filter: "Zql":"fixVersion != RUBY#2.0"
@Test(priority = 28)
	public void test28_createZqlFilter_by_fixVersion_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion != "+Config.getValue("fixVersion"));			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 29
 * create ZQL filter: "Zql":fixVersion != fixversioname"
 */

// create ZQL filter: "Zql":"fixVersion is not EMPTY"
@Test(priority = 29)
	public void test29_createZqlFilter_by_fixVersion_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion is not EMPTY");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 30
 * create ZQL filter: "Zql":fixVersion is EMPTY"
 */
// create ZQL filter: "Zql":"fixVersion is EMPTY"
@Test(priority = 30)
	public void test30_createZqlFilter_by_fixVersion_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion is EMPTY");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 31
 * create ZQL filter: "Zql":fixVersion not in(fixVersion,fixVersion1)"
 */

// create ZQL filter: "Zql":"fixVersion in (A1,A2)"
@Test(priority = 31)
	public void test31_createZqlFilter_by_fixVersion_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion not in ("+Config.getValue("fixVersion")+","+Config.getValue("fixVersion1")+")");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 32
 * create ZQL filter: "Zql":fixVersion in (fixVersion,fixVersion1)"
 */

// create ZQL filter: "Zql":"fixVersion in (RUBY#2.0,50,Unscheduled)"
@Test(priority = 32)
	public void test32_createZqlFilter_by_fixVersion_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("fixVersion in ("+Config.getValue("fixVersion")+","+Config.getValue("fixVersion1")+")");			
		zqlfilterJson.setName("fixVersion" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 33
 * create ZQL filter: "Zql":executionStatus = WIP"
 */

//create ZQL filter: "Zql": "executionStatus = WIP"
@Test(priority = 33)
	public void test33_createZqlFilter_by_executionStatus_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus ="+Config.getValue("executionStatus"));			
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);	
	}
/**
 * Test case - 34
 * create ZQL filter: "Zql":executionStatus != FAIL"
 */

// create ZQL filter: "Zql":"executionStatus != FAIL"
@Test(priority = 34)
	public void test34_createZqlFilter_by_executionStatus_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus !="+Config.getValue("executionStatus1"));		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 35
 * create ZQL filter: "Zql":executionStatus is not Empty"
 */

// create ZQL filter: "Zql":"executionStatus is not Empty"
@Test(priority = 35)
	public void test35_createZqlFilter_by_executionStatus_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus is not Empty");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 36
 * create ZQL filter: "Zql":executionStatus is not Empty"
 */

// create ZQL filter: "Zql":"executionStatus is Empty"
@Test(priority = 36)
	public void test36_createZqlFilter_by_executionStatus_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus is Empty");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 37
 * create ZQL filter: "Zql":executionStatus not in (executionStatus,executionStatus1)"
 */

// create ZQL filter: "Zql":"executionStatus not in (PASSED,WIP)"
@Test(priority = 37)
	public void test37_createZqlFilter_by_executionStatus_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus not in ("+Config.getValue("executionStatus")+","+Config.getValue("executionStatus1")+")");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 38
 * create ZQL filter: "Zql":executionStatus in (BLOCKED,UNEXECUTED,new!)"
 */

// create ZQL filter: "Zql":"executionStatus in (BLOCKED,UNEXECUTED,new!)"
@Test(priority = 38)
	public void test38_createZqlFilter_by_executionStatus_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionStatus in ("+Config.getValue("executionStatus")+","+Config.getValue("executionStatus1")+","+Config.getValue("customStatus")+")");		
		zqlfilterJson.setName("executionStatus" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	
	}
/**
 * Test case - 39
 * create ZQL filter: "Zql":executedBy = admin"
 */

// create ZQL filter: "Zql": "executedBy = admin"
@Test(priority = 39)
	public void test39_createZqlFilter_by_executedBy_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy = admin");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 40
 * create ZQL filter: "Zql":executedBy != admin"
 */
// create ZQL filter: "Zql":"executedBy != admin"
@Test(priority = 40)
	public void test40_createZqlFilter_by_executedBy_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy != admin");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 41
 * create ZQL filter: "Zql":executedBy is not Empty"
 */

// create ZQL filter: "Zql":"executedBy is not Empty"
@Test(priority = 41)
	public void test41_createZqlFilter_by_executedBy_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy is not Empty");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 42
 * create ZQL filter: "Zql":executedBy is Empty"
 */

// create ZQL filter: "Zql":"executedBy is Empty"
@Test(priority = 42)
	public void test42_createZqlFilter_by_executedBy_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy is Empty");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 43
 * create ZQL filter: "Zql":executedBy not in (admin,user1)"
 */

// create ZQL filter: "Zql":"executedBy not in (admin,user1)"
@Test(priority = 43)
	public void test43_createZqlFilter_by_executedBy_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy not in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 44
 * create ZQL filter: "Zql":executedBy in (admin,user1)"
 */

// create ZQL filter: "Zql":"executedBy in (admin,user2,user3)"
@Test(priority = 44)
	public void test44_createZqlFilter_by_executedBy_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executedBy in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("executedBy" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 45
 * create ZQL filter: "Zql":assignee = admin"
 */
// create ZQL filter: "Zql": "assignee = admin"
@Test(priority = 45)
	public void test45_createZqlFilter_by_assignee_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee = admin");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 46
 * create ZQL filter: "Zql":assignee != admin"
 */

// create ZQL filter: "Zql":"assignee != admin"
@Test(priority = 46)
	public void test46_createZqlFilter_by_assignee_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee != admin");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 47
 * create ZQL filter: "Zql":assignee is not Empty"
 */
// create ZQL filter: "Zql":"assignee is not Empty"
@Test(priority = 47)
	public void test47_createZqlFilter_by_assignee_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee is not Empty");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 48
 * create ZQL filter: "Zql":assignee is Empty"
 */
// create ZQL filter: "Zql":"assignee is Empty"
@Test(priority = 48)
	public void test48_createZqlFilter_by_assignee_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee is Empty");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 49
 * create ZQL filter: "Zql":assignee not in (admin,user1)"
 */

// create ZQL filter: "Zql":"assignee not in (admin,user1)"
@Test(priority = 49)
	public void test49_createZqlFilter_by_assignee_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee not in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 50
 * create ZQL filter: "Zql":assignee not in (admin,user1)"
 */
// create ZQL filter: "Zql":"assignee in (admin,user2,user3)"
@Test(priority = 50)
	public void test50_createZqlFilter_by_assignee_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("assignee in ("+Config.getValue("user")+","+Config.getValue("user1")+")");		
		zqlfilterJson.setName("assignee" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 51
 * create ZQL filter: "Zql":issue = IE-1"
 */

// create ZQL filter: "Zql": "issue = IE-1"
@Test(priority = 51)
	public void test51_createZqlFilter_by_issue_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue ="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 52
 * create ZQL filter: "Zql":issue = IE-1"
 */

// create ZQL filter: "Zql":"issue != IE-1"
@Test(priority = 52)
	public void test52_createZqlFilter_by_issue_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue !="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 53
 * create ZQL filter: "Zql":issue <= IE-1"
 */

// create ZQL filter: "Zql":"issue <= IE-1"
@Test(priority = 53)
	public void test53_createZqlFilter_by_issue_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue <="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 54
 * create ZQL filter: "Zql":issue >= IE-1"
 */

// create ZQL filter: "Zql":"issue >= IE-1"
@Test(priority = 54)
	public void test54_createZqlFilter_by_isuue_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue >="+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 55
 * create ZQL filter: "Zql":issue < IE-1"
 */

// create ZQL filter: "Zql":"issue < IE-1"
@Test(priority = 55)
	public void test55_createZqlFilter_by_issue_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue <"+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 56
 * create ZQL filter: "Zql":issue > IE-1"
 */

// create ZQL filter: "Zql":"issue > IE-1"
@Test(priority = 56)
	public void test56_createZqlFilter_by_issue_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue >"+Config.getValue("issueid"));		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 57
 * create ZQL filter: "Zql":issue not in (IE-1,IE-2)"
 */

// create ZQL filter: "Zql":"issue not in (IE-1,IE-2)"
@Test(priority = 57)
	public void test57_createZqlFilter_by_issue_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue not in ("+Config.getValue("issueid")+","+Config.getValue("issueid1")+")");		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 58
 * create ZQL filter: "Zql":issue not in (IE-1,IE-2)"
 */

// create ZQL filter: "Zql":"assignee in (issue1,issue2,issue3)"
@Test(priority = 58)
	public void test58_createZqlFilter_by_issue_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("issue not in ("+Config.getValue("issueid")+","+Config.getValue("issueid1")+","+Config.getValue("issueid2")+")");		
		zqlfilterJson.setName("issue" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 59
 * create ZQL filter: "Zql":creationDate = yyyy-MM-dd"
 */
// create ZQL filter: "Zql": "creationDate = 2016-11-23"
@Test(priority = 59)
	public void test59_createZqlFilter_by_creationDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate ="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 60
 * create ZQL filter: "Zql":creationDate != yyyy-MM-dd"
 */
// create ZQL filter: "Zql":"creationDate != 2016-11-23"
@Test(priority = 60)
	public void test60_createZqlFilter_by_creationDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate !="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 61
 * create ZQL filter: "Zql":creationDate <= yyyy-MM-dd"
 */

// create ZQL filter: "Zql":"creationDate <= 2016-11-23"
@Test(priority = 61)
	public void test61_createZqlFilter_by_creationDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate <="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 62
 * create ZQL filter: "Zql":creationDate >= yyyy-MM-dd"
 */
// create ZQL filter: "Zql":"creationDate >= 2016-11-23"
@Test(priority = 62)
	public void test62_createZqlFilter_by_creationDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate >="+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 63
 * create ZQL filter: "Zql":creationDate < yyyy-MM-dd"
 */

// create ZQL filter: "Zql":"creationDate < 2016-11-23"
@Test(priority = 63)
	public void test63_createZqlFilter_by_creationDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate <"+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 64
 * create ZQL filter: "Zql":creationDate > yyyy-MM-dd"
 */

// create ZQL filter: "Zql":"creationDate > 2016-11-23"
@Test(priority = 64)
	public void test64_createZqlFilter_by_creationDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate >"+Config.getValue("creationdate"));		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 65
 * create ZQL filter: "Zql":creationDate not in (yyyy-MM-dd,yyyy-MM-dd)"
 */

// create ZQL filter: "Zql":"creationDate not in (2016-11-23,2016-11-22)"
@Test(priority = 65)
	public void test65_createZqlFilter_by_creationDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate not in ("+Config.getValue("creationdate")+","+Config.getValue("creationdate")+")");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 66
 * create ZQL filter: "Zql":creationDate  in (yyyy-MM-dd,yyyy-MM-dd)"
 */

// create ZQL filter: "Zql":"creationDate in
// (2016-11-23,2016-11-22,2016-11-21)"
@Test(priority = 66)
	public void test66_createZqlFilter_by_creationDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate in ("+Config.getValue("creationdate")+Config.getValue("creationdate")+")");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 67
 * create ZQL filter: "Zql":creationDate is not Empty"
 */

// create ZQL filter: "Zql":"creationDate is not Empty"
@Test(priority = 67)
	public void test67_createZqlFilter_by_creationDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate is not Empty");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 68
 * create ZQL filter: "Zql":creationDate is Empty"
 */

// create ZQL filter: "Zql":"creationDate is Empty"
@Test(priority = 68)
	public void test68_createZqlFilter_by_creationDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("creationDate is Empty");		
		zqlfilterJson.setName("creationDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 69
 * create ZQL filter: "Zql":executionDate = yyyy-mm-dd"
 */

// create ZQL filter: "Zql": "executionDate = 2016-11-23"
@Test(priority = 69)
	public void test69_createZqlFilter_by_executionDate_equalsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate ="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 70
 * create ZQL filter: "Zql":executionDate != yyyy-mm-dd"
 */


// create ZQL filter: "Zql":"executionDate != 2016-11-23"
@Test(priority = 70)
	public void test70_createZqlFilter_by_executionDate_NotEqualsto() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate !="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 71
 * create ZQL filter: "Zql":executionDate <= yyyy-mm-dd"
 */

// create ZQL filter: "Zql":"executionDate <= 2016-11-23"
@Test(priority = 71)
	public void test71_createZqlFilter_by_executionDate_lesThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate <="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 72
 * create ZQL filter: "Zql":executionDate >= yyyy-mm-dd"
 */

// create ZQL filter: "Zql":"executionDate >= 2016-11-23"
@Test(priority = 72)
	public void test72_createZqlFilter_by_executionDate_greaterThanEqualsTo() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate >="+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 73
 * create ZQL filter: "Zql":executionDate < yyyy-mm-dd"
 */

// create ZQL filter: "Zql":"executionDate < 2016-11-23"
@Test(priority = 73)
	public void test73_createZqlFilter_by_executionDate_lessThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate <"+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 74
 * create ZQL filter: "Zql":executionDate > yyyy-mm-dd"
 */

// create ZQL filter: "Zql":"executionDate > 2016-11-23"
@Test(priority = 74)
	public void test74_createZqlFilter_by_executionDate_greaterThan() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate >"+Config.getValue("executionDate"));		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 75
 * create ZQL filter: "Zql":executionDate not in (yyy-mm-dd,yyyy-mm-dd)"
 */

// create ZQL filter: "Zql":"executionDate not in (2016-11-23,2016-11-22)"
@Test(priority = 75)
	public void test75_createZqlFilter_by_executionDate_notIn() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate not in ("+Config.getValue("executionDate")+","+Config.getValue("executionDate1")+")");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 76
 * create ZQL filter: "Zql":executionDate in (yyy-mm-dd,yyyy-mm-dd)"
 */

// create ZQL filter: "Zql":"executionDate in
// (2016-11-23,2016-11-22,2016-11-21)"
@Test(priority = 76)
	public void test76_createZqlFilter_by_executionDate_In() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate in ("+Config.getValue("executionDate")+Config.getValue("executionDate1")+")");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 77
 * create ZQL filter: "Zql":executionDate is not Empty"
 */

// create ZQL filter: "Zql":"executionDate is not Empty"
@Test(priority = 77)
	public void test77_createZqlFilter_by_executionDate_isNOtEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is not Empty");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 78
 * create ZQL filter: "Zql":executionDate is Empty"
 */

// create ZQL filter: "Zql":"executionDate is Empty"
@Test(priority = 78)
	public void test78_createZqlFilter_by_executionDate_isEmpty() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("executionDate is Empty");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 79
 * create ZQL filter: "Zql":project =projectKey AND priority in (High,Highest)"
 */

// create ZQL filter: "Zql":"project = IE  AND priority in (High,Highest)"
@Test(priority = 79)
	public void test79_createZqlFilter_by_project_And_priority() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project ="+Config.getValue("projectKey")+ " AND priority in (High,Highest)");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 80
 * create ZQL filter: "Zql":project =projectKey AND priority in (High,Highest)"
 */
	
// create ZQL filter: "Zql":"project in (IE,RUBY) OR assignee  is not EMPTY"
@Test(priority = 80)
	public void test80_createZqlFilter_by_project_Or_Assignee() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project in ("+Config.getValue("projectKey")+Config.getValue("projectKey1")+")"+ "AND priority in (High,Highest)");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 81
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 */
		
// create ZQL filter: "project != RUBY ORDER BY component DESC"
@Test(priority = 81)
	public void test81_createZqlFilter_by_project_OrderBy_Component() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 82
 * create ZQL filter: "Zql":"project = "IE" AND fixVersion = v1 OR project = "RUBY" AND fixVersion = version1) AND TYPE in (BUG, Improvement) AND status in (resolved) ORDER BY key DESC"
 */
			
// create ZQL filter: "project = "IE" AND fixVersion = v1 OR project = "RUBY" AND fixVersion = version1) AND TYPE in (BUG, Improvement) AND status in (resolved) ORDER BY key DESC"
@Test(priority = 82)
	public void test82_createZqlFilter_by_complexZql() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		String Zql="project ="+Config.getValue("projectKey")+" AND fixVersion ="+Config.getValue("fixVersion")+
				" OR "+"project ="+Config.getValue("projectKey")+" AND fixVersion ="+Config.getValue("fixVersion1")+" AND executedBy in (admin,user1) AND executionStatus in (PASS,FAIL)  ORDER BY component DESC";
		Zqlfilter zqlfilterJson = new Zqlfilter("create filter");
		System.out.println(Zql);
		zqlfilterJson.setZql(Zql);		
		zqlfilterJson.setName("executionDate" + System.currentTimeMillis());		
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		zqlfilterJson.setDescription("Description");		
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator,zqlfilterJson.toString());
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		boolean createFilterStatus = zapiService.validateZQLFilter(zqlfilterJson.toString(), createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 83
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * sharePerm is private
 */
			
// create ZQL filter with sharePerm is private
@Test(priority = 83)
	public void test83_createZqlFilter_with_sharePerm_private() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 84
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * sharePerm is inavalid
 */
			
// create ZQL filter with favorite is false
@Test(priority = 84)
	public void test84_createZqlFilter_with_favorite_false() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("inavalid");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 84
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name capital letters
 */
			
// create ZQL filter when filterName is only in capital letter
@Test(priority = 85)
	public void test85_createZqlFilter_with_FilterName_capital() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("API FILTER IN CAPITAL" + System.currentTimeMillis() );
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 86
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name small letters
 */
			
// create ZQL filter when filterName is only in small letter
@Test(priority = 86)
	public void test86_createZqlFilter_with_FilterName_small() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter name in samll letter" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 87
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name numeric
 */
		
// create ZQL filter when filterName is only in numeric char
@Test(priority = 87)
	public void test87_createZqlFilter_with_FilterName_numeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("907766543" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 88
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name numeric
 */
	
// create ZQL filter when filterName is in alphanumeric char
@Test(priority = 88)
	public void test88_createZqlFilter_with_FilterName_alphanumeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("Alpha76654567213gfgdchjytr767ujh" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
/**
 * Test case - 89
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name special characters
 */

// create ZQL filter when filterName is in special char
@Test(priority = 89)
	public void test89_createZqlFilter_with_FilterName_specialChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("@#$*(*&^%" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
/**
 * Test case - 90
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name international characters
 */
	
// create ZQL filter when filterName is in international char
@Test(priority = 90)
	public void test90_createZqlFilter_with_FilterName_internationalChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("ã�®ãƒ�ã‚°ã�¯ã€�ãƒ†ã‚¹ãƒˆã‚·ãƒŠãƒªã‚ªã‚’" + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 91
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * filter name long name
 */

// create ZQL filter when filter has long name
@Test(priority = 91)
	public void test91_createZqlFilter_with_FilterName_longChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed..." + System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}				
/**
 * Test case - 92
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * description is only in capital letter
 */
// create ZQL filter when description is only in capital letter
@Test(priority = 92)
	public void test92_createZqlFilter_with_description_capital() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("private");
		zqlfilterJson.setDescription("DESCRIPTION IN CAPITAL");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 93
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * description is only in small letter
 */

// create ZQL filter when description is only in small letter
@Test(priority = 93)
	public void test93_createZqlFilter_with_description_small() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("private");
		zqlfilterJson.setDescription("description in small letter");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 94
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * description is only in capital letter
 */

// create ZQL filter when description is only in numeric char
@Test(priority = 94)
	public void test94_createZqlFilter_with_description_numeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(false);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("45678908769623456798765678");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 95
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * description is only in alpha numeric
 */
	
// create ZQL filter when description is in alphanumeric char
@Test(priority = 95)
	public void test95_createZqlFilter_with_description_alphanumeric() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("fghjknbvfdt76543erfghu765ertyhgfd");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 96
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * Description is only in special characters
 */
	
// create ZQL filter when description is in special char
@Test(priority = 96)
	public void test96_createZqlFilter_with_description_specialChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("*&^%$#@!#$%^&*");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
	
/**
 * Test case - 97
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * Description is only in international characters
 */
// create ZQL filter when description is in international char
@Test(priority = 97)
	public void test97_createZqlFilter_with_description_internationalChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("æ˜¯éªŒè¯�æµ‹è¯•åœºæ™¯ã€‚è¯·å…³é—­å®ƒå›ºå®šæ—¶");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
/**
 * Test case - 98
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * Description is only in long description
 */
	
// create ZQL filter when description is so long char
@Test(priority = 98)
	public void test98_createZqlFilter_with_description_longChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("This issue is not exesiting in the following test bed , please try to add more informanctionof how to reproduce this issue , closing this as of now plrease reopen when required . I had assigned this issue . Already checked in code , code checkin failed...");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 99
 * create ZQL filter: "Zql":project !=projectKey ORDER BY component DESC"
 * Description is only in empty
 */
	
// create ZQL filter without description
@Test(priority = 99)
	public void test99_createZqlFilter_with_description_longChar() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("This issue is not exesiting in the following test bed"
				+ " , please try to add more informanctionof how to reproduce this issue , "
				+ "closing this as of now plrease reopen when required . I had assigned this issue . "
				+ "Already checked in code , code checkin failed...");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 100
 * attempt to create ZQL filter without filter name
 * 
 */

// attempt to create ZQL filter without filter name
@Test(priority = 100)
	public void test100_attempt_to_createZqlFilter_without_filterName() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
	//	zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 101
 * attempt to create ZQL filter with existing filter name
 * 
 */	
// attempt to create ZQL filter with existing filter name
@Test(priority = 101)
	public void test101_attempt_to_createZqlFilter_with_existing_filterName() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		String filtername="api filter123" + System.currentTimeMillis();
		zqlfilterJson.setName(filtername);
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		zqlfilterJson.setDescription("");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		Zqlfilter zqlfilterJson1 = new Zqlfilter();
		zqlfilterJson1.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson1.setName(filtername);
		zqlfilterJson1.setFavorite(true);
		zqlfilterJson1.setSharePerm("global");
		zqlfilterJson1.setDescription("");		
		payLoad = zqlfilterJson1.toString();
		System.out.println("Payload:-->" + payLoad);
		createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		boolean createFilterStatus1 = zapiService.validateAlreadyExistsZQLFilter(createFilterResponse);
		Assert.assertTrue(createFilterStatus1);
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");
		
		extentReport.endTest(test);
	}
/**
 * Test case - 102
 * attempt to create ZQL filter with invalid sharePerm
 * 
 */	

// attempt to create ZQL filter with invalid sharePerm
@Test(priority = 102)
	public void test102_attempt_to_createZqlFilter_with_invalid_sharePerm() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("invalid");
		zqlfilterJson.setDescription("");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 103
 * create ZQL filter with sharePerm is global
 * 
 */	

// create ZQL filter with sharePerm is global
@Test(priority = 103)
	public void test103_createZqlFilter_with_sharePerm_global() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setZql("project is Empty");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");			
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 104
 * create ZQL filter with favorite is true
 * 
 */	

// create ZQL filter with favorite is true
@Test(priority = 104)
	public void test104_createZqlFilter_with_favorite_true() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");		
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
		zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
/**
 * Test case - 105
 *create ZQL filter without giving favorite
 * 
 */	

// create ZQL filter without giving favorite
@Test(priority = 105)
	public void test105_createZqlFilter_without_favorite() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("poornachandra");	
		
		Zqlfilter zqlfilterJson = new Zqlfilter();
		zqlfilterJson.setZql("project !="+Config.getValue("projectKey")+" ORDER BY component DESC");
		zqlfilterJson.setName("api filter"+ System.currentTimeMillis());
	//	zqlfilterJson.setFavorite(true);
		zqlfilterJson.setSharePerm("global");
		
		String payLoad = zqlfilterJson.toString();
		System.out.println("Payload:-->" + payLoad);
		Response createFilterResponse = zapiService.createZQLFilter(jwtGenerator, payLoad);
		Assert.assertNotNull(createFilterResponse, "Create Zql Filter Api Response is null.");
		test.log(LogStatus.PASS, "Create Zql filter Api executed successfully.");	
	
		boolean createFilterStatus = zapiService.validateZQLFilter(payLoad, createFilterResponse);
		Assert.assertTrue(createFilterStatus);
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
}
