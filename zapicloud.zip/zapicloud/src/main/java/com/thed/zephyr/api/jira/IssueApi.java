package com.thed.zephyr.api.jira;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author Created by niravshah on 11/9/16.
 */
public interface IssueApi {
    
	/**
	 * @param basicAuth
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response createIssue(RequestSpecification basicAuth, String payLoad);

    /**
     * @param basicAuth
     * @param issueKey
     * @return Response of the executed API.
     * @author Created by manoj.behera on 14-Nov-2016.
     */
    Response deleteIssue(RequestSpecification basicAuth, String issueKey);
    
    //get transitions
    Response getTransitions(RequestSpecification basicAuth, String issueKey);
    //update transitions
    Response editissue(RequestSpecification basicAuth, String issueKey,String payload);
    
    
    
    
}
