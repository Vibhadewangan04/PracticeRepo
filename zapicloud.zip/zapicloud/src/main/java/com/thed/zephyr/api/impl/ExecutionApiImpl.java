/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.ExecutionApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import static com.jayway.restassured.RestAssured.given;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("executionApi")
public class ExecutionApiImpl implements ExecutionApi{

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ExecutionApi#createExecution(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response createExecution(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution";
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println("URI :"+uri.toString());
		System.out.println("payLoad :"+payLoad);
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ExecutionApi#getExecutionStatuses(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecutionStatuses(JwtGenerator jwtGenerator){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/statuses";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().headers(headers).when().get(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ExecutionApi#getExecution(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecution(JwtGenerator jwtGenerator, Long projectId, Long issueId, String executionId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/"+executionId;
		URI uri = null;
		if(projectId == null){
			uri = UriBuilder.fromUri(uriStr).queryParam("issueId", issueId).build();
		}else if (issueId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).build();
		}else{
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("issueId", issueId).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ExecutionApi#getExecutions(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getExecutions(JwtGenerator jwtGenerator, Long projectId, Long issueId, int offset, int size){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions";
		URI uri = null;
		if (projectId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("issueId", issueId).queryParam("offset", offset).queryParam("size", size).build();
		}
		else if (issueId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("offset", offset).queryParam("size", size).build();
		}
		else {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("issueId", issueId).queryParam("offset", offset).queryParam("size", size).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getExecutionsByCycle(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId, int offset, int size){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/search/cycle/"+cycleId;
		URI uri = null;
		if (projectId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("versionId", versionId).queryParam("offset", offset).queryParam("size", size).build();
		}
		else if (versionId == null) {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("offset", offset).queryParam("size", size).build();
		}
		else {
			uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("offset", offset).queryParam("size", size).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ExecutionApi#deleteExecution(com.thed.zephyr.cloud.rest.client.JwtGenerator, java.lang.String, java.lang.String)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response deleteExecution(JwtGenerator jwtGenerator, Long issueId, String executionId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/"+executionId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("issueId", issueId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("DELETE", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		return given().headers(headers).when().delete(uri);
	}
	@Override
	public Response deleteBulkExecutions(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/delete";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).post(uri);
	}
	@Override
	public Response updateBulkStatus(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response assignBulkExecutions(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/bulkAssign";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response getExecutionsByIssue(JwtGenerator jwtGenerator, Long issueId, int offset, int size){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/search/issue/"+issueId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("offset", offset).queryParam("size", size).queryParam("expand", "executionStatus").queryParam("action", "expand").build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getExecutionsByIssue(JwtGenerator jwtGenerator, String issueKey, int offset, int size){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/search/issue/"+issueKey;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("offset", offset).queryParam("size", size).queryParam("expand", "executionStatus").queryParam("action", "expand").build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getExecutionSummariesBySprintAndIssue(JwtGenerator jwtGenerator, Long sprintId, String issueIdorKeys){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/search/sprint/"+sprintId+"/issues";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Content-Type", "application/json");
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 System.out.println(uri.toString());
		// String issueIdorKeys = "{\"issueIdOrKeys\":\"10803\"}";
		return given().headers(headers).body(issueIdorKeys).when().post(uri);
	}
	@Override
	public Response updateExecution(JwtGenerator jwtGenerator, String executionId, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/execution/"+executionId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println("JWT is" + jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println("Payload is" + payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	@Override
	public Response exportExecution(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/export";
		URI uri = UriBuilder.fromUri(uriStr).build();
		System.out.println(uri.toString());
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response downloadExportedFile(JwtGenerator jwtGenerator, String downloadFilename){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/cycle/export/download/"+downloadFilename;
		System.out.println(uriStr);
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response reOrderExecutions(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/private/rest/api/1.0/execution/reOrder";
		URI uri = UriBuilder.fromUri(uriStr).build();
		System.out.println(uri.toString());
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response addTestsTocycle(JwtGenerator jwtGenerator, String cycleId, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/add/cycle/"+cycleId;
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response getExecutionsByZQL(JwtGenerator jwtGenerator, String executionId, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/search";
		URI uri;
		if (executionId == null) {
			uri = UriBuilder.fromUri(uriStr).build();
		}
		else {
			uri = UriBuilder.fromUri(uriStr).queryParam("executionId", executionId).build();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	
	@Override
	public Response getExecutionTimeTracking(JwtGenerator jwtGenerator, Long projectId, Long versionId, String cycleId){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executionstimetrackingbycycles";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("versionId", versionId).queryParam("cycleIds", "cycleId").build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response updateExecutionCustomfield(JwtGenerator jwtGenerator, String executionId, String payLoad) {
		///connect/public/rest/api/1.0/executions/0075f2e8-b27a-41dc-9a08-c9967b0f9815/customField
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/executions/"+executionId+"/customField";
		System.out.println("URI for customfield"+uriStr);
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println("JWT is " + jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		//System.out.println("Payload is" + payLoad);
		System.out.println(uri.toString());
		return given().headers(headers).body(payLoad).when().put(uri);
	}
}
