/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import static com.jayway.restassured.RestAssured.given;
import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.ServerInfoApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("serverInfoApi")
public class ServerInfoApiImpl implements ServerInfoApi{

	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ServerInfoApi#getServerInfo(com.thed.zephyr.cloud.rest.client.JwtGenerator)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getServerInfo(JwtGenerator jwtGenerator){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/serverinfo";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ServerInfoApi#getSystemProp(com.thed.zephyr.cloud.rest.client.JwtGenerator)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getSystemProp(JwtGenerator jwtGenerator){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/systemprop";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = 3600;
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
}
