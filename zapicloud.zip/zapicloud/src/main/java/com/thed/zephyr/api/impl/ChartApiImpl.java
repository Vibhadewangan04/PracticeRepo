/**
 * Created by manoj.behera on 21-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.ChartApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 21-Nov-2016
 *
 */
@Service("chartApi")
public class ChartApiImpl  implements ChartApi{

	@Override
	public Response getTestsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/chart/tests/created";
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("range", daysPrevious).queryParam("aggregation", periodName).build();
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("daysPrevious", daysPrevious).queryParam("periodName", periodName).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getExecutionsCreated(JwtGenerator jwtGenerator, Long projectId, int daysPrevious, String periodName){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/chart/executions/created";
//		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("range", daysPrevious).queryParam("aggregation", periodName).build();
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("daysPrevious", daysPrevious).queryParam("periodName", periodName).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().headers(headers).when().get(uri);
	}
}
