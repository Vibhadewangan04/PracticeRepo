/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface ZqlApi {

	/**
	 * @param jwtGenerator
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLFieldConfiguration(JwtGenerator jwtGenerator);
	/**
	 * @param jwtGenerator
	 * @param payLoad
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response executeZQLSearch(JwtGenerator jwtGenerator, String payLoad);
	/**
	 * @param jwtGenerator
	 * @param fieldName
	 * @param fieldValue
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLAutoComplete(JwtGenerator jwtGenerator, String fieldName, String fieldValue);
	/**
	 * @param jwtGenerator
	 * @return Response of the executed API.
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getZQLFieldValues(JwtGenerator jwtGenerator);
}
