/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetExecutionsByCycleApi extends BaseTest {

	JwtGenerator jwtGenerator = null;
	Long versionId = null;
	Long projectId = null;
	String cycleId = null;
	int offset = 0;
	int size = 0;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//TODO
	//Get execution by ProjectId,cycleId and versionId
	@Test(priority = 1, enabled = testEnabled)
	public void test1_getExecutionsByCycleIdProjectIdAndVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "0001478768964952-242ac1131-0001";
		offset = 0;
		size = 10;
		
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		
		
		//creating cycle
		
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(-1l);
				cycleJson.setName("Get execution by cycle");
				cycleJson.setDescription("Get execution by cycle");

				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(-1l);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(1);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
				
				
			
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with executions in Adhoc Cycle of scheduled version
	@Test(priority = 2, enabled = testEnabled)
	public void test2_getExecutionsByCycleIdWithExecutionsInAdhocCycleOfScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		cycleId = "-1";
		offset = 0;
		size = 10;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				/*Long issueId = issueIds.get(0);
				System.out.println(issueId);*/
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(versionId);
				executionJson.setCycleId("-1");
				executionJson.setNoOfExecutions(2);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
				

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with executions in Non-Adhoc Cycle of scheduled version
	@Test(priority = 3,enabled = testEnabled)
	public void test3_getExecutionsByCycleIdWithExecutionsInNonAdhocCycleOfScheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionOneId"));
		//cycleId = "0001478768964952-242ac1131-0001";
		offset = 0;
		size = 10;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				/*Long issueId = issueIds.get(0);
				System.out.println(issueId);*/
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Get execution by cycle");
		cycleJson.setDescription("Get execution by cycle");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(versionId);
		executionJson.setCycleId(cycleId);
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");
		
		

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with executions in Adhoc Cycle of unscheduled version
	@Test(priority = 4, enabled = testEnabled)
	public void test4_getExecutionsByCycleIdWithExecutionsInAdhocCycleOfUncheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 10;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		/*Long issueId = issueIds.get(0);
		System.out.println(issueId);*/

//creating executions
Execution executionJson = new Execution();
executionJson.setStatusId(-1l);
executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
executionJson.setVersionId(versionId);
executionJson.setCycleId("-1");
executionJson.setNoOfExecutions(2);
//executionJson.setCycleId(this.cycleIdScheduledVersion);
List<Long> list = new ArrayList<>(issueIds);
executionJson.setIssueIds(list);
JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with executions in Non-Adhoc Cycle of unscheduled version
	@Test(priority = 5, enabled = testEnabled)
	public void test5_getExecutionsByCycleIdWithExecutionsInNonAdhocCycleOfUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "0001478768964952-242ac1131-0001";
		offset = 0;
		size = 10;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		/*Long issueId = issueIds.get(0);
		System.out.println(issueId);*/
			//creating cycle
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(versionId);
			cycleJson.setName("Get execution by cycle");
			cycleJson.setDescription("Get execution by cycle");
			
			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status1, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
			
			//creating executions
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setVersionId(versionId);
			executionJson.setCycleId(cycleId);
			executionJson.setNoOfExecutions(2);
			//executionJson.setCycleId(this.cycleIdScheduledVersion);
			List<Long> list = new ArrayList<>(issueIds);
			executionJson.setIssueIds(list);
			JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with executions fully executed
	@Test(priority = 6, enabled = testEnabled)
	public void test6_getExecutionsByCycleIdWithExecutionsFullyExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "0001478768964952-242ac1131-0001";
		offset = 0;
		size = 10;
   
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
					//creating cycle
					
					Cycle cycleJson = new Cycle();
					cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
					cycleJson.setVersionId(versionId);
					cycleJson.setName("Get execution by cycle");
					cycleJson.setDescription("Get execution by cycle");
					
					Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
					Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
					test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
					boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
					Assert.assertTrue(status1, "Response Validation Failed.");
					test.log(LogStatus.PASS, "Response validated successfully.");
					String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
					
					//creating executions
					Execution executionJson = new Execution();
					executionJson.setStatusId(-1l);
					executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
					executionJson.setVersionId(versionId);
					executionJson.setCycleId(cycleId);
					executionJson.setNoOfExecutions(2);
					//executionJson.setCycleId(this.cycleIdScheduledVersion);
					List<Long> list = new ArrayList<>(issueIds);
					executionJson.setIssueIds(list);
					JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
					Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

					
					//update executions
					List<String> exeIds = new ArrayList<>() ;
					JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
					System.out.println("length="+jsarray2.length());
					for (int j=0;j<jsarray2.length();j++){
						JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
						String exeid =jsobj2.getJSONObject("execution").get("id").toString();
						exeIds.add(exeid);
						Long issueId1 = issueIds.get(j);
						executionJson.setIssueId(issueId1);
						System.out.println(issueId1);
						executionJson.setStatusId(1l);
						executionJson.setExecutionId(exeid);
						Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
								executionJson.toString());
						Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
						test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
						System.out.println(updateExecutionResponse.getBody().asString());
						System.out.println("updated execution");
					}
		
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with executions partially executed
	@Test(priority = 7, enabled = testEnabled)
	public void test7_getExecutionsByCycleIdWithExecutionsPartiallyExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "0001478768964952-242ac1131-0001";
		offset = 0;
		size = 10;

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
			//creating cycle
			
			Cycle cycleJson = new Cycle();
			cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			cycleJson.setVersionId(versionId);
			cycleJson.setName("Get execution by cycle");
			cycleJson.setDescription("Get execution by cycle");
			
			Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
			Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
			test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
			boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
			Assert.assertTrue(status1, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
			
			//creating executions
			Execution executionJson = new Execution();
			executionJson.setStatusId(-1l);
			executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
			executionJson.setVersionId(versionId);
			executionJson.setCycleId(cycleId);
			executionJson.setNoOfExecutions(2);
			//executionJson.setCycleId(this.cycleIdScheduledVersion);
			List<Long> list = new ArrayList<>(issueIds);
			executionJson.setIssueIds(list);
			JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
			Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

			
			//update executions
			List<String> exeIds = new ArrayList<>() ;
			JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
			System.out.println("length="+jsarray2.length());
			for (int j=0;j<jsarray2.length();j++){
				JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
				String exeid =jsobj2.getJSONObject("execution").get("id").toString();
				exeIds.add(exeid);
				//Long issueId1 = issueIds.get(j);
				executionJson.setIssueId(issueId);
				System.out.println(issueId);
				executionJson.setStatusId(1l);
				executionJson.setExecutionId(exeid);
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			}

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with 50 executions
	@Test(priority = 8,enabled = false)
	public void test8_getExecutionsByCycleIdWith50Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 10;
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(versionId);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(50);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with 500 executions
	@Test(priority = 9,enabled=false)
	public void test9_getExecutionsByCycleIdWith500Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 10;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(versionId);
		executionJson.setCycleId(cycleId);
		executionJson.setNoOfExecutions(500);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");


		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Get executions by cycle id with 1000 executions
	@Test(priority = 10,enabled=false)
	public void test10_getExecutionsByCycleIdWith1000Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 10;
		

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(versionId);
		executionJson.setCycleId(cycleId);
		executionJson.setNoOfExecutions(1000);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");


		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Attempt to get execution by cycle id and versionId without passing projectId
	@Test(priority = 11, enabled = testEnabled)
	public void test11_attemptToGetExecutionsByCycleIdAndversionIdWithoutPassingProjectId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = null;
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 10;
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(versionId);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(2);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");


		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//Attempt to get execution by cycle id and projectId without passing versionId
	@Test(priority = 12, enabled = testEnabled)
	public void test12_attemptToGetExecutionsByCycleIdAndprojectIdWithoutPassingVersionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = null;
		cycleId = "-1";
		offset = 0;
		size = 10;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(-1l);
		executionJson.setCycleId(cycleId);
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//FIXME
	//Need deleted cycleId
	/**
	 * Attempt to get execution by cycle id, versionId, project id if cycleId doesn't exist
	 * BugId = ZAPICLOUD-67
	 * @param status2 
	 */
	@Test(priority = 13, enabled = testEnabled)
	public void test13_attemptToGetExecutionsByCycleIdProjectIdAndVersionIdIfCycleIdDoesNotExist(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		//cycleId = "0001478";
		offset = 0;
		size = 10;
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				cycleJson.setVersionId(versionId);
				cycleJson.setName("Get execution by cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(-1l);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(1);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

				// delete cycle
				Response response2 = zapiService.deleteCycle(jwtGenerator, projectId, versionId, cycleId);
				Assert.assertNotNull(response2, "Delete Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Delete Cycle Api executed successfully.");

				boolean status2 = zapiService.validateDeletedCycle(projectId, versionId, cycleId, response2);
				Assert.assertTrue(status2, "Response Validation Failed.");

				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
				boolean status = zapiService.validateGetExecutionsWithOtherCycleId(response, projectId, versionId, cycleId, offset, size);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
	}

	//TODO
	//Need CycleId that does not belong to project
	//Attempt to get execution  with project id, version id, cycle id if the cycle does not belong to the project
	@Test(priority = 14, enabled = testEnabled)
	public void test14_attemptToGetExecutionsByCycleIdProjectIdAndVersionIdIfCycleDoesNotBelongToTheProject(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		// = "0001479280127255-242ac1138-0001";
		offset = 0;
		size = 10;
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		//creating cycle
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		cycleJson.setVersionId(versionId);
		cycleJson.setName("Get execution by cycle");
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson.setVersionId(versionId);
		executionJson.setCycleId(cycleId);
		executionJson.setNoOfExecutions(1);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsWithOtherCycleId(response, projectId, versionId, cycleId, offset, size);
			Assert.assertTrue(status, "Response Validation Failed.");
			test.log(LogStatus.PASS, "Response validated successfully.");
			extentReport.endTest(test);
	}

	//TODO
	//FIXME
	/**
	 *Attempt to get execution  with project id, version id, cycle id if the version does not belong to the project
	 *BugId = ZAPICLOUD-67,ZFJCLOUD-2595
	 */
	//@Test(priority = 15, enabled = testEnabled)
	public void test15_attemptToGetExecutionsByCycleIdProjectIdAndVersionIdIfVersionDoesNotBelongToTheProject(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = 10101l;
		//cycleId = "0001478768964952-242ac1131-0001";
		offset = 0;
		size = 10;
		long versionId1 = Long.parseLong(Config.getValue("versionOneId"));
		
		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId1"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating cycle
				
				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
				cycleJson.setVersionId(versionId1);
				cycleJson.setName("Get execution by cycle");
				cycleJson.setDescription("Get execution by cycle");
				
				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status1, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
				
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
				executionJson.setVersionId(versionId1);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(1);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
			Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				extentReport.endTest(test);
	}

	//TODO
	//Get execution with cycleId, project id, version id with defects and comments associated to some executions
	@Test(priority = 16, enabled = testEnabled)
	public void test16_getExecutionsByCycleIdProjectIdAndVersionIdWithDefectsAndCommentsLinkedToExecutions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 10;

		//create issues
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
				Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
			
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(createIssueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
				Long issueId = issueIds.get(0);
				System.out.println(issueId);
				
				//creating executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setVersionId(-1l);
				executionJson.setCycleId(cycleId);
				executionJson.setNoOfExecutions(2);
				//executionJson.setCycleId(this.cycleIdScheduledVersion);
				List<Long> list = new ArrayList<>(issueIds);
				executionJson.setIssueIds(list);
				JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

				//create defect to link		
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
				Response response1 = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(response1, "Create Issue Api Response is null.");
				
				boolean issueStatus = jiraService.validateCreateIssueApi(response1);
				Assert.assertTrue(issueStatus, "Response Validation Failed.");
				Long bugId = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
				List<Long> defectsList = new ArrayList<>();
				defectsList.add(bugId);	    

				//update 
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(createExecutionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					//Long issueId = issueIds.get(j);
					executionJson.setIssueId(issueId);
					executionJson.setDefects(defectsList);
					executionJson.setComment("Comment added to executions");
					System.out.println(issueId);
					executionJson.setStatusId(2l);
					executionJson.setExecutionId(exeid);
					
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
					
		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
				}
	}

	//Attempt to get executions by cycle id, if the size is set to 51
	@Test(priority = 17,enabled = testEnabled)
	public void test17_attemptToGetExecutionsByCycleIdIfSizeIsSetTo51(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 0;
		size = 51;
		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		
		//creating executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setVersionId(-1l);
		executionJson.setCycleId(cycleId);
		executionJson.setNoOfExecutions(2);
		//executionJson.setCycleId(this.cycleIdScheduledVersion);
		List<Long> list = new ArrayList<>(issueIds);
		executionJson.setIssueIds(list);
		JSONArray createExecutionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");


		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//Attempt to get executions by cycle id, if the offset value is greater size
	@Test(priority = 18, enabled = testEnabled)
	public void test18_attemptToGetExecutionsByCycleIdIfOffsetIsGreaterThanSize(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = -1l;
		cycleId = "-1";
		offset = 20;
		size = 10;
		
		//create issue
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad1.setSummary("test");
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));
		System.out.println(issuePayLoad1.toString());
		Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(response1, "Create Issue Api Response is null.");
		
		boolean status1 = jiraService.validateCreateIssueApi(response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		long issueId1 = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
		String issueKey1 = new JSONObject(response1.body().asString()).getString("key");
		
		//create execution
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(issueId1);
		executionJson.setCycleId("-1");
	    executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));
		

		Response response = zapiService.getExecutionsByCycle(jwtGenerator, projectId, versionId, cycleId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByCycle(response, projectId, versionId, cycleId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

}
