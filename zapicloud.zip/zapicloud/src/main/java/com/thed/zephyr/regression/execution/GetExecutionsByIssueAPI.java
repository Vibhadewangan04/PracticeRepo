/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseBodyData;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetExecutionsByIssueAPI extends BaseTest {

	JwtGenerator jwtGenerator = null;
	Long issueId = null;
	Long StoryissueId= null;
	int offset = 0;
	int size = 0;

	//private Long ProjectId = Long.parseLong(Config.getValue("ProjectId")); 
   
	
	
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("accountId"));
	
	
	}

	
	
	
	
	@Test(priority = 0, enabled = true)
	public void test_to_create_story(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

	//create story issue then link above issue to this story
	Issue issuePayLoad1 = new Issue();
	issuePayLoad1.setProject(Config.getValue("projectId"));
	issuePayLoad1.setIssuetype(Config.getValue("issueTypeStoryId"));
	issuePayLoad1.setSummary("Test"+System.currentTimeMillis());
	issuePayLoad1.setPriority("1");
	issuePayLoad1.setReporter(Config.getValue("adminUserName"));

	Response Createtestresponse2 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
	Assert.assertNotNull(Createtestresponse2, "Create Issue Api Response is null.");
	test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

	boolean status2 = jiraService.validateCreateIssueApi(Createtestresponse2);
	Assert.assertTrue(status2, "Response Validation Failed.");
	issueId = Long.parseLong(new JSONObject(Createtestresponse2.body().asString()).get("id").toString());
	String issueKeys2 =(String) new JSONObject(Createtestresponse2.body().asString()).get("key");
	}
	
	
	

	//Get executions by issue id with executions in Adhoc Cycle of scheduled version
	@Test(priority = 1, enabled = true)
	public void test1_getExecutionByIssueIdWithExecutionsInAdhoCycleOfScheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		//Create executions in Adhoc cycle and pass the issueId after executing
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 1;

		/*Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("ExecutionsInAdhoCycle");
		cycleJson.setDescription("Cycle for get executions");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");*/
		String cycleId = "-1";
		
		/*//create story issue then link above issue to this story
		Issue issuePayLoad1 = new Issue();
		issuePayLoad1.setProject(Config.getValue("projectId"));
		issuePayLoad1.setIssuetype(Config.getValue("issueTypeStoryId"));
		issuePayLoad1.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad1.setPriority("1");
		issuePayLoad1.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse2 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
		Assert.assertNotNull(Createtestresponse2, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status2 = jiraService.validateCreateIssueApi(Createtestresponse2);
		Assert.assertTrue(status2, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse2.body().asString()).get("id").toString());
		String issueKeys2 =(String) new JSONObject(Createtestresponse2.body().asString()).get("key");
		*/
		
		//create test issue
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("***" +issueResponse);
	//	String APIKey =(String) new JSONObject(issueResponse.body().asString()).get("key");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
	
	
	String issueKeys2 = "API-2" ; 
//		link this story to that issue
			//String Payload2 = "{\"type\":{\"id":"10000"},"inwardIssue":{"key":"API-786"},"outwardIssue":{"key":"API-802"}}
	//	String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\"API-2\"}}";
		
			String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
			System.out.println("qqq" +Payload2);
			
			Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
			System.out.println("qqq" +response22.asString());
			Assert.assertNotNull(response22, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
				
		Long issueId = issueIds.get(0);
		//issueId = 10000l;
		offset = 0;
		size = 10;

		
		//String issueIdOfStory = Config.getValue("issueIdOfStory");
		Long issueIdOfStory = Long.parseLong(Config.getValue("issueIdOfStory"));
		System.out.println("story id is" +issueIdOfStory);
	
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOfStory, offset, size);
		// if user wants details of story link test executions
	//	Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size); if user wants details of issueId only
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println("qqqq" +response);
		System.out.println("qqqq as string" +response.asString());
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	
	}
	
	
//	@Test(priority = 1, enabled = False)
	public void Test_test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeStoryId"));
		issuePayLoad.setSummary("Test"+System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
		String issuekey =(String) new JSONObject(Createtestresponse.body().asString()).get("key");
	
		
		// creating issue - story
				Issue issuePayLoad1 = new Issue();
				issuePayLoad1.setProject(Config.getValue("projectId"));
				issuePayLoad1.setIssuetype(Config.getValue("issueTypeStoryId"));
				issuePayLoad1.setSummary("Test"+System.currentTimeMillis());
				issuePayLoad1.setPriority("1");
				issuePayLoad1.setReporter(Config.getValue("adminUserName"));

				Response Createtestresponse2 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
				Assert.assertNotNull(Createtestresponse2, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

				boolean status2 = jiraService.validateCreateIssueApi(Createtestresponse2);
				Assert.assertTrue(status2, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(Createtestresponse2.body().asString()).get("id").toString());
				String issuekey2 =(String) new JSONObject(Createtestresponse2.body().asString()).get("key");
	
	
       //	link this story to that issue
			//String Payload2 = "{\"type\":{\"id":"10000"},"inwardIssue":{"key":"API-786"},"outwardIssue":{"key":"API-802"}}
			
			String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issuekey2+"\"}}";
			System.out.println("qqq" +Payload2);
			
			Response response = jiraService.createIssueLink(basicAuth, Payload2);
			System.out.println("qqq" +response.asString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
				
	}
	
	
	
	

	//TODO
	//Get executions by issue id with executions in Non-Adhoc Cycle of scheduled version
	@Test(priority = 2, enabled =true )
	public void test2_getExecutionByIssueIdWithExecutionsInNonAdhoCycles(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		//Create executions in Adhoc cycle and pass the issueId after executing
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 1;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("ExecutionsInNonAdhoCycle");
		cycleJson.setDescription("Cycle for get executions");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		
			String issueKeys2 = "API-2" ; 
		
			String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
			System.out.println("qqq" +Payload2);
			
			Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
			System.out.println("qqq" +response22.asString());
			Assert.assertNotNull(response22, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		Long issueId = issueIds.get(0);
		//issueId = 10000l;
		offset = 0;
		size = 10;
		
		Long issueIdOfStory = Long.parseLong(Config.getValue("issueIdOfStory"));
		System.out.println("story id is" +issueIdOfStory);
	
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOfStory, offset, size);

	//	Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	
	//TODO
	//Get executions by issue id with executions in Adhoc Cycle of unscheduled version
	@Test(priority = 3, enabled =true )
	public void test3_getExecutionByIssueIdWithExecutionsInAdhoCycleOfUnscheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		//Create executions in Adhoc cycle and pass the issueId after executing
		
				Long ProjectID = Long.parseLong(Config.getValue("projectId"));
				Long VersionID = Long.parseLong(Config.getValue("unscheduleId"));
				// implement cycle with test executed to different statuses
				int numberOfExecutions = 1;

				String cycleId = "-1";
				/*Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(ProjectID);
				cycleJson.setVersionId(VersionID);
				cycleJson.setName("ExecutionsInNonAdhoCycle");
				cycleJson.setDescription("Cycle for get executions");

				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();*/

				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(ProjectID));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				
				List<Long> issueKeys = new ArrayList<>() ;
				JSONArray jsarray3 = new JSONArray(issueResponse);
				for(int k= 0;k<jsarray3.length();k++){
			
					JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
					String issuekey= (String)jsobj3.get("key");
					
					System.out.println("*****key"+issuekey);
				
				
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(issueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
			
				//create executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(ProjectID);
				executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
				executionJson.setVersionId(VersionID);
				executionJson.setNoOfExecutions(numberOfExecutions);
				executionJson.setCycleId(cycleId);
				System.out.println(executionJson.toString());

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS,
						"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId = issueIds.get(j);
					executionJson.setIssueId(issueId);
					System.out.println(issueId);
					long StatusId = j+1;
					executionJson.setStatusId(StatusId);
					executionJson.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				  //To create Issue link
				String issueKeys2 = "API-2" ; 
				
				String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
				System.out.println("qqq" +Payload2);
				
				Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
				System.out.println("qqq" +response22.asString());
				Assert.assertNotNull(response22, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			

				Long issueId = issueIds.get(0);
				//issueId = 10000l;
				offset = 0;
				size = 10;

				Long issueIdOfStory = Long.parseLong(Config.getValue("issueIdOfStory"));
				System.out.println("story id is" +issueIdOfStory);
				
	     Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOfStory, offset, size);
		//Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}

	//TO
	//Get executions by issue id with executions in Non-Adhoc Cycle of unscheduled version
	@Test(priority = 4, enabled =true )
	public void test4_getExecutionByIssueIdWithExecutionsInNonAdhoCycleOfUnscheduledversion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		//Create executions in Adhoc cycle and pass the issueId after executing
		
				Long ProjectID = Long.parseLong(Config.getValue("projectId"));
				Long VersionID = Long.parseLong(Config.getValue("unscheduleId"));
				// implement cycle with test executed to different statuses
				int numberOfExecutions = 1;

				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(ProjectID);
				cycleJson.setVersionId(VersionID);
				cycleJson.setName("ExecutionsInNonAdhoCycle");
				cycleJson.setDescription("Cycle for get executions");

				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(ProjectID));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				
				List<Long> issueKeys = new ArrayList<>() ;
				JSONArray jsarray3 = new JSONArray(issueResponse);
				for(int k= 0;k<jsarray3.length();k++){
			
					JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
					String issuekey= (String)jsobj3.get("key");
					
					System.out.println("*****key"+issuekey);
				
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(issueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
			
				//create executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(ProjectID);
				executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
				executionJson.setVersionId(VersionID);
				executionJson.setNoOfExecutions(numberOfExecutions);
				executionJson.setCycleId(cycleId);
				System.out.println(executionJson.toString());

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS,
						"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId = issueIds.get(j);
					executionJson.setIssueId(issueId);
					System.out.println(issueId);
					long StatusId = j+1;
					executionJson.setStatusId(StatusId);
					executionJson.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String issueKeys2 = "API-2" ; 
				
				String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
				System.out.println("qqq" +Payload2);
				
				Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
				System.out.println("qqq" +response22.asString());
				Assert.assertNotNull(response22, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
				
				Long issueId = issueIds.get(0);
				//issueId = 10000l;
				offset = 0;
				size = 10;

				Long issueIdOfStory = Long.parseLong(Config.getValue("issueIdOfStory"));
				System.out.println("story id is" +issueIdOfStory);
			
				Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOfStory, offset, size);
				
	//	Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	
	
	
	@Test(priority = 5, enabled =true )
	public void test5_getExecutionByIssueIdWithExecutionsFullyExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//Create executions in Adhoc cycle and pass the issueId after executing
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("ExecutionsFullyExecutedCycle");
		cycleJson.setDescription("Cycle for get executions");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		

		Long issueId = issueIds.get(1);
		//issueId = 10000l;
		offset = 0;
		size = 10;

		Long issueIdOfStory = Long.parseLong(Config.getValue("issueIdOfStory"));
		System.out.println("story id is" +issueIdOfStory);
	
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOfStory, offset, size);
	//	Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	
	
	
	@Test(priority = 6, enabled =true )
	public void test6_getExecutionByIssueIdWithExecutionsPartiallyExecuted(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		//Create executions in Adhoc cycle and pass the issueId after executing
		
				Long ProjectID = Long.parseLong(Config.getValue("projectId"));
				Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
				// implement cycle with test executed to different statuses
				int numberOfExecutions = 2;

				Cycle cycleJson = new Cycle();
				cycleJson.setProjectId(ProjectID);
				cycleJson.setVersionId(VersionID);
				cycleJson.setName("ExecutionsFullyExecutedCycle");
				cycleJson.setDescription("Cycle for get executions");

				Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
				Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
				test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
				boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
				Assert.assertTrue(status, "Response Validation Failed.");
				test.log(LogStatus.PASS, "Response validated successfully.");
				String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(ProjectID));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(issueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
			
				//create executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(ProjectID);
				executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
				executionJson.setVersionId(VersionID);
				executionJson.setNoOfExecutions(numberOfExecutions);
				executionJson.setCycleId(cycleId);
				System.out.println(executionJson.toString());

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS,
						"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length()-1;j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId = issueIds.get(j);
					executionJson.setIssueId(issueId);
					System.out.println(issueId);
					long StatusId = j+1;
					executionJson.setStatusId(StatusId);
					executionJson.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				

				Long issueId = issueIds.get(1);
				//issueId = 10000l;
				offset = 0;
				size = 10;
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	
	

	//TODO
	//Get executions by issue id with 50 executions
	@Test(priority = 7, enabled =false)
	public void test7_getExecutionByIssueIdWith50Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		

		//Create executions in Adhoc cycle and pass the issueId after executing
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 50;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("ExecutionsFullyExecutedCycle");
		cycleJson.setDescription("Cycle for get executions");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		String issueKeys2 = "API-2" ; 
		
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		Long issueId = issueIds.get(48);
		//issueId = 10000l;
		offset = 0;
		size = 10;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	
	//TODO
	//Get executions by issue id with 500 executions
	@Test(priority = 8, enabled =false)
	public void test8_getExecutionByIssueIdWith500Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");



		//Create executions in Adhoc cycle and pass the issueId after executing
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 500;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("ExecutionsFullyExecutedCycle");
		cycleJson.setDescription("Cycle for get executions");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		Long issueId = issueIds.get(490);
		//issueId = 10000l;
		offset = 0;
		size = 10;


		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	//TODO
	//Get executions by issue id with 1000 executions
	@Test(priority = 9, enabled = false)
	public void test9_getExecutionByIssueIdWith1000Executions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		//Create executions in Adhoc cycle and pass the issueId after executing
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed to different statuses
		int numberOfExecutions = 5;
	//	int numberOfExecutions = 1000; id user want 1000 executions
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("ExecutionsFullyExecutedCycle");
		cycleJson.setDescription("Cycle for get executions");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			System.out.println(issueId);
			long StatusId = j+1;
			executionJson.setStatusId(StatusId);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		
		Long issueId = issueIds.get(4998);
		//issueId = 10000l;
		offset = 0;
		size = 10;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	//TODO
	//Get executions by issue id and different execution status (I.e pass, fail, wip, blocked)
	@Test(priority = 10, enabled =true )
	public void test10_getExecutionByIssueIdWithDifferentExecutionStatus(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		//Create executions in Adhoc cycle and pass the issueId after executing
		
				Long ProjectID = Long.parseLong(Config.getValue("projectId"));
				Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
				// implement cycle with test executed to different statuses
			
				String cycleId = "-1";				
				
				// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(Config.getValue("projectId"));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("Test"+System.currentTimeMillis());
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				Response Createtestresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(Createtestresponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
				System.out.println("****Createtestresponse*"+Createtestresponse.asString());
				
				boolean status = jiraService.validateCreateIssueApi(Createtestresponse);
				Assert.assertTrue(status, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
				String issuekey =(String) new JSONObject(Createtestresponse.body().asString()).get("key");
		
				
			 for (int i=1; i<3; i++) {
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson.setIssueId(issueId);
				executionJson.setCycleId(cycleId);
				executionJson.setVersionId(Long.parseLong(Config.getValue("versionTwoId")));

				Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
				
				System.out.println("****createExecution*"+response.asString());
				
			//	issueId = Long.parseLong(new JSONObject(Createtestresponse.body().asString()).get("id").toString());
				//String exeid = new JSONObject(response.body().asString()).get("execution").toString();
				
				//to get id of execution
				JSONObject obj = (JSONObject) new JSONObject(response.body().asString()).get("execution");
				System.out.println("id of execution" + obj.getString("id"));
				String exeid = (obj.getString("id"));
			 
				executionJson.setIssueId(issueId);
				System.out.println(issueId);
				long StatusId = i+1;
				executionJson.setStatusId(StatusId);
				executionJson.setExecutionId(exeid);
	
			   //update executions
				Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
						executionJson.toString());
				Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
				System.out.println(updateExecutionResponse.getBody().asString());
				System.out.println("updated execution");
			 }
			 
	          //To create Issue link
				String issueKeys2 = "API-2" ; 
				String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
				System.out.println("qqq" +Payload2);
				
				Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
				System.out.println("qqq" +response22.asString());
				Assert.assertNotNull(response22, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		//		Long issueId = issueIds.get(1);
				//issueId = 10000l;
			//	issueId = 10031l;
				offset = 0;
				size = 10;
				
				Long issueIdOfStory = Long.parseLong(Config.getValue("issueIdOfStory"));
				System.out.println("story id is" +issueIdOfStory);
			
				Response response1 = zapiService.getExecutionsByIssue(jwtGenerator, issueIdOfStory, offset, size);

		//Response response1 = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response1, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response1.getBody().asString());
		boolean status11 = zapiService.validateGetExecutionsByIssue(response1, issueId, offset, size);
		Assert.assertTrue(status11, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
     
	}
	
	
	@Test(priority = 100, enabled =true )
	public void test100_getExecutionByIssueIdWithDifferentExecutionStatus(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		//Create executions in Adhoc cycle and pass the issueId after executing
		
				Long ProjectID = Long.parseLong(Config.getValue("projectId"));
				Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
				// implement cycle with test executed to different statuses
				int numberOfExecutions = 2;

				
				String cycleId = "-1";
				
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(ProjectID));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
				issuePayLoad.setSummary("test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter(Config.getValue("adminUserName"));

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				
				System.out.println("****issueResponse"+issueResponse.toString());
				
				List<Long> issueKeys = new ArrayList<>() ;
				JSONArray jsarray3 = new JSONArray(issueResponse);
				for(int k= 0;k<jsarray3.length();k++){
			
					JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
					String issuekey= (String)jsobj3.get("key");
					
					System.out.println("*****key"+issuekey);
				
				List<Long> issueIds = new ArrayList<>() ;
				JSONArray jsarray = new JSONArray(issueResponse);
				for(int i= 0;i<jsarray.length();i++){
			
					JSONObject jsobj = new JSONObject(jsarray.getString(i));
					Long l= Long.parseLong(jsobj.get("id").toString());
					issueIds.add(l);
				}
				System.out.println("*****"+issueIds);
			
				//create executions
				Execution executionJson = new Execution();
				executionJson.setStatusId(-1l);
				executionJson.setProjectId(ProjectID);
				executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
				executionJson.setVersionId(VersionID);
				executionJson.setNoOfExecutions(numberOfExecutions);
				executionJson.setCycleId(cycleId);
				System.out.println(executionJson.toString());

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS,
						"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId = issueIds.get(j);
					executionJson.setIssueId(issueId);
					System.out.println(issueId);
					long StatusId = j+1;
					executionJson.setStatusId(StatusId);
					executionJson.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String issueKeys2 = "API-2" ; 
				String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
				System.out.println("qqq" +Payload2);
				
				Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
				System.out.println("qqq" +response22.asString());
				Assert.assertNotNull(response22, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

				Long issueId = issueIds.get(1);
				//issueId = 10000l;
				offset = 0;
				size = 10;


		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	
	//TODO
	//Attempt to get executions by issue id, by passing invalid issueId
	@Test(priority = 11, enabled =true )
	public void test11_attemptTogetExecutionByIssueIdByPassingInvalidIssueId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
			
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		/*Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		int numberOfExecutions = 2;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");*/
		
		issueId = 99l;
		offset = 0;
		size = 10;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	

	//TODO
	//Attempt to get executions by issue id, passing issueId as null
	@Test(priority = 12, enabled =true )
	public void test12_attemptTogetExecutionByPassingIssueIdAsNull(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		/*String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");*/
		
		issueId = null;
		offset = 0;
		size = 10;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}	
	
	
	//TODO need to do changes on 13, 14 check it with below code
	//Attempt to getExecutions with issueId if there are no executions scheduled for that issue
	@Test(priority = 13, enabled =true )
	public void test13_attemptTogetExecutionByPassingIssueIdIfThereAreNoExecutionsScheduledForThatIssue(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response createResponse= jiraService.createIssue(basicAuth, issuePayLoad.toString());
		
		String issueid = new JSONObject(createResponse.body().asString()).get("id").toString();
		//issueId = 10518l;
		offset = 0;
		size = 10;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//getExectuions by issueId if there are defects and comments linked to the Execution Id
	@Test(priority = 14, enabled =true )
	public void test14_getExecutionByIssueIdWhenDefectsAndCommentsAreLinkedToExecutionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
			
		

		Long issueId = issueIds.get(1);
		//issueId = 10000l;
		offset = 0;
		size = 10;

		Response response1 = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response1, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	
	
	
	
	
	@Test(priority = 133, enabled = false )
	public void test133_attemptTogetExecutionByPassingIssueIdIfThereAreNoExecutionsScheduledForThatIssue(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response createResponse= jiraService.createIssue(basicAuth, issuePayLoad.toString());
		
		System.out.println(createResponse.getBody().asString());
		
		String issueid = new JSONObject(createResponse.body().asString()).get("id").toString();
		
		String issuekey =(String) new JSONObject(createResponse.body().asString()).get("key");
		
		//issueId = 10518l;
		offset = 0;
		size = 10;
		
		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueid, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//TODO
	//getExectuions by issueId if there are defects and comments linked to the Execution Id
	@Test(priority = 144, enabled =false )
	public void test144_getExecutionByIssueIdWhenDefectsAndCommentsAreLinkedToExecutionId(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		// implement cycle with test executed schedules having defect
		// links/comments/component/label
		int numberOfExecutions = 2;

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(ProjectID);
		cycleJson.setVersionId(VersionID);
		cycleJson.setName("Move Cycle");
		cycleJson.setDescription("Cycle moved");

		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();

		// Creating tests
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		
		//create defect to link		
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Bug Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
				
		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean issueStatus = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(issueStatus, "Response Validation Failed.");
		Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(bugId);
		
	
		//create executions
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(ProjectID);
		executionJson.setIssueIds(CommonUtils.getListAsLong(issueResponse, "id"));
		executionJson.setVersionId(VersionID);
		executionJson.setNoOfExecutions(numberOfExecutions);
		executionJson.setCycleId(cycleId);
		System.out.println(executionJson.toString());

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS,
				"Create multiple executions in scheduled version adhoc cycle(5 executions) successfully.");
		
		
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId = issueIds.get(j);
			executionJson.setIssueId(issueId);
			executionJson.setDefects(defectsList);
			System.out.println(issueId);
			executionJson.setStatusId(2l);
			executionJson.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
			
		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		

		Long issueId = issueIds.get(1);
		//issueId = 10000l;
		offset = 0;
		size = 10;

		Response response1 = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status1 = zapiService.validateGetExecutionsByIssue(response1, issueId, offset, size);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}
	}
	//Attempt to get executions by issue id, if the size is set to 51
	@Test(priority = 15, enabled =true )
	public void test15_attemptToGetExecutionsByIssueIdWhenSizeIsSetTo51(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response createResponse= jiraService.createIssue(basicAuth, issuePayLoad.toString());
		
		String issueid = new JSONObject(createResponse.body().asString()).get("id").toString();

		//issueId = 10000l;
		offset = 0;
		size = 51;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//FIXME
	//TODO
	//Attempt to get executions by issue id, if the offset is set to an invalid value
	@Test(priority = 16, enabled =true )
	public void test16_attemptToGetExecutionsByIssueIdIfOffsetIsSetToInvalidValue(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response createResponse= jiraService.createIssue(basicAuth, issuePayLoad.toString());
		
		String issueid = new JSONObject(createResponse.body().asString()).get("id").toString();
		
		String issuekey =(String) new JSONObject(createResponse.body().asString()).get("key");
		

		/*Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		int numberOfExecutions = 2;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		
		List<Long> issueKeys = new ArrayList<>() ;
		JSONArray jsarray3 = new JSONArray(issueResponse);
		for(int k= 0;k<jsarray3.length();k++){
	
			JSONObject jsobj3 = new JSONObject(jsarray3.getString(k));
			String issuekey= (String)jsobj3.get("key");
			
			System.out.println("*****key"+issuekey);
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(issueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);*/
	
		//issueId = 10000l;
		offset = 45644444;
		size = 10;
		
		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetExecution(response, projectId, issueId);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

	//FIXME
	//TODO
	/**
	 * Attempt to get executions by issue id, if the offset value is greater size
	 * ZAPICLOUD-66
	 */
	@Test(priority = 17, enabled =true )
	public void test17_attemptToGetExecutionsByIssueIdIfOffsetIsGreaterThenSize(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response createResponse= jiraService.createIssue(basicAuth, issuePayLoad.toString());
		
		String issueid = new JSONObject(createResponse.body().asString()).get("id").toString();

		//issueId = 10000l;
		offset = 20;
		size = 10;

		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		boolean status = zapiService.validateGetExecutionsByIssue(response, issueId, offset, size);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		extentReport.endTest(test);
	}

	//FIXME
	//TODO
	//Attempt to get Executions by projectId if the offset is greater than the number of excutions for the issue
	@Test(priority = 18, enabled =true )
	public void test18_attemptToGetExecutionsByIssueIdIfOffsetIsGreaterThanNumberOfExecutions(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");
		
		Long ProjectID = Long.parseLong(Config.getValue("projectId"));
		Long VersionID = Long.parseLong(Config.getValue("versionOneId"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(ProjectID));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response createResponse= jiraService.createIssue(basicAuth, issuePayLoad.toString());
		
		String issueid = new JSONObject(createResponse.body().asString()).get("id").toString();
		String issuekey =(String) new JSONObject(createResponse.body().asString()).get("key");
		
		//issueId = 10000l;
		offset = 9999999;
		size = 10;

		String issueKeys2 = "API-2" ; 
		String Payload2 = "{\"type\":{\"id\":\"10000\"},\"inwardIssue\":{\"key\":\""+issuekey+"\"},\"outwardIssue\":{\"key\":\""+issueKeys2+"\"}}";
		System.out.println("qqq" +Payload2);
		
		Response response22 = jiraService.createIssueLink(basicAuth, Payload2);
		System.out.println("qqq" +response22.asString());
		Assert.assertNotNull(response22, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
		
		
		Response response = zapiService.getExecutionsByIssue(jwtGenerator, issueId, offset, size);
		Assert.assertNotNull(response, "Get Executions By Issue Api Response is null.");
		test.log(LogStatus.PASS, "Get Executions By Issue Api executed successfully.");
		System.out.println(response.getBody().asString());
		//		boolean status = zapiService.validateGetExecution(response, issueId);
		//		Assert.assertTrue(status, "Response Validation Failed.");
		//		test.log(LogStatus.PASS, "Response validated successfully.");
		//		extentReport.endTest(test);
	}

}
