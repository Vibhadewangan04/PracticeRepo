/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira.impl;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.api.jira.ProjectApi;
import com.thed.zephyr.api.jira.UserApi;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
@Service("userApi")
public class UserApiImpl implements UserApi {
	@Override
	public Response getUsersFromPicker(RequestSpecification basicAuth, String query, int offset, int maxResults, boolean showAvatar, String exclude){
		 String api = "/rest/api/2/user/search";
//		 Map<String, String> headers = new HashMap<String, String>();
//		 headers.put("Content-Type", "application/json");
		 return basicAuth.queryParam("offset", offset).queryParam("maxResults", maxResults)
				 .queryParam("showAvatar", showAvatar).when().get(api);
//		 return basicAuth.queryParam("query", query).queryParam("offset", offset).queryParam("maxResults", maxResults)
//				 .queryParam("showAvatar", showAvatar).queryParam("exclude", exclude).when().get(api);
	 }
//	@Override
//	public Response getUsersFromPicker(RequestSpecification basicAuth){
//		 String api = "/rest/api/2/project";
////		 Map<String, String> headers = new HashMap<String, String>();
////		 headers.put("Content-Type", "application/json");
//		 return basicAuth.queryParam("query", query).queryParam("offset", offset).queryParam("maxResults", maxResults)
//				 .queryParam("showAvatar", showAvatar).queryParam("exclude", exclude).when().get(api);
//	 }
}
