/**
 * Created by manoj.behera on 19-Nov-2016.
 */
package com.thed.zephyr.regression.teststep;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 19-Nov-2016
 *
 */
public class CreateTeststepApi extends BaseTest{

//	JwtGenerator jwtGenerator = null;
      private Long projectId = Long.parseLong(Config.getValue("projectId")); 
      private Long issueId;
      Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
      
	 @BeforeClass
	 public void beforeClass(){
		 
//	  jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	  
	  	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).get("id").toString());
	 }
	 /**
		 * creating teststep
		 */
		
		//Create test step with step, data and results
		@Test(priority = 1, enabled = true)
		public void test1_createTeststep_with_stepDataAndResult(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step values
			String stepValue = "A";
			String dataValue = "B";
			String resultValue = "C"; 
			
			Teststep teststepJson = new Teststep();
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			System.out.println("payload-->"+ teststepJson.toString());
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Test Step Api Response is null.");
			test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
			System.out.println(response.getBody().asString());
			
			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//Create test step with only test step
		@Test(priority = 2, enabled = true)
		public void test2_createTeststep_with_only_step(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step values
			String stepValue = "A";
			
			Teststep teststepJson = new Teststep();
			teststepJson.setStep(stepValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//Create test step with only test data
		@Test(priority = 3, enabled = true)
		public void test3_createTeststep_with_only_testData(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			String dataValue = "only data";
			Teststep teststepJson = new Teststep();
			teststepJson.setData(dataValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//Create test step with only expected result
		@Test(priority = 4, enabled = true)
		public void test4_createTeststep_with_only_ExpectedResult(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			String resultData = "only result";
			Teststep teststepJson = new Teststep();
			teststepJson.setResult(resultData);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//Create test step with only step and data
		@Test(priority = 5, enabled = true)
		public void test5_createTeststep_with_stepAndData(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			String stepValue = "step";
			String dataValue = "data";
			Teststep teststepJson = new Teststep();
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//Create test step with only data and results
		@Test(priority = 6, enabled = true)
		public void test6_createTeststep_with_dataAndResult(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			String dataValue = "data";
			String resultValue = "result";
			Teststep teststepJson = new Teststep();		
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//Create test step with only step and results
		@Test(priority = 7, enabled = true)
		public void test7_createTeststep_with_stepAndResult(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			String stepValue = "step";
			String resultValue = "result";
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//Only capital letters in steps
		@Test(priority = 8, enabled = true)
		public void test8_createTeststep_with_capitalLetters(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values
			String stepValue = "AAAA";
			String dataValue = "BBBB";
			String resultValue = "CCCC";
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//only small letters in steps
		@Test(priority = 9, enabled = true)
		public void test9_createTeststep_with_smallLetters(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values
			String stepValue = "aaaa";
			String dataValue = "bbbb";
			String resultValue = "cccc";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//alphanumeric characters
		@Test(priority = 10, enabled = true)
		public void test10_createTeststep_with_AlphaNumeric_char(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values
			String stepValue = "ASD34";
			String dataValue = "MKO45";
			String resultValue = "OPI987";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//Only numbers
		@Test(priority = 11, enabled = true)
		public void test11_createTeststep_with_only_Numbers(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values
			String stepValue = "1234";
			String dataValue = "345";
			String resultValue = "987";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//special characters
		@Test(priority = 12, enabled = true)
		public void test12_createTeststep_with_Special_Char(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
	
			//Step Values
			String stepValue = "!@#";
			String dataValue = "&&*";
			String resultValue = "987#$$%^";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//international characters
		@Test(priority = 13, enabled = true)
		public void test13_createTeststep_with_international_char(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
//		Long character name		
		@Test(priority = 14, enabled = true)
		public void test14_createTeststep_with_long_name(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values only English supported languages
			String stepValue = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa mjopiu";
			String dataValue = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa mjopiu";
			String resultValue = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa mjopiu";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}


		//Existing steps
		@Test(priority = 15, enabled = true)
		public void test15_createTeststep_when_existing_steps(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
		
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		


		//Create test step by passing no body to create step, data and result values
		@Test(priority = 16)
		public void test16_createTeststep_with_emptyData(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
	
			Teststep teststepJson = new Teststep();		
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//Multiple steps
		@Test(priority = 17, enabled = true)
		public void test17_createTeststep_multipleSteps_sameData(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "abc";
			String dataValue = "jjj";
			String resultValue = "kkk";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			for (int i = 0; i < 20; i++) {
				Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());

				boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
			}
			
		}
		

	 @Test(priority = 18, enabled = true)
	 public void test18_createTeststep_wiki1(){
		
	  ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	  test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	  test.assignAuthor("Manoj");
	 
	  Teststep teststepJson = new Teststep();
	  teststepJson.setStep("h1. Biggest heading");
	  teststepJson.setData("h1. Hey");
	  teststepJson.setResult("h1. Hello");
	  
	  Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	  Assert.assertNotNull(response, "create test step response is null");
	  test.log(LogStatus.PASS, "Create Test Step Api executed successfully.");
	  System.out.println(response.getBody().asString());

	  boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	  Assert.assertTrue(status);
	  test.log(LogStatus.PASS, "Response validated suuccessfully.");
	  extentReport.endTest(test);
	 }
	 
	  @Test(priority = 19, enabled = true)
	  public void test19_createTeststep_wiki2(){
	  ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	  test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	  test.assignAuthor("Manoj");
	 
	  Teststep teststepJson = new Teststep();
	  teststepJson.setStep("h2. Bigger heading");
	  teststepJson.setData("h2. Hi");
	  teststepJson.setResult("h2. Dude");
	  
	  System.out.println(teststepJson);
	  Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	  Assert.assertNotNull(response, "Create Execution Api Response is null.");
	  test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	  System.out.println(response.getBody().asString());

	  boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	  Assert.assertTrue(status);
	  test.log(LogStatus.PASS, "Response validated suuccessfully.");
	  extentReport.endTest(test);
	 }
	 
	 @Test(priority = 20, enabled = true)
	 public void test20_createTeststep_wiki3(){
	  ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	  test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	  test.assignAuthor("Manoj");
	  
	  Teststep teststepJson = new Teststep();
	  teststepJson.setStep("h3. Big heading");
	  teststepJson.setData("h3. Hello");
	  teststepJson.setResult("h3. Buddy");
	  
	  System.out.println(teststepJson);
	  Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	  Assert.assertNotNull(response, "Create Execution Api Response is null.");
	  test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	  System.out.println(response.getBody().asString());

	  boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	  Assert.assertTrue(status);
	  test.log(LogStatus.PASS, "Response validated suuccessfully.");
	  extentReport.endTest(test);
	 }
	  
	  @Test(priority = 21, enabled = true)
	  public void test21_createTeststep_wiki4(){
	   ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	   test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	   test.assignAuthor("Manoj");
	
	   Teststep teststepJson = new Teststep();
	   teststepJson.setStep("h4. Normal heading");
	   teststepJson.setData("h4. Hello world");
	   teststepJson.setResult("h4. Hi Everyone");
	   
	   System.out.println(teststepJson);
	   Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	   Assert.assertNotNull(response, "Create Execution Api Response is null.");
	   test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	   System.out.println(response.getBody().asString());

	   boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	   Assert.assertTrue(status);
	   test.log(LogStatus.PASS, "Response validated suuccessfully.");
	   extentReport.endTest(test);
	  }
	   
	   @Test(priority = 22, enabled = true)
	   public void test22_createTeststep_wiki5(){
	    ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	    test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	    test.assignAuthor("Manoj");
	    
	    Teststep teststepJson = new Teststep();
	    teststepJson.setStep("h5. Small heading");
	    teststepJson.setData("h5. Good morning");
	    teststepJson.setResult("h5. how are u");
	    
	    System.out.println(teststepJson);
	    Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	    Assert.assertNotNull(response, "Create Execution Api Response is null.");
	    test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	    System.out.println(response.getBody().asString());

	    boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	    Assert.assertTrue(status);
	    test.log(LogStatus.PASS, "Response validated suuccessfully.");
	    extentReport.endTest(test);
	   }

	    @Test(priority = 23, enabled = true)
	    public void test23_createTeststep_wiki6(){
	     ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	     test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	     test.assignAuthor("Manoj");
	     
	     Teststep teststepJson = new Teststep();
	     teststepJson.setStep("h6. Smallest heading");
	     teststepJson.setData("h6. bye");
	     teststepJson.setResult("h6. Good Night");
	     
	     System.out.println(teststepJson);
	     Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	     Assert.assertNotNull(response, "Create Execution Api Response is null.");
	     test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	     System.out.println(response.getBody().asString());

	     boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	     Assert.assertTrue(status);
	     test.log(LogStatus.PASS, "Response validated suuccessfully.");
	     extentReport.endTest(test);
	    }
	     
	     @Test(priority = 24, enabled = true)
	     public void test24_createTeststep_wikiStrong(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	     
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("*strong*");
	      teststepJson.setData("*alphabet in strong case*");
	      teststepJson.setResult("*Hehehe*");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	      
	      // _emphasis_
	      @Test(priority = 25, enabled = true)
	      public void test25_createTeststep_wikiEmphasis(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	   
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("_emphasis_");
	       teststepJson.setData("_Java programmimg_");
	       teststepJson.setResult("_c++ programmimg_");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //??citation??
	      @Test(priority = 26, enabled = true)
	      public void test26_createTeststep_wikiCitation(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	       
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("??citation??");
	       teststepJson.setData("??Zapi technology??");
	       teststepJson.setResult("??zephyr,bangalore??");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //-deleted-
	      @Test(priority = 27, enabled = true)
	      public void test27_createTeststep_wikiDeleted(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	     
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("-deleted-");
	       teststepJson.setData("-test cases to delete-");
	       teststepJson.setResult("-facebook-");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //+inserted+
	      @Test(priority = 28, enabled = true)
	      public void test28_createTeststep_wikiInserted(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	    
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("+inserted+");
	       teststepJson.setData("+underline the points+");
	       teststepJson.setResult("+important notes+");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //^superscript^
	      @Test(priority = 29, enabled = true)
	      public void test29_createTeststep_wikiSuperscript(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	     
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("^2^ 3");
	       teststepJson.setData("10 ^2^");
	       teststepJson.setResult("7 ^3^ 4");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //~subscript~
	      @Test(priority = 30, enabled = true)
	      public void test30_createTeststep_wikiSubscript(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	   
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("~2~ 3");
	       teststepJson.setData("10 ~2~");
	       teststepJson.setResult("7 ~3~ 4");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //Some block quoted text
	      @Test(priority = 31, enabled = true)
	      public void test31_createTeststep_wikiBlockQuotedText(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	   
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("bq. test step");
	       teststepJson.setData("bq. test data");
	       teststepJson.setResult("bq. step result");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //quote a block of text
	      @Test(priority = 32, enabled = true)
	      public void test32_createTeststep_wikiBlockQuotedText2(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	  
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("{quote}here is quotable content to be quoted {quote}");
	       teststepJson.setData("{quote}here is quotable content to be quoted {quote}");
	       teststepJson.setResult("{quote}here is quotable content to be quoted {quote}");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //text in different color
	      @Test(priority = 33, enabled = true)
	      public void test33_createTeststep_wikiColorText(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	  
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("{color:red}look ma, red text!{color}");
	       teststepJson.setData("{color:blue}look ma, blue text!{color}");
	       teststepJson.setResult("{color:yellow}yellow text!{color}");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      // ----creates a horizontal line
	      @Test(priority = 34, enabled = true)
	      public void test34_createTeststep_wikiHorizontalLine(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("----creates a horizontal line");
	       teststepJson.setData("----creates a horizontal line");
	       teststepJson.setResult("----creates a horizontal line");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	      //Produces � symbol.
	      @Test(priority = 35, enabled = true)
	      public void test35_createTeststep_wikiProducesHifenSymbol(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	       
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("---produces hifen symbol");
	       teststepJson.setData("---produces hifen symbol");
	       teststepJson.setResult("---produces hifen symbol");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	      
	    // add link in step
	    @Test(priority = 36, enabled = true)
	      public void test36_createTeststep_wikiLink(){
	       ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	       test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	       test.assignAuthor("Manoj");
	       
	       Teststep teststepJson = new Teststep();
	       teststepJson.setStep("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
	       teststepJson.setData("[Atlassian|http://atlassian.com]");
	       teststepJson.setResult("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
	       
	       System.out.println(teststepJson);
	       Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	       Assert.assertNotNull(response, "Create Execution Api Response is null.");
	       test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	       System.out.println(response.getBody().asString());

	       boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	       Assert.assertTrue(status);
	       test.log(LogStatus.PASS, "Response validated suuccessfully.");
	       extentReport.endTest(test);
	      }
	    
	    // bullet points
	    @Test(priority = 37, enabled = true)
	    public void test37_createTeststep_wikiBulletPoints(){
	     ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	     test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	     test.assignAuthor("Manoj");
	     
	     Teststep teststepJson = new Teststep();
	     teststepJson.setStep("* some\n* bullet\n* points");
	     teststepJson.setData("* Whatsup app\n* facebook\n* Twitter");
	     teststepJson.setResult("* java programming language\n* c++\n* Ruby and Pythan");
	     
	     System.out.println(teststepJson);
	     Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	     Assert.assertNotNull(response, "Create Execution Api Response is null.");
	     test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	     System.out.println(response.getBody().asString());

	     boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	     Assert.assertTrue(status);
	     test.log(LogStatus.PASS, "Response validated suuccessfully.");
	     extentReport.endTest(test);
	    }
	    
	    // with numbered list
	    @Test(priority = 38, enabled = true)
	    public void test38_createTeststep_wikiNumberedList(){
	     ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	     test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	     test.assignAuthor("Manoj");
	     
	     Teststep teststepJson = new Teststep();
	     teststepJson.setStep("# a\n# numbered\n# list");
	     teststepJson.setData("# Zapi\n# Zapi Technology,banglore\n# Vlcc building");
	     teststepJson.setResult("# Zephyr\n# Zfjcloud\n# Zee and Zfj");
	     
	     System.out.println(teststepJson);
	     Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	     Assert.assertNotNull(response, "Create Execution Api Response is null.");
	     test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	     System.out.println(response.getBody().asString());

	     boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	     Assert.assertTrue(status);
	     test.log(LogStatus.PASS, "Response validated suuccessfully.");
	     extentReport.endTest(test);
	    }
	    
	    //create a line break
	    @Test(priority = 39, enabled = true)
	    public void test39_createTeststep_wikiLineBreak(){
	     ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	     test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	     test.assignAuthor("Manoj");
	     
	     Teststep teststepJson = new Teststep();
	     teststepJson.setStep("Hello\\\\good morning");
	     teststepJson.setData("Hello\\\\world");
	     teststepJson.setResult("Hi\\\\everyone");
	     
	     System.out.println(teststepJson);
	     Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	     Assert.assertNotNull(response, "Create Execution Api Response is null.");
	     test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	     System.out.println(response.getBody().asString());

	     boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	     Assert.assertTrue(status);
	     test.log(LogStatus.PASS, "Response validated suuccessfully.");
	     extentReport.endTest(test);
	    }
	    
	    //inserting an image to test step
	     @Test(priority = 40, enabled = true)
	        public void test40_createTeststep_wikiWithImage(){
	         ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	         test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	         test.assignAuthor("Manoj");
	         
	         Teststep teststepJson = new Teststep();
	         teststepJson.setStep("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
	         teststepJson.setData("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
	         teststepJson.setResult("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
	         
	         System.out.println(teststepJson);
	         Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	         Assert.assertNotNull(response, "Create Execution Api Response is null.");
	         test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	         System.out.println(response.getBody().asString());

	         boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	         Assert.assertTrue(status);
	         test.log(LogStatus.PASS, "Response validated suuccessfully.");
	         extentReport.endTest(test);
	        }
	     
	     //insert table in test step
	     @Test(priority = 41, enabled = true)
	     public void test41_createTeststep_withInsertTable(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
	      teststepJson.setData("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
	      teststepJson.setResult("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     // insert E-mail link
	     @Test(priority = 42, enabled = true)
	     public void test42_createTeststep_withEmailLink(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("[mailto:legendaryservice@atlassian.com]");
	      teststepJson.setData("[mailto:legendaryservice@atlassian.com]");
	      teststepJson.setResult("[mailto:legendaryservice@atlassian.com]");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     
	     // insert empty line
	     @Test(priority = 43, enabled = true)
	     public void test43_createTeststep_withEmptyLine(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("paragraph1\n\nparagraph2");
	      teststepJson.setData("paragraph1\n\nparagraph2");
	      teststepJson.setResult("paragraph1\n\nparagraph2");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     
	     //insert to escape special characters
	     @Test(priority = 44, enabled = true)
	     public void test44_createTeststep_withEscapeChar(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("\\* a\n\\* b");
	      teststepJson.setData("\\* a\n\\* b");
	      teststepJson.setResult("\\* a\n\\* b");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     
	     // insert different types wiki
	     @Test(priority = 45, enabled = true)
	     public void test45_createTeststep_withdifferentWiki1(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("-deleted-");
	      teststepJson.setData("||heading 1||heading 2||heading 3||\n|col A1|col A2|col A3|\n|col B1|col B2|col B3|");
	      teststepJson.setResult("h2. Bigger heading");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     
	     // insert different types wiki
	     @Test(priority = 46, enabled = true)
	     public void test46_createTeststep_withdifferentWiki2(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("* some\n* bullet\n* points");
	      teststepJson.setData("!http://www.planwallpaper.com/static/images/Winter-Tiger-Wild-Cat-Images.jpg!");
	      teststepJson.setResult("[http://jira.atlassian.com]\n[Atlassian|http://atlassian.com]");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     
	     // insert different types wiki
	     @Test(priority = 47, enabled = true)
	     public void test47_createTeststep_withdifferentWiki3(){
	      ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	      test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	      test.assignAuthor("Manoj");
	      
	      Teststep teststepJson = new Teststep();
	      teststepJson.setStep("{color:green}look ma, green text!{color}");
	      teststepJson.setData("# a\n# numbered\n# list");
	      teststepJson.setResult("[mailto:legendaryservice@atlassian.com]");
	      
	      System.out.println(teststepJson);
	      Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
	      Assert.assertNotNull(response, "Create Execution Api Response is null.");
	      test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	      System.out.println(response.getBody().asString());

	      boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
	      Assert.assertTrue(status);
	      test.log(LogStatus.PASS, "Response validated suuccessfully.");
	      extentReport.endTest(test);
	     }
	     
			//Attempt to add test step in bug issue type
			@Test(priority = 48, enabled = true)
			public void test48_attempt_to_createTeststep_for_issueType_Bug(){
				ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
				test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
				test.assignAuthor("Manoj");

				// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
				issuePayLoad.setSummary("Bug");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");

				Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
				Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

				boolean createIssuestatus = jiraService.validateCreateIssueApi(createIssueresponse);
				Assert.assertTrue(createIssuestatus, "Response Validation Failed.");
				issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
			 
				//Step Values only English supported languages
				String stepValue = "ndryshoje";
				String dataValue = "ndryshoje";
				String resultValue = "ndryshoje";
				
				Teststep teststepJson = new Teststep();		
				teststepJson.setStep(stepValue);
				teststepJson.setData(dataValue);
				teststepJson.setResult(resultValue);
				
				Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
				Assert.assertNotNull(response, "Create Execution Api Response is null.");
				test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
				System.out.println(response.getBody().asString());

				boolean status = zapiService.validateInvalidIssueTypeId(response);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated suuccessfully.");
				extentReport.endTest(test);
			}
			
	   //Attempt to add test step in improvement issue type
	 	@Test(priority = 49, enabled = true)
	 	public void test49_attempt_to_createTeststep_for_issueType_Improvement(){
	 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");

			// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeImprovementId"));
			issuePayLoad.setSummary("Improvement");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");

			Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			boolean createIssuestatus = jiraService.validateCreateIssueApi(createIssueresponse);
			Assert.assertTrue(createIssuestatus, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
		 
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidIssueTypeId(response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	 	}
	 	
	 	//Attempt to add test step in task issue type
	 	@Test(priority = 50, enabled = true)
	 	public void test50_attempt_to_createTeststep_for_issueType_Task(){
	 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");

			// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTaskId"));
			issuePayLoad.setSummary("Task");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");

			Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			boolean createIssuestatus = jiraService.validateCreateIssueApi(createIssueresponse);
			Assert.assertTrue(createIssuestatus, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
		 
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidIssueTypeId(response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	 	}

	 	//Attempt to add test step in New Feature issue type
	 	@Test(priority = 51, enabled = true)
	 	public void test51_attempt_to_createTeststep_for_issueType_NewFeature(){
	 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");

			// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeNewFetureId"));
			issuePayLoad.setSummary("NewFeture");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");

			Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			boolean createIssuestatus = jiraService.validateCreateIssueApi(createIssueresponse);
			Assert.assertTrue(createIssuestatus, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
		 
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidIssueTypeId(response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	 	}

	 	//Attempt to add test step in Custom issue type
	 	@Test(priority = 52, enabled = true)
	 	public void test52_attempt_to_createTeststep_for_issueType_Custom(){
	 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");

			// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeUserDefinedId"));
			issuePayLoad.setSummary("Custom");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");

			Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

			boolean createIssuestatus = jiraService.validateCreateIssueApi(createIssueresponse);
			Assert.assertTrue(createIssuestatus, "Response Validation Failed.");
			issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
		 
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidIssueTypeId(response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
	 	}

	 	//Attempt to add test step in Sub-task issue type
	 	@Test(priority = 53, enabled = true)
	 	public void test53_attempt_to_createTeststep_for_issueType_SubTask(){
	 		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	 		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
	 		test.assignAuthor("Manoj");
	 	// Creating defect
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTaskId"));
			issuePayLoad.setSummary("Task Summary " + System.currentTimeMillis());
			issuePayLoad.setPriority("1");
			//issuePayLoad.setparent(Config.getValue("issueKey"));
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad.toString());
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			//
			boolean issueStatus = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long bugId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
			String bugissueKey = new JSONObject(response.body().asString()).getString("key");
			
			// Creating subtask
			Issue issuePayLoad1 = new Issue();
			issuePayLoad1.setProject(Config.getValue("projectId"));
			issuePayLoad1.setIssuetype(Config.getValue("issueTypeSubTaskId"));
			issuePayLoad1.setSummary("Sub task Summary " + System.currentTimeMillis());
			issuePayLoad1.setPriority("1");
			issuePayLoad1.setparent(bugissueKey);
			issuePayLoad1.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad1.toString());
			Response response1 = jiraService.createIssue(basicAuth, issuePayLoad1.toString());
			Assert.assertNotNull(response1, "Create Issue Api Response is null.");
			//
			boolean issueStatus1 = jiraService.validateCreateIssueApi(response1);
			Assert.assertTrue(issueStatus1, "Response Validation Failed.");
			Long subtaskid = Long.parseLong(new JSONObject(response1.body().asString()).getString("id"));
	 		
	 		//Step Values only English supported languages
	 		String stepValue = "ndryshoje";
	 		String dataValue = "ndryshoje";
	 		String resultValue = "ndryshoje";
	 		
	 		Teststep teststepJson = new Teststep();		
	 		teststepJson.setStep(stepValue);
	 		teststepJson.setData(dataValue);
	 		teststepJson.setResult(resultValue);
	 		
	 		Response createteststepresponse = zapiService.createTeststep(jwtGenerator, projectId, subtaskid, teststepJson.toString());
	 		Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
	 		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	 		System.out.println(response.getBody().asString());

	 		boolean status = zapiService.validateCreateTestStepOtherIssueType(projectId, subtaskid, teststepJson.toString(), createteststepresponse);
	 		Assert.assertTrue(status);
	 		test.log(LogStatus.PASS, "Response validated suuccessfully.");
	 		extentReport.endTest(test);
	 	}
		
	//Create multiple Empty test steps 
	 	@Test(priority = 54, enabled = true)
	 	public void test54_create_multiple_Empty_testSteps(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			// Creating Test issue Type
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("Created Test Summary " + System.currentTimeMillis());
			issuePayLoad.setPriority("1");			
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad.toString());
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			//
			boolean issueStatus = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long Testissueid = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
			
			
			Teststep teststepJson = new Teststep();
			teststepJson.setNoOfTeststeps(5);
			
			JSONArray createteststepresponse = zapiService.createTeststeps(jwtGenerator, projectId, Testissueid, teststepJson.toString());
			Assert.assertNotNull(createteststepresponse, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
//			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateTeststepsWithData(projectId, Testissueid, teststepJson.toString(), createteststepresponse);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 	//create multiple Test steps with data
	 	@Test(priority = 55, enabled = true)
	 	public void test55_create_multiple_Teststeps_WithData(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			// Creating Test issue Type
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(Config.getValue("projectId"));
			issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
			issuePayLoad.setSummary("Created Test Summary " + System.currentTimeMillis());
			issuePayLoad.setPriority("1");			
			issuePayLoad.setReporter(Config.getValue("adminUserName"));
			System.out.println(issuePayLoad.toString());
			Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
			Assert.assertNotNull(response, "Create Issue Api Response is null.");
			//
			boolean issueStatus = jiraService.validateCreateIssueApi(response);
			Assert.assertTrue(issueStatus, "Response Validation Failed.");
			Long Testissueid = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
			
			List<String> step = new ArrayList<>();
			step.add("step 1");
			step.add("step 2");
			step.add("step 3");
			List<String> stepData = new ArrayList<>();
			stepData.add("stepData 1");
			stepData.add("stepData 2");
			stepData.add("stepData 3");
			List<String> stepRes = new ArrayList<>();
			stepRes.add("stepRes 1");
			stepRes.add("stepRes 2");
			stepRes.add("stepRes 3");
			Teststep teststepJson = new Teststep();
			teststepJson.setStepList(step);
			teststepJson.setDataList(stepData);
			teststepJson.setResultList(stepRes);
			System.out.println("Request PayLoad: "+teststepJson.toString());
			
			JSONArray createTeststepsresponse = zapiService.createTeststeps(jwtGenerator, projectId, Testissueid, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println("Response: "+response);	
			
			boolean status = zapiService.validateTeststepsWithData(projectId, Testissueid, teststepJson.toString(), createTeststepsresponse);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
			
		}
		
		//invalid issue id
	 	@Test(priority = 56, enabled = true)
	 	public void test56_attempt_to_createTeststep_with_invalid_issueId(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			
			Long invalidIssueId = 15544l;
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, invalidIssueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidIssueId(invalidIssueId, response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
		
		//Invalid project id
	 	@Test(priority = 57, enabled = true)
	 	public void test57_attempt_to_createTeststep_with_invalid_projectId(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			Long invalidProjectId = 145544l;
			
			Response response = zapiService.createTeststep(jwtGenerator, invalidProjectId, issueId, teststepJson.toString());
			System.out.println(response.getBody().asString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidProjectId(invalidProjectId, response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

		//Invalid ProjectId and invalid issueId and projectId
	 	@Test(priority = 58, enabled = true)
	 	public void test58_attempt_to_createTeststep_with_invalid_issueId_and_projectId(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");	
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			Long invalidProjectId = 145544l;
			Long invalidIssueId = 15544l;
			
			Response response = zapiService.createTeststep(jwtGenerator, invalidProjectId, invalidIssueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			boolean status = zapiService.validateInvalidProjectIdForCreateTestStep(invalidProjectId, response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 	
	 	//Null ProjectId
	 	@Test(priority = 59, enabled = true)
	 	public void test59_attempt_to_createTeststep_with_projectId_null(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			Long projectId = null;
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			//boolean status = zapiService.validateTeststepWithProjectIdNull(projectId, issueId, teststepJson.toString(), response);
			boolean status = zapiService.validateInvalidProjectId(projectId, response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 	
	 	// ProjectId 0
	 	@Test(priority = 60, enabled = true)
	 	public void test60_attempt_to_createTeststep_with_projectId_zero(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			Long projectId = 0l;
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			//boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			boolean status = zapiService.validateInvalidProjectId(projectId, response);
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 	
	 	//Null issueID
	 	@Test(priority = 61, enabled = true)
	 	public void test61_attempt_to_createTeststep_with_issueId_null(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			Long issueId = null;
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			//boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			boolean status = zapiService.validateInvalidIssueId(issueId, response);
			//clientMessage":"Cannot parse parameter issueId as Long: For input string:
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}
	 	
	 	//issueID 0
	 	@Test(priority = 62, enabled = true)
	 	public void test62_attempt_to_createTeststep_with_issueId_Zero(){
			ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
			test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
			test.assignAuthor("Manoj");
			
			//Step Values only English supported languages
			String stepValue = "ndryshoje";
			String dataValue = "ndryshoje";
			String resultValue = "ndryshoje";
			
			Teststep teststepJson = new Teststep();		
			teststepJson.setStep(stepValue);
			teststepJson.setData(dataValue);
			teststepJson.setResult(resultValue);
			Long issueId = 0l;
			
			Response response = zapiService.createTeststep(jwtGenerator, projectId, issueId, teststepJson.toString());
			Assert.assertNotNull(response, "Create Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
			System.out.println(response.getBody().asString());

			//boolean status = zapiService.validateTeststep(projectId, issueId, teststepJson.toString(), response);
			boolean status = zapiService.validateInvalidIssueId(issueId, response);
			//"clientMessage":"issueId field value is null or 0 is not valid."
			Assert.assertTrue(status);
			test.log(LogStatus.PASS, "Response validated suuccessfully.");
			extentReport.endTest(test);
		}

}
