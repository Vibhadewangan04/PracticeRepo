/**
 * Created by manoj.behera on 15-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.StepresultsApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 15-Nov-2016
 *
 */
@Service("stepresultsApi")
public class StepresultsApiImpl implements StepresultsApi {
	
	@Override
	public Response getStepResult(JwtGenerator jwtGenerator, String executionId, String stepResultId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/stepresult/"+stepResultId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("executionId", executionId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri);
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getStepResults(JwtGenerator jwtGenerator, Long issueId, String executionId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/stepresult/search";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("issueId", issueId).queryParam("executionId", executionId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getStepDefectsByExecutionId(JwtGenerator jwtGenerator, Long projectId, String executionId) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/stepdefect/byexecution";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("projectId", projectId).queryParam("executionId", executionId).queryParam("expand", "executionStatus").build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response getStepResultByStatus(JwtGenerator jwtGenerator, int statusId, int offset, int maxResults) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/stepresult/search/status/"+statusId;
		URI uri = UriBuilder.fromUri(uriStr).queryParam("offset", offset).queryParam("maxResults", maxResults).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
//		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response updateStepResult(JwtGenerator jwtGenerator, String stepResultId, String payLoad) {
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/stepresult/"+stepResultId;
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("PUT", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().put(uri);
	}
	
}
