// add test to cycle

package com.thed.zephyr.regression.execution;

import java.net.URISyntaxException;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.response.ResponseOptions;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

public class AddTestsToCycleIndividually extends BaseTest {
	
	String cycleId = null;
	String issueKey = null;
	Long versionId = null;
	  private Long projectId = Long.parseLong(Config.getValue("projectId")); 
	  private Long projectId1 = Long.parseLong(Config.getValue("projectId1")); 
      private Long issueId;
      Long issueTypeId = Long.parseLong(Config.getValue("issueTypeTestId"));
      Long issueTypeId1 = Long.parseLong(Config.getValue("issueTypeStoryId"));
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add individual tests to a cycle in a version of a project
	 */
	
	@Test(priority = 1)
	public void addTestsTocycle_test1(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

		Response createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");

		boolean status1 = jiraService.validateCreateIssueApi(createIssueresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
	//	issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
		//get test issue id then pass in payload
		String issueid = new JSONObject(createIssueresponse.body().asString()).get("id").toString();
		System.out.println("qqqresponse" + createIssueresponse.toString());
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
				 
	
	//	String cycleId = "0001479971459664-242ac1122-0001";
//	String payLoad = "{\"issues\":[\"TRAC-11\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
//	String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":-1,\"projectId\":"+ projectId + ",\" \"method\":\"1\"}";
		String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
//	String payLoad = "{\"issues\":[+ issueid+],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}"; - wrong
	//	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple tests to a cycle in a version of a project
	 */
	
	//@Test(priority = 2)
/*	public void addTestsTocycle_test2(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		Response createIssueresponse = null;
		// creating issue - Test
		for (int i = 0; i < 3; i++) {
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");

	 createIssueresponse = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(createIssueresponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Create Issue Api executed successfully.");
	
		boolean status1 = jiraService.validateCreateIssueApi(createIssueresponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		}
		//issueId = Long.parseLong(new JSONObject(createIssueresponse.body().asString()).get("id").toString());
		//get test issue id then pass in payload
		String issueid = new JSONObject(createIssueresponse.body().asString()).get("id").toString();
		System.out.println("qqqresponse" + createIssueresponse.toString());
		
		
		System.out.println(createIssueresponse.asString());
		String responseData = createIssueresponse.getBody().asString();
		System.out.println(responseData);
		JSONArray responseJson = new JSONArray(responseData);
		JSONObject json2 = new JSONObject(responseJson.get(1).toString());
		String issueid2= json2.get("id").toString();
		
		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();
		}
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
	//	String cycleId = "0001479971459664-242ac1122-0001";
	//	String payLoad = "{\"issues\":[\"TRAC-9\",\"TRAC-10\",\"TRAC-11\",\"TRAC-12\",\"TRAC-13\",\"TRAC-14\",\"TRAC-15\",\"TRAC-16\",\"TRAC-17\",\"TRAC-18\",\"TRAC-19\",\"TRAC-20\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
	//	String payLoad = "{\"issues\":["+ issueid  +"],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response addTestsTocycleresponse = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(addTestsTocycleresponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, addTestsTocycleresponse);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); 
	} */
	
	
	@Test(priority = 22)
	public void addTestsTocycle_test222(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
				 
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
	
		System.out.println("issueResponse" + issueResponse.toString());
	
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
	
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple issues to a cycle in a version of a project, if some issues are not of type tests
	 */
	
	@Test(priority = 3)
	public void addTestsTocycle_test3(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		//create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 2;
				
				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created test issue type");	
				
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
		
		// creating issue - story
		Issue issuePayLoad2 = new Issue();
		issuePayLoad2.setProject(String.valueOf(projectId));
		issuePayLoad2.setIssuetype(String.valueOf(issueTypeId1));
		issuePayLoad2.setSummary("Test");
		issuePayLoad2.setPriority("1");
		issuePayLoad2.setReporter("admin");
		int numberOfExecutions2 = 2;

		List<String> issueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad2.toString(), numberOfExecutions2);
		Assert.assertNotNull(issueResponse1, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse1.toString());
		System.out.println("created story issue type");	
	
		JSONArray responseJson1 = new JSONArray(issueResponse1);		
    	JSONObject json3 = new JSONObject(responseJson1.get(0).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson1.get(1).toString());
		String issueid4= json4.get("id").toString();  
		
		
	
	//	String cycleId = "0001479971459664-242ac1122-0001";
//	String payLoad = "{\"issues\":[\"TRAC-11\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
	//	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
	//	String payLoad = "{\"issues\":[\"TRAC-9\",\"TRAC-10\",\"TRAC-63\",\"TRAC-65\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add mulitple issues to a cycle in a version of a project, if none of the issues are of type test
	 */
	@Test(priority = 4)
	public void addTestsTocycle_test44(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId1));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
		System.out.println("created story issue type");	
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	   JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
	
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	

	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple tests to a cycle if some tests already exist in the cycle
	 */
	
	@Test(priority = 5)
	public void addTestsTocycle_test5(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
		     	JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString();  
				
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);

	
	//	String cycleId = "0001479971459664-242ac1122-0001";
//	String payLoad = "{\"issues\":[\"TRAC-11\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
	//	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
	//	String payLoad = "{\"issues\":[\"TRAC-9\",\"TRAC-10\",\"TRAC-63\",\"TRAC-65\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		Issue issuePayLoad2 = new Issue();
		issuePayLoad2.setProject(String.valueOf(projectId));
		issuePayLoad2.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad2.setSummary("Test");
		issuePayLoad2.setPriority("1");
		issuePayLoad2.setReporter("admin");
		int numberOfExecutions2 = 2;

		List<String> issueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad2.toString(), numberOfExecutions2);
		Assert.assertNotNull(issueResponse1, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse1.toString());
		System.out.println("created story issue type");	
	
		JSONArray responseJson1 = new JSONArray(issueResponse1);		
	JSONObject json5 = new JSONObject(responseJson1.get(0).toString());
		String issueid5= json5.get("id").toString();
		
		JSONObject json6 = new JSONObject(responseJson1.get(1).toString());
		String issueid6= json6.get("id").toString();
		
		String payLoad2 = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 + "," + issueid5 + "," + issueid6 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status21 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);		
	}
	
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add mulitple tests to a cycle if all the tests already exists in the non-adhoc cycle
	 */
	
	@Test(priority = 6)
	public void addTestsTocycle_test6() {
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
	test.assignAuthor("Debadatta");
	
	projectId = Long.parseLong(Config.getValue("projectId"));
	versionId = Long.parseLong(Config.getValue("unscheduleId"));
	
	// creating issue - Test
			Issue issuePayLoad = new Issue();
			issuePayLoad.setProject(String.valueOf(projectId));
			issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
			issuePayLoad.setSummary("Test");
			issuePayLoad.setPriority("1");
			issuePayLoad.setReporter("admin");
			int numberOfExecutions = 4;

			List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
			Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
			test.log(LogStatus.PASS, "Issue created successfully.");
			System.out.println("issueResponse" + issueResponse.toString());
			System.out.println("created story issue type");	
		
			JSONArray responseJson = new JSONArray(issueResponse);
			JSONObject json = new JSONObject(issueResponse.get(0).toString());
			String issueid= json.get("id").toString();
			
			JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
			String issueid2= json2.get("id").toString();
			
		JSONObject json3 = new JSONObject(responseJson.get(2).toString());
			String issueid3= json3.get("id").toString();
			
			JSONObject json4 = new JSONObject(responseJson.get(3).toString());
			String issueid4= json4.get("id").toString();  
			
	
	Cycle cycleJson = new Cycle();
	cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
	cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
	cycleJson.setName("new zephyr");
	
	Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
	Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
	test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
	
	System.out.println("qqq2response"+ createCycleresponse.toString());
	
	boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
	Assert.assertTrue(status2, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated successfully.");
	String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
	System.out.println("cycleIDresponse" + cycleId);


//	String cycleId = "0001479971459664-242ac1122-0001";
//String payLoad = "{\"issues\":[\"TRAC-11\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
//	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
//	String payLoad = "{\"issues\":[\"TRAC-9\",\"TRAC-10\",\"TRAC-63\",\"TRAC-65\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
 	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
	Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
	Assert.assertTrue(status, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
	System.out.println("added 1 time");	
	
	String payLoad2 = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
	Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
	Assert.assertNotNull(response2, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	boolean status21 = zapiService.validateAddTestsToCycle(payLoad2, response2);
	Assert.assertTrue(status21, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);		
	System.out.println("attempt to add 2nd time ");	
}

	
	/*{
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479973871662-242ac1122-0001";
		String payLoad = "{\"issues\":[\"TRAC-9\",\"TRAC-10\",\"TRAC-11\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}*/

	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple tests to a cycle if some tests belong to a different project
	 */
	
	@Test(priority = 7)
	public void addTestsTocycle_test7(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString();  
				
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
	
		// craeted 2 issue in diff project
		Issue issuePayLoad2 = new Issue();
		issuePayLoad2.setProject(String.valueOf(projectId1));
		// project id of different project
		issuePayLoad2.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad2.setSummary("Test");
		issuePayLoad2.setPriority("1");
		issuePayLoad2.setReporter("admin");
		int numberOfExecutions2 = 2;

		List<String> issueResponse1 = jiraService.createIssues(basicAuth, issuePayLoad2.toString(), numberOfExecutions2);
		Assert.assertNotNull(issueResponse1, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse1.toString());
		System.out.println("created story issue type");	
	
		JSONArray responseJson1 = new JSONArray(issueResponse1);		
	    JSONObject json5 = new JSONObject(responseJson1.get(0).toString());
		String issueid5= json5.get("id").toString();
		
		JSONObject json6 = new JSONObject(responseJson1.get(1).toString());
		String issueid6= json6.get("id").toString();
		
		String payLoad2 = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 + "," + issueid5 + "," + issueid6+ "],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		System.out.println("2 issue from different project not added- pass");	
		Response response2 = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad2);
		Assert.assertNotNull(response2, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status21 = zapiService.validateAddTestsToCycle(payLoad2, response2);
		Assert.assertTrue(status21, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479973871662-242ac1122-0001";
		String payLoad = "{\"issues\":[\"TRAC-15\",\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add mulitple tests to an adhoc cycle in a scheduled version of a project
	 */
	
	@Test(priority = 8)
	public void addTestsTocycle_test8(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString(); 
		
				
		String cycleId = "-1";
		String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add same test mulitple times to an adhoc cycle in a version of a project
	 */
	
	@Test(priority = 9)
	public void addTestsTocycle_test9(){
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString(); 
		
				
		String cycleId = "-1";
		for (int i = 0; i < 2; i++) {
		String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 + "],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";	
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		}
	}
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple tests to a non-adhoc cycle in an unscheduled version of a project
	 */
	
	@Test(priority = 10)
	public void addTestsTocycle_test10(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		//creating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
				 
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
	
		System.out.println("issueResponse" + issueResponse.toString());
	
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
	
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":-1,\"projectId\":10003,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479980766013-242ac1122-0001";
		String payLoad = "{\"issues\":[\"TRAC-15\",\"TRAC-16\",\"TRAC-17\",\"TRAC-15\",\"TRAC-16\",\"TRAC-17\"],\"versionId\":-1,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */

	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple tests to an adhoc cycle in an unscheduled version of a project
	 */
	
	@Test(priority = 11)
	public void addTestsTocycle_test11(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString(); 
		
				
		String cycleId = "-1";
		String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "-1";
		String payLoad = "{\"issues\":[\"TRAC-15\",\"TRAC-16\",\"TRAC-17\",\"TRAC-15\",\"TRAC-16\",\"TRAC-17\"],\"versionId\":-1,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */
	
	
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add multiple tests to a cycle if some tests belong to a different project
	 * // testcase 7 and this 12 same so changing case for
	 * attempt to Add multiple tests to a cycle if cycle belong to a different project
	 */
	
	
	@Test(priority = 12)
	public void addTestsTocycle_test12(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				 
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		//creating cycle to diff project
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		
		//String cycleId = "-1";
     //	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":10011,\"projectId\":10003,\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidCycleId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		System.out.println("attempt to Add multiple tests to a cycle if cycle belong to a different project- pass");
	}
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001473871662-242ac1122-0001";
		String payLoad = "{\"issues\":[\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001479973871662-242ac1122-0001";
		String payLoad = "{\"issues\":[\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */

	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to a cycle, if the tests doesn�t belong to that project
	 */
	//"test will fail bcoz of this issue ZFJCLOUD-4946 if want to pass this then need to give below validation")
	@Test(priority = 13)
	public void addTestsTocycle_test13(){
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		//creating cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue in diff project - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId1));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		System.out.println("test will fail bcoz of this issue ZFJCLOUD-4946 if want to pass this then need to give below validation");
		
		//String cycleId = "-1";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	//	boolean status = zapiService.validateAddTestsToCycle(payLoad, response); this validation pass case for now
		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
		
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001478768964952-242ac1131-0001";
		String payLoad = "{\"issues\":[\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidCycleId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	} */
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to a cycle, if the cycle does not belong to that version of the project
	 */
	
	@Test(priority = 14)
	public void addTestsTocycle_test14(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
				 
		//creating cycle to unschedule but user will try to add in diff version
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		System.out.println("qqqq \"Cycle\" + c + \"is invalid or does not belong to the projectId 10,003 and versionId -1.\"), \"Error Code is null\"");
		
		//String cycleId = "-1";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidCycleId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001473871662-242ac1122-0001";
		String payLoad = "{\"issues\":[\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	} */
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to Add tests to a cycle , if the cycle id is invalid 
	 */
	
	@Test(priority = 15)
	public void addTestsTocycle_test15(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString();  	
				System.out.println("addTestsTocycle started");
				
		String cycleId = "11111";
		//need to check payload
		String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";	
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
		
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "000473871662-242ac1122-0001";
		String payLoad = "{\"issues\":[\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */
		
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to cycle, if cycleId is  blank or empty string 
	 */
	
	@Test(priority = 16)
	public void addTestsTocycle_test16(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString();  	
				System.out.println("addTestsTocycle started");
				
		String cycleId = null;
		//need to check payload
		String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleBlankCycleId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}	
		
		
		
		
/*		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "";
		String payLoad = "{\"issues\":[\"APIB-73\",\"APIB-74\"],\"versionId\":10301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */
		
		/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to Add tests to a cycle if version id is invalid
	 */
	
	@Test(priority = 17)
	public void addTestsTocycle_test17(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				 
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = 111l;
		
		//creating cycle to unschedule but user will try to add in diff version
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		System.out.println("qqqq \"Cycle\" + c + \"is invalid or does not belong to the projectId 10,003 and versionId -1.\"), \"Error Code is null\"");
		//String cycleId = "-1";
			
		//	String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
		
		
		
		
		
	/*	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		String cycleId = "0001478768964952-242ac1131-0001";
		String payLoad = "{\"issues\":[\"TRAC-7\",\"TRAC-4\"],\"versionId\":11301,\"projectId\":10200,\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycleInvalidId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test); */
		
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to Add tests to a cycle if project id is invalid
	 */
	
	@Test(priority = 18)
	public void addTestsTocycle_test18(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				 
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		//creating cycle to unschedule
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		System.out.println("qqqq \"Cycle\" + c + \"is invalid or does not belong to the projectId 10,003 and versionId -1.\"), \"Error Code is null\"");
		//String cycleId = "-1";
			
		projectId = 111l;
		//	String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	
			
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to adhoc if cycle id is null
	 */
	
	@Test(priority = 19)
	public void addTestsTocycle_test19(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString();  	
				System.out.println("addTestsTocycle started");
				
		String cycleId = null;
		//need to check payload
		String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
		//String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 + "],\"versionId\":10014,\"projectId\":10003,\"method\":\"1\"}";	
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");

		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);

	}

	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to cycle, if issuesId is invalid
	 */
	//"test will fail bcoz of this issue ZFJCLOUD-4946 if want to pass this then need to give below validation")
	@Test(priority = 20)
	public void addTestsTocycle_test20(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				 
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		
		// creating issue - Test
		/*Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  */
		/*long issueid= 111l;
		long issueid2= 111l;
		long issueid3= 111l;
		long issueid4= 111l;*/
		
		String issueid = null;
		String issueid2 = null;
		String issueid3 = null;
		String issueid4 = null;
		
		
		//System.out.println("cycleId is"  + cycleId);
		//System.out.println("qqqq \"Cycle\" + c + \"is invalid or does not belong to the projectId 10,003 and versionId -1.\"), \"Error Code is null\"");
		String cycleId = "-1";
		System.out.println("test will fail bcoz of this issue ZFJCLOUD-4946 if want to pass this then need to give below validation");
		
			
		//	String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
	//	boolean status = zapiService.validateAddTestsToCycle(payLoad, response); actual response is wrong bug id ZFJCLOUD-4946
		
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to a cycle, if projectId is null
	 */
	
	@Test(priority = 21)
	public void addTestsTocycle_test21(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				 
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		//creating cycle to unschedule
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		System.out.println("qqqq \"Cycle\" + c + \"is invalid or does not belong to the projectId 10,003 and versionId -1.\"), \"Error Code is null\"");
		//String cycleId = "-1";
			
		projectId = null;
		//	String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);				
	}
	
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Attempt to add tests to a cycle, if versionId is null
	 */
	
	@Test(priority = 22)
	public void addTestsTocycle_test22(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				 
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("versionFourId"));
		
		//creating cycle to unschedule
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(Long.parseLong(Config.getValue("unscheduleId")));
		cycleJson.setName("new zephyr");
		
		Response createCycleresponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(createCycleresponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		System.out.println("qqq2response"+ createCycleresponse.toString());
		
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), createCycleresponse);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(createCycleresponse.body().asString()).get("id").toString();
		System.out.println("cycleIDresponse" + cycleId);
		
		// creating issue - Test
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(String.valueOf(projectId));
		issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
		issuePayLoad.setSummary("Test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter("admin");
		int numberOfExecutions = 4;

		List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
		Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
		test.log(LogStatus.PASS, "Issue created successfully.");
		System.out.println("issueResponse" + issueResponse.toString());
	
		JSONArray responseJson = new JSONArray(issueResponse);
		JSONObject json = new JSONObject(issueResponse.get(0).toString());
		String issueid= json.get("id").toString();
		
		JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
		String issueid2= json2.get("id").toString();
		
	    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
		String issueid3= json3.get("id").toString();
		
		JSONObject json4 = new JSONObject(responseJson.get(3).toString());
		String issueid4= json4.get("id").toString();  
		System.out.println("cycleId is"  + cycleId);
		System.out.println("qqqq \"Cycle\" + c + \"is invalid or does not belong to the projectId 10,003 and versionId -1.\"), \"Error Code is null\"");
		//String cycleId = "-1";
			
		//projectId = 111l;
		versionId = null;
		
		//	String payLoad = "{\"issues\":["+ issueid +"],\"versionId\":" + versionId + ",\"projectId\":"+ projectId + ",\"method\":\"1\"}";
     	String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		boolean status = zapiService.validateAddTestsToCycleInvalidIssueIdAndVersionId(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);				
	}
				
	/**
	 * Created by debadatta.kathar on 24-Nov-2016
	 * Add same test to an adhoc cycle, in unscheduled version of the project
	 */
	
	@Test(priority = 23)
	public void addTestsTocycle_test23(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
		
		projectId = Long.parseLong(Config.getValue("projectId"));
		versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		// creating issue - Test
				Issue issuePayLoad = new Issue();
				issuePayLoad.setProject(String.valueOf(projectId));
				issuePayLoad.setIssuetype(String.valueOf(issueTypeId));
				issuePayLoad.setSummary("Test");
				issuePayLoad.setPriority("1");
				issuePayLoad.setReporter("admin");
				int numberOfExecutions = 4;

				List<String> issueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), numberOfExecutions);
				Assert.assertNotNull(issueResponse, "Create Issue Api Response is null.");
				test.log(LogStatus.PASS, "Issue created successfully.");
				System.out.println("issueResponse" + issueResponse.toString());
				System.out.println("created story issue type");	
			
				JSONArray responseJson = new JSONArray(issueResponse);
				JSONObject json = new JSONObject(issueResponse.get(0).toString());
				String issueid= json.get("id").toString();
				
				JSONObject json2 = new JSONObject(issueResponse.get(1).toString());
				String issueid2= json2.get("id").toString();
				
			    JSONObject json3 = new JSONObject(responseJson.get(2).toString());
				String issueid3= json3.get("id").toString();
				
				JSONObject json4 = new JSONObject(responseJson.get(3).toString());
				String issueid4= json4.get("id").toString(); 
		
				
		String cycleId = "-1";
		for (int i = 0; i < 2; i++) {
			String payLoad = "{\"issues\":["+ issueid + "," + issueid2 + "," + issueid3 + "," + issueid4 +"],\"versionId\":" + versionId + ",\"projectId\":" + projectId + ",\"method\":\"1\"}";
		Response response = zapiService.addTestsTocycle(jwtGenerator, cycleId, payLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		
		boolean status = zapiService.validateAddTestsToCycle(payLoad, response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		}
	}

}
