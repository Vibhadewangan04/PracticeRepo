package com.thed.zephyr.regression.folder;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Folder;

public class CreateFolderApi extends BaseTest{

	String cycleId = null;
	/*JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}*/
	/**
	 * create a folder in Unscheduled version  planned cycle
	 */
	@Test(priority = 1, enabled = testEnabled)
	public void reg1_createFolderInUnscheduledVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolder" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
	}
	
	
	/**
	 * Attempt to Create a folder in Adhoc cycle ,Unscheduled version
	 */
	@Test(priority = 2, enabled = testEnabled)
	public void reg2_AttemptToCreateFolderInAdhocCycle(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		cycleId = "-1";
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolder" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
	}
	
	
	/**
	 * Attempt to Create a folder in Adhoc cycle ,scheduled version
	 */
	@Test(priority = 3, enabled = testEnabled)
	public void reg3_AttemptToCreateFolderInAdhocCycleScheduleVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		cycleId = "-1";
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolder" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
	}
	
	/**
	 * Attempt to Create a same folder in Planned cycle ,Unscheduled version
	 */
	
	@Test(priority = 4, enabled = testEnabled)
	public void reg4_AttemptToCreateSameFolder(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("unscheduleId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createSameFolder");
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		//attempt to create folder with same name
		JSONObject obj1 = new JSONObject(response1.getBody().asString());
		System.out.println(obj1);
		String folderName = obj1.get("name").toString();
		System.out.println();
		folderJson.setName(folderName);
		Response response2 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response2, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response2.getStatusCode());
		boolean status2 = zapiService.validateFolder(folderJson.toString(), response2);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
	}
	
	
	/**
	 *Attempt to Create a same folder in Planned  cycle ,scheduled version
	 */
	
	@Test(priority = 5, enabled = testEnabled)
	public void reg5_AttemptToCreateSameFolderInScheduleVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createSameFolder");
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		//attempt to create folder with same name
		JSONObject obj1 = new JSONObject(response1.getBody().asString());
		System.out.println(obj1);
		String folderName = obj1.get("name").toString();
		System.out.println();
		folderJson.setName(folderName);
		Response response2 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response2, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response2.getStatusCode());
		boolean status2 = zapiService.validateFolder(folderJson.toString(), response2);
		Assert.assertTrue(status2, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
	}
	
	
	
	
	/**
	 *create a folder in scheduled version  planned cycle
	 */
	
	@Test(priority = 6, enabled = testEnabled)
	public void reg6_CreateFolderInScheduleVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolderScheduleVersion" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		
	}
	
	
	/**
	 *Attempt to create folder without providing folder name 
	 */
	
	@Test(priority = 7, enabled = testEnabled)
	public void reg7_AttemptCreateFolderWithoutName(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		//folderJson.setName("createFolderScheduleVersion" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		
	}
	
	/**
	 *Attempt to create folder without providing Cycle id 
	 */
	
	@Test(priority = 8, enabled = testEnabled)
	public void reg8_AttemptCreateFolderWithoutCycleName(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolderScheduleVersion" + System.currentTimeMillis());
		
		//folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		
	}
	
	
	/**
	 *Attempt to create folder without providing Project Id
	 */
	
	@Test(priority = 9, enabled = testEnabled)
	public void reg9_AttemptCreateFolderWithoutProject(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolderScheduleVersion" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		//folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		
	}
	
	
	/**
	 *Attempt to create folder without providing Version Id
	 */
	
	@Test(priority = 10, enabled = testEnabled)
	public void reg10_AttemptCreateFolderWithoutVersion(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectId);
		cycleJson.setVersionId(versionId);
		cycleJson.setName("createCycleInUnscheduledVersion");
		
		Response response = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		
		boolean status = zapiService.validateCycle(cycleJson.toString(), response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		JSONObject obj = new JSONObject(response.getBody().asString());
		System.out.println(obj);
		cycleId = obj.get("id").toString();
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolderScheduleVersion" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		//folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		
	}
	
	/**
	 *Attempt to create folder with invalid  Cycle id
	 */
	
	@Test(priority = 11, enabled = testEnabled)
	public void reg11_AttemptCreateFolderWithInvalidCycleid(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation Regression Test Suite - ZFJCLOUD");
		test.assignAuthor("Jagadeesh");
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Long versionId = Long.parseLong(Config.getValue("versionOneId"));
		
		
		cycleId = "1234";
		System.out.println(cycleId);
		
		Folder folderJson = new Folder();
			
		folderJson.setName("createFolderScheduleVersion" + System.currentTimeMillis());
		
		folderJson.setCycleid(cycleId);
		folderJson.setProjectId(projectId);
		folderJson.setVersionId(versionId);
		folderJson.SetclearCustomFieldsFlag(true);
		
		Response response1 = zapiService.createFolderCycle(jwtGenerator, folderJson.toString());
		Assert.assertNotNull(response1, "Create Folder Api Response is null.");
		test.log(LogStatus.PASS, "Create Folder Api executed successfully.");
		
		System.out.println(response1.body().asString());
		System.out.println(response1.getStatusCode());
		
		
		boolean status1 = zapiService.validateFolder(folderJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		
		
	}
	
}