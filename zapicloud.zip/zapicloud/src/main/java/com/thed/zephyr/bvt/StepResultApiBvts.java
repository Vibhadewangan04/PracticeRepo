/**
 * Created by manoj.behera on 07-Dec-2016.
 */
package com.thed.zephyr.bvt;

import java.util.ArrayList;
import java.util.List;

import org.bouncycastle.crypto.tls.SecurityParameters;
import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.model.StepResult;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Stepresult;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;

/**
 * @author manoj.behera 07-Dec-2016
 *
 */
public class StepResultApiBvts extends BaseTest {
	String cycleId = null;
	Long issueId = null;
	String teststepId = null;
	JSONObject teststepObj = null;
	String executionId = null;
	String stepResId = null;
	JSONArray stepResJSONArray = null;
	
	Long oldBugId = null;


	@BeforeClass
	public void beforeClass() {
		Issue issueBugPayLoad = new Issue();
		issueBugPayLoad.setProject(Config.getValue("projectId"));
		issueBugPayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issueBugPayLoad.setSummary("Defect");
		issueBugPayLoad.setPriority("1");
		issueBugPayLoad.setReporter(Config.getValue("adminUserName"));

		Response bugResponse = jiraService.createIssue(basicAuth, issueBugPayLoad.toString());
		Assert.assertNotNull(bugResponse, "Create Issue Api Response is null.");
		//
		boolean bugStatus = jiraService.validateCreateIssueApi(bugResponse);
		Assert.assertTrue(bugStatus, "Response Validation Failed.");
		oldBugId = Long.parseLong(new JSONObject(bugResponse.body().asString()).getString("id"));
		
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("Summary " + System.currentTimeMillis());
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		
		Long projectId = Long.parseLong(Config.getValue("projectId"));
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("step");
		teststepJson.setData("data");
		teststepJson.setResult("result");

		Response createTeststepResponse = zapiService.createTeststep(jwtGenerator, projectId, issueId,
				teststepJson.toString());
		Assert.assertNotNull(createTeststepResponse, "Create Teststep Api Response is null.");
		System.out.println(createTeststepResponse.getBody().asString());

		boolean createTeststepValidationStatus = zapiService.validateTeststep(projectId, issueId,
				teststepJson.toString(), createTeststepResponse);
		Assert.assertTrue(createTeststepValidationStatus, "Create Teststep Api response not validated.");

		teststepObj = new JSONObject(createTeststepResponse.body().asString());
		System.out.println(teststepObj);
		teststepId = teststepObj.getString("id");
		
	}
	@BeforeMethod
	public void beforeMethod(){
		
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		executionJson.setIssueId(this.issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(Long.parseLong(Config.getValue("versionOneId")));

		Response createExecutionResponse = zapiService.createExecution(jwtGenerator, executionJson.toString());
		Assert.assertNotNull(createExecutionResponse, "Create Execution Api Response is null.");

		boolean status = zapiService.validateExecution(executionJson.toString(), createExecutionResponse);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");

		executionId = new JSONObject(
				new JSONObject(createExecutionResponse.getBody().asString()).get("execution").toString())
						.getString("id");
		
//		Response getStepResultsResponse = zapiService.getStepResults(jwtGenerator, issueId, executionId);
//		Assert.assertNotNull(getStepResultsResponse, "Create Execution Api Response is null.");
//		System.out.println(getStepResultsResponse.getBody().asString());
//		JSONArray ja=new JSONObject(getStepResultsResponse.getBody().asString()).getJSONArray("stepResults");
//		JSONObject stepres = ja.getJSONObject(0);
//		stepResId = stepres.getString("id");
//		System.err.println(stepResId);
	}
	
	@Test(priority = 61, enabled = testEnabled)
	public void bvt61_getStepResults() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Response stepResultsResponse = zapiService.getStepResults(jwtGenerator, issueId, executionId);
		Assert.assertNotNull(stepResultsResponse, "getStepResults Api Response is null.");
		System.out.println(stepResultsResponse.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		stepResJSONArray = new JSONObject(stepResultsResponse.getBody().asString()).getJSONArray("stepResults");
		
	}
	@Test(priority = 62, enabled = testEnabled)
	public void bvt62_getStepResult() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		executionId = stepres.getString("executionId");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Response stepResultResponse = zapiService.getStepResult(jwtGenerator, executionId, stepResId);
		Assert.assertNotNull(stepResultResponse, "getStepResults Api Response is null.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepres.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Get Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update the step result with status to default status
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	@Test(priority = 63, enabled = testEnabled)
	public void bvt63_updateStepResult_defaultStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Stepresult stepResJson = new Stepresult();
		stepResJson.setId(stepres.getString("id"));
		stepResJson.setStepId(stepres.getString("stepId"));
		stepResJson.setExecutionId(stepres.getString("executionId"));
		stepResJson.setIssueId(stepres.getLong("issueId"));
		stepResJson.setStatusId(1l);
//		String stepResultId = "0001481370178329-242ac112-0001";

//		String payLoad = "{\"status\":{\"id\":2},\"issueId\":15719,\"stepId\":\"0001481370140007-242ac112-0001\",\"executionId\":\"0001481359286206-242ac112-0001\"}";

		Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
		Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
		test.log(LogStatus.PASS, "Update Stepresult Api executed successfully.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update the step result with status to custom status
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	@Test(priority = 64, enabled = testEnabled)
	public void bvt64_updateStepResult_customStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Stepresult stepResJson = new Stepresult();
		stepResJson.setId(stepres.getString("id"));
		stepResJson.setStepId(stepres.getString("stepId"));
		stepResJson.setExecutionId(stepres.getString("executionId"));
		stepResJson.setIssueId(stepres.getLong("issueId"));
		stepResJson.setStatusId(5l);

		Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
		Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
		test.log(LogStatus.PASS, "Update Stepresult Api executed successfully.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update the step result with new defects associated
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	@Test(priority = 65, enabled = testEnabled)
	public void bvt65_updateStepResult_customStatus() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeBugId"));
		issuePayLoad.setSummary("Defect");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		//
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		long newStepDefectId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		
		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Stepresult stepResJson = new Stepresult();
		stepResJson.setId(stepres.getString("id"));
		stepResJson.setStepId(stepres.getString("stepId"));
		stepResJson.setExecutionId(stepres.getString("executionId"));
		stepResJson.setIssueId(stepres.getLong("issueId"));
		stepResJson.setStatusId(2l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(newStepDefectId);
		stepResJson.setDefects(defectsList);

		Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
		Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
		test.log(LogStatus.PASS, "Update Stepresult Api executed successfully.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update the step result with old defect associated
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	@Test(priority = 66, enabled = testEnabled)
	public void bvt66_updateStepResult_oldDefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Stepresult stepResJson = new Stepresult();
		stepResJson.setId(stepres.getString("id"));
		stepResJson.setStepId(stepres.getString("stepId"));
		stepResJson.setExecutionId(stepres.getString("executionId"));
		stepResJson.setIssueId(stepres.getLong("issueId"));
		stepResJson.setStatusId(2l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(oldBugId);
		stepResJson.setDefects(defectsList);

		Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
		Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
		test.log(LogStatus.PASS, "Update Stepresult Api executed successfully.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update the step result with comments associated
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	@Test(priority = 67, enabled = testEnabled)
	public void bvt67_updateStepResult_oldDefect() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Stepresult stepResJson = new Stepresult();
		stepResJson.setId(stepres.getString("id"));
		stepResJson.setStepId(stepres.getString("stepId"));
		stepResJson.setExecutionId(stepres.getString("executionId"));
		stepResJson.setIssueId(stepres.getLong("issueId"));
		stepResJson.setComment("Comment");

		Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
		Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
		test.log(LogStatus.PASS, "Update Stepresult Api executed successfully.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * Update the step result with status, comment and defect associated
	 * @author Created by manoj.behera on 27-Mar-2017.
	 */
	@Test(priority = 68, enabled = testEnabled)
	public void bvt68_updateStepResult_withDefectStatusAndComment() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject stepres = stepResJSONArray.getJSONObject(0);
		stepResId = stepres.getString("id");
		System.err.println(stepResId);
		System.out.println(stepres.toString());
		
		Stepresult stepResJson = new Stepresult();
		stepResJson.setId(stepres.getString("id"));
		stepResJson.setStepId(stepres.getString("stepId"));
		stepResJson.setExecutionId(stepres.getString("executionId"));
		stepResJson.setIssueId(stepres.getLong("issueId"));
		stepResJson.setStatusId(2l);
		List<Long> defectsList = new ArrayList<>();
		defectsList.add(oldBugId);
		stepResJson.setDefects(defectsList);
		stepResJson.setComment("Comment");
		
		Response stepResultResponse = zapiService.updateStepResult(jwtGenerator, stepResId, stepResJson.toString());
		Assert.assertNotNull(stepResultResponse, "Update Stepresult Api Response is null.");
		test.log(LogStatus.PASS, "Update Stepresult Api executed successfully.");
		System.out.println(stepResultResponse.getBody().asString());
		
		boolean stepResultStatus = zapiService.validateStepResult(stepResJson.toString(), stepResultResponse);
		Assert.assertTrue(stepResultStatus, "Update Stepresult status validated successfully.");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}



}
