/**
 * Created by manoj.behera on 15-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 15-Nov-2016
 *
 */
public interface StepresultsApi {

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param executionId
	 * @param stepResultId
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response getStepResult(JwtGenerator jwtGenerator, String executionId, String stepResultId);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param issueId
	 * @param executionId
	 * @return
	 * @author Created by manoj.behera on 15-Nov-2016.
	 */
	Response getStepResults(JwtGenerator jwtGenerator, Long issueId, String executionId);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param stepResultId
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response updateStepResult(JwtGenerator jwtGenerator, String stepResultId, String payLoad);

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param executionId
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response getStepDefectsByExecutionId(JwtGenerator jwtGenerator, Long projectId, String executionId);

	/**
	 * @param jwtGenerator
	 * @param statusId
	 * @param offset
	 * @param maxResults
	 * @return
	 * @author Created by manoj.behera on 20-Nov-2016.
	 */
	Response getStepResultByStatus(JwtGenerator jwtGenerator, int statusId, int offset, int maxResults);

	

}
