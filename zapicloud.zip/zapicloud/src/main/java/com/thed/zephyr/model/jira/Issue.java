package com.thed.zephyr.model.jira;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.util.JSONPObject;
import com.google.gson.JsonArray;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class Issue {

	private String project;
	private String summary;
	private String issuetype;
	private String priority;
	private String reporter;
	private String environment;
	private JSONArray fixVersions;
	private JSONArray components;
	private JSONArray labels;
	
	private String EpicName;
	private String issueId;
	
	private String parentIssueId;
	private String issueKey;
	private String parent;
//	private List<Long> fixVersions;
	
	
	public void setFixVersions(JSONArray versions) {
		this.fixVersions = versions;
	}
	
	/**
	 * @return the component
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public JSONArray getComponents() {
		return components;
	}


	/**
	 * @param component the component to set
	 * @author Created by manoj.behera on 21-Mar-2017.
	 */
	public void setComponents(JSONArray components) {
		this.components = components;
	}


	/**
	 * @return the label
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public JSONArray getLabels() {
		return labels;
	}


	/**
	 * @param label the label to set
	 * @author Created by manoj.behera on 21-Mar-2017.
	 */
	public void setLabels(JSONArray labels) {
		this.labels = labels;
	}


	/**
	 * @return the project
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public String getProject() {
		return project;
	}


	/**
	 * @return the summary
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public String getSummary() {
		return summary;
	}


	/**
	 * @return the issuetype
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public String getIssuetype() {
		return issuetype;
	}


	/**
	 * @return the priority
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public String getPriority() {
		return priority;
	}


	/**
	 * @return the reporter
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public String getReporter() {
		return reporter;
	}


	/**
	 * @return the environment
	 * Created by manoj.behera on 21-Mar-2017.
	 */
	public String getEnvironment() {
		return environment;
	}


	/**
	 * @param project the project to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setProject(String project) {
		this.project = project;
	}


	/**
	 * @param summary the summary to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setSummary(String summary) {
		this.summary = summary;
	}


	/**
	 * @param issuetype the issuetype to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setIssuetype(String issuetype) {
		this.issuetype = issuetype;
	}


	/**
	 * @param priority the priority to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setPriority(String priority) {
		this.priority = priority;
	}


	/**
	 * @param reporter the reporter to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setReporter(String reporter) {
		this.reporter = reporter;
	}


	/**
	 * @param environment the environment to set
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@SuppressWarnings("null")
	@Override
	public String toString() {
		JSONObject issueJson = new JSONObject();
		JSONObject innerJson = new JSONObject();
		innerJson.put("project", new JSONObject().put("id", this.project));
		innerJson.put("summary", this.summary);
		innerJson.put("issuetype", new JSONObject().put("id", this.issuetype));
		innerJson.put("priority", new JSONObject().put("id", this.priority));
		innerJson.put("reporter", new JSONObject().put("name", this.reporter));
		if(this.fixVersions != null ){
			innerJson.put("fixVersions", this.fixVersions);
		}
		if(this.components != null ){
			JSONArray compjs=new JSONArray();
			for (int i = 0; i < components.length(); i++) {
				//new JSONArray().put(new JSONObject().put("id", this.components.get(i).toString()));
				JSONObject js1=new JSONObject().put("id", this.components.get(i).toString());				
				compjs.put(i,js1);				
				//System.out.println(compjs);
			}
			//System.err.println(compjs);
			innerJson.put("components",compjs);
					
			
		}
		if(this.fixVersions != null ){
			JSONArray fixversionjs=new JSONArray();
			for (int i = 0; i < fixVersions.length(); i++) {
				//new JSONArray().put(new JSONObject().put("id", this.components.get(i).toString()));
				JSONObject Fixjs1=new JSONObject().put("id", this.fixVersions.get(i).toString());				
				fixversionjs.put(i,Fixjs1);				
				//System.out.println(js);
			}
			//System.err.println(fixversionjs);
			innerJson.put("fixVersions",fixversionjs);
			
		}
		
		
		if(this.labels != null ){
			JSONArray labelsjs =new JSONArray();
			for (int i = 0; i < labels.length(); i++) {
				//new JSONArray().put(new JSONObject().put("id", this.components.get(i).toString()));
				JSONObject labeljs1=new JSONObject().put("id", this.labels.get(i).toString());				
				labelsjs.put(i,labeljs1);				
				//System.out.println(labelsjs);
			}
			//System.err.println(labelsjs);
			innerJson.put("labels",labelsjs);
		}
		
		
		
		/*if(this.labels != null ){
			innerJson.put("labels", this.labels);
		}*/
		
		if(this.EpicName !=null)
		{
			innerJson.put("customfield_10011", this.EpicName);
		}
		if(this.parent !=null)
		{
			innerJson.put("parent", new JSONObject().put("key", this.parent));
		}
//		innerJson.put("reporter", new JSONObject().put("name", this.reporter));
		/*if(this.environment != null ){
			dummy.put("environment", this.environment);
		}*/
		issueJson.put("fields", innerJson) ;
		return issueJson.toString();
	}
	
	public void setEpicName(String EpicName) {
		// TODO Auto-generated method stub
		this.EpicName=EpicName;
	}

	
	public void setparent(String parent) {
		// TODO Auto-generated method stub
		this.parent= parent;
	}
}


