/**
 * Created by manoj.behera on 17-Nov-2016.
 */
package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriBuilderException;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.TraceabilityApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 17-Nov-2016
 *
 */
@Service("traceabilityApi")
public class TraceabilityApiImpl implements TraceabilityApi{
	@Override
	public Response exportTraceabilityReport(JwtGenerator jwtGenerator, String payLoad){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/traceability/export";
		URI uri = UriBuilder.fromUri(uriStr).build();
		System.out.println(uri.toString());
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("POST", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).body(payLoad).when().post(uri);
	}
	@Override
	public Response downloadExportedFile(JwtGenerator jwtGenerator, String downloadFilename){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/traceability/export/download/"+downloadFilename;
		System.out.println(uriStr);
		URI uri = null;
		try {
			uri = new URI(uriStr);
		} catch (URISyntaxException e) {
			e.printStackTrace();
		}
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response generateRequirementTraceability(JwtGenerator jwtGenerator, Long versionId, String requirementIdOrKeyList){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/traceability/search/tests/requirement";
//		URI uri = UriBuilder.fromUri(uriStr).replaceQueryParam(",", "%2C").queryParam("requirementIdOrKeyList", requirementIdOrKeyList.toString()).queryParam("versionId", versionId).build();
		URI uri = null;
		try {
			uri = UriBuilder.fromUri(uriStr).queryParam("requirementIdOrKeyList", requirementIdOrKeyList.toString()).queryParam("versionId", versionId).build();
		} catch (IllegalArgumentException | UriBuilderException e) {
			e.printStackTrace();
		};
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Content-Type", "application/json");
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response generateDefectTraceability(JwtGenerator jwtGenerator,  Long versionId, String defectIdList){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/traceability/search/defect/statistics";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("defectIdList", defectIdList.toString()).queryParam("versionId", versionId).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().urlEncodingEnabled(true).headers(headers).when().get(uri);
	}
	@Override
	public Response searchExecutionsByDefect(JwtGenerator jwtGenerator, Long versionId, Long defectId, int offset, int maxResult){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/traceability/search/executions/defect";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("defectId", defectId).queryParam("versionId", versionId).queryParam("offset", offset).queryParam("maxResult", maxResult).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().headers(headers).when().get(uri);
	}
	@Override
	public Response searchExecutionsByTest(JwtGenerator jwtGenerator, Long versionId, Long testId, int offset, int maxResult){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/traceability/search/executions/test";
		URI uri = UriBuilder.fromUri(uriStr).queryParam("testId", testId).queryParam("versionId", versionId).queryParam("offset", offset).queryParam("maxResult", maxResult).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		 
		return given().headers(headers).when().get(uri);
	}
}
