package com.thed.zephyr.api.impl;

import static com.jayway.restassured.RestAssured.given;

import java.net.URI;
import java.util.HashMap;
import java.util.Map;
import javax.ws.rs.core.UriBuilder;

import org.springframework.stereotype.Service;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.Config;
import com.thed.zephyr.api.ConfigApi;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
@Service("configApi")
public class ConfigApiImpl implements ConfigApi {
	
	/* (non-Javadoc)
	 * @see com.thed.zephyr.api.ConfigApi#getGeneralConfigInfo(com.thed.zephyr.cloud.rest.client.JwtGenerator)
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	@Override
	public Response getGeneralConfigInfo(JwtGenerator jwtGenerator){
		String uriStr = Config.getValue("zephyrBaseUrl")+"/public/rest/api/1.0/config/generalinformation";
		URI uri = UriBuilder.fromUri(uriStr).build();
		int expirationInSec = Integer.parseInt(Config.getValue("expiryTime"));
		String jwt = jwtGenerator.generateJWT("GET", uri, expirationInSec);
		System.out.println(jwt);
		Map<String, String> headers = new HashMap<String, String>();
		headers.put("Content-Type", "application/json");
		headers.put("Authorization", jwt);
		headers.put("zapiAccessKey", Config.getValue("accessKey"));
		headers.put("Cookie", "PLAY_LANG="+Config.getValue("language"));
		System.out.println(uri.toString());
		return given().headers(headers).when().get(uri);
	}
}
