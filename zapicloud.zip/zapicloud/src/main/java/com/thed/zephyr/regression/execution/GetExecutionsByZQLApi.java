/**
 *
 */
package com.thed.zephyr.regression.execution;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.CommonUtils;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Praveenkumar
 *
 */
public class GetExecutionsByZQLApi extends BaseTest {

	String cycleIdScheduledVersion = null;
	String issueKey = null;
	String cycleId = null;
	
	JwtGenerator jwtGenerator = null;
	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	//Get Executions by ZQL by passing valid ZQL and executionId of first execution
	@Test(priority = 1)
	public void test1_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=exeIds.get(1).toString();
		
				String[] executions = {ex1,ex2}	;	

	
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex1, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad, status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//Get Executions by ZQL by passing valid ZQL and executionId of execution in middle
	@Test(priority = 2)
	public void test2_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 3);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		Long issueId2= issueIds.get(2);
		
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(3);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=exeIds.get(1).toString();
				
				String	ex3=exeIds.get(2).toString();
				
		
				String[] executions = {ex1,ex2, ex3}	;	

	
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex2, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad.toString(), status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//Get Executions by ZQL by passing valid ZQL and executionId of last execution
	@Test(priority = 3)
	public void test3_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=exeIds.get(1).toString();
		
				String[] executions = {ex1,ex2}	;	

	
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex2, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad.toString(), status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//Attempt to get Executions by ZQL by passing wrong executionId
	@Test(priority = 4)
	public void test4_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String executionId = "99";
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);

		Response response = zapiService.getExecutionsByZQL(jwtGenerator, executionId, payLoad);
		Assert.assertNotNull(response, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(response.getBody().asString());
				boolean status = zapiService.validateZqlWithInvalidExecutionId(response , executionId);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//Attempt to get Executions by ZQL by passing wrong ZQL
	@Test(priority = 5)
	public void test5_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=exeIds.get(1).toString();
		
				String[] executions = {ex1,ex2}	;	

				String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" AND fixVersion =12wd \"}";
				System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex2, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad.toString(), status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//	Attempt to get Executions by ZQL without passing executionId
	@Test(priority = 6)
	public void test6_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=null;
		
				String[] executions = {ex1,ex2}	;	

				String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" AND fixVersion =12wd \"}";
				System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex2, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
						
				boolean status = zapiService.validateExecutionIdNull(ex2, status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
				
	}

	//  Attempt to get Executions by ZQL without passing ZQL in payload
	@Test(priority = 7)
	public void test7_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=null;
		
				String[] executions = {ex1,ex2}	;	

				String payLoad = "{\"offset\":0}";
				System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex2, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearchWithoutPassingZql(payLoad.toString(), status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
		
		
		
	}

	//  Get Executions by ZQL without passing offset in payload
	@Test(priority = 8)
	public void test8_() {
		

		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 2);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(2);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=exeIds.get(1).toString();
		
				String[] executions = {ex1,ex2}	;	

				String payLoad = "{\"zql\":\"project = "+Config.getValue("projectKey")+" AND fixVersion =12wd \"}";
				System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex2, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad, status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//	Attempt to get Executions by ZQL by passing ZQL and executionId which is not in ZQL
	@Test(priority = 9)
	public void test9_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		String executionId = "0001480407927918-242ac1123-0001";
		String payLoad = "{\"zql\":\"project = RUBY\",\"offset\":0}";

		Response response = zapiService.getExecutionsByZQL(jwtGenerator, executionId, payLoad);
		Assert.assertNotNull(response, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(response.getBody().asString());
			boolean status = zapiService.validateZqlWithInvalidExecutionId(response, executionId);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//	Get Executions by ZQL by passing valid executionId and ZQL having 1 execution
	@Test(priority = 10)
	public void test10_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Praveen");

		
		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
	
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//Long issueId1= issueIds.get(1);
		

// Create cycle
		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(Long.parseLong(Config.getValue("projectId")));
		cycleJson.setVersionId(-1l);
		cycleJson.setName("Create execution"+System.currentTimeMillis());
		cycleJson.setDescription("Get execution by cycle");
		
		Response cycleResponse = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(cycleResponse, "Create Cycle Api Response is null.");
		test.log(LogStatus.PASS, "Create Cycle Api executed successfully.");
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), cycleResponse);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated successfully.");
		String cycleId = new JSONObject(cycleResponse.body().asString()).get("id").toString();
		String CycleName = new JSONObject(cycleResponse.body().asString()).get("name").toString();	
		System.out.println(CycleName);


	//2 executions
				Execution executionJson11 = new Execution();
				executionJson11.setStatusId(-1l);
				executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId")));
				executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
				executionJson11.setVersionId(-1l);
				executionJson11.setNoOfExecutions(1);
				executionJson11.setCycleId(cycleId);

				JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
				Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
				
				//update
				
				List<String> exeIds = new ArrayList<>() ;
				JSONArray jsarray2 = new JSONArray(executionResponse.toString());
				System.out.println("length="+jsarray2.length());
				for (int j=0;j<jsarray2.length();j++){
					JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
					String exeid =jsobj2.getJSONObject("execution").get("id").toString();
					exeIds.add(exeid);
					Long issueId11 = issueIds.get(j);
					executionJson11.setIssueId(issueId11);
					System.out.println(issueId11);
					executionJson11.setStatusId(1l);
					executionJson11.setExecutionId(exeid);
					
					////update executions
					Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
							executionJson11.toString());
					Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
					test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
					System.out.println(updateExecutionResponse.getBody().asString());
					System.out.println("updated execution");
				}
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				//String	ex2=exeIds.get(1).toString();
		
				//String[] executions = {ex1,ex2}	;	

	
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex1, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad, status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

	//	Get Executions by ZQL by passing valid executionId and ZQL having 100 execution
	@Test(priority = 11)
	public void test11_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		System.out.println("jsarray: " + jsarray.length());
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(1);
		executionJson11.setCycleId("-1");
		

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(0);
			System.out.println("issueId11: " + issueId11);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				//String	ex2=exeIds.get(1).toString();
		
				//String[] executions = {ex1,ex2}	;	

	
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex1, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad, status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}
	//	Get Executions by ZQL by passing valid executionId and ZQL having 500 execution
	@Test(priority = 12)
	public void test12_() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		//create issues
		Issue issuePayLoad = new Issue();
		issuePayLoad.setProject(Config.getValue("projectId1"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));
		
		List<String> createIssueResponse = jiraService.createIssues(basicAuth, issuePayLoad.toString(), 1);
		Assert.assertNotNull(createIssueResponse, "Create issues Api Response is null.");
		
		List<Long> issueIds = new ArrayList<>() ;
		JSONArray jsarray = new JSONArray(createIssueResponse);
		System.out.println("jsarray: " + jsarray.length());
		for(int i= 0;i<jsarray.length();i++){
	
			JSONObject jsobj = new JSONObject(jsarray.getString(i));
			Long l= Long.parseLong(jsobj.get("id").toString());
			issueIds.add(l);
		}
		System.out.println("*****"+issueIds);
		Long issueId = issueIds.get(0);
		System.out.println(issueId);
		//Long issueId1= issueIds.get(1);
		
		//2 executions
		Execution executionJson11 = new Execution();
		executionJson11.setStatusId(-1l);
		executionJson11.setProjectId(Long.parseLong(Config.getValue("projectId1")));
		executionJson11.setIssueIds(CommonUtils.getListAsLong(createIssueResponse, "id"));
		executionJson11.setVersionId(-1l);
		executionJson11.setNoOfExecutions(5);
		executionJson11.setCycleId("-1");
		

		JSONArray executionResponse = zapiService.createExecutions(jwtGenerator, executionJson11.toString());
		Assert.assertNotNull(executionResponse, "Create Execution Api Response is null.");
		
		//update
		
		List<String> exeIds = new ArrayList<>() ;
		JSONArray jsarray2 = new JSONArray(executionResponse.toString());
		System.out.println("length="+jsarray2.length());
		for (int j=0;j<jsarray2.length();j++){
			JSONObject jsobj2 = new JSONObject(jsarray2.getString(j));
			String exeid =jsobj2.getJSONObject("execution").get("id").toString();
			exeIds.add(exeid);
			Long issueId11 = issueIds.get(0);
			System.out.println("issueId11: " + issueId11);
			executionJson11.setIssueId(issueId11);
			System.out.println(issueId11);
		//	executionJson11.setStatusId(1l);
			executionJson11.setExecutionId(exeid);
			
			////update executions
			Response updateExecutionResponse = zapiService.updateExecution(jwtGenerator, exeid,
					executionJson11.toString());
			Assert.assertNotNull(updateExecutionResponse, "Update Execution Api Response is null.");
			test.log(LogStatus.PASS, "Update Execution Api executed successfully.");
			System.out.println(updateExecutionResponse.getBody().asString());
			System.out.println("updated execution");
		}
		
				
				String projectId = Config.getValue("projectId");
				String versionId = "-1l";
				System.out.println("projectid: " + projectId);
				System.out.println("versionId: " +versionId);
			
				String	ex1=exeIds.get(0).toString();
		
				String	ex2=exeIds.get(1).toString();
		
				String[] executions = {ex1,ex2}	;	

	
		String payLoad = "{\"offset\":0,\"zql\":\"project = "+Config.getValue("projectKey")+" \"}";
		System.out.println("payload: " + payLoad);


		Response status_2 = zapiService.getExecutionsByZQL(jwtGenerator, ex1, payLoad);
		Assert.assertNotNull(status_2, "Get Executions By ZQL Api Response is null");
		test.log(LogStatus.PASS, "Get Executions By ZQL Api executed successfully.");
		System.out.println(status_2.getBody().asString());
			boolean status = zapiService.validateExecuteZQLSearch(payLoad, status_2);
				Assert.assertTrue(status);
				test.log(LogStatus.PASS, "Response validated successfully");
				extentReport.endTest(test);
	}

}