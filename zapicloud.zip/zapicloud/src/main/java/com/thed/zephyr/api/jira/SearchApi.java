/**
 * Created by manoj.behera on 03-Dec-2016.
 */
package com.thed.zephyr.api.jira;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;

/**
 * @author manoj.behera 03-Dec-2016
 *
 */
public interface SearchApi {

	/**
	 * @param basicAuth
	 * @param payLoad
	 * @return
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	Response searchRequest(RequestSpecification basicAuth, String payLoad);

	/**
	 * @param basicAuth
	 * @param jql
	 * @param startAt
	 * @param maxResults
	 * @return
	 * @author Created by manoj.behera on 27-Apr-2017.
	 */
	Response searchRequest(RequestSpecification basicAuth, String jql, int startAt, int maxResults);

	Response createFilterInSearchTest(RequestSpecification basicAuth, String payload);

	Response createIssueLink(RequestSpecification basicAuth, String payload);

	
	


}
