/**
 * Created by manoj.behera on 02-Dec-2016.
 */
package com.thed.zephyr.regression.zql;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 02-Dec-2016
 *
 */
public class GetZQLFieldValues extends BaseTest {
	JwtGenerator jwtGenerator = null;

	@BeforeClass
	public void beforeClass() {
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"),
				Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}

	@Test(priority = 2)
	public void getZQLFieldValues() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject json = new JSONObject();

		Response getAllProjectResponse = jiraService.getProjects(basicAuth, "20");
		Assert.assertNotNull(getAllProjectResponse, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(getAllProjectResponse.getBody().asString());
		JSONArray projectJsonArray = new JSONArray(getAllProjectResponse.getBody().asString());
		json.put("project", projectJsonArray);

		Response response = zapiService.getZQLFieldValues(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldValues(json, response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldValues Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getZQLFieldValues2() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject json = new JSONObject();

		Response getAllPriorities = jiraService.getPriorities(basicAuth);
		Assert.assertNotNull(getAllPriorities, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(getAllPriorities.getBody().asString());
		JSONArray projectJsonArray = new JSONArray(getAllPriorities.getBody().asString());
		json.put("priority", projectJsonArray);

		Response response = zapiService.getZQLFieldValues(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldValues(json, response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldValues Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

	@Test(priority = 2)
	public void getZQLFieldValues3() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");

		JSONObject json = new JSONObject();

		Response getAllPriorities = jiraService.getUsersFromPicker(basicAuth, "", 0, 50, false, null);
		Assert.assertNotNull(getAllPriorities, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(getAllPriorities.getBody().asString());
		JSONArray projectJsonArray = new JSONArray(getAllPriorities.getBody().asString());
		json.put("priority", projectJsonArray);

		Response response = zapiService.getZQLFieldValues(jwtGenerator);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		boolean status = zapiService.validateGetZQLFieldValues(json, response);
		Assert.assertTrue(status, "Not validated response of getZQLFieldValues Api");

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
}
