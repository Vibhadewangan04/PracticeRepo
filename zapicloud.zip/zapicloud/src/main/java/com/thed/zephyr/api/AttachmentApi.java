/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.api;

import com.jayway.restassured.response.Response;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public interface AttachmentApi {

	/**
	 * @param jwtGenerator
	 * @param projectId
	 * @param versionId
	 * @param issueId
	 * @param cycleId
	 * @param entityName
	 * @param entityId
	 * @param comment
	 * @param fileName
	 * @return
	 * @author Created by manoj.behera on 30-Nov-2016.
	 */
	Response addAttachment(JwtGenerator jwtGenerator, Long projectId, Long versionId, Long issueId, String cycleId,
			String entityName, String entityId, String comment, String fileName);
	/**
	 * @param jwtGenerator
	 * @param entityId
	 * @param projectId
	 * @param issueId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getExecutionAttachmentsList(JwtGenerator jwtGenerator, String stepResultId);
	/**
	 * @param jwtGenerator
	 * @param attachmentId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response getAttachmentThumbnail(JwtGenerator jwtGenerator, String attachmentId);
	/**
	 * @param jwtGenerator
	 * @param attachmentId
	 * @return Response
	 * @author Created by manoj.behera on 14-Nov-2016.
	 */
	Response deleteAttachment(JwtGenerator jwtGenerator, String attachmentId);
	/**
	 * @param jwtGenerator
	 * @param attachmentId
	 * @return
	 * @author Created by manoj.behera on 17-Nov-2016.
	 */
	Response getAttachmentImage(JwtGenerator jwtGenerator, String attachmentId);
	/**
	 * @param jwtGenerator
	 * @param executionId
	 * @return
	 * @author Created by manoj.behera on 01-Dec-2016.
	 */
	Response getStepResultAttachmentsList(JwtGenerator jwtGenerator, String executionId);
	
}
