/**
 * Created by manoj.behera on 14-Nov-2016.
 */
package com.thed.zephyr.regression.execution;

import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.model.Cycle;
import com.thed.zephyr.model.Execution;
import com.thed.zephyr.model.Teststep;
import com.thed.zephyr.model.jira.Issue;
import com.thed.zephyr.util.RestUtils;

/**
 * @author manoj.behera 14-Nov-2016
 *
 */
public class DeleteExecutionApi extends BaseTest{
	String cycleId = null;
	String issueKey = null;
	Long issueId = null;
	Long projectid=Long.parseLong(Config.getValue("projectId"));
	Long schVersionID=Long.parseLong(Config.getValue("versionTwoId"));
	Long unschversionID=Long.parseLong(Config.getValue("versionOneId"));
	String Cycleid=null;
	String Stepresultid=null;
	String stepentityName = "stepResult";
	String ExecutionentityName = "execution";
	
	JwtGenerator jwtGenerator = null;
	String cycleIdScheduledVersion = "-1";
	String cycleIdUnscheduledVersion = "-1";
	String cycleIdadhoc="-1";
	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
			
		Issue issuePayLoad = new Issue();
		//issuePayLoad.setProject(projectid);
		issuePayLoad.setProject(Config.getValue("projectId"));
		issuePayLoad.setIssuetype(Config.getValue("issueTypeTestId"));
		issuePayLoad.setSummary("test");
		issuePayLoad.setPriority("1");
		issuePayLoad.setReporter(Config.getValue("adminUserName"));

		Response response = jiraService.createIssue(basicAuth, issuePayLoad.toString());
		Assert.assertNotNull(response, "Create Issue Api Response is null.");
		System.err.println(response.getBody().asString());
		issueId = Long.parseLong(new JSONObject(response.body().asString()).getString("id"));
		//		
		boolean status = jiraService.validateCreateIssueApi(response);
		Assert.assertTrue(status, "Response Validation Failed.");
		
		Teststep teststepJson = new Teststep();
		teststepJson.setStep("stepValue");
		teststepJson.setData("dataValue");
		teststepJson.setResult("resultValue");
		System.out.println("payload-->"+ teststepJson.toString());
		Response createstepresponse = zapiService.createTeststep(jwtGenerator, projectid, issueId, teststepJson.toString());
		Assert.assertNotNull(createstepresponse, "Create Test Step Api Response is null.");		
		System.err.println(createstepresponse.getBody().asString());
		Stepresultid=new JSONObject(createstepresponse.body().asString()).get("id").toString();
		boolean createstepstatus = zapiService.validateTeststep(projectid, issueId, teststepJson.toString(),createstepresponse);
		Assert.assertTrue(createstepstatus);

		Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(schVersionID);
		cycleJson.setName("zephyr");

		System.out.println(cycleJson.toString());
		Response response1 = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		Assert.assertNotNull(response1, "Create Cycle Api Response is null.");
		System.out.println(response1.getBody().asString());
		boolean status1 = zapiService.validateCycle(cycleJson.toString(), response1);
		Assert.assertTrue(status1, "Response Validation Failed.");
		System.out.println(response1.getBody().asString());
		cycleIdScheduledVersion = new JSONObject(response1.body().asString()).get("id").toString();

		// Cycle cycleJson = new Cycle();
		cycleJson.setProjectId(projectid);
		cycleJson.setVersionId(unschversionID);
		cycleJson.setName("zephyr");

		System.out.println(cycleJson.toString());
		Response response2 = zapiService.createCycle(jwtGenerator, cycleJson.toString());
		System.out.println(response2.getBody().asString());
		cycleId=new JSONObject(response2.body().asString()).get("id").toString();
		Assert.assertNotNull(response2, "Create Cycle Api Response is null.");
		System.out.println(response2.getBody().asString());
		boolean status2 = zapiService.validateCycle(cycleJson.toString(), response2);
		Assert.assertTrue(status2, "Response Validation Failed.");
		cycleIdUnscheduledVersion = new JSONObject(response2.getBody().asString()).getString("id");
	}
	
//Deleting an execution from a cycle in a version
@Test(priority = 1, enabled = testEnabled)
	public void test1_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
        JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
        
	   // Adding Attachment at test level
        String Executionid=jsonChildObject.get("id").toString();
       
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

//Deleting execution from Adhoc cycle in version
@Test(priority = 2, enabled = testEnabled)
	public void test2_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(schVersionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
        JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
        
	   // Adding Attachment at test level
        String Executionid=jsonChildObject.get("id").toString();
        
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

//Deleting execution in Adhoc unscheduled
@Test(priority = 3, enabled = testEnabled)
	public void test3_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId("-1");
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
        JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
        
	   // Adding Attachment at test level
        String Executionid=jsonChildObject.get("id").toString();
        
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
//Deleting an execution in unscheduled version
@Test(priority = 4, enabled = testEnabled)
	public void test4_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdUnscheduledVersion);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
        JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
        
	   // Adding Attachment at test level
        String Executionid=jsonChildObject.get("id").toString();
       
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
		
	}
	
//Delete Execution from a cycle to a version if the status is changed to (PASS/FAIL/WIP/BLOCKED/CUSTOM)
//Create manually an execution with updated status
@Test(priority = 5, enabled = testEnabled)
	public void test5_1_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
        JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
        
	   // Adding Attachment at test level
        String Executionid=jsonChildObject.get("id").toString();
       
        //update Execution
        String payLoad = "{\"status\":{\"id\":1},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":10300}";
    	Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
    	System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
//Delete Execution from a cycle to a version if the status is changed to (PASS/FAIL/WIP/BLOCKED/CUSTOM)
//Create manually an execution with updated status
@Test(priority = 6, enabled = testEnabled)
	public void test5_2_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
      JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
      
	   // Adding Attachment at test level
      String Executionid=jsonChildObject.get("id").toString();
     
      //update Execution
      String payLoad = "{\"status\":{\"id\":2},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":10300}";
  	Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
  	System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

//Delete Execution from a cycle to a version if the status is changed to (PASS/FAIL/WIP/BLOCKED/CUSTOM)
//Create manually an execution with updated status
@Test(priority = 7, enabled = testEnabled)
	public void test5_3_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
    
	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();
   
		//update Execution
		String payLoad = "{\"status\":{\"id\":3},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":10300}";
		Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
		System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}

//Delete Execution from a cycle to a version if the status is changed to (PASS/FAIL/WIP/BLOCKED/CUSTOM)
//Create manually an execution with updated status
@Test(priority = 8, enabled = testEnabled)
	public void test5_4_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");
  
	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();
 
		//update Execution
		String payLoad = "{\"status\":{\"id\":4},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":10300}";
		Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
		System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
//Delete Execution from a cycle to a version if the status is changed to (PASS/FAIL/WIP/BLOCKED/CUSTOM)
//Create manually an execution with updated status
@Test(priority = 9, enabled = testEnabled)
public void test5_5_deleteExecution(){
	ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
	test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
	test.assignAuthor("Debadatta");
			
	Execution executionJson = new Execution();
	executionJson.setStatusId(-1l);
	executionJson.setProjectId(projectid);
	executionJson.setIssueId(issueId);
	executionJson.setCycleId(cycleIdadhoc);
	executionJson.setVersionId(unschversionID);
	System.err.println(executionJson.toString());
	Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
	System.err.println(response.getBody().asString());
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
	boolean status = zapiService.validateExecution(executionJson.toString(), response);
	Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
	test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
	//Getting Entity id
	JSONObject jsonObject = new JSONObject(response.getBody().asString());		
	JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

   // Adding Attachment at test level
	String Executionid=jsonChildObject.get("id").toString();

	//update Execution
	String payLoad = "{\"status\":{\"id\":5},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":10300}";
	Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
	System.err.println("update"+updateresponse.getBody().asString());
//	IssueId to be deleted		
	response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
	Assert.assertNotNull(response, "Create Execution Api Response is null.");
	test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
	System.out.println(response.getBody().asString());
	status = zapiService.validateDeletedExecution(Executionid,response);
	Assert.assertTrue(status, "Response Validation Failed.");
	test.log(LogStatus.PASS, "Response validated suuccessfully.");
	extentReport.endTest(test);
	
}
//Delete an execution from a cycle which has comments in the test level
//Manually add comments in the test level
@Test(priority = 10, enabled = testEnabled)
	public void test10_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();

		//update Execution
		String payLoad = "{\"status\":{\"id\":5},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":11409,\"comment\":\"comment added\"}";
		Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
		System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
	//Delete an execution from a cycle which has defects associated at the test level
	//Manually add defects at the test level
@Test(priority = 11, enabled = testEnabled)
	public void test11_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();

		//update Execution
		String payLoad = "{\"status\":{\"id\":5},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\",\"versionId\":11409,\"defects\":[\"10000\"]}";
		Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
		System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
	//Delete an execution from a cycle which has attachements associated at the test level
	//Manually add attachements at the test level
	@Test(priority = 12, enabled = testEnabled)
	public void test12_deleteExecution(){
		
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();
	    String comment = "addins";
	    String fileName = "attachment.png";  
	    
	    Response addattachmentresponse = zapiService.addAttachment(jwtGenerator, projectid,unschversionID, issueId,cycleIdadhoc, ExecutionentityName, Executionid, comment, fileName);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.err.println(addattachmentresponse.getBody().asString());

//		boolean addattachmentstatus = zapiService.validateCreatedAttachment(executionJson.toString(),Executionid, comment, fileName, addattachmentresponse);
//		Assert.assertTrue(addattachmentstatus, "Not validated added attachment");
		
		response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
				
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		
		extentReport.endTest(test);
		
	}
	
	//Delete an execution from a cycle which has comments, attachments and defects associated at the test level
	//Manually add comments, attachments and defects associated at the test level
	@Test(priority = 13, enabled = testEnabled)
	public void test13_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();

		//update Execution
		String payLoad = "{\"status\":{\"id\":5},\"id\":\""+Executionid+"\",\"projectId\":"+projectid+",\"issueId\":"+issueId+",\"cycleId\":\""+cycleIdadhoc+"\","
				+ "\"comment\":\"comment newly added\",\"defects\":[\"10000\"],\"assigneeType\":\"assignee\",\"assignee\":\"admin\",\"changeAssignee\":true}";
		Response updateresponse = zapiService.updateExecution(jwtGenerator, Executionid, payLoad);
		System.err.println("update"+updateresponse.getBody().asString());
//		IssueId to be deleted		
		/*response = zapiService.deleteExecution(jwtGenerator,issueId, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());
		status = zapiService.validateDeletedExecution(Executionid,response);
		Assert.assertTrue(status, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");*/
		extentReport.endTest(test);
		
	}

	//Invalid Issue Id
	@Test(priority = 14, enabled = testEnabled)
	public void test14_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();
		
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,123l, Executionid);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());		
		boolean status1 = zapiService.validateDeletedExecutionWithInvalidIsueId(response);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
	//Invalid execution id
	@Test(priority = 15, enabled = testEnabled)
	public void test15_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();
		
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,issueId, "123");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());		
		
		boolean status1 = zapiService.validateDeletedExecutionWithInvalidExecutionId(response);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
	//Invalid issueId and executionId
	@Test(priority = 16, enabled = testEnabled)
	public void test16_deleteExecution(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Debadatta");
				
		Execution executionJson = new Execution();
		executionJson.setStatusId(-1l);
		executionJson.setProjectId(projectid);
		executionJson.setIssueId(issueId);
		executionJson.setCycleId(cycleIdadhoc);
		executionJson.setVersionId(unschversionID);
		System.err.println(executionJson.toString());
		Response response = zapiService.createExecution(jwtGenerator, executionJson.toString());
		System.err.println(response.getBody().asString());
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Create Execution Api executed successfully.");
		boolean status = zapiService.validateExecution(executionJson.toString(), response);
		Assert.assertTrue(status, "Create Execution Api Response Validation Failed.");
		test.log(LogStatus.PASS, "Create Execution Api Response validated suuccessfully.");
		//Getting Entity id
		JSONObject jsonObject = new JSONObject(response.getBody().asString());		
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("execution");

	   // Adding Attachment at test level
		String Executionid=jsonChildObject.get("id").toString();
		
//		IssueId to be deleted		
		response = zapiService.deleteExecution(jwtGenerator,10000l, "123");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());		
		
		boolean status1 = zapiService.validateDeletedExecutionWithInvalidExecutionId(response);
		Assert.assertTrue(status1, "Response Validation Failed.");
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
		
	}
	
	/*
	 * Test cases need to be add for delete execution 
	 * 
	 * 1.need to add multiple defect
	 * 2.need to add multiple attachment
	 * 3.update execution code
	 * 4.all step result execution predefine and custom status(P/F/W/B/custom)
	 * 5.attachment at step single/multiple
	 * 6.comment at step level
	 * 7.edited comment at test/step level
	 * 8.deleting single/multiple attachment at test/step level
	 * 9.update Assignee
	 * 10.Test/step(P/F/W/B/custom) execution with comment
	 * 11.Test/step(P/F/W/B/custom) execution with attachment
	 * 12.Test/step(P/F/W/B/custom) execution with edited comment
	 * 13.Test/step(P/F/W/B/custom) execution with single deleted attachment
	 * 14.Test/step(P/F/W/B/custom) execution with multiple attachment and edited comment
	 * 15.Test/step(P/F/W/B/custom) execution with single attachment and edited comment
	 * 
	 
	
*/	
}
