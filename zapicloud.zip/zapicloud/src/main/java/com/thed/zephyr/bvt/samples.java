/**
 * Created by manoj.behera on 30-Jan-2017.
 */
package com.thed.zephyr.bvt;

import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;

/**
 * @author manoj.behera 30-Jan-2017
 *
 */
public class samples extends BaseTest{
	/**
	 * [{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10000","id":"10000","name":"v1","archived":false,"released":false,"projectId":10000},{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10001","id":"10001","name":"v2","archived":false,"released":false,"projectId":10000},{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10002","id":"10002","name":"v3","archived":false,"released":false,"projectId":10000},{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10003","id":"10003","name":"v4","archived":false,"released":false,"projectId":10000}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void getProjectVersions() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Response response = jiraService.getProjectVersions(basicAuth, "10000");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * [{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10000","id":"10000","name":"v1","archived":false,"released":false,"projectId":10000},{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10001","id":"10001","name":"v2","archived":false,"released":false,"projectId":10000},{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10002","id":"10002","name":"v3","archived":false,"released":false,"projectId":10000},{"self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/version/10003","id":"10003","name":"v4","archived":false,"released":false,"projectId":10000}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void getProjectComponents() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Response response = jiraService.getProjectComponents(basicAuth, "10000");
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * [{"expand":"description,lead,issueTypes,url,projectKeys","self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/project/10000","id":"10000","key":"SPAR","name":"Sparta","avatarUrls":{"48x48":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?avatarId=10324","24x24":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=small&avatarId=10324","16x16":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=xsmall&avatarId=10324","32x32":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=medium&avatarId=10324"},"projectTypeKey":"software"}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void getAllProjects() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Response response = jiraService.getAllProjects(basicAuth);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * [{"expand":"description,lead,issueTypes,url,projectKeys","self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/project/10000","id":"10000","key":"SPAR","name":"Sparta","avatarUrls":{"48x48":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?avatarId=10324","24x24":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=small&avatarId=10324","16x16":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=xsmall&avatarId=10324","32x32":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=medium&avatarId=10324"},"projectTypeKey":"software"}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void getAllProjectTypes() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		Response response = jiraService.getAllProjectTypes(basicAuth);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * [{"expand":"description,lead,issueTypes,url,projectKeys","self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/project/10000","id":"10000","key":"SPAR","name":"Sparta","avatarUrls":{"48x48":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?avatarId=10324","24x24":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=small&avatarId=10324","16x16":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=xsmall&avatarId=10324","32x32":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=medium&avatarId=10324"},"projectTypeKey":"software"}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void createVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		String versionPayLoad = "{\"name\": \"New Version \",\"project\": \"PXA\",\"projectId\": 10000}";
		Response response = jiraService.createVersion(basicAuth, versionPayLoad);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * [{"expand":"description,lead,issueTypes,url,projectKeys","self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/project/10000","id":"10000","key":"SPAR","name":"Sparta","avatarUrls":{"48x48":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?avatarId=10324","24x24":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=small&avatarId=10324","16x16":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=xsmall&avatarId=10324","32x32":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=medium&avatarId=10324"},"projectTypeKey":"software"}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void getVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		String versionId = "";
		Response response = jiraService.getVersion(basicAuth, versionId);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}
	/**
	 * [{"expand":"description,lead,issueTypes,url,projectKeys","self":"https://zfjcloud-211-qabench-performance6.atlassian.net/rest/api/2/project/10000","id":"10000","key":"SPAR","name":"Sparta","avatarUrls":{"48x48":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?avatarId=10324","24x24":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=small&avatarId=10324","16x16":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=xsmall&avatarId=10324","32x32":"https://zfjcloud-211-qabench-performance6.atlassian.net/secure/projectavatar?size=medium&avatarId=10324"},"projectTypeKey":"software"}]
	 * 
	 * @author Created by manoj.behera on 30-Jan-2017.
	 */
	@Test(priority = 2)
	public void deleteVersion() {
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API BVT Suite - ZFJCLOUD");
		test.assignAuthor("Manoj");
		
		String versionId = "";
		String moveFixIssuesTo = "";
		String moveAffectedIssuesTo = "";
		Response response = jiraService.deleteVersion(basicAuth, versionId, moveFixIssuesTo, moveAffectedIssuesTo);
		Assert.assertNotNull(response, "Create Execution Api Response is null.");
		test.log(LogStatus.PASS, "Update Cycle Api executed successfully.");
		System.out.println(response.getBody().asString());

		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
