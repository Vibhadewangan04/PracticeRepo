package com.thed.zephyr.regression.execution;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;
import com.thed.zephyr.cloud.rest.client.JwtGenerator;
import com.thed.zephyr.util.RestUtils;

/**
 * @author Soumyaranjan
 * 
 *
 */
public class GetExecutionStatuses extends BaseTest {
	
	JwtGenerator jwtGenerator = null;
	//Long issueId = null;
	//int offset = 0;
	//int size = 0;

	@BeforeClass
	public void beforeClass(){
		jwtGenerator = RestUtils.jwrGenerator(Config.getValue("zephyrBaseUrl"), Config.getValue("accessKey"), Config.getValue("secretKey"), Config.getValue("adminUserName"));
	}
	
	@Test(priority = 1, enabled = testEnabled)
	public void getExecutionStatuses(){
		ExtentTest test = extentReport.startTest(Thread.currentThread().getStackTrace()[1].getMethodName());
		test.assignCategory("Automation API Regression Suite - ZFJCLOUD");
		test.assignAuthor("Soumyaranjan");
		
		Response response = zapiService.getExecutionStatuses(jwtGenerator);
		Assert.assertNotNull(response, "Get Execution statuses Response is Null");
		test.log(LogStatus.PASS, "Get Execution statuses Api executed successfully.");
		System.out.println(response.getBody().asString());
		
		boolean status = zapiService.validateGetExecutionStatuses(response);
		Assert.assertTrue(status);
		
		test.log(LogStatus.PASS, "Response validated suuccessfully.");
		extentReport.endTest(test);
	}

}
