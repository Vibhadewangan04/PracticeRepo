package com.thed.zephyr.bvt;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.json.JSONArray;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.thed.zephyr.BaseTest;
import com.thed.zephyr.Config;



public class sprint  extends BaseTest{
	 
	@Test()
    public void test1()
    {
        String projectId=Config.getValue("projectId1");
        Response s =jiraService.getProjectBoard(basicAuth, projectId);
        System.out.println(s.getBody().asString());
        System.out.println(s.getBody().asString());
        JSONObject jsobj = new JSONObject(s.getBody().asString());
        String views = jsobj.get("views").toString();
        System.out.println(views);
       // String sprintname = jsobj.get("name").toString();
        JSONArray jsarray = new org.json.JSONArray(jsobj.get("views").toString());
        Long Boardid = null;
        for (int i = 0; i < jsarray.length(); i++) {        	
        	
        	//System.out.println(jsarray.get(i));
        	JSONObject ns = new JSONObject(jsarray.get(i).toString());
        	String parentProjectId=ns.get("parentProjectId").toString();
        
        	if(projectId.equals(parentProjectId))
        	{
        		Boardid=Long.parseLong(ns.get("id").toString());
        	}
		}
        System.out.println(Boardid);
        //create sprint
        String Sprintname="Sprint"+System.currentTimeMillis();
        String CreateSprintpayload="{\"name\": \""+Sprintname+"\",\"originBoardId\":"+Boardid+"}";
        Response sprintresponse =jiraService.createSprint(basicAuth, CreateSprintpayload);
        System.out.println(sprintresponse.getBody().asString());
        JSONObject sprint=new JSONObject(sprintresponse.getBody().asString());
        Long Sprintid =sprint.getLong("id");
        System.out.println("Sprintid"+Sprintid);
     
        
        //add issue to sprint
        String issueIdorKeys = Config.getValue("issueIdOrKeys");
        String addissuesprintpayload= "{\"issues\":["+issueIdorKeys+"]}";
     //  String addissuesprintpayload="{\"update\":{\"transition\":{\"id\":\"2\"}}}";
        System.out.println(addissuesprintpayload);
        Response addsprintresponse =jiraService.addissuetosprint(basicAuth, Sprintid, addissuesprintpayload);
        System.out.println(addsprintresponse.getBody().asString());
        System.out.println(addsprintresponse.getStatusCode());
        
        //get transitions
        
       Response getresponse=jiraService.getTransitions(basicAuth, issueIdorKeys);
       System.out.println(getresponse.getBody().asString()); 
       JSONObject jsobj1 = new JSONObject(getresponse.getBody().asString());
   
       System.out.println(jsobj1.get("transitions").toString());
       JSONArray js = new JSONArray(jsobj1.get("transitions").toString());
       System.out.println("array" + js.getJSONObject(0));
     
       JSONObject transition = new JSONObject(js.getJSONObject(2).toString());
       System.out.println("transition: " + js.getJSONObject(0).toString());
       String id=  transition.get("id").toString();
       System.out.println(transition.get("id").toString());
       System.out.println(getresponse.getStatusCode());
     
     /*JSONObject jsobj2 = new JSONObject(transition.getBody().asString());
      System.out.println("jsobj2: " + jsobj2);*/
       
      // JSONObject responseJson = new JSONObject(responseData);
     //  JSONArray json = new JSONArray(responseData.get("id").toString());

      // Assert.assertEquals( responseData.getJSONObject(0).getString("id"), "11");
       
       
     /*  String responseData = Cloneteststepresponse.getBody().asString();
       System.out.println(responseData);
       JSONArray responseJson = new JSONArray(responseData);
       JSONObject json = new JSONObject(responseJson.get(1).toString());

       String stepid2= json.get("id").toString();*/
       
       
       /*JSONObject  JS=new JSONObject (getresponse.body().asString());
       List<String> issueIds2= new ArrayList<>() ;
       JSONArray jsarray2 = new JSONArray(JS);
      // JSONArray jsarray1 = new org.json.JSONArray(JS.get("transitions").toString());
       System.out.println("ison response"+jsarray2);
       for(int i= 0;i<jsarray2.length();i++){
    	   JSONObject json = new JSONObject(jsarray2.get(i).toString());
			//JSONObject jsobj11 = new JSONObject(jsarray1.getst);
			Long l= Long.parseLong(json.get("id").toString());
			//issueIds2.add(l);
		}
		System.out.println("*****"+issueIds2);*/
		/*Long issueId2 = issueIds2.get(0);
		System.out.println(issueId2);
		Long issueId3=issueIds2.get(1);*/
		//convert long to string
	   // String issue3=	Long.toString(issueId2);
     // Long id= JS.getLong("id");
     // System.out.println(id);
     
      
        
        //edit issue
        Long projname=Long.parseLong(projectId);
       // String editissuepayload= "{\"id\":\"1\"}";
       String editissuepayload="{\"transition\":{\"id\":\""+id+"\"}}";
       
        System.out.println(editissuepayload);
        Response editresponse =jiraService.editissue(basicAuth, issueIdorKeys, editissuepayload);
        System.out.println(editresponse.getBody().asString());
        System.out.println("edit issue res"+editresponse.getStatusCode());
        
        //update sprint
        String updatesprintpayload="{\"state\":\"active\",\"name\":\""+Sprintname+"\",\"startDate\":\"2015-04-11T15:22:00.000+10:00\",\"endDate\":\"2015-04-20T01:22:00.000+10:00\"}";
        System.out.println(updatesprintpayload);
        Response updatesprintresponse= jiraService.updatesprint(basicAuth, Sprintid, updatesprintpayload);
        System.out.println(updatesprintresponse.getBody().asString());
        System.out.println(updatesprintresponse.getStatusCode());
        
        //delete sprint
        Response del=  jiraService.deletesprint(basicAuth, Sprintid);
      System.out.println(del.getBody().asString()); 
      System.out.println(del.getStatusCode());
      System.out.println("deleted ");
      
    }
	
	@Test()
    public void test2()
    {
		 
}
}