package grp.art;

public class ABC {
	
	
	static int i;   //run fine,  if remove statis gets compile time error
	static String s = "qwe";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("i:" +i);
		System.out.println("string:" +s);
		

	}

}


/*output
i:0
string:qwe
*/