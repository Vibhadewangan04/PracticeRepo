package grp.art;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;



public class Train {

	public static void main(String[] args) throws InterruptedException {



		//System.setProperty("webdriver.gecko.driver","../art/driversExe/geckodriver/geckodriver.exe"); 
		//WebDriver driver=new FirefoxDriver();


		System.setProperty("webdriver.chrome.driver", "../art/driversExe/chrome97/chromedriver.exe");
		WebDriver driver = new ChromeDriver();


		driver.navigate().to("https://www.irctc.co.in/nget/train");  // IRCTC Website URL
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(3,TimeUnit.SECONDS) ;

		ChromeOptions options = new ChromeOptions();
		options.addArguments("--disable-notifications");

		System.out.println("clicked on block popup");

		//	options.setExperimentalOption("excludeSwitches",
		//	     Arrays.asList("disable-popup-blocking"));

		driver.switchTo().alert().accept();

		System.out.println("clicked on accept");

		Select fromValue = new Select(driver.findElement(By.className("ng-tns-c58-8 ui-autocomplete ui-widget")));

		fromValue.selectByVisibleText("C SHIVAJI MAH T - CSTM");


		Select ToValue = new Select(driver.findElement(By.className("ng-tns-c58-9 ui-autocomplete ui-widget")));
		ToValue.selectByVisibleText("HOWRAH JN - HWH");

		Select BookingOption = new Select(driver.findElement(By.className("ui-dropdown-items-wrapper ng-tns-c66-12")));

		BookingOption.selectByVisibleText("TATKAL");
		
		Actions action = new Actions(driver);
		
		WebElement calender = driver.findElement(By.xpath("//span[@class='ng-tns-c59-10 ui-calendar']"));
		
		WebElement AvailableBerth = driver.findElement(By.xpath("//label[contains(text(),'Train with Available Berth')]"));
		
		action.moveToElement(calender).click().sendKeys("25/01/2022").moveToElement(AvailableBerth).click().perform();
		

		WebElement SearchButton = driver.findElement(By.xpath("//button[@class='search_btn train_Search']"));
		SearchButton.click();
		
		System.out.println("clicked on search button successfully");



		/* 
		 * 
		 *  
		 *  2. Use IRCTC url https://www.irctc.co.in/nget/train 
    search
   1. Fill From - "C SHIVAJI MAH T - CSTM"
                To - "HOWRAH JN - HWH"

   2. Select "TATKAL"

  3. Select Date 1month from Today's Date
  4. Select "AC 3 Tier (3A)"
  5. Select "Train with Available Berth"
  6. Click on Search   
		 */



	}
}
