package grp.art;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class TestNg {

	// keep test annotation to run with testNg, comment test annotation and uncomment main class to run without testNg(Java application)

	@Test
	public void test(){

		//	public static void main(String[] args) {

		 int i, j, k, row= 4, num=10;
	       
	        for( i=1; i<=row; i++) // for row
	            { 
	        	
	        	for (k=row; k>=i; k--)         
				{  
					System.out.print(" ");   
				}   
	            
	            for( j=1; j<=i; j++) //  inner loop for columns
	            { 
	               System.out.print(num+ "" );  
	               num--;
	            }   
	            	            
	         System.out.println(); // ending line after each row
	        } 

}
}