package grp.art;

/*public class Practice {

		public static void main(String args[]) 
		{ 
		     int num =1, row =4;
		     
		      for(int i=1; i<=row; i++) // for row
		          {           
		          
		          for(int j=1; j<=i; j++) //  inner loop for columns
		          {     
		          	
		              System.out.print(num+ " "); 
		              num++;
		          }   
		          
		          System.out.println(); // ending line after each row
		      } 
		}
		
}*/


/*public class Practice {

public static void main(String args[]) 
{ 
	
       int i, j, k, row= 4, num=10;
       
        for( i=1; i<=row; i++) // for row
            { 
        	
        	for (k=row; k>=i; k--)         
			{  
				System.out.print(" ");   
			}   
            
            for( j=1; j<=i; j++) //  inner loop for columns
            { 
               System.out.print(num+ "" );  
               num--;
            }   
            	            
         System.out.println(); // ending line after each row
        } 
    }
}
	
	*/






// prime number program

public class Practice {

	public static void main(String args[]) 
	{ 

		int i, m=0, flag=0;

		int n=61;

		m= n/2;

		if (n==0|n==1) {  
			flag = 1;
			System.out.println(n + " is not prime"); 

		} 



		else {
			for (i=2; i<=m; i++)
				if (n%i==0) 
				{
					System.out.println(n+ " is not prime");

					flag=1;
					break;	   
				}

		}	  

		if (flag==0) {
			System.out.println(n+ " is prime");
		}	              

	}  
}
	









