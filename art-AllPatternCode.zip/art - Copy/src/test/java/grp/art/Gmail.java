package grp.art;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;


public class Gmail {

	public static void main(String[] args) throws IOException, InterruptedException {

		//System.setProperty("webdriver.gecko.driver","../art/driversExe/geckodriver/geckodriver.exe"); 
		//WebDriver driver=new FirefoxDriver();


		System.setProperty("webdriver.chrome.driver", "../art/driversExe/chrome97/chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		Actions action = new Actions(driver);


		//login to gmail
		String url = "https://accounts.google.com/signin";
		driver.get(url);

		WebElement Username = driver.findElement(By.id("identifierId"));


		action.moveToElement(Username).sendKeys("usernameMailId").sendKeys(Keys.TAB).sendKeys(Keys.TAB).sendKeys(Keys.TAB).click()
		.sendKeys("password").perform();
		
		WebDriverWait wait=new WebDriverWait(driver, 20); 

		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Next']"))).click();

		//   WebElement Next = driver.findElement(By.xpath("//span[text()='Next']"));         
		//   Next.click();

		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);        

		driver.findElement(By.xpath("//input[@class='whsOnd zHQkBf']")).sendKeys("pswd");        

		driver.findElement(By.xpath("//span[text()='Next']")).click();


		//click on compose and add mail id and subject
		driver.findElement(By.xpath("//div[text()='COMPOSE']")).click();
		driver.findElement(By.name("to")).sendKeys("Id");
		driver.findElement(By.name("subjectbox")).sendKeys("SubjectLine");


		//click on attachment
		driver.findElement(By.xpath("//div[@class='a1 aaA aMZ']")).click();

		//using autoit 3rd party tool to attach a file
		Runtime.getRuntime().exec("C:\\selenium\\AutoIT\\fileUpload.exe");
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);   


		//click on send
		driver.findElement(By.xpath("//div[text()='Send']")).click();
		String msg = driver.findElement(By.xpath("//div[contains(text(),'Your message has been sent.')]")).getText();
		String expectedMsg  = "Your message has been sent. View message";
		Assert.assertEquals(msg, expectedMsg);
		System.out.println("Test is pass");
		driver.close();

	}  

}